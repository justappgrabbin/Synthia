import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Inference sessions — each session is a goal-driven reasoning conversation.
 */
export const sessions = mysqlTable("sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  goalName: varchar("goalName", { length: 255 }).notNull(),
  goalDescription: text("goalDescription"),
  status: mysqlEnum("status", ["active", "completed", "archived"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Session = typeof sessions.$inferSelect;
export type InsertSession = typeof sessions.$inferInsert;

/**
 * Messages in a session — user messages and AI responses.
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  reasoning: text("reasoning"), // AI's internal reasoning for this response
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

/**
 * Knowledge map — structured summary of what's been figured out in a session.
 */
export const knowledgeMap = mysqlTable("knowledgeMap", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  section: varchar("section", { length: 255 }).notNull(), // e.g., "Problem Definition", "Key Requirements", "Technical Approach"
  content: text("content").notNull(), // Markdown-formatted content
  order: int("order").default(0).notNull(), // For ordering sections
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type KnowledgeMapEntry = typeof knowledgeMap.$inferSelect;
export type InsertKnowledgeMapEntry = typeof knowledgeMap.$inferInsert;

/**
 * Final implementation plans — generated from completed sessions.
 */
export const plans = mysqlTable("plans", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(), // Markdown-formatted implementation plan
  generatedAt: timestamp("generatedAt").defaultNow().notNull(),
});

export type Plan = typeof plans.$inferSelect;
export type InsertPlan = typeof plans.$inferInsert;

// Relations
export const sessionsRelations = relations(sessions, ({ many }) => ({
  messages: many(messages),
  knowledgeMap: many(knowledgeMap),
  plans: many(plans),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  session: one(sessions, {
    fields: [messages.sessionId],
    references: [sessions.id],
  }),
}));

export const knowledgeMapRelations = relations(knowledgeMap, ({ one }) => ({
  session: one(sessions, {
    fields: [knowledgeMap.sessionId],
    references: [sessions.id],
  }),
}));

export const plansRelations = relations(plans, ({ one }) => ({
  session: one(sessions, {
    fields: [plans.sessionId],
    references: [sessions.id],
  }),
}));