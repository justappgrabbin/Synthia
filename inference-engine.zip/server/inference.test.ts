import { describe, it, expect, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import type { User } from "../drizzle/schema";

// Mock database functions
vi.mock("./db", () => ({
  getDb: vi.fn(),
  createSession: vi.fn(),
  getUserSessions: vi.fn(),
  getSessionById: vi.fn(),
  deleteSession: vi.fn(),
  addMessage: vi.fn(),
  getSessionMessages: vi.fn(),
  upsertKnowledgeMapSection: vi.fn(),
  getSessionKnowledgeMap: vi.fn(),
  createPlan: vi.fn(),
  getSessionPlan: vi.fn(),
  updateSessionStatus: vi.fn(),
}));

// Mock LLM
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn(() =>
    Promise.resolve({
      choices: [
        {
          message: {
            content: "Test response from AI",
          },
        },
      ],
    })
  ),
}));

function createMockContext(): TrpcContext {
  const user: User = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as TrpcContext["res"],
  };
}

describe("Inference Engine API", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("sessions router", () => {
    it("should create a new session", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const { createSession } = await import("./db");
      vi.mocked(createSession).mockResolvedValueOnce({
        insertId: 1,
        rowsAffected: 1,
      } as any);

      await caller.sessions.create({
        goalName: "Build a neural network",
        goalDescription: "Learn how to implement a basic neural network",
      });

      expect(createSession).toHaveBeenCalledWith(
        1,
        "Build a neural network",
        "Learn how to implement a basic neural network"
      );
    });

    it("should list user sessions", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const { getUserSessions } = await import("./db");
      const mockSessions = [
        {
          id: 1,
          userId: 1,
          goalName: "Build a neural network",
          goalDescription: "Learn how to implement a basic neural network",
          status: "active" as const,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];
      vi.mocked(getUserSessions).mockResolvedValueOnce(mockSessions);

      await caller.sessions.list();

      expect(getUserSessions).toHaveBeenCalledWith(1);
    });

    it("should delete a session", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const { deleteSession } = await import("./db");
      vi.mocked(deleteSession).mockResolvedValueOnce({});

      await caller.sessions.delete({ sessionId: 1 });

      expect(deleteSession).toHaveBeenCalledWith(1);
    });

    it("should rename a session", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const { getDb } = await import("./db");
      const mockDb = {
        update: vi.fn().mockReturnThis(),
        set: vi.fn().mockReturnThis(),
        where: vi.fn().mockResolvedValueOnce({}),
      };
      vi.mocked(getDb).mockResolvedValueOnce(mockDb);

      await caller.sessions.rename({
        sessionId: 1,
        goalName: "Updated Goal Name",
      });

      expect(getDb).toHaveBeenCalled();
    });
  });

  describe("chat router", () => {
    it("should send a message and get AI response", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const { addMessage, getSessionById, getSessionMessages, getSessionKnowledgeMap } =
        await import("./db");

      vi.mocked(getSessionById).mockResolvedValueOnce({
        id: 1,
        userId: 1,
        goalName: "Test Goal",
        goalDescription: "Test description",
        status: "active",
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      vi.mocked(getSessionMessages).mockResolvedValueOnce([]);
      vi.mocked(getSessionKnowledgeMap).mockResolvedValueOnce([]);
      vi.mocked(addMessage).mockResolvedValueOnce({});

      const result = await caller.chat.send({
        sessionId: 1,
        message: "How do I build a neural network?",
      });

      expect(result.aiResponse).toBe("Test response from AI");
    });
  });

  describe("plans router", () => {
    it("should generate a plan", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const { getSessionById, getSessionKnowledgeMap, getSessionMessages, createPlan, updateSessionStatus } =
        await import("./db");

      vi.mocked(getSessionById).mockResolvedValueOnce({
        id: 1,
        userId: 1,
        goalName: "Build a neural network",
        goalDescription: "Learn how to implement a basic neural network",
        status: "active",
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      vi.mocked(getSessionKnowledgeMap).mockResolvedValueOnce([]);
      vi.mocked(getSessionMessages).mockResolvedValueOnce([]);
      vi.mocked(createPlan).mockResolvedValueOnce({});
      vi.mocked(updateSessionStatus).mockResolvedValueOnce({});

      const result = await caller.plans.generate({ sessionId: 1 });

      expect(result.title).toContain("Implementation Plan");
    });
  });

  describe("auth router", () => {
    it("should return current user", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const user = await caller.auth.me();

      expect(user?.email).toBe("test@example.com");   });

    it("should logout user", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.auth.logout();

      expect(result.success).toBe(true);
    });
  });
});
