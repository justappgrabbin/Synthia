import { eq, desc, asc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, sessions, messages, knowledgeMap, plans } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Session queries
 */
export async function createSession(
  userId: number,
  goalName: string,
  goalDescription?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(sessions).values({
    userId,
    goalName,
    goalDescription,
    status: "active",
  });
  return result;
}

export async function getUserSessions(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(sessions)
    .where(eq(sessions.userId, userId))
    .orderBy(desc(sessions.updatedAt));
}

export async function getSessionById(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(sessions)
    .where(eq(sessions.id, sessionId))
    .limit(1);
  return result[0];
}

export async function updateSessionStatus(
  sessionId: number,
  status: "active" | "completed" | "archived"
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .update(sessions)
    .set({ status, updatedAt: new Date() })
    .where(eq(sessions.id, sessionId));
}

export async function deleteSession(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.delete(sessions).where(eq(sessions.id, sessionId));
}

/**
 * Message queries
 */
export async function addMessage(
  sessionId: number,
  role: "user" | "assistant",
  content: string,
  reasoning?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(messages).values({
    sessionId,
    role,
    content,
    reasoning,
  });
}

export async function getSessionMessages(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(messages)
    .where(eq(messages.sessionId, sessionId))
    .orderBy(asc(messages.createdAt));
}

/**
 * Knowledge map queries
 */
export async function upsertKnowledgeMapSection(
  sessionId: number,
  section: string,
  content: string,
  order: number = 0
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if section exists
  const existing = await db
    .select()
    .from(knowledgeMap)
    .where(
      and(
        eq(knowledgeMap.sessionId, sessionId),
        eq(knowledgeMap.section, section)
      )
    )
    .limit(1);

  if (existing.length > 0) {
    return db
      .update(knowledgeMap)
      .set({ content, updatedAt: new Date() })
      .where(eq(knowledgeMap.id, existing[0].id));
  } else {
    return db.insert(knowledgeMap).values({
      sessionId,
      section,
      content,
      order,
    });
  }
}

export async function getSessionKnowledgeMap(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(knowledgeMap)
    .where(eq(knowledgeMap.sessionId, sessionId))
    .orderBy(asc(knowledgeMap.order));
}

/**
 * Plan queries
 */
export async function createPlan(
  sessionId: number,
  title: string,
  content: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(plans).values({
    sessionId,
    title,
    content,
  });
}

export async function getSessionPlan(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(plans)
    .where(eq(plans.sessionId, sessionId))
    .orderBy(desc(plans.generatedAt))
    .limit(1);
  return result[0];
}
