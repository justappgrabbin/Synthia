import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  createSession,
  getUserSessions,
  getSessionById,
  deleteSession,
  addMessage,
  getSessionMessages,
  upsertKnowledgeMapSection,
  getSessionKnowledgeMap,
  createPlan,
  getSessionPlan,
  updateSessionStatus,
  getDb,
} from "./db";
import { invokeLLM } from "./_core/llm";
import { sessions } from "../drizzle/schema";
import { eq } from "drizzle-orm";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  sessions: router({
    create: protectedProcedure
      .input(z.object({ goalName: z.string().min(1), goalDescription: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const result = await createSession(
          ctx.user.id,
          input.goalName,
          input.goalDescription
        );
        return result;
      }),
    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserSessions(ctx.user.id);
    }),
    get: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        const session = await getSessionById(input.sessionId);
        const msgs = await getSessionMessages(input.sessionId);
        const knowledge = await getSessionKnowledgeMap(input.sessionId);
        return { session, messages: msgs, knowledgeMap: knowledge };
      }),
    delete: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .mutation(async ({ input }) => {
        return deleteSession(input.sessionId);
      }),
    rename: protectedProcedure
      .input(z.object({ sessionId: z.number(), goalName: z.string().min(1) }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        return db
          .update(sessions)
          .set({ goalName: input.goalName, updatedAt: new Date() })
          .where(eq(sessions.id, input.sessionId));
      }),
  }),
  chat: router({
    send: protectedProcedure
      .input(
        z.object({
          sessionId: z.number(),
          message: z.string().min(1),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Add user message
        await addMessage(input.sessionId, "user", input.message);

        // Generate AI response using LLM
        const sessionData = await getSessionById(input.sessionId);
        const conversationHistory = await getSessionMessages(input.sessionId);
        const knowledge = await getSessionKnowledgeMap(input.sessionId);

        // Build context for LLM
        const systemPrompt = `You are an AI reasoning assistant helping users achieve their goals. 
Goal: ${sessionData?.goalName}
Description: ${sessionData?.goalDescription || ""}

Current knowledge discovered:
${knowledge.map((k) => `## ${k.section}\n${k.content}`).join("\n\n")}

Your role:
1. Ask clarifying questions to understand the goal better
2. Break down complex problems into manageable sub-problems
3. Guide the user step-by-step through the reasoning process
4. Update the knowledge map with new insights
5. When ready, help generate a final implementation plan

Respond in a conversational, helpful tone. Be specific and actionable.`;

        const messages = [
          { role: "system" as const, content: systemPrompt },
          ...conversationHistory.map((m) => ({
            role: m.role as "user" | "assistant",
            content: m.content,
          })),
        ];

        // Call LLM
        const response = await invokeLLM({ messages });
        const msgContent = response.choices[0]?.message?.content;
        const aiContent =
          typeof msgContent === "string"
            ? msgContent
            : "I couldn't generate a response.";

        // Add AI response
        await addMessage(input.sessionId, "assistant", aiContent);

        // Extract and update knowledge map based on response
        // This is a simplified version - in production, you'd parse the response more intelligently
        const knowledgeUpdatePrompt = `Extract key insights from this conversation turn and suggest updates to the knowledge map.
User message: ${input.message}
AI response: ${aiContent}

Return JSON with format: {"section": "section name", "content": "markdown content", "order": 0}`;

        const knowledgeResponse = await invokeLLM({
          messages: [
            {
              role: "system",
              content:
                "You are a knowledge extraction assistant. Extract key insights and return valid JSON.",
            },
            { role: "user", content: knowledgeUpdatePrompt },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "knowledge_update",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  section: { type: "string" },
                  content: { type: "string" },
                  order: { type: "number" },
                },
                required: ["section", "content", "order"],
                additionalProperties: false,
              },
            },
          },
        });

        try {
          const knowledgeMsgContent = knowledgeResponse.choices[0]?.message?.content;
          const contentStr =
            typeof knowledgeMsgContent === "string" ? knowledgeMsgContent : "{}";
          const knowledgeData = JSON.parse(contentStr);
          if (knowledgeData.section && knowledgeData.content) {
            await upsertKnowledgeMapSection(
              input.sessionId,
              knowledgeData.section,
              knowledgeData.content,
              knowledgeData.order
            );
          }
        } catch (e) {
          // Silently fail knowledge extraction
        }

        return { aiResponse: aiContent };
      }),
  }),
  plans: router({
    generate: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .mutation(async ({ input }) => {
        const sessionData = await getSessionById(input.sessionId);
        const knowledge = await getSessionKnowledgeMap(input.sessionId);
        const msgs = await getSessionMessages(input.sessionId);

        const planPrompt = `Based on the following goal and discovered knowledge, generate a detailed, step-by-step implementation plan.

Goal: ${sessionData?.goalName}
Description: ${sessionData?.goalDescription}

Knowledge Discovered:
${knowledge.map((k) => `## ${k.section}\n${k.content}`).join("\n\n")}

Conversation Summary:
${msgs.slice(-10).map((m) => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`).join("\n")}

Generate a comprehensive, actionable implementation plan with clear steps, dependencies, and success criteria. Format as markdown.`;

        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content:
                "You are an expert at creating detailed implementation plans. Be specific, actionable, and thorough.",
            },
            { role: "user", content: planPrompt },
          ],
        });

        const planContentRaw = response.choices[0]?.message?.content;
        const planContent = typeof planContentRaw === "string" ? planContentRaw : "";
        const title = `Implementation Plan: ${sessionData?.goalName}`;

        await createPlan(input.sessionId, title, planContent);
        await updateSessionStatus(input.sessionId, "completed");

        return { title, content: planContent };
      }),
    get: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return getSessionPlan(input.sessionId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
