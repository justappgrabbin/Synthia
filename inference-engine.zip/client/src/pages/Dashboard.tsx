import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Loader2, Plus, Trash2, Menu, X, Send, BookOpen } from "lucide-react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

export default function Dashboard() {
  const { sessionId: paramSessionId } = useParams<{ sessionId?: string }>();
  const [, setLocation] = useLocation();
  const { user } = useAuth();

  // State
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeSessionId, setActiveSessionId] = useState<number | null>(
    paramSessionId ? parseInt(paramSessionId) : null
  );
  const [newGoalName, setNewGoalName] = useState("");
  const [newGoalDesc, setNewGoalDesc] = useState("");
  const [showNewGoalForm, setShowNewGoalForm] = useState(false);
  const [messageInput, setMessageInput] = useState("");
  const [showPlanView, setShowPlanView] = useState(false);

  // API calls
  const sessionsQuery = trpc.sessions.list.useQuery();
  const sessionDataQuery = trpc.sessions.get.useQuery(
    { sessionId: activeSessionId || 0 },
    { enabled: !!activeSessionId }
  );
  const createSessionMutation = trpc.sessions.create.useMutation();
  const deleteSessionMutation = trpc.sessions.delete.useMutation();
  const sendMessageMutation = trpc.chat.send.useMutation();
  const generatePlanMutation = trpc.plans.generate.useMutation();
  const getPlanQuery = trpc.plans.get.useQuery(
    { sessionId: activeSessionId || 0 },
    { enabled: !!activeSessionId && showPlanView }
  );

  // Handle create new goal
  const handleCreateGoal = async () => {
    if (!newGoalName.trim()) {
      toast.error("Please enter a goal name");
      return;
    }
    try {
      await createSessionMutation.mutateAsync({
        goalName: newGoalName,
        goalDescription: newGoalDesc,
      });
      setNewGoalName("");
      setNewGoalDesc("");
      setShowNewGoalForm(false);
      await sessionsQuery.refetch();
      toast.success("Goal created!");
    } catch (error) {
      toast.error("Failed to create goal");
    }
  };

  // Handle delete session
  const handleDeleteSession = async (id: number) => {
    if (!confirm("Delete this goal session?")) return;
    try {
      await deleteSessionMutation.mutateAsync({ sessionId: id });
      if (activeSessionId === id) {
        setActiveSessionId(null);
      }
      await sessionsQuery.refetch();
      toast.success("Goal deleted");
    } catch (error) {
      toast.error("Failed to delete goal");
    }
  };

  // Handle send message
  const handleSendMessage = async () => {
    if (!messageInput.trim() || !activeSessionId) return;
    try {
      await sendMessageMutation.mutateAsync({
        sessionId: activeSessionId,
        message: messageInput,
      });
      setMessageInput("");
      await sessionDataQuery.refetch();
      toast.success("Message sent!");
    } catch (error) {
      toast.error("Failed to send message");
    }
  };

  // Handle generate plan
  const handleGeneratePlan = async () => {
    if (!activeSessionId) return;
    try {
      await generatePlanMutation.mutateAsync({ sessionId: activeSessionId });
      await getPlanQuery.refetch();
      setShowPlanView(true);
      toast.success("Plan generated!");
    } catch (error) {
      toast.error("Failed to generate plan");
    }
  };

  const sessions = sessionsQuery.data || [];
  const currentSession = sessionDataQuery.data?.session;
  const messages = sessionDataQuery.data?.messages || [];
  const knowledgeMap = sessionDataQuery.data?.knowledgeMap || [];
  const plan = getPlanQuery.data;

  return (
    <div className="flex flex-col h-screen bg-background md:flex-row">
      {/* Sidebar - Phone-first: overlay on mobile, fixed on desktop */}
      <div
        className={`fixed inset-0 z-40 bg-black/50 md:hidden ${
          sidebarOpen ? "block" : "hidden"
        }`}
        onClick={() => setSidebarOpen(false)}
      />

      <aside
        className={`fixed left-0 top-0 bottom-0 w-64 bg-card border-r border-border z-50 transform transition-transform md:relative md:translate-x-0 md:z-auto ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar header */}
          <div className="p-4 border-b border-border">
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-xl font-bold text-foreground">Inference</h1>
              <button
                onClick={() => setSidebarOpen(false)}
                className="md:hidden"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <Button
              onClick={() => {
                setShowNewGoalForm(true);
                setSidebarOpen(false);
              }}
              className="w-full"
              size="sm"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Goal
            </Button>
          </div>

          {/* Sessions list */}
          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {sessionsQuery.isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
              </div>
            ) : sessions.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                No goals yet. Create one to start!
              </p>
            ) : (
              sessions.map((session) => (
                <div
                  key={session.id}
                  className={`p-3 rounded-lg cursor-pointer transition-colors ${
                    activeSessionId === session.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted hover:bg-muted/80 text-foreground"
                  }`}
                >
                  <div
                    onClick={() => {
                      setActiveSessionId(session.id);
                      setSidebarOpen(false);
                      setShowPlanView(false);
                    }}
                    className="flex-1"
                  >
                    <p className="font-medium text-sm truncate">
                      {session.goalName}
                    </p>
                    <p className="text-xs opacity-75 truncate">
                      {session.goalDescription || "No description"}
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteSession(session.id);
                    }}
                    className="text-xs opacity-50 hover:opacity-100 mt-2"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar - Mobile menu button */}
        <div className="md:hidden flex items-center justify-between p-4 border-b border-border bg-card">
          <button onClick={() => setSidebarOpen(true)}>
            <Menu className="w-6 h-6" />
          </button>
          <h2 className="text-lg font-semibold text-foreground truncate">
            {currentSession?.goalName || "Select a goal"}
          </h2>
          <div className="w-6" />
        </div>

        {/* Content area */}
        {!activeSessionId ? (
          <div className="flex-1 flex items-center justify-center p-4">
            <div className="text-center">
              <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h2 className="text-2xl font-bold text-foreground mb-2">
                Welcome to Inference Engine
              </h2>
              <p className="text-muted-foreground mb-6">
                Create a new goal or select one from the sidebar to get started
              </p>
              <Button onClick={() => setShowNewGoalForm(true)} size="lg">
                <Plus className="w-5 h-5 mr-2" />
                Create Your First Goal
              </Button>
            </div>
          </div>
        ) : showPlanView && plan ? (
          /* Plan view */
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="p-4 border-b border-border bg-card">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-foreground">
                  {plan.title}
                </h2>
                <Button
                  onClick={() => setShowPlanView(false)}
                  variant="outline"
                  size="sm"
                >
                  Back to Chat
                </Button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              <Card className="p-6">
                <Streamdown>{plan.content}</Streamdown>
              </Card>
            </div>
            <div className="p-4 border-t border-border bg-card">
              <Button
                onClick={() => {
                  navigator.clipboard.writeText(plan.content);
                  toast.success("Plan copied to clipboard!");
                }}
                className="w-full"
              >
                Copy Plan
              </Button>
            </div>
          </div>
        ) : (
          /* Chat view */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Messages area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center text-muted-foreground">
                    <p className="mb-2">Start the conversation</p>
                    <p className="text-sm">
                      Tell me about your goal and I'll help you figure it out
                    </p>
                  </div>
                </div>
              ) : (
                messages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex ${
                      msg.role === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-3 rounded-lg ${
                        msg.role === "user"
                          ? "bg-primary text-primary-foreground rounded-br-none"
                          : "bg-muted text-foreground rounded-bl-none"
                      }`}
                    >
                      <Streamdown>{msg.content}</Streamdown>
                    </div>
                  </div>
                ))
              )}
              {sendMessageMutation.isPending && (
                <div className="flex justify-start">
                  <div className="bg-muted text-foreground px-4 py-3 rounded-lg rounded-bl-none">
                    <Loader2 className="w-5 h-5 animate-spin" />
                  </div>
                </div>
              )}
            </div>

            {/* Knowledge map panel - visible on larger screens */}
            {knowledgeMap.length > 0 && (
              <div className="hidden lg:block border-l border-border bg-muted/30 w-80 overflow-y-auto p-4">
                <h3 className="font-bold text-foreground mb-4">
                  Knowledge Map
                </h3>
                <div className="space-y-4">
                  {knowledgeMap.map((entry, idx) => (
                    <div key={idx} className="space-y-2">
                      <h4 className="font-semibold text-sm text-foreground">
                        {entry.section}
                      </h4>
                      <div className="text-xs text-muted-foreground">
                        <Streamdown>{entry.content}</Streamdown>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Input area */}
            <div className="p-4 border-t border-border bg-card space-y-3">
              {knowledgeMap.length > 0 && (
                <div className="md:hidden bg-muted/30 p-3 rounded-lg max-h-32 overflow-y-auto">
                  <p className="text-xs font-semibold text-foreground mb-2">
                    Knowledge Map
                  </p>
                  <div className="space-y-2">
                    {knowledgeMap.slice(0, 2).map((entry, idx) => (
                      <div key={idx} className="text-xs text-muted-foreground">
                        <p className="font-medium">{entry.section}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              <div className="flex gap-2">
                <Input
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  placeholder="Type your message..."
                  disabled={sendMessageMutation.isPending}
                  className="flex-1 text-base"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={
                    !messageInput.trim() || sendMessageMutation.isPending
                  }
                  size="icon"
                >
                  <Send className="w-5 h-5" />
                </Button>
              </div>
              <Button
                onClick={handleGeneratePlan}
                disabled={generatePlanMutation.isPending || messages.length < 2}
                className="w-full"
                variant="outline"
              >
                {generatePlanMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  "Generate Implementation Plan"
                )}
              </Button>
            </div>
          </div>
        )}
      </main>

      {/* New goal modal */}
      {showNewGoalForm && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/50">
          <Card className="w-full md:w-96 rounded-t-2xl md:rounded-2xl p-6 space-y-4">
            <h2 className="text-2xl font-bold text-foreground">Create New Goal</h2>
            <Input
              placeholder="Goal name (e.g., Build a neural network)"
              value={newGoalName}
              onChange={(e) => setNewGoalName(e.target.value)}
              className="text-base"
            />
            <Input
              placeholder="Description (optional)"
              value={newGoalDesc}
              onChange={(e) => setNewGoalDesc(e.target.value)}
              className="text-base"
            />
            <div className="flex gap-2">
              <Button
                onClick={() => {
                  setShowNewGoalForm(false);
                  setNewGoalName("");
                  setNewGoalDesc("");
                }}
                variant="outline"
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateGoal}
                disabled={createSessionMutation.isPending}
                className="flex-1"
              >
                {createSessionMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : null}
                Create
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
