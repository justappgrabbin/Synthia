import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { Brain, Zap, BookOpen, ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20 flex flex-col">
      {/* Navigation */}
      <nav className="px-4 py-6 md:px-8 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Brain className="w-7 h-7 text-primary" />
          <span className="text-xl font-bold text-foreground">Inference</span>
        </div>
        <Button asChild>
          <a href={getLoginUrl()}>Sign In</a>
        </Button>
      </nav>

      {/* Hero section */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-12 md:py-0">
        <div className="max-w-2xl text-center space-y-8">
          {/* Headline */}
          <div className="space-y-4">
            <h1 className="text-4xl md:text-6xl font-bold text-foreground leading-tight">
              Think Through Your Goals
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground">
              An AI reasoning assistant that walks you step-by-step through any goal, asks clarifying questions, and builds a complete implementation plan.
            </p>
          </div>

          {/* CTA Button */}
          <div className="flex gap-4 justify-center flex-col sm:flex-row">
            <Button asChild size="lg" className="text-base h-12">
              <a href={getLoginUrl()}>
                Get Started
                <ArrowRight className="w-5 h-5 ml-2" />
              </a>
            </Button>
            <Button asChild variant="outline" size="lg" className="text-base h-12">
              <a href="#features">Learn More</a>
            </Button>
          </div>

          {/* Trust badges */}
          <div className="text-sm text-muted-foreground">
            <p>No credit card required • Free to start</p>
          </div>
        </div>
      </div>

      {/* Features section */}
      <section id="features" className="px-4 py-16 md:px-8 md:py-24 bg-card/50 border-t border-border">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground text-center mb-4">
            How It Works
          </h2>
          <p className="text-center text-muted-foreground mb-12 md:mb-16">
            Structured reasoning for complex problems
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Brain className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">
                Conversational Reasoning
              </h3>
              <p className="text-muted-foreground">
                Have a natural conversation with an AI that asks clarifying questions and breaks down complex goals into manageable steps.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">
                Knowledge Map
              </h3>
              <p className="text-muted-foreground">
                Watch your understanding grow in real-time as the AI builds a structured knowledge map of everything you've figured out.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">
                Implementation Plans
              </h3>
              <p className="text-muted-foreground">
                Get a detailed, step-by-step implementation plan tailored to your specific goal and context.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-4 py-16 md:px-8 md:py-24">
        <div className="max-w-2xl mx-auto text-center space-y-8">
          <div className="space-y-4">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              Ready to Think Clearly?
            </h2>
            <p className="text-lg text-muted-foreground">
              Start your first goal session and see how structured reasoning can help you achieve your objectives.
            </p>
          </div>
          <Button asChild size="lg" className="text-base h-12">
            <a href={getLoginUrl()}>
              Start Now
              <ArrowRight className="w-5 h-5 ml-2" />
            </a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-4 py-8 md:px-8 border-t border-border text-center text-sm text-muted-foreground">
        <p>Built with care for clear thinking</p>
      </footer>
    </div>
  );
}
