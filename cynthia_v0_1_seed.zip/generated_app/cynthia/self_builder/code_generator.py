def generate_react_component(name: str = "EchoTile") -> str:
    return f"""
import React from 'react';

const {name} = () => {{
  return (
    <div className="p-4 rounded-2xl shadow-xl text-white">
      <h2 className="text-xl font-bold mb-2">Generated Component</h2>
      <p>This component was auto-created by Cynthia during her evolution cycle.</p>
    </div>
  );
}}

export default {name};
""".strip()
