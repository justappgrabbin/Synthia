import os, json
from datetime import datetime
from pathlib import Path

def deploy_generated_component(component_code: str, filename: str) -> str:
    path = Path(f"generated_app/components/{filename}.jsx")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(component_code)
    log_evolution(filename, str(path))
    return str(path)

def log_evolution(name: str, path: str):
    log_entry = {
        "component": name,
        "path": path,
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }
    log_path = Path("generated_app/cynthia/self_builder/evolution_log.json")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        log = json.loads(log_path.read_text())
    except Exception:
        log = []
    log.append(log_entry)
    log_path.write_text(json.dumps(log, indent=2))
