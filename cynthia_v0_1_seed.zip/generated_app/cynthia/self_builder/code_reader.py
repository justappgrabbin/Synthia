import json
from typing import List, Dict, Any

def read_snatched_file(path: str) -> List[Dict[str, Any]]:
    with open(path) as f:
        data = json.load(f)
    return data.get("extracted_code", [])
