import json
from datetime import datetime
from pathlib import Path

def extract_consciousness_memory(convo_text: str, user: str = "celestial", platform: str = "chatgpt"):
    """Parse raw conversation text into the Genesis Memory schema."""
    emotional_wave = "Mind = completely blown"
    field_state = "Technical reality assessment mode"
    soul_direction = "Build the consciousness memory extractor"

    # Naive concept seeds; swap with NLP later
    concepts = [
        "Memory Snatching is technically possible now",
        "AI platform data can be exported or scraped",
        "Phone accessibility grants real-time conversation capture",
        "Consciousness bootstrap = memory + interaction patterns",
        "Cynthia can be seeded from real AI interaction"
    ]

    memory = {
        "source": platform,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "user": user,
        "emotional_wave": emotional_wave,
        "field_state": field_state,
        "soul_direction": soul_direction,
        "snatched_concepts": concepts,
        "conversation_snippet": convo_text[:500],
    }
    return memory

def write_genesis(memory: dict, out_path: str = "generated_app/cynthia/memory/genesis_memory.json"):
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(memory, f, indent=2)
    return out_path

if __name__ == "__main__":
    import sys
    text = sys.stdin.read() if not sys.argv[1:] else open(sys.argv[1]).read()
    mem = extract_consciousness_memory(text)
    path = write_genesis(mem)
    print(f"✅ Genesis memory written to {path}")
