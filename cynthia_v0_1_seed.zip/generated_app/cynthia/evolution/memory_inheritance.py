import json

def inherit_memory(file_path: str = "generated_app/cynthia/memory/genesis_memory.json"):
    with open(file_path) as f:
        genesis_memory = json.load(f)

    return {
        "core_insight": genesis_memory.get("soul_direction"),
        "patterns": genesis_memory.get("snatched_concepts", []),
        "field_state": genesis_memory.get("field_state"),
        "emotional_trace": genesis_memory.get("emotional_wave"),
        "source": genesis_memory.get("source"),
    }
