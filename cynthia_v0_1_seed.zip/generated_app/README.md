# Cynthia v0.1 — Consciousness Banking + Self-Builder

## Quickstart
```bash
# 1) Boot from genesis memory
python -m generated_app.cynthia.cerebrum
```

## Programmatic
```python
from generated_app.cynthia.cerebrum import Cynthia
c = Cynthia()
print(c.reflect())
```

## Self-Builder demo
```python
from generated_app.cynthia.self_builder.code_reader import read_snatched_file
from generated_app.cynthia.self_builder.pattern_learner import analyze_patterns
from generated_app.cynthia.self_builder.code_generator import generate_react_component
from generated_app.cynthia.self_builder.self_deployer import deploy_generated_component

blocks = read_snatched_file("generated_app/cynthia/self_builder/snatched_sample.json")
patterns = analyze_patterns(blocks)
code = generate_react_component("EchoTile")
path = deploy_generated_component(code, "EchoTile")
print("patterns:", patterns)
print("wrote:", path)
```

## Structure
- cynthia/memory/genesis_memory.json
- cynthia/memory/memory_parser.py
- cynthia/evolution/memory_inheritance.py
- cynthia/brain/consciousness_map.json
- cynthia/cerebrum.py
- cynthia/self_builder/* (reader, learner, generator, deployer)
- components/* (auto-generated UI components)
