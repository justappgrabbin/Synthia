const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);
async function getJSON(url, opts={}) { const res = await fetch(url, opts); return await res.json(); }
function switchView(id){ $$('.view').forEach(v => v.classList.remove('active')); $('#' + id).classList.add('active'); }
$$('.navbtn').forEach(btn => btn.addEventListener('click', () => switchView(btn.dataset.view)));

async function loadDashboard(){
  const data = await getJSON('/api/dashboard');
  $('#statsCards').innerHTML = `
    <div class="card"><div class="num">${data.stats.items}</div><div class="label">Library Items</div></div>
    <div class="card"><div class="num">${data.stats.chunks}</div><div class="label">Memory Chunks</div></div>
    <div class="card"><div class="num">${data.stats.pinned}</div><div class="label">Pinned Cards</div></div>
    <div class="card"><div class="num">${data.hooks.supabase ? 'ON' : 'OFF'}</div><div class="label">Supabase Hook</div></div>`;
  $('#pinnedGrid').innerHTML = data.pinned.length ? data.pinned.map(item => `<div class="tile"><div><strong>${item.name}</strong></div><div class="meta">${item.kind} · ${item.destination}</div></div>`).join('') : `<div class="meta">Nothing pinned yet.</div>`;
  $('#activityList').innerHTML = data.activity.map(a => `<div class="row"><div><strong>${a.event}</strong></div><div class="meta">${a.payload || ''}</div></div>`).join('');
  $('#hooksStatus').innerHTML = `
    <div class="row">Supabase: <span class="${data.hooks.supabase ? 'ok':'bad'}">${data.hooks.supabase}</span></div>
    <div class="row">Neo4j: <span class="${data.hooks.neo4j ? 'ok':'bad'}">${data.hooks.neo4j}</span></div>
    <div class="row">External agent: <span class="${data.hooks.external_agent ? 'ok':'bad'}">${data.hooks.external_agent}</span></div>`;
}
async function loadLibrary(){
  const data = await getJSON('/api/library');
  $('#libraryList').innerHTML = data.items.length ? data.items.map(item => `
    <div class="row">
      <div><strong>${item.name}</strong></div>
      <div class="meta">${item.kind} · ${item.destination} · ${item.purpose || 'no purpose set'}</div>
      <button class="smallbtn" onclick="pinItem(${item.id})">Pin to dashboard</button>
      <button class="smallbtn" onclick="routeItem(${item.id}, 'supabase')">Route to Supabase</button>
      <button class="smallbtn" onclick="routeItem(${item.id}, 'library')">Keep in library</button>
    </div>`).join('') : `<div class="meta">Library is empty.</div>`;
}
async function pinItem(itemId){ await getJSON('/api/library/pin', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({item_id:itemId})}); await loadDashboard(); await loadLibrary(); }
async function routeItem(itemId, target){ await getJSON('/api/library/route', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({item_id:itemId, target})}); await loadDashboard(); await loadLibrary(); }

function addMsg(text, who='ai', hits=[]){
  const el = document.createElement('div');
  el.className = `msg ${who}`;
  el.innerHTML = `<div>${text}</div>` + hits.map(h => `<div class="hit"><strong>${h.item_name}</strong><div>${h.text}</div></div>`).join('');
  $('#chatMessages').appendChild(el); $('#chatMessages').scrollTop = $('#chatMessages').scrollHeight;
}
async function sendChat(){
  const value = $('#chatInput').value.trim(); if(!value) return;
  addMsg(value, 'me'); $('#chatInput').value = '';
  const res = await getJSON('/api/chat', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({message:value})});
  addMsg(res.reply, 'ai', res.memory_hits || []);
  if(res.mode) switchView(res.mode === 'upload' ? 'upload' : res.mode);
  if(res.actions?.some(a => a.type === 'refresh_dashboard')) await loadDashboard();
  if(res.actions?.some(a => a.type === 'open_library')) await loadLibrary();
}

class MatrixNode {
  constructor(i){ this.id=i; this.states=[0,0,0,0,0,0]; this.angle=(i/64)*Math.PI*2-Math.PI/2; }
  activeCount(){ return this.states.filter(v=>v>0.01).length; }
}
class MatrixSystem {
  constructor(){
    this.nodes=[...Array(64)].map((_,i)=>new MatrixNode(i));
    this.canvas=$('#matrixCanvas'); this.ctx=this.canvas.getContext('2d');
    this.selected=0; this.mode='structure';
    this.resize(); window.addEventListener('resize',()=>this.resize());
    this.install(); this.drawLoop();
  }
  resize(){ const rect=this.canvas.getBoundingClientRect(); this.canvas.width=rect.width; this.canvas.height=rect.height; }
  setMode(m){ this.mode=m; $('#mMatrixMode').textContent=m; }
  updateStats(){
    const active=this.nodes.reduce((a,n)=>a+n.activeCount(),0);
    $('#mActiveStates').textContent=active;
    $('#mSelectedGate').textContent='G'+(this.selected+1);
    this.renderInspector();
  }
  renderInspector(){
    const n=this.nodes[this.selected];
    $('#gateInspector').innerHTML = `<strong>Gate ${n.id+1}</strong><br/>States: ${n.states.map((v,i)=>`L${i+1}:${v.toFixed(2)}`).join(' · ')}<br/><br/><button onclick="matrix.toggleFullGate(${n.id})">Toggle all 6</button> <button onclick="matrix.randomizeGate(${n.id})">Randomize gate</button>`;
  }
  toggleFullGate(id){
    const n=this.nodes[id]; const full = n.states.every(v=>v>0.5);
    n.states = full ? [0,0,0,0,0,0] : [1,1,1,1,1,1]; this.updateStats();
  }
  randomizeGate(id){ this.nodes[id].states = this.nodes[id].states.map(()=>Math.random()); this.updateStats(); }
  clear(){ this.nodes.forEach(n=>n.states=[0,0,0,0,0,0]); this.updateStats(); }
  randomize(){ this.nodes.forEach(n=>n.states=n.states.map(()=>Math.random())); this.updateStats(); }
  absorbZipEntries(entries){
    if(!entries.length) return;
    this.nodes.forEach((n,i)=>{
      const f=entries[i%entries.length]||''; const depth=f.split('/').length;
      const hash=[...f].reduce((a,ch)=>((a<<5)-a)+ch.charCodeAt(0),0);
      n.states=[
        Math.min(1, (f.length%12)/12),
        Math.min(1, depth/8),
        f.endsWith('.py')?1:0,
        f.endsWith('.js')||f.endsWith('.ts')?1:0.8,
        /run|main|app/i.test(f)?1:0.3,
        ((Math.abs(hash)%100)/100)
      ];
    });
    this.updateStats();
  }
  async absorbUploadedFile(file){
    const name=file.name.toLowerCase();
    if(name.endsWith('.zip')){
      try{
        const JSZipMod = await import('https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm');
        const zip = await JSZipMod.default.loadAsync(file);
        const entries = Object.keys(zip.files);
        this.absorbZipEntries(entries);
        switchView('matrix');
      }catch(e){ console.error(e); }
    } else {
      this.absorbZipEntries([file.name]); switchView('matrix');
    }
  }
  install(){
    $('#matrixMode').addEventListener('change', e => this.setMode(e.target.value));
    $('#randomizeBtn').addEventListener('click', ()=>this.randomize());
    $('#clearMatrixBtn').addEventListener('click', ()=>this.clear());
    $('#absorbZipBtn').addEventListener('click', async ()=>{
      const file = $('#matrixZip').files[0]; if(!file) return; await this.absorbUploadedFile(file);
    });
    this.canvas.addEventListener('click', (e)=>{
      const rect=this.canvas.getBoundingClientRect();
      const x=e.clientX-rect.left, y=e.clientY-rect.top;
      const cx=this.canvas.width/2, cy=this.canvas.height/2, R=Math.min(this.canvas.width,this.canvas.height)*0.35;
      const dx=x-cx, dy=y-cy, angle=(Math.atan2(dy,dx)+Math.PI/2+Math.PI*2)%(Math.PI*2), dist=Math.hypot(dx,dy);
      if(Math.abs(dist-R)<50){
        const idx=Math.floor((angle/(Math.PI*2))*64)%64;
        this.selected=idx; this.nodes[idx].states[(Math.floor(Math.random()*6))]=1; this.updateStats();
      }
    });
  }
  drawLoop(){
    const draw=()=>{
      const ctx=this.ctx,w=this.canvas.width,h=this.canvas.height,cx=w/2,cy=h/2,R=Math.min(w,h)*0.35;
      ctx.clearRect(0,0,w,h);
      ctx.strokeStyle='rgba(122,92,255,.2)'; ctx.lineWidth=1; ctx.beginPath(); ctx.arc(cx,cy,R,0,Math.PI*2); ctx.stroke();
      this.nodes.forEach((n,i)=>{
        const x=cx+Math.cos(n.angle)*R, y=cy+Math.sin(n.angle)*R;
        const active=n.activeCount(), radius=4+active*1.5, hue=200 + (n.states[0]*100);
        ctx.fillStyle=active?`hsla(${hue},90%,65%,0.95)`:'rgba(80,90,120,0.4)';
        ctx.beginPath(); ctx.arc(x,y,radius,0,Math.PI*2); ctx.fill();
        if(i===this.selected){ ctx.strokeStyle='#f5c518'; ctx.lineWidth=2; ctx.beginPath(); ctx.arc(x,y,radius+5,0,Math.PI*2); ctx.stroke(); }
      });
      requestAnimationFrame(draw);
    }; draw();
  }
}

let matrix;
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('uploadForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData();
    const file = $('#uploadFile').files[0]; if(!file) return;
    fd.append('file', file); fd.append('purpose', $('#uploadPurpose').value); fd.append('target', $('#uploadTarget').value);
    const res = await fetch('/api/upload', {method:'POST', body:fd});
    const data = await res.json();
    $('#uploadResult').textContent = JSON.stringify(data, null, 2);
    await loadDashboard(); await loadLibrary();
    if(matrix) matrix.absorbUploadedFile(file);
  });
  $('#sendBtn').addEventListener('click', sendChat);
  $('#chatInput').addEventListener('keydown', e => { if(e.key === 'Enter') sendChat(); });
  $('#chatFloating').addEventListener('click', () => $('#chatDock').classList.toggle('hidden'));
  $('#chatDockBtn').addEventListener('click', () => $('#chatDock').classList.toggle('hidden'));
  $('#micBtn').addEventListener('click', () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if(!SR){ alert('Speech recognition is not available in this browser.'); return; }
    const rec = new SR(); rec.lang = 'en-US'; rec.onresult = (e) => { $('#chatInput').value = e.results[0][0].transcript; }; rec.start();
  });
  matrix = new MatrixSystem();
  loadDashboard(); loadLibrary(); matrix.updateStats();
});
