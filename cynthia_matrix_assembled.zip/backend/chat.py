from typing import Dict, Any, List
from .storage import all_chunks, stats, pinned_items, recent_activity
from .learning import score_query
from .hooks import hook_status, notify_external_agent

class Cynthia:
    def __init__(self):
        self.mode = "dashboard"

    def retrieve(self, message: str) -> List[Dict[str, Any]]:
        rows = all_chunks()
        scored = []
        for r in rows:
            s = score_query(message, r["token_blob"])
            if s > 0:
                scored.append((s, r))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [r for _, r in scored[:5]]

    def reply(self, message: str) -> Dict[str, Any]:
        m = message.lower().strip()
        hits = self.retrieve(message)

        if "upload" in m or "send this" in m:
            return {
                "reply": "Uploader ready. Drop the file, choose: library, dashboard, or supabase.",
                "mode": "upload",
                "actions": [{"type": "open_upload"}],
                "memory_hits": [],
            }

        if "library" in m or "books" in m:
            return {
                "reply": "Library open. You can upload books, zips, notes, and code. They persist across sessions.",
                "mode": "library",
                "actions": [{"type": "open_library"}],
                "memory_hits": [],
            }

        if "stats" in m or "dashboard" in m or "home" in m:
            s = stats()
            return {
                "reply": f"Dashboard: {s['items']} items, {s['chunks']} memory chunks, {s['pinned']} pinned cards.",
                "mode": "dashboard",
                "actions": [{"type": "refresh_dashboard"}],
                "memory_hits": [],
            }

        if "hooks" in m or "supabase" in m or "neo4j" in m:
            hs = hook_status()
            return {
                "reply": f"Hooks status. Supabase: {hs['supabase']}. Neo4j: {hs['neo4j']}. External agent: {hs['external_agent']}.",
                "mode": "dashboard",
                "actions": [{"type": "show_hooks"}],
                "memory_hits": [],
            }

        if "send to my agent" in m or "external agent" in m:
            sent = notify_external_agent({"message": message})
            return {
                "reply": "I sent that to your external agent." if sent.get("ok") else f"Could not send it: {sent.get('error') or sent.get('status_code')}",
                "mode": "chat",
                "actions": [],
                "memory_hits": [],
            }

        if hits:
            snippets = [f"[{h['item_name']}] {h['text'][:180].replace(chr(10), ' ')}" for h in hits]
            return {
                "reply": "I found memory that matches what you asked. Use it, pin it, or upload more.",
                "mode": "chat",
                "actions": [{"type": "show_memory_hits"}],
                "memory_hits": [{"item_name": h["item_name"], "text": h["text"][:250]} for h in hits],
            }

        return {
            "reply": "Ready. Ask for upload, library, dashboard, hooks, or search memory.",
            "mode": "chat",
            "actions": [],
            "memory_hits": [],
        }
