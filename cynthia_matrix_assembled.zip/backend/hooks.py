from typing import Dict, Any
import requests
from .config import (
    SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, SUPABASE_BUCKET,
    NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD, EXTERNAL_AGENT_URL, EXTERNAL_AGENT_TOKEN
)

def hook_status() -> Dict[str, bool]:
    return {
        "supabase": bool(SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY),
        "neo4j": bool(NEO4J_URI and NEO4J_USER and NEO4J_PASSWORD),
        "external_agent": bool(EXTERNAL_AGENT_URL),
    }

def upload_to_supabase(filename: str, data: bytes) -> Dict[str, Any]:
    if not (SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY):
        return {"ok": False, "error": "Supabase not configured"}
    url = f"{SUPABASE_URL}/storage/v1/object/{SUPABASE_BUCKET}/{filename}"
    headers = {
        "Authorization": f"Bearer {SUPABASE_SERVICE_ROLE_KEY}",
        "apikey": SUPABASE_SERVICE_ROLE_KEY,
        "Content-Type": "application/octet-stream",
        "x-upsert": "true",
    }
    try:
        resp = requests.post(url, headers=headers, data=data, timeout=30)
        return {"ok": resp.ok, "status_code": resp.status_code, "body": resp.text}
    except Exception as e:
        return {"ok": False, "error": str(e)}

def notify_external_agent(payload: Dict[str, Any]) -> Dict[str, Any]:
    if not EXTERNAL_AGENT_URL:
        return {"ok": False, "error": "External agent not configured"}
    headers = {"Content-Type": "application/json"}
    if EXTERNAL_AGENT_TOKEN:
        headers["Authorization"] = f"Bearer {EXTERNAL_AGENT_TOKEN}"
    try:
        resp = requests.post(EXTERNAL_AGENT_URL, json=payload, headers=headers, timeout=30)
        return {"ok": resp.ok, "status_code": resp.status_code, "body": resp.text}
    except Exception as e:
        return {"ok": False, "error": str(e)}

def sync_item_to_neo4j(item: Dict[str, Any]) -> Dict[str, Any]:
    if not (NEO4J_URI and NEO4J_USER and NEO4J_PASSWORD):
        return {"ok": False, "error": "Neo4j not configured"}
    try:
        from neo4j import GraphDatabase
        driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))
        with driver.session() as session:
            session.run(
                "MERGE (i:LibraryItem {id:$id}) SET i.name=$name, i.kind=$kind, i.destination=$destination, i.purpose=$purpose",
                id=item["id"], name=item["name"], kind=item["kind"], destination=item["destination"], purpose=item.get("purpose", "")
            )
        driver.close()
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}
