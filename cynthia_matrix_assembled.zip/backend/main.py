from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse
from pathlib import Path
from .storage import init_db, add_item, add_chunks, list_items, stats, recent_activity, pin_item, route_item, log_event, pinned_items
from .learning import save_upload, ingest_file
from .hooks import hook_status, upload_to_supabase, sync_item_to_neo4j
from .chat import Cynthia
from .models import ChatIn, PinIn, RouteIn
from .config import BASE_DIR

app = FastAPI(title="Cynthia Matrix")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)
init_db()
brain = Cynthia()

FRONTEND_DIR = BASE_DIR / "frontend"
STATIC_DIR = FRONTEND_DIR / "static"

@app.get("/", response_class=HTMLResponse)
def root():
    return (FRONTEND_DIR / "index.html").read_text(encoding="utf-8")

@app.get("/static/{path:path}")
def static_files(path: str):
    return FileResponse(STATIC_DIR / path)

@app.get("/api/dashboard")
def api_dashboard():
    return {
        "stats": stats(),
        "activity": recent_activity(),
        "pinned": pinned_items(),
        "hooks": hook_status(),
    }

@app.get("/api/library")
def api_library():
    return {"items": list_items()}

@app.post("/api/library/pin")
def api_pin(body: PinIn):
    pin_item(body.item_id)
    log_event("pin_item", str(body.item_id))
    return {"ok": True}

@app.post("/api/library/route")
def api_route(body: RouteIn):
    route_item(body.item_id, body.target)
    log_event("route_item", f"{body.item_id}:{body.target}")
    return {"ok": True}

@app.post("/api/upload")
async def api_upload(
    file: UploadFile = File(...),
    purpose: str = Form(""),
    target: str = Form("library")
):
    data = await file.read()
    saved = save_upload(file.filename, data)
    kind, chunks, preview = ingest_file(saved)
    item_id = add_item(file.filename, kind, str(saved), purpose=purpose, destination=target)
    if chunks:
        add_chunks(item_id, chunks)

    item = {
        "id": item_id,
        "name": file.filename,
        "kind": kind,
        "destination": target,
        "purpose": purpose,
    }

    supa = None
    if target == "supabase":
        supa = upload_to_supabase(file.filename, data)

    neo = sync_item_to_neo4j(item)
    log_event("upload", f"{file.filename}:{target}")

    return {
        "ok": True,
        "item_id": item_id,
        "kind": kind,
        "chunks_indexed": len(chunks),
        "preview": preview,
        "supabase": supa,
        "neo4j": neo,
    }

@app.post("/api/chat")
def api_chat(body: ChatIn):
    log_event("chat", body.message[:500])
    return brain.reply(body.message)

@app.get("/api/hooks")
def api_hooks():
    return hook_status()
