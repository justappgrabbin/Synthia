from pydantic import BaseModel
from typing import Optional, List, Dict, Any

class ChatIn(BaseModel):
    message: str

class PinIn(BaseModel):
    item_id: int

class RouteIn(BaseModel):
    item_id: int
    target: str  # library | dashboard | supabase

class ChatOut(BaseModel):
    reply: str
    mode: str = "chat"
    actions: List[Dict[str, Any]] = []
    memory_hits: List[Dict[str, Any]] = []

class HookStatus(BaseModel):
    supabase: bool
    neo4j: bool
    external_agent: bool
