import sqlite3
from pathlib import Path
from typing import List, Dict, Any, Optional
from .config import DB_PATH

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_conn()
    cur = conn.cursor()
    cur.executescript(
        '''
        CREATE TABLE IF NOT EXISTS library_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            kind TEXT NOT NULL,
            source_path TEXT NOT NULL,
            purpose TEXT DEFAULT '',
            pinned INTEGER DEFAULT 0,
            destination TEXT DEFAULT 'library',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS memory_chunks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_id INTEGER NOT NULL,
            chunk_index INTEGER NOT NULL,
            text TEXT NOT NULL,
            token_blob TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(item_id) REFERENCES library_items(id)
        );
        CREATE TABLE IF NOT EXISTS activity_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event TEXT NOT NULL,
            payload TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        '''
    )
    conn.commit()
    conn.close()

def add_item(name: str, kind: str, source_path: str, purpose: str = '', destination: str='library') -> int:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        'INSERT INTO library_items(name, kind, source_path, purpose, destination) VALUES (?, ?, ?, ?, ?)',
        (name, kind, source_path, purpose, destination)
    )
    item_id = cur.lastrowid
    conn.commit()
    conn.close()
    return item_id

def add_chunks(item_id: int, chunks: List[Dict[str, Any]]):
    conn = get_conn()
    cur = conn.cursor()
    cur.executemany(
        'INSERT INTO memory_chunks(item_id, chunk_index, text, token_blob) VALUES (?, ?, ?, ?)',
        [(item_id, c["chunk_index"], c["text"], c["token_blob"]) for c in chunks]
    )
    conn.commit()
    conn.close()

def pin_item(item_id: int):
    conn = get_conn()
    conn.execute('UPDATE library_items SET pinned=1, destination="dashboard" WHERE id=?', (item_id,))
    conn.commit()
    conn.close()

def route_item(item_id: int, target: str):
    conn = get_conn()
    if target == "dashboard":
        conn.execute('UPDATE library_items SET pinned=1, destination=? WHERE id=?', (target, item_id))
    else:
        conn.execute('UPDATE library_items SET destination=?, pinned=CASE WHEN ?="dashboard" THEN 1 ELSE 0 END WHERE id=?', (target, target, item_id))
    conn.commit()
    conn.close()

def list_items(limit: int = 100):
    conn = get_conn()
    rows = conn.execute('SELECT * FROM library_items ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def pinned_items():
    conn = get_conn()
    rows = conn.execute('SELECT * FROM library_items WHERE pinned=1 ORDER BY id DESC').fetchall()
    conn.close()
    return [dict(r) for r in rows]

def stats():
    conn = get_conn()
    cur = conn.cursor()
    items = cur.execute('SELECT COUNT(*) c FROM library_items').fetchone()["c"]
    chunks = cur.execute('SELECT COUNT(*) c FROM memory_chunks').fetchone()["c"]
    pinned = cur.execute('SELECT COUNT(*) c FROM library_items WHERE pinned=1').fetchone()["c"]
    recent = [dict(r) for r in cur.execute('SELECT * FROM library_items ORDER BY id DESC LIMIT 5').fetchall()]
    conn.close()
    return {"items": items, "chunks": chunks, "pinned": pinned, "recent": recent}

def log_event(event: str, payload: str = ''):
    conn = get_conn()
    conn.execute('INSERT INTO activity_log(event, payload) VALUES (?, ?)', (event, payload))
    conn.commit()
    conn.close()

def recent_activity(limit: int = 20):
    conn = get_conn()
    rows = conn.execute('SELECT * FROM activity_log ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def all_chunks():
    conn = get_conn()
    rows = conn.execute('SELECT memory_chunks.*, library_items.name AS item_name FROM memory_chunks JOIN library_items ON library_items.id = memory_chunks.item_id').fetchall()
    conn.close()
    return [dict(r) for r in rows]
