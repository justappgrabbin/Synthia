import os, re, zipfile, shutil
from pathlib import Path
from collections import Counter
from typing import List, Dict, Any, Tuple
from .config import UPLOADS_DIR, LIBRARY_DIR

TEXT_EXTS = {".txt", ".md", ".py", ".js", ".ts", ".tsx", ".jsx", ".json", ".html", ".css", ".csv", ".yml", ".yaml"}

def tokenize(text: str) -> List[str]:
    return re.findall(r"[a-zA-Z0-9_]{2,}", text.lower())

def chunk_text(text: str, size: int = 800, overlap: int = 100) -> List[str]:
    if not text:
        return []
    chunks = []
    i = 0
    while i < len(text):
        chunks.append(text[i:i+size])
        i += max(1, size - overlap)
    return chunks

def prepare_chunks(text: str) -> List[Dict[str, Any]]:
    out = []
    for idx, chunk in enumerate(chunk_text(text)):
        toks = tokenize(chunk)
        blob = jsonable_counter(Counter(toks))
        out.append({"chunk_index": idx, "text": chunk, "token_blob": blob})
    return out

def jsonable_counter(counter: Counter) -> str:
    return " ".join([f"{k}:{v}" for k, v in counter.items()])

def parse_blob(blob: str) -> Counter:
    c = Counter()
    for part in blob.split():
        if ":" in part:
            k, v = part.split(":", 1)
            try:
                c[k] = int(v)
            except:
                pass
    return c

def score_query(query: str, blob: str) -> float:
    q = Counter(tokenize(query))
    b = parse_blob(blob)
    if not q or not b:
        return 0.0
    score = 0
    for term, qv in q.items():
        score += min(qv, b.get(term, 0))
    norm = sum(q.values()) + sum(b.values()) * 0.01
    return score / norm

def save_upload(filename: str, data: bytes) -> Path:
    path = UPLOADS_DIR / filename
    base = path.stem
    suffix = path.suffix
    i = 1
    while path.exists():
        path = UPLOADS_DIR / f"{base}_{i}{suffix}"
        i += 1
    path.write_bytes(data)
    return path

def ingest_file(path: Path) -> Tuple[str, List[Dict[str, Any]], str]:
    ext = path.suffix.lower()
    kind = "file"
    text = ""
    if ext in TEXT_EXTS:
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            text = ""
    elif ext == ".zip":
        kind = "zip"
        extracted = LIBRARY_DIR / path.stem
        if extracted.exists():
            shutil.rmtree(extracted)
        extracted.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(path, "r") as zf:
            zf.extractall(extracted)
        texts = []
        for fp in extracted.rglob("*"):
            if fp.is_file() and fp.suffix.lower() in TEXT_EXTS:
                try:
                    texts.append(f"FILE: {fp.relative_to(extracted)}\n" + fp.read_text(encoding="utf-8", errors="ignore"))
                except Exception:
                    pass
        text = "\n\n".join(texts)
    else:
        kind = ext.lstrip(".") or "binary"
    chunks = prepare_chunks(text) if text else []
    return kind, chunks, text[:4000]
