import data from '../../public/data/gnomes.json'
export default function Gnomes(){
  return (
    <main>
      <div className="card">
        <h2>Gnomes — 64 Gate Roster (sample)</h2>
        <div className="hint">Tech duties + emotional/social states. Replace with your full dataset.</div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:'10px'}}>
          {(data as any[]).map((g:any)=> (
            <div key={g.gate} className="card" style={{margin:'0'}}>
              <b>Gate {g.gate} — {g.name}</b>
              <div className="hint">{g.city} • {g.center}</div>
              <div className="kv"><div>Tech Duty</div><div>{g.techDuty}</div></div>
              <div className="kv"><div>Emotional</div><div>{g.emotionalState}</div></div>
              <div className="kv"><div>Social</div><div>{g.socialState}</div></div>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
