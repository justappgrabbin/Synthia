import Link from 'next/link'
import SpecMark from '../components/SpecMark'

export default function Page(){
  return (
    <main>
      <div className="card">
        <h1>Cynthia — You‑n‑I‑Verse</h1>
        <p className="hint">Body‑as‑world‑map, gnomes, and a sentence engine with locked vocabulary (Base 5 = Space).</p>
        <div className="kv"><div>Engine:</div><div>Sentence Engine V2 (dimension, gate, line, color, tone, base, degree, minute, axis, zodiac, house)</div></div>
        <div className="kv"><div>Speculation:</div><div>Undefined gates/centers and planetary overlays are marked with <SpecMark/> until tested.</div></div>
      </div>
      <div className="card">
        <b>Jump in</b>
        <ul>
          <li><Link href="/lab">Lab</Link> — generate sentences & collect quotes.</li>
          <li><Link href="/chart">Chart</Link> — gate/line viewer.</li>
          <li><Link href="/gnomes">Gnomes</Link> — 64‑gate roster (tech duties).</li>
          <li><Link href="/modstore">Mod Store</Link> — install modules (coming soon).</li>
        </ul>
      </div>
    </main>
  )
}
