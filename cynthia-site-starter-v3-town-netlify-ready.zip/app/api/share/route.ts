import { NextRequest, NextResponse } from 'next/server'
import { readFeed, writeFeed, type Post } from '../../../server/db'
import { applyBuild } from '../../../server/town'

export async function POST(req: NextRequest){
  try{
    const body = await req.json()
    const { surface, commentary, meta, tags = [], speculative = false } = body || {}
    if(!surface || typeof surface!=='string') throw new Error('surface required')
    const post: Post = {
      id: crypto.randomUUID(), ts: Date.now(),
      surface, commentary: commentary||'', meta: meta||{},
      tags: Array.isArray(tags) ? tags.slice(0,8).map(String) : [],
      speculative: !!speculative, comments: []
    }
    const feed = await readFeed()
    feed.posts.unshift(post)
    await writeFeed(feed)
    // auto-build: each shared sentence feeds its gate's home
    try{ const gate = Number(meta?.gate); if(gate) await applyBuild(gate, 1) }catch{}
    return NextResponse.json({ success:true, data: post })
  }catch(e:any){
    return NextResponse.json({ success:false, error:e.message }, { status:400 })
  }
}
