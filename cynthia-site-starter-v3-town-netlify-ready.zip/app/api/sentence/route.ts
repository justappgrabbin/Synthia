import { NextRequest, NextResponse } from 'next/server'
import { buildSentenceV2 } from '../../../lib/sentence-engine-v2'

export async function POST(req: NextRequest){
  try{
    const body = await req.json()
    const out = buildSentenceV2(body)
    return NextResponse.json({ success:true, data: out })
  }catch(e:any){
    return NextResponse.json({ success:false, error: e.message }, { status: 400 })
  }
}
