import { NextRequest, NextResponse } from 'next/server'
import { readTown } from '../../../server/town'

export async function GET(_req: NextRequest){
  const state = await readTown()
  return NextResponse.json({ success:true, data: state })
}
