import { NextRequest, NextResponse } from 'next/server'
import { readFeed } from '../../../server/db'

export async function GET(_req: NextRequest){
  const feed = await readFeed()
  return NextResponse.json({ success:true, data: feed })
}
