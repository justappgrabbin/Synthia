import { NextRequest, NextResponse } from 'next/server'
import { readFeed, writeFeed, type Comment } from '../../../server/db'

export async function POST(req: NextRequest){
  try{
    const body = await req.json()
    const { postId, text, author } = body || {}
    if(!postId || !text) throw new Error('postId and text required')
    const feed = await readFeed()
    const post = feed.posts.find(p => p.id===postId)
    if(!post) throw new Error('post not found')
    const c: Comment = { id: crypto.randomUUID(), ts: Date.now(), text: String(text).slice(0,2000), author: author?String(author):undefined }
    post.comments.push(c)
    await writeFeed(feed)
    return NextResponse.json({ success:true, data: c })
  }catch(e:any){
    return NextResponse.json({ success:false, error:e.message }, { status:400 })
  }
}
