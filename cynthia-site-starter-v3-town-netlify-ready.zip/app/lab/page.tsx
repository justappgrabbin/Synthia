'use client'
import { useState } from 'react'
import SpecMark from '../../components/SpecMark'

export default function Lab(){
  const [surface,setSurface]=useState('')
  const [commentary,setCommentary]=useState('')
  const [error,setError]=useState('')
  async function run(e:any){
    e.preventDefault()
    setError(''); setSurface(''); setCommentary('')
    const fd = new FormData(e.currentTarget)
    const body = {
      dimension:{ name: fd.get('dimension') },
      gate:{ number: Number(fd.get('gate')), name: fd.get('gateName')||undefined },
      line:{ number: Number(fd.get('line')), title: fd.get('lineTitle')||undefined },
      color:{ number: Number(fd.get('color')) },
      tone:{ number: Number(fd.get('tone')) },
      base:{ number: Number(fd.get('base')), keyword: fd.get('base')==='5'?'Space':undefined },
      degree: Number(fd.get('degree')), minute: Number(fd.get('minute')),
      axis: (fd.get('axis')||'') || undefined, zodiac: String(fd.get('zodiac')), house: Number(fd.get('house')),
    }
    try{
      const res = await fetch('/api/sentence',{ method:'POST', body: JSON.stringify(body)})
      const json = await res.json()
      if(!json.success){ setError(json.error||'Error'); return }
      setSurface(json.data.surface); setCommentary(json.data.commentary)
    }catch(err:any){ setError(err.message) }
  }
  return (
    <main>
      <form className="card" onSubmit={run}>
        <h2>Lab — Sentence Generator <SpecMark/></h2>
        <div className="hint">Marking speculative overlays (undefined gates/centers) with <SpecMark/>. Base 5 stays “Space”.</div>
        <div className="grid">
          <div><label>Dimension</label><select name="dimension"><option>Movement</option><option>Evolution</option><option>Being</option><option>Design</option><option selected>Space</option></select></div>
          <div><label>Gate #</label><input className="input" name="gate" type="number" min="1" max="64" defaultValue="23"/></div>
          <div><label>Gate Name</label><input className="input" name="gateName" placeholder="Assimilation"/></div>
          <div><label>Line #</label><select name="line">{[1,2,3,4,5,6].map(n=> <option key={n}>{n}</option>)}</select></div>
          <div><label>Line Title</label><input className="input" name="lineTitle" placeholder="Opportunist"/></div>
          <div><label>Color</label><select name="color">{[1,2,3,4,5,6].map(n=> <option key={n}>{n}</option>)}</select></div>
          <div><label>Tone</label><select name="tone">{[1,2,3,4,5,6].map(n=> <option key={n}>{n}</option>)}</select></div>
          <div><label>Base</label><select name="base">{[1,2,3,4,5].map(n=> <option key={n} selected={n===5}>{n}</option>)}</select></div>
          <div><label>Degree</label><input className="input" name="degree" type="number" min="0" max="29" defaultValue="12"/></div>
          <div><label>Minute</label><input className="input" name="minute" type="number" min="0" max="59" defaultValue="34"/></div>
          <div><label>Zodiac</label><select name="zodiac">{['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'].map(s=> <option key={s}>{s}</option>)}</select></div>
          <div><label>House</label><select name="house">{[1,2,3,4,5,6,7,8,9,10,11,12].map(n=> <option key={n}>{n}</option>)}</select></div>
        </div>
        <label>Axis (optional)</label><input className="input" name="axis" placeholder="Mind ↔ Throat"/>
        <button className="btn" type="submit">Generate</button>
        {error && <div className="card" style={{borderColor:'#a33'}}>Error: {error}</div>}
        {surface && <div className="card"><b>Surface</b><div>{surface}</div></div>}
        {commentary && <div className="card"><b>Commentary</b><div className="hint">{commentary}</div></div>}
      </form>
    </main>
  )
}
