import SpecMark from '../../components/SpecMark'
export default function ModStore(){
  return (
    <main>
      <div className="card">
        <h2>Mod Store <SpecMark/></h2>
        <p className="hint">Install feature mods (TinyLlama, Lab auto‑update, Agent routing). Coming soon.</p>
      </div>
    </main>
  )
}
