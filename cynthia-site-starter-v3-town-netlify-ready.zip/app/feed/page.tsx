'use client'
import { useEffect, useState } from 'react'
import SpecMark from '../../components/SpecMark'

type Post = {
  id:string; ts:number; surface:string; commentary:string;
  meta:any; tags:string[]; speculative:boolean; comments:{id:string; ts:number; text:string; author?:string}[]
}

export default function Feed(){
  const [feed,setFeed]=useState<Post[]>([])
  const [loading,setLoading]=useState(true)
  const [err,setErr]=useState('')
  const [tags,setTags]=useState('resonance,lab')
  const [speculative,setSpeculative]=useState(false)

  async function load(){
    setLoading(true); setErr('')
    try{
      const r = await fetch('/api/feed')
      const j = await r.json()
      if(!j.success) throw new Error(j.error||'error')
      setFeed(j.data.posts||[])
    }catch(e:any){ setErr(e.message) }finally{ setLoading(false) }
  }
  useEffect(()=>{ load() }, [])

  async function share(){
    setErr('')
    const cached = localStorage.getItem('lastSentence')
    if(!cached){ setErr('Generate a sentence in Lab first.'); return }
    const { surface, commentary, meta } = JSON.parse(cached)
    const body = { surface, commentary, meta, tags: tags.split(',').map((s:string)=>s.trim()).filter(Boolean), speculative }
    const r = await fetch('/api/share',{ method:'POST', body: JSON.stringify(body) })
    const j = await r.json()
    if(!j.success){ setErr(j.error||'share failed') }
    else{ await load() }
  }

  async function addComment(postId:string, text:string){
    const r = await fetch('/api/comment',{ method:'POST', body: JSON.stringify({ postId, text }) })
    const j = await r.json()
    if(!j.success){ alert(j.error||'failed') }
    else{ await load() }
  }

  return (
    <main>
      <div className="card">
        <h2>Community Feed</h2>
        <div className="hint">Share your sentence bundle and discuss. Mark speculative posts with <SpecMark/> until validated.</div>
        <div className="kv"><div>Tags</div><input className="input" value={tags} onChange={e=>setTags(e.target.value)} /></div>
        <div className="kv"><div>Speculative?</div><label><input type="checkbox" checked={speculative} onChange={e=>setSpeculative(e.target.checked)} /> Mark with *</label></div>
        <button className="btn" onClick={share}>Share last sentence</button>
        {err && <div className="hint" style={{color:'#faa'}}>{err}</div>}
      </div>
      <div className="card">
        <b>Recent Posts</b>
        {loading && <div className="hint">Loading…</div>}
        {!loading && feed.length===0 && <div className="hint">No posts yet. Generate in Lab, then click “Share last sentence”.</div>}
        <div>
          {feed.map(p=> (
            <div key={p.id} className="card" style={{margin:'12px 0'}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <div><b>{new Date(p.ts).toLocaleString()}</b> {p.speculative && <SpecMark/>}</div>
                <div className="hint">{p.tags.map(t=> `#${t}`).join(' ')}</div>
              </div>
              <div style={{marginTop:'6px'}}>{p.surface}</div>
              {p.commentary && <div className="hint" style={{marginTop:'6px'}}>{p.commentary}</div>}
              <details style={{marginTop:'6px'}}>
                <summary className="hint">Meta</summary>
                <pre className="hint" style={{whiteSpace:'pre-wrap'}}>{JSON.stringify(p.meta,null,2)}</pre>
              </details>
              <div style={{marginTop:'8px'}}>
                <b>Comments</b>
                {p.comments.length===0 && <div className="hint">Be the first to comment.</div>}
                {p.comments.map(c=> (
                  <div key={c.id} className="kv">
                    <div className="hint">{new Date(c.ts).toLocaleTimeString()}</div>
                    <div>{c.text}</div>
                  </div>
                ))}
                <CommentBox onSubmit={(txt)=>addComment(p.id, txt)} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}

function CommentBox({ onSubmit }:{ onSubmit:(t:string)=>void }){
  const [v,setV]=useState('')
  return (
    <div style={{display:'flex', gap:8, marginTop:8}}>
      <input className="input" value={v} onChange={e=>setV(e.target.value)} placeholder="Add a comment…" />
      <button className="btn" onClick={()=>{ if(v.trim()) onSubmit(v.trim()); setV('') }}>Post</button>
    </div>
  )
}
