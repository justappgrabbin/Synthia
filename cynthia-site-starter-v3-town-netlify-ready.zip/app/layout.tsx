import './globals.css'
import Link from 'next/link'

export const metadata = { title: 'Cynthia — You-n-I-Verse', description: 'Consciousness Lab Scaffold' }

export default function RootLayout({ children }: { children: React.ReactNode }){
  return (
    <html lang="en">
      <body>
        <div className="container">
          <nav className="nav">
            <Link href="/">Home</Link>
            <Link href="/lab">Lab</Link>
            <Link href="/chart">Chart</Link>
            <Link href="/gnomes">Gnomes</Link>
            <Link href="/modstore">Mod Store</Link>
            <Link href="/feed">Feed</Link>
            <Link href="/town">Town</Link>
          </nav>
          {children}
          <footer>
            ⚠️ Items marked with <span className="spec">*</span> are <b>experimental speculation</b> — in-lab hypotheses awaiting community testing.
          </footer>
        </div>
      </body>
    </html>
  )
}
