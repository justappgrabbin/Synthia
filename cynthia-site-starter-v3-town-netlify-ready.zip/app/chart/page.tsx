import lines from '../../public/data/lines.json'
export default function Chart(){
  return (
    <main>
      <div className="card">
        <h2>Chart — Line Titles (sample)</h2>
        <div className="hint">Pulled from /public/data/lines.json. Replace with your full 384-line dataset.</div>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead><tr><th style={{textAlign:'left'}}>Gate</th><th>1</th><th>2</th><th>3</th></tr></thead>
          <tbody>
            {Object.keys(lines).map((g:any)=> (
              <tr key={g}>
                <td style={{padding:'6px 4px',borderBottom:'1px solid #1f2a37'}}>Gate {g}</td>
                {[1,2,3].map(n=> <td key={n} style={{padding:'6px 4px',borderBottom:'1px solid #1f2a37'}}>{(lines as any)[g]?.[n]}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  )
}
