'use client'
import { useEffect, useMemo, useState } from 'react'

type District = { id:string; name:string; center:string; x:number; y:number }
type Home = { gate:number; name:string; center:string; level:number; xp:number }

export default function Town(){
  const [districts,setDistricts]=useState<District[]>([])
  const [homes,setHomes]=useState<Home[]>([])
  const [err,setErr]=useState('')
  const [selected,setSelected]=useState<Home|null>(null)

  async function load(){
    setErr('')
    try{
      const r = await fetch('/api/town')
      const j = await r.json()
      if(!j.success) throw new Error(j.error||'failed')
      setDistricts(j.data.districts); setHomes(j.data.homes)
    }catch(e:any){ setErr(e.message) }
  }
  useEffect(()=>{ load() }, [])

  const grouped = useMemo(()=>{
    const map: Record<string, Home[]> = {}
    homes.forEach(h=>{ map[h.center] ||= []; map[h.center].push(h) })
    Object.values(map).forEach(list=> list.sort((a,b)=>a.gate-b.gate))
    return map
  },[homes])

  const viewW = 1000, viewH = 680

  async function buildSelected(){
    if(!selected) return
    const r = await fetch('/api/town/build', { method:'POST', body: JSON.stringify({ gate:selected.gate, amount:1 }) })
    const j = await r.json()
    if(!j.success){ alert(j.error||'failed') } else { await load() }
  }

  return (
    <main>
      <div className="card">
        <h2>City of Gnomes — Homes & Districts</h2>
        <div className="hint">Every shared sentence feeds a home. 3xp → level up (max 5). Districts = Human Design centers.</div>
        {err && <div className="hint" style={{color:'#faa'}}>Error: {err}</div>}
        <svg viewBox={`0 0 ${viewW} ${viewH}`} style={{width:'100%', background:'#0b0f14', border:'1px solid #1f2a37', borderRadius:12}}>
          {/* District anchors */}
          {districts.map(d=>{
            const x = d.x*viewW, y = d.y*viewH
            return (
              <g key={d.id}>
                <circle cx={x} cy={y} r={40} fill="none" stroke="#335" strokeWidth={2}/>
                <text x={x} y={y-50} textAnchor="middle" fill="#8aa" fontSize="14">{d.name}</text>
                <text x={x} y={y-32} textAnchor="middle" fill="#567" fontSize="12">{d.center}</text>
              </g>
            )
          })}
          {/* Homes around each district */}
          {districts.flatMap(d=>{
            const list = grouped[d.center]||[]
            const cx = d.x*viewW, cy = d.y*viewH
            const radius = 70
            return list.map((h, i)=>{
              const angle = (i / list.length) * 2 * Math.PI
              const hx = cx + Math.cos(angle)*radius
              const hy = cy + Math.sin(angle)*radius
              const size = 6 + (h.level*3)
              return (
                <g key={h.gate} onClick={()=>setSelected(h)} style={{cursor:'pointer'}}>
                  <circle cx={hx} cy={hy} r={size} fill={h.level>0?'#7cf':'#445'} stroke="#9bf" strokeWidth={h.level>0?1.5:0.5} />
                  <title>{`Gate ${h.gate} — ${h.name} (Lv${h.level}, XP ${h.xp})`}</title>
                </g>
              )
            })
          })}
        </svg>
        {selected && (
          <div className="card" style={{marginTop:12}}>
            <b>Gate {selected.gate} — {selected.name}</b>
            <div className="kv"><div>Center</div><div>{selected.center}</div></div>
            <div className="kv"><div>Level</div><div>{selected.level}</div></div>
            <div className="kv"><div>XP</div><div>{selected.xp} (3 XP → +1 level)</div></div>
            <button className="btn" onClick={buildSelected}>Give 1 build XP</button>
          </div>
        )}
      </div>
    </main>
  )
}
