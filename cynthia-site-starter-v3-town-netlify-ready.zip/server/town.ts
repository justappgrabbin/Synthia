import { promises as fs } from 'fs'
import path from 'path'

const DATA_DIR = path.join(process.cwd(), 'data')
const STATE_FILE = path.join(DATA_DIR, 'town_state.json')

export type District = { id:string; name:string; center:string; x:number; y:number }
export type Home = { gate:number; name:string; center:string; level:number; xp:number }
export type TownState = { districts: District[]; homes: Home[] }

// anchors for 9 centers in normalized coords (0..1)
const CENTER_ANCHORS: Record<string,{x:number;y:number;name:string}> = {
  "Head": {x:0.5, y:0.08, name:"Observatory"},
  "Ajna": {x:0.5, y:0.16, name:"Library"},
  "Throat": {x:0.5, y:0.24, name:"Forum Plaza"},
  "G": {x:0.5, y:0.36, name:"Citadel"},
  "Heart": {x:0.62, y:0.34, name:"Treasury"},
  "Solar Plexus": {x:0.62, y:0.46, name:"Riverfront"},
  "Spleen": {x:0.38, y:0.46, name:"Forest"},
  "Sacral": {x:0.5, y:0.54, name:"Market"},
  "Root": {x:0.5, y:0.68, name:"Mountain Base"},
}

// Gate→Center mapping
const CENTER_BY_GATE: Record<number,string> = {
  1:"G",2:"G",7:"G",13:"G",10:"G",15:"G",25:"G",46:"G",
  21:"Heart",51:"Heart",26:"Heart",40:"Heart",
  6:"Solar Plexus",22:"Solar Plexus",30:"Solar Plexus",37:"Solar Plexus",
  36:"Solar Plexus",55:"Solar Plexus",49:"Solar Plexus",
  5:"Sacral",9:"Sacral",14:"Sacral",29:"Sacral",34:"Sacral",27:"Sacral",59:"Sacral",3:"Sacral",42:"Sacral",
  57:"Spleen",50:"Spleen",32:"Spleen",28:"Spleen",18:"Spleen",44:"Spleen",48:"Spleen",
  41:"Root",60:"Root",52:"Root",53:"Root",54:"Root",58:"Root",38:"Root",39:"Root",19:"Root",
  61:"Head",63:"Head",64:"Head",
  24:"Ajna",47:"Ajna",4:"Ajna",11:"Ajna",17:"Ajna",43:"Ajna",
  20:"Throat",23:"Throat",56:"Throat",16:"Throat",62:"Throat",31:"Throat",33:"Throat",
  8:"Throat",45:"Throat",35:"Throat",12:"Throat"
}

// Short names for gates (fallbacks)
const GATE_NAME: Record<number,string> = {
  1:"Creative", 2:"Receptive", 3:"Ordering", 4:"Answers", 5:"Patterns",
  6:"Friction", 7:"Leadership", 8:"Contribution", 9:"Focus", 10:"Behavior",
  11:"Ideas", 12:"Standstill", 13:"Listener", 14:"Resources", 15:"Rhythm",
  16:"Skills", 17:"Opinions", 18:"Correction", 19:"Needs", 20:"Now",
  21:"Control", 22:"Grace", 23:"Assimilation", 24:"Rationalize", 25:"Innocence",
  26:"Trickster", 27:"Nourishment", 28:"Struggle", 29:"Commitment", 30:"Desire",
  31:"Influence", 32:"Continuity", 33:"Retreat", 34:"Power", 35:"Change",
  36:"Crisis", 37:"Family", 38:"Fighter", 39:"Provocation", 40:"Deliverance",
  41:"Start", 42:"Completion", 43:"Insight", 44:"Alertness", 45:"Gatherer",
  46:"Embodiment", 47:"Realization", 48:"Depth", 49:"Principles", 50:"Values",
  51:"Shock", 52:"Stillness", 53:"Development", 54:"Ambition", 55:"Spirit",
  56:"Wanderer", 57:"Clarity", 58:"Joy", 59:"Intimacy", 60:"Limitation",
  61:"Inner Truth", 62:"Details", 63:"Doubt", 64:"Confusion"
}

async function ensure(){
  try{ await fs.mkdir(DATA_DIR, { recursive: true }) }catch{}
  try{ await fs.access(STATE_FILE) } catch {
    // build initial state
    const districts = Object.entries(CENTER_ANCHORS).map(([center, p]) => ({
      id: center, name: p.name, center, x: p.x, y: p.y
    }))
    const homes: Home[] = []
    for(let g=1; g<=64; g++){
      const center = CENTER_BY_GATE[g]
      homes.push({ gate:g, name: GATE_NAME[g]||('Gate '+g), center, level: 0, xp: 0 })
    }
    const init: TownState = { districts, homes }
    await fs.writeFile(STATE_FILE, JSON.stringify(init, null, 2), 'utf-8')
  }
}

export async function readTown(): Promise<TownState>{
  await ensure()
  const raw = await fs.readFile(STATE_FILE, 'utf-8')
  return JSON.parse(raw) as TownState
}

export async function writeTown(state: TownState){
  await ensure()
  await fs.writeFile(STATE_FILE, JSON.stringify(state, null, 2), 'utf-8')
}

// Simple leveling curve: every 3 xp → +1 level up to 5
export async function applyBuild(gate:number, amount=1){
  const state = await readTown()
  const h = state.homes.find(h => h.gate===gate)
  if(!h) return
  h.xp += Math.max(0, amount|0)
  const targetLevel = Math.min(5, Math.floor(h.xp/3))
  if (targetLevel > h.level) h.level = targetLevel
  await writeTown(state)
}

export function anchors(){ return CENTER_ANCHORS }
export function centerOfGate(g:number){ return CENTER_BY_GATE[g] }
