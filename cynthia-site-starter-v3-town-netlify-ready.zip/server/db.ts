import { promises as fs } from 'fs';
import path from 'path';

const DATA_PATH = path.join(process.cwd(), 'data');
const FEED_FILE = path.join(DATA_PATH, 'feed.json');

export type Comment = { id:string; ts:number; text:string; author?:string };
export type Post = {
  id:string; ts:number;
  surface:string; commentary:string;
  meta:Record<string,any>;
  tags:string[]; speculative:boolean;
  comments: Comment[];
};

async function ensureFile(){
  try{ await fs.mkdir(DATA_PATH, { recursive: true }); }catch{}
  try{ await fs.access(FEED_FILE); }
  catch{ await fs.writeFile(FEED_FILE, JSON.stringify({ posts: [] }, null, 2), 'utf-8'); }
}

export async function readFeed(): Promise<{posts:Post[]}>{
  await ensureFile();
  const raw = await fs.readFile(FEED_FILE, 'utf-8');
  return JSON.parse(raw || '{"posts":[]}');
}

export async function writeFeed(data:{posts:Post[]}){
  await ensureFile();
  await fs.writeFile(FEED_FILE, JSON.stringify(data, null, 2), 'utf-8');
}
