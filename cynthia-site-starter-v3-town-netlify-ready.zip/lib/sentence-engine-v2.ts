// Sentence Engine V2 — exact fields; Base 5 = Space locked
export type DimensionName = 'Movement'|'Evolution'|'Being'|'Design'|'Space'
export type InputV2 = {
  dimension: { name: DimensionName, key?: string }
  gate: { number: number, name?: string }
  line: { number: 1|2|3|4|5|6, title?: string }
  color: { number: 1|2|3|4|5|6, motivation?: string }
  tone: { number: 1|2|3|4|5|6, keyword?: string }
  base: { number: 1|2|3|4|5, keyword?: string }
  degree: number; minute: number
  axis?: string; zodiac: string; house: 1|2|3|4|5|6|7|8|9|10|11|12
}
export type OutputV2 = { surface: string; commentary: string; meta: Record<string,any> }
export const DIMENSION_KEYNOTE = { Movement:'I define', Evolution:'I remember', Being:'I am', Design:'I design', Space:'I think' } as const
export const LINE_STYLE = {1:'Investigator',2:'Hermit',3:'Martyr',4:'Opportunist',5:'Heretic',6:'Role Model'} as const
export const COLOR_MOTIVATION = {1:'Fear',2:'Hope',3:'Desire',4:'Need',5:'Guilt',6:'Innocence'} as const
export const TONE_KEYWORD = {1:'Smell',2:'Taste',3:'Touch',4:'Sound',5:'Light',6:'Feeling'} as const
export const BASE_KEYWORD = {1:'Life',2:'The Other',3:'Mutation',4:'Form',5:'Space'} as const
export const HOUSE_FLAVOR = {1:'identity & approach',2:'resources & worth',3:'learning & voice',4:'home & roots',5:'creativity & play',6:'service & skill',7:'bond & mirror',8:'merging & power',9:'belief & travel',10:'role & reputation',11:'community & networks',12:'rest & the unseen'} as const
const clamp=(n:number,min:number,max:number)=>Math.max(min,Math.min(max,n))
const fmt=(d:number,m:number)=>`${clamp(Math.trunc(d),0,29)}°${clamp(Math.trunc(m),0,59)}′`
export function buildSentenceV2(x:InputV2):OutputV2{
  if(x.base.number===5 && x.base.keyword && x.base.keyword!=='Space') throw new Error('Base 5 must be "Space".')
  const keynote = DIMENSION_KEYNOTE[x.dimension.name as DimensionName]
  const gateName = x.gate.name?`${x.gate.number} ${x.gate.name}`:`Gate ${x.gate.number}`
  const lineTitle = x.line.title || LINE_STYLE[x.line.number]
  const houseFlavor = HOUSE_FLAVOR[x.house]
  const colorWord = x.color.motivation || COLOR_MOTIVATION[x.color.number]
  const toneWord = x.tone.keyword || TONE_KEYWORD[x.tone.number]
  const baseWord = x.base.keyword || BASE_KEYWORD[x.base.number]
  if(x.base.number===5 && baseWord!=='Space') throw new Error('Base 5 must resolve to "Space".')
  const where = `${x.zodiac} ${x.house} (${houseFlavor})`
  const pos = fmt(x.degree,x.minute)
  const opener = `${keynote} in ${gateName}, line ${x.line.number} — the ${lineTitle.toLowerCase()} move.`
  const spine  = `It comes through ${colorWord.toLowerCase()} → ${toneWord.toLowerCase()} on the ${baseWord.toLowerCase()} base.`
  const place  = `Position ${pos} in ${where}${x.axis?` along the ${x.axis} axis`:''}.`
  const surface=[opener,spine,place,'Say the real thing and then act once.'].join(' ')
  const commentary=[`Dimension: ${x.dimension.name}${x.dimension.key?' ('+x.dimension.key+')':''}`,`Gate: ${x.gate.number}${x.gate.name?' — '+x.gate.name:''}`,`Line: ${x.line.number}${x.line.title?' — '+x.line.title:''}`,`Color: ${x.color.number}${colorWord?' ('+colorWord+')':''}`,`Tone: ${x.tone.number}${toneWord?' ('+toneWord+')':''}`,`Base: ${x.base.number}${baseWord?' — '+baseWord:''}`,`Zodiac: ${x.zodiac} • House ${x.house} (${houseFlavor})`,`Position: ${pos}`,x.axis?`Axis: ${x.axis}`:'`'].filter(Boolean).join(' • ') 
  return { surface, commentary, meta: { ...x, lineTitle, gateName, position:pos } }
}
