export default function SpecMark(){ return <span title="Experimental speculation — in testing" className="spec">*</span> }
