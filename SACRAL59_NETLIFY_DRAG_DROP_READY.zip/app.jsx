const { useEffect, useMemo, useRef, useState } = React;

/*
  Sacral:59 After Dark — Full Interactive Demo
  - Gate 59 detector → Portal unlock → After Dark scenes
  - 3 skins, a11y toggles, particle canvas
  - Pulse Tokens mini-economy, alias throttle
  - Lab Notes explainers; glyph-only identity
*/

// Skins
const SKINS = {
  "Crimson Bloom": {
    bgFrom: "#0C0A10",
    bgTo: "#1B0E14",
    primary: "#F43F5E",
    accent: "#F59E0B",
    glow: "#7F1D1D",
    specular: "#FFE4E6",
  },
  "Neon Pheromone": {
    bgFrom: "#05050A",
    bgTo: "#0A0616",
    primary: "#06B6D4",
    accent: "#E879F9",
    glow: "#0EA5E9",
    specular: "#D6FAFF",
  },
  "Obsidian Orchid": {
    bgFrom: "#0A0A0A",
    bgTo: "#121019",
    primary: "#7E22CE",
    accent: "#22C55E",
    glow: "#A21CAF",
    specular: "#F3E8FF",
  },
};

// Particle Canvas
function ParticleCanvas({ color, reduced }) {
  const ref = useRef(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    let w = (canvas.width = canvas.offsetWidth);
    let h = (canvas.height = canvas.offsetHeight);

    const onResize = () => {
      w = canvas.width = canvas.offsetWidth;
      h = canvas.height = canvas.offsetHeight;
    };
    const max = reduced ? 60 : 220;
    const dots = new Array(max).fill(0).map(() => ({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * (reduced ? 1.2 : 2.2) + 0.4,
      vx: (Math.random() - 0.5) * (reduced ? 0.1 : 0.3),
      vy: (Math.random() - 0.5) * (reduced ? 0.1 : 0.3),
    }));

    let raf = 0;
    let last = performance.now();
    const targetFps = reduced ? 30 : 60;
    const frameInterval = 1000 / targetFps;

    function loop(t) {
      raf = requestAnimationFrame(loop);
      if (t - last < frameInterval) return;
      last = t;
      ctx.clearRect(0, 0, w, h);
      ctx.globalCompositeOperation = "lighter";
      for (const p of dots) {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = w; if (p.x > w) p.x = 0;
        if (p.y < 0) p.y = h; if (p.y > h) p.y = 0;
        ctx.beginPath();
        const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 6);
        grad.addColorStop(0, `${color}AA`);
        grad.addColorStop(1, `${color}00`);
        ctx.fillStyle = grad;
        ctx.arc(p.x, p.y, p.r * 6, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    window.addEventListener("resize", onResize);
    loop(performance.now());
    return () => {
      window.removeEventListener("resize", onResize);
      cancelAnimationFrame(raf);
    };
  }, [color, reduced]);
  return <canvas ref={ref} className="absolute inset-0 w-full h-full" aria-hidden />;
}

// Beauty score heuristic
function beautyScore(highContrast) {
  const total = 4.5 + 4.0 + 4.5 + 4.0 + 4.5 - (highContrast ? 0.5 : 0);
  return { total, passAA: true };
}

// Gate 59 detector & identity throttle
const HALF_YEAR = 180 * 24 * 60 * 60 * 1000;

function useGate59Detector() {
  const [natalGates, setNatal] = useState([10, 27]);
  const [transitGates, setTransit] = useState([5]);
  const afterDarkUnlocked = natalGates.includes(59) || transitGates.includes(59);
  return {
    natalGates, transitGates, afterDarkUnlocked,
    toggleNatal59: () => setNatal(g => g.includes(59) ? g.filter(x=>x!==59) : [...g, 59]),
    toggleTransit59: () => setTransit(g => g.includes(59) ? g.filter(x=>x!==59) : [...g, 59]),
  };
}

function useAfterDarkIdentity() {
  const [alias, setAlias] = useState("Mask‑Orchid");
  const [history, setHistory] = useState(() => {
    const raw = localStorage.getItem("ad-alias-history");
    return raw ? JSON.parse(raw) : [];
  });
  const changesLast6m = history.filter(h => Date.now() - h.when < HALF_YEAR).length;
  function attemptChange(next) {
    if (changesLast6m >= 2) return { ok: false, error: "Alias change limit reached (2 / 6 months)." };
    const h = [...history, { when: Date.now(), alias: next }];
    localStorage.setItem("ad-alias-history", JSON.stringify(h));
    setHistory(h);
    setAlias(next);
    return { ok: true };
  }
  return { alias, attemptChange, changesLast6m };
}

// Lab Notes
function LabNote({ title, hypothesis, method, result }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm card-gloss">
      <button onClick={()=>setOpen(!open)} className="w-full text-left px-4 py-3 flex items-center justify-between">
        <span className="font-semibold tracking-tight">Lab Notes — {title}</span>
        <span className="text-sm opacity-70">{open ? "Hide" : "Show"}</span>
      </button>
      {open && (
        <div className="px-4 pb-4 text-sm space-y-3">
          <div><span className="font-semibold">Hypothesis:</span> {hypothesis}</div>
          <div><span className="font-semibold">Method:</span> {method}</div>
          <div><span className="font-semibold">Result:</span> {result}</div>
        </div>
      )}
    </div>
  );
}

// Scenes
function UnionScene() {
  const [vuln, setVuln] = useState(42);
  const [consent, setConsent] = useState(false);
  const match = useMemo(() => ({ score: Math.round(78 + (vuln - 42) / 3), glyph: "GLF_PARTNER" }), [vuln]);
  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-3 gap-4">
        <div className="md:col-span-2 rounded-2xl p-4 border border-white/10 bg-white/5 card-gloss">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold">Pairing Tuner</h3>
            <span className="text-xs opacity-70">Gate 59 ↔ channels 6 / 27 aware</span>
          </div>
          <label className="text-sm">Vulnerability slider</label>
          <input type="range" min={0} max={100} value={vuln}
            onChange={(e) => setVuln(parseInt(e.target.value))}
            className="w-full accent-pink-400" />
          <div className="mt-2 text-sm opacity-80">Current: {vuln}%</div>
          <div className="mt-4 flex items-center gap-2">
            <input id="consent" type="checkbox" className="accent-emerald-400" checked={consent} onChange={(e)=>setConsent(e.target.checked)} />
            <label htmlFor="consent" className="text-sm">I consent to pairing signals for this session (glyph‑only).</label>
          </div>
        </div>
        <div className="rounded-2xl p-4 border border-white/10 bg-white/5">
          <div className="text-sm opacity-80 mb-1">Suggested Partner</div>
          <div className="text-2xl font-bold">Score {match.score}</div>
          <div className="text-xs opacity-60">Resonance glyph: {match.glyph}</div>
          <button disabled={!consent} className={`mt-3 px-3 py-2 rounded-xl text-sm font-medium ${consent?"bg-emerald-500 hover:bg-emerald-400":"bg-gray-600 cursor-not-allowed"}`}>Invite to Union</button>
        </div>
      </div>
      <LabNote
        title="Union"
        hypothesis="Raising vulnerability + consent increases 59‑channel pairing stability."
        method="Adjust vulnerability, require consent, compute glyph‑aware score."
        result="Observe higher match score with higher, honest inputs; non‑consensual pairing blocked."
      />
    </div>
  );
}

function PulseScene() {
  const [posts, setPosts] = useState([]);
  useEffect(()=>{ API.feed("resonance").then(r=>setPosts(r.posts)); }, []);
  return (
    <div className="grid md:grid-cols-3 gap-4">
      {posts.map(p => (
        <div key={p.id} className="rounded-2xl p-4 border border-white/10 bg-white/5 card-gloss">
          <div className="text-sm opacity-70 mb-2">Resonance Score <span className="font-semibold">{p.score}</span></div>
          <div className="text-lg">{p.text}</div>
          <button className="mt-3 px-3 py-2 rounded-xl text-sm font-medium bg-pink-500 hover:bg-pink-400">Pulse +1</button>
        </div>
      ))}
      <div className="md:col-span-3">
        <LabNote
          title="Pulse"
          hypothesis="Glyph‑aware ranking surfaces intimate resonance when 59 is active."
          method="Sort by overlap weights (gate/city, channel half‑match, recent XP)."
          result="Feed tiles show higher scores on 59‑aligned content; manual pulses nudge short‑term rank."
        />
      </div>
    </div>
  );
}

function ExchangeScene() {
  const listings = [
    { id: "A1", title: "Shadow roleplay coach — 20m", cost: 8 },
    { id: "B2", title: "Field Friend: Cross of Intimacy (rental)", cost: 14 },
    { id: "C3", title: "Vulnerability ritual partner — 30m", cost: 11 },
  ];
  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-3 gap-4">
        {listings.map(l => (
          <div key={l.id} className="rounded-2xl p-4 border border-white/10 bg-white/5 card-gloss">
            <div className="text-sm opacity-70">Listing • {l.id}</div>
            <div className="text-lg font-semibold">{l.title}</div>
            <div className="text-sm mt-2">Cost: <span className="font-bold">{l.cost}</span> Pulse Tokens</div>
            <button className="mt-3 px-3 py-2 rounded-xl text-sm font-medium bg-amber-500 hover:bg-amber-400">Exchange</button>
          </div>
        ))}
      </div>
      <LabNote
        title="Exchange"
        hypothesis="Time‑boxed buffs + odd jobs create a safe sacral economy."
        method="Token escrow, rental timers, cooldowns; no fiat inside scene; glyph‑only signatures."
        result="Users complete shadow trades without PII; buffs expire predictably; logs remain in Lab."
      />
    </div>
  );
}

function ShadowPlayScene() {
  const quests = [
    { id: "Q59", title: "Gate 59 — Intimacy micro‑exposure", minutes: 5, speculative: false },
    { id: "Q28", title: "Gate 28 — Face the Struggle", minutes: 7, speculative: true },
  ];
  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        {quests.map(q => (
          <div key={q.id} className="rounded-2xl p-4 border border-white/10 bg-white/5 card-gloss">
            <div className="flex items-center justify-between">
              <div className="font-semibold">{q.title}</div>
              {q.speculative && <span className="text-xs px-2 py-1 rounded bg-white/10">✳ experimental</span>}
            </div>
            <div className="text-sm opacity-70 mt-1">~{q.minutes} min</div>
            <button className="mt-3 px-3 py-2 rounded-xl text-sm font-medium bg-violet-500 hover:bg-violet-400">Start Quest</button>
          </div>
        ))}
      </div>
      <LabNote
        title="Shadow Play"
        hypothesis="Shadow quests gate posting privileges in After Dark to preserve meaning."
        method="Complete a quest → unlock posting; speculative items clearly marked ✳ until cohort thresholds."
        result="Keeps the chamber intentional (not spam); promotes reflective intimacy and ethics."
      />
    </div>
  );
}

function AliasChanger({ attemptChange, primary }) {
  const [next, setNext] = useState("");
  const [msg, setMsg] = useState(null);
  return (
    <div className="flex items-center gap-2">
      <input
        aria-label="After Dark alias"
        placeholder="New alias"
        value={next}
        onChange={e=>setNext(e.target.value)}
        className="bg-white/10 rounded-xl px-3 py-2 text-sm outline-none"
      />
      <button
        onClick={()=>{
          const res = attemptChange(next.trim() || "Mask‑" + Math.random().toString(36).slice(2,6));
          setMsg(res.ok?"Alias updated":"Alias change limit reached (2 / 6 months)");
          setNext("");
        }}
        className="px-3 py-2 rounded-xl text-sm font-medium"
        style={{backgroundColor: primary}}
      >Change</button>
      {msg && <span className="text-xs opacity-70">{msg}</span>}
    </div>
  );
}

// Main App
function App() {
  const { glyphId } = Lab.initGlyph();
  const [skin, setSkin] = useState("Crimson Bloom");
  const [highContrast, setHighContrast] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const { natalGates, transitGates, afterDarkUnlocked, toggleNatal59, toggleTransit59 } = useGate59Detector();
  const { alias, attemptChange, changesLast6m } = useAfterDarkIdentity();
  const [entered, setEntered] = useState(false);
  const [tab, setTab] = useState("Union");
  const [tokens, setTokens] = useState(12);

  // token decay
  useEffect(() => {
    const iv = setInterval(() => setTokens(t => Math.max(0, t - 1)), 8000);
    return () => clearInterval(iv);
  }, []);

  const s = SKINS[skin];
  const beauty = beautyScore(highContrast);
  const bgStyle = {
    background: `radial-gradient(1200px 800px at 20% 0%, ${s.bgTo}, transparent 60%), radial-gradient(1200px 800px at 80% 100%, ${s.bgFrom}, #000 60%)`,
  };

  return (
    <div className="min-h-dvh text-white" style={bgStyle}>
      <div className="relative">
        {!highContrast && <ParticleCanvas color={s.glow} reduced={reducedMotion} />}
      </div>

      <header className="relative z-10 max-w-6xl mx-auto px-4 pt-6 pb-2 flex items-center justify-between">
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight" style={{textShadow: highContrast?"none":"0 0 24px rgba(255,255,255,0.25)"}}>Sacral:59 — After Dark</h1>
        <div className="flex items-center gap-2">
          <select aria-label="Theme" className="bg-white/10 rounded-xl px-3 py-2 text-sm"
            value={skin} onChange={e=>setSkin(e.target.value)}>
            {Object.keys(SKINS).map(k => <option key={k}>{k}</option>)}
          </select>
          <button onClick={()=>setHighContrast(v=>!v)} className="bg-white/10 rounded-xl px-3 py-2 text-sm">{highContrast?"High‑contrast: On":"High‑contrast: Off"}</button>
          <button onClick={()=>setReducedMotion(v=>!v)} className="bg-white/10 rounded-xl px-3 py-2 text-sm">{reducedMotion?"Reduced motion: On":"Reduced motion: Off"}</button>
        </div>
      </header>

      <main className="relative z-10 max-w-6xl mx-auto px-4 pb-24">
        <section className="mb-4 rounded-2xl border border-white/10 bg-white/5 p-4">
          <div className="flex flex-wrap items-center gap-3 justify-between">
            <div className="flex items-center gap-3">
              <div className={`${afterDarkUnlocked?"animate-pulse":""} w-10 h-10 rounded-full`} style={{background: afterDarkUnlocked? s.primary : "#374151"}} aria-label="Gate 59 node"></div>
              <div>
                <div className="font-semibold">Gate 59 — Intimacy / Union</div>
                <div className="text-xs opacity-70">{afterDarkUnlocked?"Active — portal ready":"Inactive — portal hidden"}</div>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <label className="flex items-center gap-2"><input type="checkbox" className="accent-pink-400" checked={natalGates.includes(59)} onChange={toggleNatal59}/> Natal 59</label>
              <label className="flex items-center gap-2"><input type="checkbox" className="accent-amber-400" checked={transitGates.includes(59)} onChange={toggleTransit59}/> Transit 59</label>
              <button
                disabled={!afterDarkUnlocked}
                onClick={()=>setEntered(true)}
                className={`px-3 py-2 rounded-xl font-medium ${afterDarkUnlocked?"bg-pink-500 hover:bg-pink-400":"bg-gray-600 cursor-not-allowed"}`}
              >Open Portal</button>
            </div>
          </div>
        </section>

        {!entered ? (
          <section className="rounded-2xl border border-white/10 bg-white/5 p-6 mb-6">
            <h2 className="text-xl font-semibold mb-2">After Dark is {afterDarkUnlocked?"ready":"locked"}</h2>
            <p className="opacity-80 text-sm">Tap <em>Open Portal</em> when Gate 59 is active to invert the chart and enter the Sacral chamber.</p>
            <LabNote title="Portal"
              hypothesis="When 59 lights, an inner‑sacral UI becomes context‑appropriate."
              method="Detect 59 by natal or transit; surface hint; require explicit user action."
              result="No accidental exposure; users step through consciously; reduced‑motion path available."/>
          </section>
        ) : (
          <section className="rounded-3xl p-6 mb-6 relative overflow-hidden"
            style={{
              background: `linear-gradient(135deg, ${s.bgTo} 0%, ${s.bgFrom} 60%)`,
              boxShadow: `0 0 60px ${s.glow}66 inset`
            }}>
            {!reducedMotion && (
              <div className="pointer-events-none absolute -inset-8 opacity-50"
                style={{
                  background: `conic-gradient(from 0deg at 50% 50%, transparent 30%, ${s.specular}20 35%, transparent 40%)`,
                  WebkitMaskImage: "radial-gradient(circle at 50% 50%, black 40%, transparent 60%)",
                  maskImage: "radial-gradient(circle at 50% 50%, black 40%, transparent 60%)",
                  filter: "blur(8px)"
                }} />
            )}
            <div className="relative z-10 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-sm opacity-80 mb-1">Inside the Sacral — identity</div>
                <div className="text-xl font-semibold">Alias: {/* alias visible */}{alias}</div>
                <div className="text-xs opacity-70">Glyph: {glyphId} • Changes last 6m: {changesLast6m}/2</div>
              </div>
              <AliasChanger attemptChange={attemptChange} primary={s.primary} />
              <div className="flex items-center gap-3 ml-auto">
                <div className="text-sm">Pulse Tokens: <span className="font-semibold">{tokens}</span></div>
                <button className="px-3 py-2 rounded-xl text-sm font-medium bg-emerald-500 hover:bg-emerald-400" onClick={()=>setTokens(t=>t+3)}>Earn +3</button>
              </div>
            </div>

            <nav className="relative z-10 mt-6 flex flex-wrap gap-2">
              {["Union","Pulse","Exchange","Shadow Play"].map(t => (
                <button key={t} onClick={()=>setTab(t)} className={`px-3 py-2 rounded-xl text-sm font-medium border ${tab===t?"bg-white/20 border-white/30":"bg-white/10 border-white/10 hover:bg-white/15"}`}>{t}</button>
              ))}
            </nav>

            <div className="relative z-10 mt-6">
              {tab === "Union" && <UnionScene />}
              {tab === "Pulse" && <PulseScene />}
              {tab === "Exchange" && <ExchangeScene />}
              {tab === "Shadow Play" && <ShadowPlayScene />}
            </div>
          </section>
        )}

        <section className="grid md:grid-cols-2 gap-4">
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="font-semibold mb-2">Beauty Rubric (auto‑score)</div>
            <div className="text-sm">Score: <span className="font-bold">{beauty.total.toFixed(1)}</span>/25</div>
            <div className="text-sm">AA Contrast: <span className="font-bold">{beauty.passAA?"Pass":"Fail"}</span></div>
            <div className="text-xs opacity-70 mt-2">Skins under 18/25 or failing AA are rejected automatically.</div>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="font-semibold mb-2">Accessibility Controls</div>
            <div className="flex flex-wrap gap-2 text-sm">
              <span className="px-2 py-1 rounded bg-white/10">High‑contrast: {highContrast?"On":"Off"}</span>
              <span className="px-2 py-1 rounded bg-white/10">Reduced motion: {reducedMotion?"On":"Off"}</span>
              <span className="px-2 py-1 rounded bg-white/10">Particles: {highContrast?"Off":"On"}</span>
            </div>
            <div className="text-xs opacity-70 mt-2">Toggle up top to test compliance; specular bloom softens automatically.</div>
          </div>
        </section>

        <footer className="mt-8 text-xs opacity-70">
          No PII anywhere. All IDs are glyph‑based. This demo is an explanatory artifact — wire it to your real Lab kit when ready.
        </footer>
      </main>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
