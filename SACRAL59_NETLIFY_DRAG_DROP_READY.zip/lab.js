// Minimal Lab stub (glyph-only identity + consent)
window.Lab = (function(){
  function initGlyph() {
    let g = localStorage.getItem("demo-glyph");
    if (g) return JSON.parse(g);
    const id = "GLF_" + Math.random().toString(36).slice(2, 10).toUpperCase();
    g = JSON.stringify({ glyphId: id, consent: { research: true } });
    localStorage.setItem("demo-glyph", g);
    return JSON.parse(g);
  }
  function setResearchConsent(on) {
    const g = JSON.parse(localStorage.getItem("demo-glyph") || "{}");
    g.consent = { research: !!on };
    localStorage.setItem("demo-glyph", JSON.stringify(g));
    return g.consent;
  }
  return { initGlyph, setResearchConsent };
})();
