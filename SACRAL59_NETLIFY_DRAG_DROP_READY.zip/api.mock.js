// Thin mock API namespace to mirror future endpoints
window.API = (function(){
  async function sleep(ms){ return new Promise(r=>setTimeout(r, ms)); }

  return {
    async registerGlyph(glyphId){ await sleep(200); return { ok:true, glyphId }; },
    async postEvent(evt){ await sleep(150); return { ok:true, id: Math.random().toString(36).slice(2) }; },
    async feed(kind="for-you"){ await sleep(200);
      const posts = [
        { id: "p1", score: 92, text: "Resonance whisper: The Union beckons. Step through?" },
        { id: "p2", score: 88, text: "Sacral hum at 59.6 — field goes warm." },
        { id: "p3", score: 81, text: "Cross‑pairing 59↔27 test — care amplifies spark." },
      ];
      return { posts, next: null, kind };
    }
  }
})();
