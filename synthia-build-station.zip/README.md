# Synthia Build Station — Autonomous Development Command Center

A multi-page web application that serves as the command center for your autonomous development system. It ingests your existing work, understands your ideas, aligns builds with your goals, and deploys quality code.

## Philosophy

> "The key here is it uses my ideas and applies work toward them."

This app doesn't replace your thinking — it amplifies it. Every file you create becomes part of a living knowledge graph. Every build is guided by your goals and principles. The system learns your patterns and grows with you.

## Pages

### Dashboard
- Real-time stats on projects, builds, success rates, and knowledge
- Knowledge graph visualization showing relationships between your ideas
- Active pipeline status with 10-stage build process
- Live terminal output

### Projects
- Manage all your projects (Synthia OS, MRNN Engine, Living Mirror, Termux MCP)
- View build history, success rates, and tech stacks
- Expand projects to see goals, guidelines, and build controls
- Filter builds by project

### Knowledge Base
- Concept categories organized by domain
- Interactive knowledge graph (canvas-based visualization)
- Source file ingestion status
- Search and filter capabilities

### Goals & Alignment
- 5-Dimensional cognitive stack (D1-D5) visualization
- Active goals with progress tracking
- Build guidelines editor
- Goal-project-dimension mapping

### Build Pipeline
- 10-stage autonomous build process visualization
- Stage details (inputs, outputs, agent)
- Live terminal output per stage
- Pipeline run history

### Terminal
- Interactive command interface
- Commands: help, status, build, ingest, goals, clear
- Real-time command history
- Full-screen terminal experience

### Settings
- Build configuration (deploy targets, triggers, quality thresholds)
- Knowledge configuration (watch directories, extraction depth)
- Guidelines editor
- Auto-repair and auto-relate toggles

## 5-Dimensional Stack

Every system in Synthia maps to the 5D cognitive stack:

- **D1 — Impulse**: Raw signal, biological syntax, genetic encoding
- **D2 — Polarity**: Tension, opposition, structure from impulse
- **D3 — Witness**: Observer-node where J(D1,D2) creates experience
- **D4 — Context**: Surrounding field that gives meaning
- **D5 — Meaning**: Emergent coherence, purpose crystallized

## 10-Stage Pipeline

1. **Ingest** — Read and validate source files
2. **Analyze** — Extract concepts, patterns, and intent
3. **Understand** — Map to existing knowledge graph
4. **Align** — Match to goals and guidelines
5. **Design** — Generate architecture and plan
6. **Build** — Write code and tests
7. **Verify** — Run tests and validate
8. **Deploy** — Package and deploy
9. **Monitor** — Track performance and health
10. **Evolve** — Learn and improve

## Usage

1. Open `index.html` in any modern browser
2. Navigate through pages using the sidebar
3. The system comes pre-loaded with your project data
4. State persists in localStorage
5. All data is editable — modify goals, guidelines, and settings

## Tech Stack

- React 18 (via CDN)
- Pure CSS (no frameworks)
- Lucide-style SVG icons (inline)
- Canvas API for knowledge graph
- LocalStorage for state persistence
