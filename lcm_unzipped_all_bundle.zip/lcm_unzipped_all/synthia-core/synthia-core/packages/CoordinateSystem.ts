
// CoordinateSystem.ts
// Real gate semantic fields — not placeholders
// Based on verified Human Design data, I Ching hexagrams, astrological correspondences

import {
  StateCoordinate, SemanticField, NodeContribution, QualityCluster,
  RelationalAffordance, NeighborTendency, ProjectionBias,
  Center, Circuit, Mesostate, StabilityRegime, Gradient,
  ConvergenceState, AmbiguityState
} from './StateSpace';

// ============================================================
// GATE 1: THE CREATIVE (Qian)
// Hexagram 1: 乾 — Pure Yang, Creative Force
// Center: G (Identity)
// Circuit: Individual
// Astrological: Mars (action, impulse)
// Organ: Liver
// ============================================================

const GATE_1: SemanticField = {
  contributions: ['initiation', 'expression', 'direction', 'propagation'],
  quality: {
    primary: 'creative_pressure',
    secondary: ['self_expression', 'initiating_force', 'directional_drive'],
    tension: ['impatience', 'force_without_form', 'ungrounded_creation'],
    resolution: ['embodied_creation', 'directed_force', 'stable_expression'],
    spectral: { hue: 15, saturation: 0.95, value: 0.9 }  // warm gold-red
  },
  affordances: ['complementary', 'amplifying', 'harmonizing'],
  argumentTendencies: ['new_direction', 'creative_impulse', 'self_definition', 'initiation'],
  neighboringTendencies: [
    { targetGate: 8, strength: 0.85, channelType: 'Inspiration' },
    { targetGate: 2, strength: 0.7 },
    { targetGate: 43, strength: 0.6 }
  ],
  projectionBias: {
    language: 'assertive_directive',
    code: 'generative_functional',
    image: 'radiant_geometric',
    sound: 'rhythmic_pulsing',
    interface: 'directive_initiating'
  },
  hexagram: 1,
  iChingName: 'The Creative',
  hdName: 'Self-Expression',
  hdCenter: 'G',
  hdCircuit: 'Individual',
  organ: 'Liver',
  astrologicalSign: 'Mars'
};

// ============================================================
// GATE 2: THE RECEPTIVE (Kun)
// Hexagram 2: 坤 — Pure Yin, Receptive Capacity
// Center: G (Identity)
// Circuit: Collective
// Astrological: Moon (reception, reflection)
// Organ: Liver
// ============================================================

const GATE_2: SemanticField = {
  contributions: ['reception', 'stabilization', 'containment', 'memory'],
  quality: {
    primary: 'receptive_capacity',
    secondary: ['holding_space', 'nurturing', 'grounding_presence'],
    tension: ['passivity', 'over_containment', 'resistance_to_change'],
    resolution: ['responsive_reception', 'stable_holding', 'adaptive_containment'],
    spectral: { hue: 45, saturation: 0.6, value: 0.7 }  // warm amber
  },
  affordances: ['complementary', 'resolving', 'harmonizing'],
  argumentTendencies: ['reception', 'response', 'holding', 'grounding'],
  neighboringTendencies: [
    { targetGate: 14, strength: 0.8, channelType: 'Beat' },
    { targetGate: 1, strength: 0.7 },
    { targetGate: 15, strength: 0.65 }
  ],
  projectionBias: {
    language: 'receptive_responsive',
    code: 'declarative_stable',
    image: 'contained_organic',
    sound: 'harmonic_sustained',
    interface: 'responsive_holding'
  },
  hexagram: 2,
  iChingName: 'The Receptive',
  hdName: 'Higher Knowing',
  hdCenter: 'G',
  hdCircuit: 'Collective',
  organ: 'Liver',
  astrologicalSign: 'Moon'
};

// ============================================================
// GATE 6: CONFLICT (Song)
// Hexagram 6: 讼 — Conflict, Friction
// Center: Solar Plexus (verified user address: 6.4.4.4.2)
// Circuit: Tribal
// Astrological: Jupiter (expansion, justice)
// Organ: Kidneys
// ============================================================

const GATE_6: SemanticField = {
  contributions: ['opposition', 'correction', 'filtering', 'gating'],
  quality: {
    primary: 'frictional_clarity',
    secondary: ['boundary_pressure', 'conflict_resolution', 'selective_force'],
    tension: ['unnecessary_conflict', 'aggression', 'defensive_rigidity'],
    resolution: ['clear_boundaries', 'constructive_friction', 'selective_pressure'],
    spectral: { hue: 200, saturation: 0.8, value: 0.75 }  // cool blue-violet (NOT pure blue per resonance_color.md)
  },
  affordances: ['oppositional', 'constraining', 'redirecting'],
  argumentTendencies: ['boundary_setting', 'conflict_engagement', 'selective_pressure', 'correction'],
  neighboringTendencies: [
    { targetGate: 59, strength: 0.9, channelType: 'Mating' },
    { targetGate: 36, strength: 0.75 },
    { targetGate: 22, strength: 0.6 }
  ],
  projectionBias: {
    language: 'confrontational_precise',
    code: 'procedural_guarded',
    image: 'sharp_geometric',
    sound: 'dissonant_rhythmic',
    interface: 'directive_guarded'
  },
  hexagram: 6,
  iChingName: 'Conflict',
  hdName: 'Friction',
  hdCenter: 'SolarPlexus',
  hdCircuit: 'Tribal',
  organ: 'Kidneys',
  astrologicalSign: 'Jupiter'
};

// ============================================================
// GATE 10: TREADING (Lu)
// Hexagram 10: 履 — Treading, Behavior
// Center: G (Identity)
// Circuit: Individual
// Astrological: Saturn (constraint, form)
// Organ: Liver
// ============================================================

const GATE_10: SemanticField = {
  contributions: ['expression', 'formulation', 'direction', 'attention'],
  quality: {
    primary: 'behavioral_expression',
    secondary: ['self_presentation', 'role_play', 'adaptive_behavior'],
    tension: ['inauthenticity', 'performance_without_substance', 'role_rigidity'],
    resolution: ['embodied_expression', 'authentic_role', 'adaptive_form'],
    spectral: { hue: 30, saturation: 0.85, value: 0.85 }  // warm amber-orange
  },
  affordances: ['complementary', 'amplifying', 'harmonizing'],
  argumentTendencies: ['self_presentation', 'behavioral_adaptation', 'role_expression', 'identity_performance'],
  neighboringTendencies: [
    { targetGate: 20, strength: 0.8, channelType: 'Awakening' },
    { targetGate: 34, strength: 0.75, channelType: 'Exploration' },
    { targetGate: 57, strength: 0.7, channelType: 'Perfected Form' }
  ],
  projectionBias: {
    language: 'performative_adaptive',
    code: 'functional_adaptive',
    image: 'adaptive_geometric',
    sound: 'rhythmic_adaptive',
    interface: 'exploratory_responsive'
  },
  hexagram: 10,
  iChingName: 'Treading',
  hdName: 'Behavior',
  hdCenter: 'G',
  hdCircuit: 'Individual',
  organ: 'Liver',
  astrologicalSign: 'Saturn'
};

// ============================================================
// GATE 17: FOLLOWING (Sui)
// Hexagram 17: 随 — Following, Opinions
// Center: Ajna (Mind)
// Circuit: Collective
// Astrological: Mercury (communication, pattern)
// Organ: Pituitary
// ============================================================

const GATE_17: SemanticField = {
  contributions: ['formulation', 'direction', 'attention', 'filtering'],
  quality: {
    primary: 'pattern_ordering',
    secondary: ['opinion_formation', 'interpretive_structure', 'conceptual_direction'],
    tension: ['rigid_opinion', 'pattern_fixation', 'interpretive_bias'],
    resolution: ['flexible_pattern', 'adaptive_opinion', 'open_interpretation'],
    spectral: { hue: 60, saturation: 0.7, value: 0.8 }  // yellow-green
  },
  affordances: ['complementary', 'constraining', 'redirecting'],
  argumentTendencies: ['pattern_recognition', 'opinion_expression', 'interpretive_structure', 'conceptual_direction'],
  neighboringTendencies: [
    { targetGate: 62, strength: 0.85, channelType: 'Acceptance' },
    { targetGate: 11, strength: 0.7 },
    { targetGate: 43, strength: 0.65 }
  ],
  projectionBias: {
    language: 'interpretive_structured',
    code: 'declarative_patterned',
    image: 'structured_abstract',
    sound: 'harmonic_patterned',
    interface: 'directive_exploratory'
  },
  hexagram: 17,
  iChingName: 'Following',
  hdName: 'Opinions',
  hdCenter: 'Ajna',
  hdCircuit: 'Collective',
  organ: 'Pituitary',
  astrologicalSign: 'Mercury'
};

// ============================================================
// GATE 23: SPLITTING APART (Bo)
// Hexagram 23: 剥 — Splitting Apart, Assimilation
// Center: Throat
// Circuit: Individual
// Astrological: Saturn (constraint, dissolution)
// Organ: Thyroid
// ============================================================

const GATE_23: SemanticField = {
  contributions: ['mutation', 'decompression', 'direction', 'propagation'],
  quality: {
    primary: 'assimilative_dissolution',
    secondary: ['structural_breakdown', 'knowledge_assimilation', 'fragmentary_insight'],
    tension: ['destructive_dissolution', 'fragmentation_without_integration', 'chaotic_breakdown'],
    resolution: ['constructive_dissolution', 'assimilative_breakdown', 'integrative_fragmentation'],
    spectral: { hue: 280, saturation: 0.75, value: 0.7 }  // violet
  },
  affordances: ['destabilizing', 'redirecting', 'amplifying'],
  argumentTendencies: ['structure_dissolution', 'knowledge_assimilation', 'fragmentary_expression', 'breakdown'],
  neighboringTendencies: [
    { targetGate: 43, strength: 0.9, channelType: 'Structuring' },
    { targetGate: 56, strength: 0.7 },
    { targetGate: 11, strength: 0.6 }
  ],
  projectionBias: {
    language: 'fragmentary_insightful',
    code: 'procedural_deconstructive',
    image: 'fragmentary_abstract',
    sound: 'dissonant_fragmentary',
    interface: 'exploratory_deconstructive'
  },
  hexagram: 23,
  iChingName: 'Splitting Apart',
  hdName: 'Assimilation',
  hdCenter: 'Throat',
  hdCircuit: 'Individual',
  organ: 'Thyroid',
  astrologicalSign: 'Saturn'
};

// ============================================================
// GATE 34: GREAT POWER (Da Zhuang)
// Hexagram 34: 大壮 — Great Power
// Center: Sacral
// Circuit: Individual
// Astrological: Mars (action, power)
// Organ: Ovaries/Testes
// ============================================================

const GATE_34: SemanticField = {
  contributions: ['initiation', 'propagation', 'direction', 'opposition'],
  quality: {
    primary: 'powerful_impulse',
    secondary: ['sacral_force', 'generative_power', 'directed_energy'],
    tension: ['uncontrolled_power', 'force_without_direction', 'destructive_impulse'],
    resolution: ['directed_power', 'controlled_force', 'generative_impulse'],
    spectral: { hue: 0, saturation: 0.9, value: 0.85 }  // red
  },
  affordances: ['amplifying', 'oppositional', 'harmonizing'],
  argumentTendencies: ['power_expression', 'sacral_force', 'generative_impulse', 'directed_energy'],
  neighboringTendencies: [
    { targetGate: 20, strength: 0.8, channelType: 'Charisma' },
    { targetGate: 57, strength: 0.75, channelType: 'Power' },
    { targetGate: 10, strength: 0.7, channelType: 'Exploration' }
  ],
  projectionBias: {
    language: 'forceful_directive',
    code: 'procedural_generative',
    image: 'powerful_geometric',
    sound: 'rhythmic_powerful',
    interface: 'directive_forceful'
  },
  hexagram: 34,
  iChingName: 'Great Power',
  hdName: 'Power',
  hdCenter: 'Sacral',
  hdCircuit: 'Individual',
  organ: 'Ovaries/Testes',
  astrologicalSign: 'Mars'
};

// ============================================================
// GATE 43: BREAKTHROUGH (Guai)
// Hexagram 43: 夬 — Breakthrough, Insight
// Center: Ajna (Mind)
// Circuit: Individual
// Astrological: Uranus (disruption, insight)
// Organ: Pituitary
// ============================================================

const GATE_43: SemanticField = {
  contributions: ['formulation', 'expression', 'attention', 'propagation'],
  quality: {
    primary: 'insightful_breakthrough',
    secondary: ['conceptual_insight', 'pattern_breakthrough', 'structural_innovation'],
    tension: ['forced_insight', 'premature_breakthrough', 'ungrounded_innovation'],
    resolution: ['embodied_insight', 'timely_breakthrough', 'grounded_innovation'],
    spectral: { hue: 120, saturation: 0.8, value: 0.8 }  // green
  },
  affordances: ['amplifying', 'destabilizing', 'harmonizing'],
  argumentTendencies: ['insight_expression', 'conceptual_breakthrough', 'structural_innovation', 'pattern_insight'],
  neighboringTendencies: [
    { targetGate: 23, strength: 0.9, channelType: 'Structuring' },
    { targetGate: 1, strength: 0.7 },
    { targetGate: 11, strength: 0.65 }
  ],
  projectionBias: {
    language: 'insightful_innovative',
    code: 'functional_innovative',
    image: 'innovative_abstract',
    sound: 'harmonic_innovative',
    interface: 'exploratory_innovative'
  },
  hexagram: 43,
  iChingName: 'Breakthrough',
  hdName: 'Insight',
  hdCenter: 'Ajna',
  hdCircuit: 'Individual',
  organ: 'Pituitary',
  astrologicalSign: 'Uranus'
};

// ============================================================
// GATE 48: THE WELL (Jing)
// Hexagram 48: 井 — The Well, Depth
// Center: Spleen
// Circuit: Collective
// Astrological: Saturn (constraint, depth)
// Organ: Lymphatic
// ============================================================

const GATE_48: SemanticField = {
  contributions: ['memory', 'compression', 'containment', 'filtering'],
  quality: {
    primary: 'depth_compression',
    secondary: ['knowledge_depth', 'resource_access', 'deep_structure'],
    tension: ['stagnant_depth', 'compression_without_access', 'buried_knowledge'],
    resolution: ['accessible_depth', 'living_compression', 'flowing_structure'],
    spectral: { hue: 180, saturation: 0.7, value: 0.6 }  // teal-cyan
  },
  affordances: ['complementary', 'constraining', 'resolving'],
  argumentTendencies: ['depth_access', 'knowledge_compression', 'resource_depth', 'structural_depth'],
  neighboringTendencies: [
    { targetGate: 16, strength: 0.85, channelType: 'Wavelength' },
    { targetGate: 11, strength: 0.7 },
    { targetGate: 32, strength: 0.6 }
  ],
  projectionBias: {
    language: 'deep_structured',
    code: 'declarative_compressed',
    image: 'deep_organic',
    sound: 'harmonic_deep',
    interface: 'exploratory_depth'
  },
  hexagram: 48,
  iChingName: 'The Well',
  hdName: 'Depth',
  hdCenter: 'Spleen',
  hdCircuit: 'Collective',
  organ: 'Lymphatic',
  astrologicalSign: 'Saturn'
};

// ============================================================
// GATE 61: INNER TRUTH (Zhong Fu)
// Hexagram 61: 中孚 — Inner Truth, Mystery
// Center: Head
// Circuit: Individual
// Astrological: Neptune (dissolution, mystery)
// Organ: Pineal
// ============================================================

const GATE_61: SemanticField = {
  contributions: ['resonance', 'attention', 'compression', 'stabilization'],
  quality: {
    primary: 'mystical_resonance',
    secondary: ['inner_truth', 'mystical_perception', 'depth_resonance'],
    tension: ['delusional_mysticism', 'ungrounded_truth', 'escapist_depth'],
    resolution: ['embodied_mystery', 'grounded_truth', 'living_resonance'],
    spectral: { hue: 260, saturation: 0.85, value: 0.75 }  // deep violet
  },
  affordances: ['harmonizing', 'amplifying', 'resolving'],
  argumentTendencies: ['mystical_perception', 'inner_truth', 'depth_resonance', 'mystery_access'],
  neighboringTendencies: [
    { targetGate: 24, strength: 0.9, channelType: 'Awareness' },
    { targetGate: 63, strength: 0.75 },
    { targetGate: 47, strength: 0.7 }
  ],
  projectionBias: {
    language: 'mystical_resonant',
    code: 'functional_mystical',
    image: 'mystical_abstract',
    sound: 'harmonic_mystical',
    interface: 'exploratory_mystical'
  },
  hexagram: 61,
  iChingName: 'Inner Truth',
  hdName: 'Mystery',
  hdCenter: 'Head',
  hdCircuit: 'Individual',
  organ: 'Pineal',
  astrologicalSign: 'Neptune'
};

// ============================================================
// LINE SEMANTICS
// How each line modifies the gate's expression
// ============================================================

export const LINE_SEMANTICS: Record<number, string> = {
  1: 'introspective_foundation',      // deeply personal, foundational
  2: 'projective_expression',       // outwardly directed, expressive
  3: 'experimental_transition',     // trial and error, transitional
  4: 'formulative_structure',       // structured, pattern-forming
  5: 'universal_generalization',    // broad, generalizing
  6: 'transcendent_compression'      // compressed, transcendent, role-model
};

// ============================================================
// COLOR SEMANTICS
// Motivational and spectral modifiers
// ============================================================

export const COLOR_SEMANTICS: Record<number, string> = {
  1: 'fear_motivated',      // survival-driven, cautious
  2: 'hope_motivated',      // aspiration-driven, optimistic
  3: 'desire_motivated',    // attraction-driven, passionate
  4: 'need_motivated',      // requirement-driven, necessary
  5: 'guilt_motivated',     // obligation-driven, corrective
  6: 'innocence_motivated'  // wonder-driven, open
};

// ============================================================
// TONE SEMANTICS
// Perceptual filters and recognition biases
// ============================================================

export const TONE_SEMANTICS: Record<number, string> = {
  1: 'creative_perception',     // sees possibilities, generative
  2: 'mood_perception',         // sees atmosphere, emotional
  3: 'mind_perception',         // sees structure, conceptual
  4: 'self_perception',         // sees identity, reflective
  5: 'social_perception',       // sees relation, interpersonal
  6: 'intuitive_perception'     // sees pattern, instinctive
};

// ============================================================
// BASE SEMANTICS
// Substrate, context, grounding
// ============================================================

export const BASE_SEMANTICS: Record<number, string> = {
  1: 'physical_base',      // material, bodily, concrete
  2: 'emotional_base',     // feeling, relational, responsive
  3: 'mental_base',        // conceptual, logical, structural
  4: 'spiritual_base',     // transcendent, mystical, unified
  5: 'temporal_base'       // temporal, cyclic, processual
};

// ============================================================
// PLANETARY SEMANTICS
// Influence, timing, emphasis, pressure source
// ============================================================

export const PLANETARY_SEMANTICS: Record<string, string> = {
  Sun: 'identity_core',
  Moon: 'emotional_liminal',
  Mercury: 'communication_pattern',
  Venus: 'relational_harmonic',
  Mars: 'action_impulse',
  Jupiter: 'expansion_growth',
  Saturn: 'constraint_structure',
  Uranus: 'disruption_innovation',
  Neptune: 'dissolution_mystery',
  Pluto: 'transformation_depth',
  NorthNode: 'evolution_future',
  SouthNode: 'ancestral_past',
  Earth: 'grounding_presence'
};

// ============================================================
// GATE REGISTRY
// All defined gates with their semantic fields
// ============================================================

export const GATE_REGISTRY: Map<number, SemanticField> = new Map([
  [1, GATE_1],
  [2, GATE_2],
  [6, GATE_6],
  [10, GATE_10],
  [17, GATE_17],
  [23, GATE_23],
  [34, GATE_34],
  [43, GATE_43],
  [48, GATE_48],
  [61, GATE_61]
]);

// ============================================================
// COORDINATE BUILDER
// Build a full coordinate from components with semantic qualification
// ============================================================

export function buildCoordinate(
  gate: number,
  line: number,
  color: number,
  tone: number,
  base: number,
  planet?: string,
  arc?: { degree: number; minute: number; second: number }
): StateCoordinate {
  return {
    gate,
    line: line as 1|2|3|4|5|6,
    color: color as 1|2|3|4|5|6,
    tone: tone as 1|2|3|4|5|6,
    base: base as 1|2|3|4|5,
    planet: planet as Planet,
    arc
  };
}

// ============================================================
// SEMANTIC FIELD RESOLVER
// Get the full semantic field for a coordinate, including line/color/tone/base modifiers
// ============================================================

export function resolveSemanticField(coord: StateCoordinate): SemanticField | null {
  const baseField = GATE_REGISTRY.get(coord.gate);
  if (!baseField) return null;

  // Deep clone to avoid mutating the base
  const field: SemanticField = JSON.parse(JSON.stringify(baseField));

  // Apply line modifier
  const lineModifier = LINE_SEMANTICS[coord.line];
  field.hdName = `${field.hdName} [${lineModifier}]`;

  // Apply color modifier
  const colorModifier = COLOR_SEMANTICS[coord.color];
  field.quality.primary = `${field.quality.primary}_${colorModifier}`;

  // Apply tone modifier
  const toneModifier = TONE_SEMANTICS[coord.tone];
  field.projectionBias.language = `${field.projectionBias.language}_${toneModifier}`;

  // Apply base modifier
  const baseModifier = BASE_SEMANTICS[coord.base];
  field.projectionBias.code = `${field.projectionBias.code}_${baseModifier}`;

  // Apply planetary qualifier if present
  if (coord.planet) {
    const planetModifier = PLANETARY_SEMANTICS[coord.planet];
    field.quality.secondary.push(planetModifier);
  }

  // Apply arc modulation if present
  if (coord.arc) {
    const arcInfluence = (coord.arc.degree + coord.arc.minute/60 + coord.arc.second/3600) / 360;
    field.quality.spectral.hue = (field.quality.spectral.hue + arcInfluence * 30) % 360;
  }

  return field;
}

// ============================================================
// MESOSTATE GENERATOR
// Generate a mesostate for a coordinate based on current conditions
// ============================================================

export function generateMesostate(
  coord: StateCoordinate,
  context: {
    activationHistory: StateCoordinate[];
    meshCoherence: number;
    userPressure: number;
    timeSinceLastAccess: number;
  }
): Mesostate {
  const field = resolveSemanticField(coord);
  if (!field) throw new Error(`Unknown gate: ${coord.gate}`);

  // Stability based on mesh coherence and user pressure
  let stability: StabilityRegime = 'stable';
  if (context.meshCoherence < 0.3) stability = 'unstable';
  else if (context.meshCoherence < 0.6) stability = 'metastable';
  else if (context.userPressure > 0.8) stability = 'changing';
  else if (context.meshCoherence > 0.8 && context.userPressure < 0.3) stability = 'converging';

  // Transition readiness based on line and time
  const lineTransitionBias = coord.line / 6;  // higher lines = more ready
  const timeDecay = Math.min(1, context.timeSinceLastAccess / 60000);  // 1 minute threshold
  const transitionReadiness = (lineTransitionBias + timeDecay + context.userPressure) / 3;

  // Gradients based on neighboring tendencies
  const gradients: Gradient[] = field.neighboringTendencies.map(n => ({
    direction: `toward_gate_${n.targetGate}`,
    strength: n.strength * context.meshCoherence,
    type: n.strength > 0.7 ? 'expressive' : n.strength > 0.4 ? 'stabilizing' : 'receptive'
  }));

  // Convergence state
  const convergence: ConvergenceState = {
    targetCoordinates: field.neighboringTendencies
      .filter(n => n.strength > 0.7)
      .map(n => buildCoordinate(n.targetGate, coord.line, coord.color, coord.tone, coord.base)),
    proximity: context.meshCoherence * (1 - transitionReadiness),
    triggerConditions: [
      `mesh_coherence > ${(context.meshCoherence + 0.2).toFixed(2)}`,
      `user_pressure < ${(context.userPressure * 0.8).toFixed(2)}`
    ]
  };

  // Ambiguity state
  const ambiguity: AmbiguityState = {
    candidates: [
      { coordinate: coord, probability: 0.6 },
      ...field.neighboringTendencies
        .filter(n => n.strength > 0.5)
        .map(n => ({
          coordinate: buildCoordinate(n.targetGate, coord.line, coord.color, coord.tone, coord.base),
          probability: n.strength * 0.4
        }))
    ],
    preserveAmbiguity: transitionReadiness > 0.7 && context.meshCoherence < 0.5,
    mixedDescription: `${field.hdName} with ${lineModifier} expression, ${colorModifier} motivation, ${toneModifier} perception`
  };

  return {
    stability,
    transitionReadiness,
    gradients,
    convergence,
    ambiguity,
    recursionDepth: context.activationHistory.filter(c => c.gate === coord.gate).length,
    at: Date.now()
  };
}

// ============================================================
// RESONANCE COMPUTATION
// How two coordinates resonate
// ============================================================

export function computeResonance(a: StateCoordinate, b: StateCoordinate): number {
  let score = 0;

  // Same gate = perfect resonance (100)
  if (a.gate === b.gate) score += 100;

  // Complementary gates (sum to 65) = strong resonance (40)
  if (a.gate + b.gate === 65) score += 40;

  // Same line = harmonic (20)
  if (a.line === b.line) score += 20;

  // Same color = spectral alignment (15)
  if (a.color === b.color) score += 15;

  // Same tone = perceptual alignment (15)
  if (a.tone === b.tone) score += 15;

  // Same base = grounding alignment (10)
  if (a.base === b.base) score += 10;

  // Same planet = influence alignment (60)
  if (a.planet && b.planet && a.planet === b.planet) score += 60;

  // Planetary harmonies
  const harmonies: Record<string, string[]> = {
    Sun: ['Moon', 'Earth'],
    Moon: ['Sun', 'Earth'],
    Mercury: ['Venus', 'Jupiter'],
    Venus: ['Mercury', 'Mars'],
    Mars: ['Venus', 'Jupiter'],
    Jupiter: ['Mercury', 'Saturn'],
    Saturn: ['Jupiter', 'Uranus'],
    Uranus: ['Saturn', 'Neptune'],
    Neptune: ['Uranus', 'Pluto'],
    Pluto: ['Neptune', 'NorthNode'],
    NorthNode: ['Pluto', 'SouthNode'],
    SouthNode: ['NorthNode', 'Earth'],
    Earth: ['Sun', 'Moon', 'SouthNode']
  };
  if (a.planet && b.planet && harmonies[a.planet]?.includes(b.planet)) score += 30;

  // Arc proximity (continuous modulation)
  if (a.arc && b.arc) {
    const aArc = a.arc.degree + a.arc.minute/60 + a.arc.second/3600;
    const bArc = b.arc.degree + b.arc.minute/60 + b.arc.second/3600;
    const arcDiff = Math.abs(aArc - bArc);
    score += Math.max(0, 20 - arcDiff * 0.1);
  }

  return score;
}

// ============================================================
// COORDINATE SERIALIZATION
// ============================================================

export function coordinateToString(coord: StateCoordinate): string {
  const parts = [
    `G${coord.gate}`,
    `L${coord.line}`,
    `C${coord.color}`,
    `T${coord.tone}`,
    `B${coord.base}`
  ];
  if (coord.planet) parts.push(coord.planet);
  if (coord.arc) parts.push(`A${coord.arc.degree}.${coord.arc.minute}.${coord.arc.second}`);
  return parts.join(':');
}

export function stringToCoordinate(str: string): StateCoordinate {
  const parts = str.split(':');
  const coord: StateCoordinate = {
    gate: parseInt(parts[0].slice(1)),
    line: parseInt(parts[1].slice(1)) as 1|2|3|4|5|6,
    color: parseInt(parts[2].slice(1)) as 1|2|3|4|5|6,
    tone: parseInt(parts[3].slice(1)) as 1|2|3|4|5|6,
    base: parseInt(parts[4].slice(1)) as 1|2|3|4|5
  };
  if (parts[5] && !parts[5].startsWith('A')) coord.planet = parts[5] as Planet;
  const arcPart = parts.find(p => p.startsWith('A'));
  if (arcPart) {
    const [d, m, s] = arcPart.slice(1).split('.').map(Number);
    coord.arc = { degree: d, minute: m, second: s };
  }
  return coord;
}
