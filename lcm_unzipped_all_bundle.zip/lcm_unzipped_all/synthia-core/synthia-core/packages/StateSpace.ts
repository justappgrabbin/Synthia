
// StateSpace.ts
// The ontological constitution of MESSY
// All possible forms exist as latent structure before expression

// ============================================================
// LAYER 1: CANONICAL COORDINATE SCHEMA
// ============================================================

export interface StateCoordinate {
  gate: number;        // 1-64, hexagram node address
  line: 1 | 2 | 3 | 4 | 5 | 6;  // local role / stance / posture
  color: 1 | 2 | 3 | 4 | 5 | 6;  // motivational / spectral modifier
  tone: 1 | 2 | 3 | 4 | 5 | 6;   // perceptual filter / recognition bias
  base: 1 | 2 | 3 | 4 | 5;       // substrate / context / grounding
  planet?: Planet;      // influence / timing / emphasis / pressure source
  arc?: ArcPosition;    // fine placement / modulation / threshold proximity
}

export type Planet = 
  | 'Sun' | 'Moon' | 'Mercury' | 'Venus' | 'Mars' 
  | 'Jupiter' | 'Saturn' | 'Uranus' | 'Neptune' | 'Pluto'
  | 'NorthNode' | 'SouthNode' | 'Earth';

export interface ArcPosition {
  degree: number;   // 0-359, coarse local placement
  minute: number;   // 0-59, finer placement refinement
  second: number;   // 0-59, highly specific local coordinate
}

// ============================================================
// LAYER 2: SEMANTIC FIELD
// What lives at each coordinate — not just a label
// ============================================================

export interface SemanticField {
  // Intrinsic node contributions (from NODE_FUNCTIONS.md)
  contributions: NodeContribution[];

  // Quality cluster — how this coordinate "feels" in the field
  quality: QualityCluster;

  // Relational affordances — what kinds of relations this node tends to form
  affordances: RelationalAffordance[];

  // Possible argument tendencies — what this node tends to act upon or receive
  argumentTendencies: string[];

  // Neighboring tendencies — which gates/lines this tends to complete channels with
  neighboringTendencies: NeighborTendency[];

  // Projection bias — how this coordinate expresses into different media
  projectionBias: ProjectionBias;

  // I Ching correspondence
  hexagram: number;  // 1-64, same as gate
  iChingName: string;

  // Human Design correspondence
  hdName: string;
  hdCenter: Center;
  hdCircuit: Circuit;

  // Biological correspondence
  organ: string;

  // Astrological correspondence
  astrologicalSign: string;
}

export type NodeContribution =
  | 'initiation' | 'reception' | 'pressure' | 'response'
  | 'stabilization' | 'mutation' | 'expression' | 'formulation'
  | 'correction' | 'attraction' | 'repulsion' | 'gating'
  | 'memory' | 'compression' | 'decompression' | 'direction'
  | 'attention' | 'resonance' | 'filtering' | 'propagation'
  | 'opposition' | 'rhythm' | 'timing' | 'salience' | 'containment' | 'opening';

export interface QualityCluster {
  // Primary quality — the dominant "feel"
  primary: string;

  // Secondary qualities — supporting tones
  secondary: string[];

  // Tension qualities — what this creates when opposed
  tension: string[];

  // Resolution qualities — what this resolves toward
  resolution: string[];

  // Spectral position — where this sits in the color/tone space
  spectral: {
    hue: number;      // 0-360
    saturation: number;  // 0-1
    value: number;      // 0-1
  };
}

export type RelationalAffordance =
  | 'complementary' | 'oppositional' | 'amplifying' | 'constraining'
  | 'resolving' | 'destabilizing' | 'harmonizing' | 'redirecting';

export interface NeighborTendency {
  targetGate: number;
  targetLine?: number;
  strength: number;  // 0-1, likelihood of channel formation
  channelType?: string;  // e.g., "Inspiration", "Logic", "Mutation"
}

export interface ProjectionBias {
  // How this coordinate tends to express into each medium
  language: string;    // e.g., "assertive", "questioning", "narrative"
  code: string;       // e.g., "procedural", "functional", "declarative"
  image: string;      // e.g., "geometric", "organic", "abstract"
  sound: string;      // e.g., "rhythmic", "harmonic", "dissonant"
  interface: string;  // e.g., "directive", "exploratory", "responsive"
}

export type Center = 
  | 'Head' | 'Ajna' | 'Throat' | 'G' | 'Heart' 
  | 'Sacral' | 'SolarPlexus' | 'Spleen' | 'Root';

export type Circuit = 
  | 'Individual' | 'Collective' | 'Tribal' | 'Integration';

// ============================================================
// LAYER 3: MESOSTATE MODEL
// The unstable, converging, or changing regime within a state
// ============================================================

export interface Mesostate {
  // Current stability condition
  stability: StabilityRegime;

  // Transition readiness — how close to changing
  transitionReadiness: number;  // 0-1

  // Active gradients — internal directional forces
  gradients: Gradient[];

  // Convergence state — what this is resolving toward
  convergence: ConvergenceState;

  // Ambiguity — unresolved mixed state
  ambiguity: AmbiguityState;

  // Recursion depth — how many times this has been revisited
  recursionDepth: number;

  // Timestamp
  at: number;
}

export type StabilityRegime =
  | 'stable'        // firmly in this macrostate
  | 'metastable'    // temporarily held but ready to shift
  | 'changing'      // actively in transition
  | 'unstable'      // high sensitivity to perturbation
  | 'converging';   // resolving toward new stability

export interface Gradient {
  direction: string;     // e.g., "toward_gate_23", "away_from_pressure"
  strength: number;      // 0-1
  type: 'expressive' | 'receptive' | 'stabilizing' | 'destabilizing';
}

export interface ConvergenceState {
  // What state this is trending toward
  targetCoordinates: StateCoordinate[];

  // How close to convergence
  proximity: number;  // 0-1

  // What would trigger full convergence
  triggerConditions: string[];
}

export interface AmbiguityState {
  // Multiple valid interpretations active simultaneously
  candidates: {
    coordinate: StateCoordinate;
    probability: number;
  }[];

  // Whether ambiguity is preserved or forced to resolve
  preserveAmbiguity: boolean;

  // Mixed state description
  mixedDescription: string;
}

// ============================================================
// LAYER 4: STATE REGION
// A macrostate (gate/hexagram) as a bounded region with internal structure
// ============================================================

export interface StateRegion {
  // Identity
  gate: number;
  hexagram: number;
  iChingName: string;
  hdName: string;

  // The semantic field at this macrostate level
  semanticField: SemanticField;

  // Internal coordinates that exist within this region
  // Each line/color/tone/base combination is a valid microstate
  microstates: Map<string, Microstate>;  // key = "line:color:tone:base"

  // Boundaries and neighboring regions
  neighbors: {
    gate: number;
    boundaryType: 'smooth' | 'sharp' | 'permeable' | 'resonant';
    transitionLikelihood: number;
  }[];

  // Stable interior zones
  stableZones: StableZone[];

  // Sensitive transition bands
  transitionBands: TransitionBand[];

  // Instability ridges
  instabilityRidges: InstabilityRidge[];
}

export interface Microstate {
  coordinate: StateCoordinate;
  semanticField: SemanticField;  // qualified by line/color/tone/base
  mesostate: Mesostate;

  // Local gradients within this microstate
  localGradients: Gradient[];

  // Expressive delivery — how this presents outwardly
  expressiveDelivery: string;

  // Stability condition
  stability: number;  // 0-1
}

export interface StableZone {
  name: string;
  coordinates: StateCoordinate[];
  description: string;
}

export interface TransitionBand {
  name: string;
  coordinates: StateCoordinate[];
  description: string;
  triggerConditions: string[];
}

export interface InstabilityRidge {
  name: string;
  coordinates: StateCoordinate[];
  description: string;
  sensitivity: number;  // 0-1
}

// ============================================================
// LAYER 5: ACTIVATION & PROPAGATION HOOKS
// How coordinates activate and propagate through the mesh
// ============================================================

export interface ActivationHook {
  // What triggers this activation
  trigger: ActivationTrigger;

  // What gets activated
  target: StateCoordinate;

  // Activation strength
  strength: number;  // 0-1

  // Propagation rules
  propagation: PropagationRule;

  // Convergence rules
  convergence: ConvergenceRule;

  // Projection rules
  projection: ProjectionRule;
}

export interface ActivationTrigger {
  type: 'recognition' | 'generation' | 'convergence' | 'external' | 'recursion';
  source: string;  // what triggered it
  context: any;    // trigger-specific context
}

export interface PropagationRule {
  // Which dimensions to propagate through
  dimensionalFlow: ('D1' | 'D2' | 'D3' | 'D4' | 'D5')[];

  // How strength decays with depth
  decayFactor: number;  // 0-1, multiply by this each hop

  // Maximum propagation depth
  maxDepth: number;

  // Whether to form edges during propagation
  formEdges: boolean;

  // Edge weight threshold
  edgeThreshold: number;  // minimum resonance to form edge
}

export interface ConvergenceRule {
  // What kind of convergence this activation tends toward
  convergenceType: 'center' | 'channel' | 'organ' | 'projection';

  // Which center/channel/organ/projection target
  target: string;

  // Convergence threshold
  threshold: number;  // 0-1
}

export interface ProjectionRule {
  // Which media to project into
  media: ('language' | 'code' | 'image' | 'sound' | 'interface')[];

  // Projection style
  style: string;

  // Quality threshold for projection
  qualityThreshold: number;  // 0-1
}
