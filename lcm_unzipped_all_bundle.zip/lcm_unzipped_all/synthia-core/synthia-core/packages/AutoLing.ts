
// AutoLing.ts
// Klein 1968: "The AUTOLING System" — bidirectional semantic/syntactic production
// Same rule table drives both generation (coordinate -> surface) and recognition (surface -> coordinate)
// But now the "rules" are state-space coordinates, not flat string relations

import {
  StateCoordinate, SemanticField, Mesostate,
  GATE_REGISTRY, resolveSemanticField, buildCoordinate,
  computeResonance, coordinateToString, stringToCoordinate,
  generateMesostate, LINE_SEMANTICS, COLOR_SEMANTICS, TONE_SEMANTICS, BASE_SEMANTICS
} from './CoordinateSystem';
import { EventMesh } from './EventMesh';

// ============================================================
// RECOGNITION PATTERNS
// Surface strings -> candidate coordinates
// Not regex on flat strings — semantic pattern matching against gate fields
// ============================================================

interface RecognitionPattern {
  // What surface features trigger this pattern
  triggers: string[];  // keywords, phrases, structural markers

  // Which gates this pattern tends to activate
  targetGates: number[];

  // Confidence weight
  weight: number;

  // Line bias — which lines this pattern favors
  lineBias?: number[];

  // Color bias — which colors this pattern favors
  colorBias?: number[];

  // Tone bias — which tones this pattern favors
  toneBias?: number[];

  // Context modifiers — how surrounding text modifies confidence
  contextModifiers: {
    preceding: string[];  // words before trigger that boost confidence
    following: string[];   // words after trigger that boost confidence
  };
}

const RECOGNITION_PATTERNS: RecognitionPattern[] = [
  {
    triggers: ['create', 'make', 'build', 'generate', 'initiate', 'start', 'new'],
    targetGates: [1, 34, 43],
    weight: 0.9,
    lineBias: [1, 2, 4],  // introspective, projective, formulative
    colorBias: [3, 4],    // desire, need
    toneBias: [1, 3],     // creative, mind
    contextModifiers: {
      preceding: ['I want to', 'let's', 'we need'],
      following: ['something', 'new', 'from scratch']
    }
  },
  {
    triggers: ['receive', 'hold', 'contain', 'ground', 'stable', 'nurture', 'support'],
    targetGates: [2, 48],
    weight: 0.85,
    lineBias: [1, 5, 6],   // introspective, universal, transcendent
    colorBias: [1, 2],     // fear, hope
    toneBias: [2, 4],      // mood, self
    contextModifiers: {
      preceding: ['I need', 'can you', 'please'],
      following: ['me', 'us', 'together']
    }
  },
  {
    triggers: ['conflict', 'friction', 'boundary', 'correct', 'judge', 'select', 'filter'],
    targetGates: [6],
    weight: 0.95,
    lineBias: [4, 5, 6],   // formulative, universal, transcendent
    colorBias: [4, 5],      // need, guilt
    toneBias: [3, 5],       // mind, social
    contextModifiers: {
      preceding: ['there is', 'I feel', 'this is'],
      following: ['between', 'with', 'against']
    }
  },
  {
    triggers: ['behave', 'act', 'perform', 'role', 'adapt', 'present', 'express'],
    targetGates: [10],
    weight: 0.88,
    lineBias: [2, 4, 5],   // projective, formulative, universal
    colorBias: [3, 4, 6],  // desire, need, innocence
    toneBias: [1, 4, 5],   // creative, self, social
    contextModifiers: {
      preceding: ['I am', 'how do I', 'what is my'],
      following: ['myself', 'in this', 'now']
    }
  },
  {
    triggers: ['pattern', 'order', 'structure', 'organize', 'opinion', 'interpret', 'follow'],
    targetGates: [17],
    weight: 0.87,
    lineBias: [3, 4, 5],   // experimental, formulative, universal
    colorBias: [3, 5],      // desire, guilt
    toneBias: [3, 5],       // mind, social
    contextModifiers: {
      preceding: ['I think', 'the', 'this follows'],
      following: ['because', 'therefore', 'so']
    }
  },
  {
    triggers: ['break', 'insight', 'understand', 'see', 'realize', 'breakthrough', 'new idea'],
    targetGates: [23, 43],
    weight: 0.92,
    lineBias: [4, 5, 6],   // formulative, universal, transcendent
    colorBias: [4, 6],     // need, innocence
    toneBias: [1, 3, 6],   // creative, mind, intuitive
    contextModifiers: {
      preceding: ['suddenly', 'I see', 'now I'],
      following: ['that', 'how', 'why']
    }
  },
  {
    triggers: ['power', 'force', 'energy', 'drive', 'push', 'move', 'action'],
    targetGates: [34],
    weight: 0.9,
    lineBias: [1, 2, 4],   // introspective, projective, formulative
    colorBias: [3, 4],     // desire, need
    toneBias: [1, 2],      // creative, mood
    contextModifiers: {
      preceding: ['I feel', 'there is', 'let's'],
      following: ['forward', 'through', 'now']
    }
  },
  {
    triggers: ['depth', 'deep', 'well', 'source', 'access', 'knowledge', 'know'],
    targetGates: [48],
    weight: 0.86,
    lineBias: [1, 5, 6],   // introspective, universal, transcendent
    colorBias: [1, 4],     // fear, need
    toneBias: [3, 4, 6],   // mind, self, intuitive
    contextModifiers: {
      preceding: ['I know', 'the', 'from the'],
      following: ['of', 'within', 'inside']
    }
  },
  {
    triggers: ['truth', 'mystery', 'inner', 'resonance', 'feel', 'intuit', 'sense'],
    targetGates: [61],
    weight: 0.89,
    lineBias: [1, 4, 6],   // introspective, formulative, transcendent
    colorBias: [2, 6],     // hope, innocence
    toneBias: [4, 6],       // self, intuitive
    contextModifiers: {
      preceding: ['I sense', 'there is', 'the'],
      following: ['within', 'between', 'of']
    }
  }
];

// ============================================================
// GENERATION PATTERNS
// Coordinates -> surface realizations
// Not template strings — semantic field-driven expression
// ============================================================

interface GenerationPattern {
  // Which coordinate features trigger this generation pattern
  coordinateMatch: (coord: StateCoordinate, field: SemanticField) => boolean;

  // Generation function
  generate: (coord: StateCoordinate, field: SemanticField, mesostate: Mesostate) => string;

  // Media type
  media: 'language' | 'code' | 'image' | 'sound' | 'interface';
}

const GENERATION_PATTERNS: GenerationPattern[] = [
  {
    coordinateMatch: (coord, field) => field.contributions.includes('initiation'),
    generate: (coord, field, mesostate) => {
      const lineDesc = LINE_SEMANTICS[coord.line];
      const colorDesc = COLOR_SEMANTICS[coord.color];
      const toneDesc = TONE_SEMANTICS[coord.tone];
      const baseDesc = BASE_SEMANTICS[coord.base];

      if (mesostate.stability === 'stable') {
        return `Initiating from ${field.hdName} [${lineDesc}]: ${field.quality.primary} with ${colorDesc} motivation, ${toneDesc} perception, grounded in ${baseDesc}.`;
      } else if (mesostate.stability === 'changing') {
        return `Initiation in flux at ${field.hdName}: ${field.quality.tension[0]} transitioning toward ${field.quality.resolution[0]}.`;
      } else {
        return `${field.hdName} initiation potential [${lineDesc}]: ${mesostate.ambiguity.mixedDescription}`;
      }
    },
    media: 'language'
  },
  {
    coordinateMatch: (coord, field) => field.contributions.includes('reception'),
    generate: (coord, field, mesostate) => {
      const lineDesc = LINE_SEMANTICS[coord.line];
      const colorDesc = COLOR_SEMANTICS[coord.color];

      if (mesostate.stability === 'stable') {
        return `Receiving at ${field.hdName} [${lineDesc}]: ${field.quality.primary} with ${colorDesc} receptivity.`;
      } else {
        return `${field.hdName} reception [${lineDesc}]: ${mesostate.ambiguity.mixedDescription}`;
      }
    },
    media: 'language'
  },
  {
    coordinateMatch: (coord, field) => field.contributions.includes('opposition') || field.contributions.includes('correction'),
    generate: (coord, field, mesostate) => {
      const lineDesc = LINE_SEMANTICS[coord.line];
      const colorDesc = COLOR_SEMANTICS[coord.color];
      const toneDesc = TONE_SEMANTICS[coord.tone];

      if (mesostate.stability === 'stable') {
        return `Boundary clarity at ${field.hdName} [${lineDesc}]: ${field.quality.primary} with ${colorDesc} motivation, ${toneDesc} perception.`;
      } else if (mesostate.stability === 'changing') {
        return `Boundary reconfiguration at ${field.hdName}: ${field.quality.tension[0]} resolving toward ${field.quality.resolution[0]}.`;
      } else {
        return `${field.hdName} boundary potential [${lineDesc}]: ${mesostate.ambiguity.mixedDescription}`;
      }
    },
    media: 'language'
  },
  {
    coordinateMatch: (coord, field) => field.contributions.includes('formulation') || field.contributions.includes('expression'),
    generate: (coord, field, mesostate) => {
      const lineDesc = LINE_SEMANTICS[coord.line];
      const colorDesc = COLOR_SEMANTICS[coord.color];
      const toneDesc = TONE_SEMANTICS[coord.tone];

      return `Expressing ${field.hdName} [${lineDesc}]: ${field.quality.primary} through ${colorDesc} motivation, ${toneDesc} perception.`;
    },
    media: 'language'
  },
  {
    coordinateMatch: (coord, field) => field.contributions.includes('memory') || field.contributions.includes('compression'),
    generate: (coord, field, mesostate) => {
      const lineDesc = LINE_SEMANTICS[coord.line];
      const colorDesc = COLOR_SEMANTICS[coord.color];

      return `Accessing depth at ${field.hdName} [${lineDesc}]: ${field.quality.primary} with ${colorDesc} motivation.`;
    },
    media: 'language'
  },
  {
    coordinateMatch: (coord, field) => field.contributions.includes('resonance') || field.contributions.includes('attention'),
    generate: (coord, field, mesostate) => {
      const lineDesc = LINE_SEMANTICS[coord.line];
      const colorDesc = COLOR_SEMANTICS[coord.color];
      const toneDesc = TONE_SEMANTICS[coord.tone];

      return `Resonating ${field.hdName} [${lineDesc}]: ${field.quality.primary} through ${colorDesc} motivation, ${toneDesc} perception.`;
    },
    media: 'language'
  }
];

// ============================================================
// AUTOLING CLASS
// Bidirectional coordinate-level recognition and generation
// ============================================================

export interface AutoLingInput {
  mode: 'recognize' | 'generate';
  text?: string;           // for recognition
  coordinate?: StateCoordinate;  // for generation
  media?: 'language' | 'code' | 'image' | 'sound' | 'interface';
}

export interface AutoLingOutput {
  ok: boolean;
  mode: 'recognize' | 'generate';

  // For recognition: candidate coordinates with confidence
  candidates?: {
    coordinate: StateCoordinate;
    confidence: number;
    semanticField: SemanticField;
    mesostate: Mesostate;
  }[];

  // For generation: surface realization
  surface?: string;

  // For both: mesh activation payload
  activation?: {
    coordinate: StateCoordinate;
    strength: number;
    propagationTargets: StateCoordinate[];
  };

  error?: string;
}

export class AutoLing {
  private mesh: EventMesh;
  private activationHistory: StateCoordinate[] = [];

  constructor(mesh: EventMesh) {
    this.mesh = mesh;
  }

  /**
   * RECOGNITION: surface string -> candidate coordinates
   * Not regex matching — semantic pattern matching against gate fields
   */
  recognize(text: string): AutoLingOutput {
    const tokens = text.toLowerCase().split(/\s+/);
    const candidates: AutoLingOutput['candidates'] = [];

    for (const pattern of RECOGNITION_PATTERNS) {
      // Check if any trigger word appears in the text
      const matchedTriggers = pattern.triggers.filter(t => tokens.includes(t));
      if (matchedTriggers.length === 0) continue;

      // Calculate base confidence from trigger match
      let confidence = pattern.weight * (matchedTriggers.length / pattern.triggers.length);

      // Apply context modifiers
      for (const preceding of pattern.contextModifiers.preceding) {
        const precedingTokens = preceding.toLowerCase().split(/\s+/);
        const matchCount = precedingTokens.filter(t => tokens.includes(t)).length;
        confidence += matchCount * 0.05;
      }

      for (const following of pattern.contextModifiers.following) {
        const followingTokens = following.toLowerCase().split(/\s+/);
        const matchCount = followingTokens.filter(t => tokens.includes(t)).length;
        confidence += matchCount * 0.05;
      }

      // Generate candidate coordinates for each target gate
      for (const gate of pattern.targetGates) {
        // Use line/color/tone biases if available, otherwise default
        const line = pattern.lineBias ? 
          pattern.lineBias[Math.floor(Math.random() * pattern.lineBias.length)] : 
          Math.floor(Math.random() * 6) + 1;
        const color = pattern.colorBias ? 
          pattern.colorBias[Math.floor(Math.random() * pattern.colorBias.length)] : 
          Math.floor(Math.random() * 6) + 1;
        const tone = pattern.toneBias ? 
          pattern.toneBias[Math.floor(Math.random() * pattern.toneBias.length)] : 
          Math.floor(Math.random() * 6) + 1;
        const base = Math.floor(Math.random() * 5) + 1;

        const coord = buildCoordinate(gate, line, color, tone, base);
        const field = resolveSemanticField(coord);
        if (!field) continue;

        // Generate mesostate for this candidate
        const mesostate = generateMesostate(coord, {
          activationHistory: this.activationHistory,
          meshCoherence: 0.5,  // placeholder — should come from actual mesh
          userPressure: confidence,
          timeSinceLastAccess: 0
        });

        candidates.push({
          coordinate: coord,
          confidence: Math.min(1, confidence),
          semanticField: field,
          mesostate
        });
      }
    }

    // Sort by confidence
    candidates.sort((a, b) => b.confidence - a.confidence);

    // Preserve ambiguity if top candidates are close
    const topCandidate = candidates[0];
    const ambiguityThreshold = 0.15;
    const ambiguousCandidates = candidates.filter(c => 
      topCandidate.confidence - c.confidence < ambiguityThreshold
    );

    if (ambiguousCandidates.length > 1) {
      // Preserve ambiguity — don't force single answer
      return {
        ok: true,
        mode: 'recognize',
        candidates: ambiguousCandidates,
        activation: {
          coordinate: topCandidate.coordinate,
          strength: topCandidate.confidence,
          propagationTargets: ambiguousCandidates.slice(1).map(c => c.coordinate)
        }
      };
    }

    return {
      ok: true,
      mode: 'recognize',
      candidates: candidates.slice(0, 3),  // top 3
      activation: topCandidate ? {
        coordinate: topCandidate.coordinate,
        strength: topCandidate.confidence,
        propagationTargets: candidates.slice(1, 3).map(c => c.coordinate)
      } : undefined
    };
  }

  /**
   * GENERATION: coordinate -> surface realization
   * Not template strings — semantic field-driven expression
   */
  generate(coord: StateCoordinate, media: 'language' | 'code' | 'image' | 'sound' | 'interface' = 'language'): AutoLingOutput {
    const field = resolveSemanticField(coord);
    if (!field) {
      return { ok: false, mode: 'generate', error: `Unknown gate: ${coord.gate}` };
    }

    // Generate mesostate for this coordinate
    const mesostate = generateMesostate(coord, {
      activationHistory: this.activationHistory,
      meshCoherence: 0.5,
      userPressure: 0.5,
      timeSinceLastAccess: 0
    });

    // Find matching generation pattern
    const pattern = GENERATION_PATTERNS.find(p => 
      p.coordinateMatch(coord, field) && p.media === media
    );

    if (!pattern) {
      // Fallback: generate from semantic field directly
      const surface = `${field.hdName} at ${coordinateToString(coord)}: ${field.quality.primary}`;
      return {
        ok: true,
        mode: 'generate',
        surface,
        activation: {
          coordinate: coord,
          strength: 0.5,
          propagationTargets: field.neighboringTendencies
            .filter(n => n.strength > 0.5)
            .map(n => buildCoordinate(n.targetGate, coord.line, coord.color, coord.tone, coord.base))
        }
      };
    }

    const surface = pattern.generate(coord, field, mesostate);

    return {
      ok: true,
      mode: 'generate',
      surface,
      activation: {
        coordinate: coord,
        strength: 0.7,
        propagationTargets: field.neighboringTendencies
          .filter(n => n.strength > 0.5)
          .map(n => buildCoordinate(n.targetGate, coord.line, coord.color, coord.tone, coord.base))
      }
    };
  }

  /**
   * Main entry point — bidirectional dispatch
   */
  run(input: AutoLingInput): AutoLingOutput {
    if (input.mode === 'recognize') {
      if (!input.text) {
        return { ok: false, mode: 'recognize', error: 'Text required for recognition' };
      }
      const result = this.recognize(input.text);

      // Activate in mesh
      if (result.activation) {
        this.mesh.publish('autoling:recognition', 'AutoLing', {
          coordinate: result.activation.coordinate,
          strength: result.activation.strength,
          candidates: result.candidates
        });

        // Record activation
        this.activationHistory.push(result.activation.coordinate);
      }

      return result;
    }

    if (input.mode === 'generate') {
      if (!input.coordinate) {
        return { ok: false, mode: 'generate', error: 'Coordinate required for generation' };
      }
      const result = this.generate(input.coordinate, input.media || 'language');

      // Activate in mesh
      if (result.activation) {
        this.mesh.publish('autoling:generation', 'AutoLing', {
          coordinate: result.activation.coordinate,
          strength: result.activation.strength,
          surface: result.surface
        });

        // Record activation
        this.activationHistory.push(result.activation.coordinate);
      }

      return result;
    }

    return { ok: false, mode: input.mode, error: 'Mode must be recognize or generate' };
  }

  /**
   * CODEGEN: Generate code from coordinate
   * Not just template functions — state-space traversal, mesh activation, projection
   */
  codegen(coord: StateCoordinate): string {
    const field = resolveSemanticField(coord);
    if (!field) return `// Unknown gate: ${coord.gate}`;

    const mesostate = generateMesostate(coord, {
      activationHistory: this.activationHistory,
      meshCoherence: 0.5,
      userPressure: 0.5,
      timeSinceLastAccess: 0
    });

    // Stage 1: State-space traversal function
    const traversalCode = [
      `// State-space traversal for ${field.hdName}`,
      `// Coordinate: ${coordinateToString(coord)}`,
      `// Stability: ${mesostate.stability}`,
      `// Transition readiness: ${mesostate.transitionReadiness.toFixed(3)}`,
      ``,
      `export function traverse_${coord.gate}_${coord.line}_${coord.color}_${coord.tone}_${coord.base}() {`,
      `  // Intrinsic contributions: ${field.contributions.join(', ')}`,
      `  // Primary quality: ${field.quality.primary}`,
      `  //`,
      `  // Neighboring tendencies:`,
      ...field.neighboringTendencies.map(n => 
        `  //   Gate ${n.targetGate}: strength ${n.strength.toFixed(2)}${n.channelType ? ' [' + n.channelType + ']' : ''}`
      ),
      `  //`,
      `  // Propagation targets:`,
      ...field.neighboringTendencies
        .filter(n => n.strength > 0.5)
        .map(n => `  //   buildCoordinate(${n.targetGate}, ${coord.line}, ${coord.color}, ${coord.tone}, ${coord.base})`),
      `  //`,
      `  // Mesostate gradients:`,
      ...mesostate.gradients.map(g => 
        `  //   ${g.direction}: strength ${g.strength.toFixed(2)} [${g.type}]`
      ),
      `  //`,
      `  // Convergence targets:`,
      ...mesostate.convergence.targetCoordinates.map(c => 
        `  //   ${coordinateToString(c)}`
      ),
      `  //`,
      `  return {`,
      `    coordinate: ${JSON.stringify(coord)},`,
      `    semanticField: ${JSON.stringify(field.quality.primary)},`,
      `    neighbors: [${field.neighboringTendencies.map(n => n.targetGate).join(', ')}],`,
      `    stability: '${mesostate.stability}',`,
      `    transitionReadiness: ${mesostate.transitionReadiness.toFixed(3)},`,
      `    gradients: ${JSON.stringify(mesostate.gradients)}`,
      `  };`,
      `}`,
      ``
    ].join('\n');

    // Stage 2: Mesh activation function
    const activationCode = [
      `// Mesh activation for ${field.hdName}`,
      `export function activate_${coord.gate}_${coord.line}_${coord.color}_${coord.tone}_${coord.base}(mesh) {`,
      `  // Publish to autoling:activation channel`,
      `  mesh.publish('autoling:activation', 'AutoLing', {`,
      `    coordinate: ${JSON.stringify(coord)},`,
      `    strength: 0.7,`,
      `    semanticField: '${field.quality.primary}',`,
      `    contributions: ${JSON.stringify(field.contributions)}`,
      `  });`,
      `  `,
      `  // Propagate to neighbors`,
      ...field.neighboringTendencies
        .filter(n => n.strength > 0.5)
        .map(n => 
          `  mesh.publish('channel:emergence', 'AutoLing', {` +
          `source: ${coord.gate}, target: ${n.targetGate}, strength: ${n.strength.toFixed(2)}});`
        ),
      `}`,
      ``
    ].join('\n');

    // Stage 3: Projection function
    const projectionCode = [
      `// Projection for ${field.hdName}`,
      `export function project_${coord.gate}_${coord.line}_${coord.color}_${coord.tone}_${coord.base}(media) {`,
      `  const projections = {`,
      `    language: '${field.projectionBias.language}',`,
      `    code: '${field.projectionBias.code}',`,
      `    image: '${field.projectionBias.image}',`,
      `    sound: '${field.projectionBias.sound}',`,
      `    interface: '${field.projectionBias.interface}'`,
      `  };`,
      `  return projections[media] || projections.language;`,
      `}`,
      ``
    ].join('\n');

    return [traversalCode, activationCode, projectionCode].join('\n');
  }
}
