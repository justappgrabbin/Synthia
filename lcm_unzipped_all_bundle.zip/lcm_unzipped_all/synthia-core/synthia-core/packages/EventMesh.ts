// EventMesh.ts
// The "mesh" connecting all tools. Pure Node EventEmitter underneath.
// Channels are not pre-declared — they emerge on first use.

import { EventEmitter } from 'node:events';
import { randomUUID } from 'node:crypto';

export class EventMesh extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(0);
    this.channels = new Map();
    this.log = [];
  }

  publish(channel, sourceTool, payload) {
    const isNew = !this.channels.has(channel);
    if (isNew) {
      this.channels.set(channel, {
        createdAt: Date.now(),
        messageCount: 0,
        sourceTools: new Set(),
      });
      this.emit('mesh:emergence', { channel, firstSource: sourceTool, at: Date.now() });
    }
    const meta = this.channels.get(channel);
    meta.messageCount += 1;
    meta.sourceTools.add(sourceTool);

    const message = {
      id: randomUUID(),
      channel,
      sourceTool,
      payload,
      at: Date.now(),
    };
    this.log.push(message);
    this.emit(channel, message);
    this.emit('mesh:any', message);
    return message;
  }

  subscribe(channel, handler) {
    this.on(channel, handler);
    return () => this.off(channel, handler);
  }

  subscribeAll(handler) {
    this.on('mesh:any', handler);
    return () => this.off('mesh:any', handler);
  }

  onEmergence(handler) {
    this.on('mesh:emergence', handler);
    return () => this.off('mesh:emergence', handler);
  }

  topology() {
    return Array.from(this.channels.entries()).map(([name, meta]) => ({
      channel: name,
      messageCount: meta.messageCount,
      sourceTools: Array.from(meta.sourceTools),
      ageMs: Date.now() - meta.createdAt,
    }));
  }
}
