// IntegrationExample.ts
// Demonstrates the full flow: recognition -> coordinate activation -> mesh propagation -> mesostate -> codegen

import { EventMesh } from './EventMesh';
import { AutoLing } from './AutoLing';
import { buildCoordinate, resolveSemanticField, coordinateToString, generateMesostate } from './CoordinateSystem';

// ============================================================
// SETUP: Create mesh and AutoLing
// ============================================================

const mesh = new EventMesh();
const autoling = new AutoLing(mesh);

// Subscribe to mesh events to observe the flow
mesh.onEmergence((event) => {
  console.log(`[MESH EMERGENCE] New channel: ${event.channel} from ${event.firstSource}`);
});

mesh.subscribeAll((message) => {
  console.log(`[MESH MESSAGE] ${message.channel} | ${message.sourceTool} | ${JSON.stringify(message.payload).slice(0, 120)}...`);
});

// ============================================================
// EXAMPLE 1: RECOGNITION
// User says: "I want to build something new"
// ============================================================

console.log('\n=== EXAMPLE 1: RECOGNITION ===');
console.log('User input: "I want to build something new"\n');

const recognitionResult = autoling.run({
  mode: 'recognize',
  text: 'I want to build something new'
});

if (recognitionResult.ok && recognitionResult.candidates) {
  console.log('\nRecognition candidates:');
  recognitionResult.candidates.forEach((c, i) => {
    console.log(`  ${i + 1}. ${coordinateToString(c.coordinate)}`);
    console.log(`     Confidence: ${(c.confidence * 100).toFixed(1)}%`);
    console.log(`     Gate: ${c.semanticField.hdName} (${c.semanticField.iChingName})`);
    console.log(`     Center: ${c.semanticField.hdCenter} | Circuit: ${c.semanticField.hdCircuit}`);
    console.log(`     Contributions: ${c.semanticField.contributions.join(', ')}`);
    console.log(`     Quality: ${c.semanticField.quality.primary}`);
    console.log(`     Stability: ${c.mesostate.stability} | Transition readiness: ${(c.mesostate.transitionReadiness * 100).toFixed(1)}%`);
    console.log(`     Gradients: ${c.mesostate.gradients.map(g => `${g.direction}(${g.strength.toFixed(2)})`).join(', ')}`);
    console.log(`     Ambiguity: ${c.mesostate.ambiguity.preserveAmbiguity ? 'PRESERVED' : 'RESOLVED'}`);
    if (c.mesostate.ambiguity.candidates.length > 1) {
      console.log(`     Ambiguous candidates: ${c.mesostate.ambiguity.candidates.map(cand => `${coordinateToString(cand.coordinate)}(${cand.probability.toFixed(2)})`).join(', ')}`);
    }
    console.log('');
  });

  if (recognitionResult.activation) {
    console.log('Mesh activation:');
    console.log(`  Coordinate: ${coordinateToString(recognitionResult.activation.coordinate)}`);
    console.log(`  Strength: ${(recognitionResult.activation.strength * 100).toFixed(1)}%`);
    console.log(`  Propagation targets: ${recognitionResult.activation.propagationTargets.map(coordinateToString).join(', ')}`);
  }
}

// ============================================================
// EXAMPLE 2: GENERATION
// From coordinate: Gate 6, Line 4, Color 4, Tone 5, Base 2 (user's verified address)
// ============================================================

console.log('\n=== EXAMPLE 2: GENERATION ===');
console.log('Coordinate: 6.4.4.5.2 (Gate 6, Line 4, Color 4, Tone 5, Base 2)\n');

const userCoord = buildCoordinate(6, 4, 4, 5, 2, 'Jupiter');
const generationResult = autoling.run({
  mode: 'generate',
  coordinate: userCoord,
  media: 'language'
});

if (generationResult.ok && generationResult.surface) {
  console.log('Generated surface:');
  console.log(`  ${generationResult.surface}\n`);

  const field = resolveSemanticField(userCoord);
  if (field) {
    console.log('Semantic field:');
    console.log(`  Gate: ${field.hdName} (${field.iChingName})`);
    console.log(`  Hexagram: ${field.hexagram}`);
    console.log(`  Center: ${field.hdCenter} | Circuit: ${field.hdCircuit}`);
    console.log(`  Organ: ${field.organ} | Astrological: ${field.astrologicalSign}`);
    console.log(`  Contributions: ${field.contributions.join(', ')}`);
    console.log(`  Quality primary: ${field.quality.primary}`);
    console.log(`  Quality secondary: ${field.quality.secondary.join(', ')}`);
    console.log(`  Tension: ${field.quality.tension.join(', ')}`);
    console.log(`  Resolution: ${field.quality.resolution.join(', ')}`);
    console.log(`  Spectral: HSL(${field.quality.spectral.hue.toFixed(1)}, ${(field.quality.spectral.saturation * 100).toFixed(0)}%, ${(field.quality.spectral.value * 100).toFixed(0)}%)`);
    console.log(`  Affordances: ${field.affordances.join(', ')}`);
    console.log(`  Neighboring tendencies: ${field.neighboringTendencies.map(n => `Gate ${n.targetGate}(${n.strength.toFixed(2)}${n.channelType ? ' [' + n.channelType + ']' : ''})`).join(', ')}`);
    console.log(`  Projection bias: ${JSON.stringify(field.projectionBias)}`);

    const mesostate = generateMesostate(userCoord, {
      activationHistory: [],
      meshCoherence: 0.7,
      userPressure: 0.8,
      timeSinceLastAccess: 0
    });

    console.log('\nMesostate:');
    console.log(`  Stability: ${mesostate.stability}`);
    console.log(`  Transition readiness: ${(mesostate.transitionReadiness * 100).toFixed(1)}%`);
    console.log(`  Gradients: ${mesostate.gradients.map(g => `${g.direction}(${g.strength.toFixed(2)})[${g.type}]`).join(', ')}`);
    console.log(`  Convergence proximity: ${(mesostate.convergence.proximity * 100).toFixed(1)}%`);
    console.log(`  Convergence targets: ${mesostate.convergence.targetCoordinates.map(coordinateToString).join(', ')}`);
    console.log(`  Ambiguity preserved: ${mesostate.ambiguity.preserveAmbiguity}`);
    console.log(`  Ambiguity candidates: ${mesostate.ambiguity.candidates.map(c => `${coordinateToString(c.coordinate)}(${c.probability.toFixed(2)})`).join(', ')}`);
    console.log(`  Recursion depth: ${mesostate.recursionDepth}`);
  }

  if (generationResult.activation) {
    console.log('\nMesh activation:');
    console.log(`  Coordinate: ${coordinateToString(generationResult.activation.coordinate)}`);
    console.log(`  Strength: ${(generationResult.activation.strength * 100).toFixed(1)}%`);
    console.log(`  Propagation targets: ${generationResult.activation.propagationTargets.map(coordinateToString).join(', ')}`);
  }
}

// ============================================================
// EXAMPLE 3: CODEGEN
// Generate code from user's verified coordinate
// ============================================================

console.log('\n=== EXAMPLE 3: CODEGEN ===');
console.log('Generating code for coordinate 6.4.4.5.2\n');

const generatedCode = autoling.codegen(userCoord);
console.log(generatedCode);

// ============================================================
// EXAMPLE 4: MESH TOPOLOGY
// Show what channels emerged from the interactions
// ============================================================

console.log('\n=== EXAMPLE 4: MESH TOPOLOGY ===');
const topology = mesh.topology();
console.log(`Total channels: ${topology.length}`);
topology.forEach(t => {
  console.log(`  ${t.channel}: ${t.messageCount} messages from [${t.sourceTools.join(', ')}] (age: ${t.ageMs}ms)`);
});

// ============================================================
// EXAMPLE 5: COMPLEX INPUT
// User says something that triggers multiple patterns with ambiguity
// ============================================================

console.log('\n=== EXAMPLE 5: COMPLEX INPUT (AMBIGUITY) ===');
console.log('User input: "I feel a breakthrough coming but I need to understand the depth first"\n');

const complexResult = autoling.run({
  mode: 'recognize',
  text: 'I feel a breakthrough coming but I need to understand the depth first'
});

if (complexResult.ok && complexResult.candidates) {
  console.log('Recognition candidates:');
  complexResult.candidates.forEach((c, i) => {
    console.log(`  ${i + 1}. ${coordinateToString(c.coordinate)}`);
    console.log(`     Confidence: ${(c.confidence * 100).toFixed(1)}%`);
    console.log(`     Gate: ${c.semanticField.hdName}`);
    console.log(`     Stability: ${c.mesostate.stability}`);
    console.log(`     Ambiguity: ${c.mesostate.ambiguity.preserveAmbiguity ? 'PRESERVED' : 'RESOLVED'}`);
    console.log('');
  });

  if (complexResult.activation && complexResult.activation.propagationTargets.length > 0) {
    console.log('Propagation targets (ambiguous state):');
    complexResult.activation.propagationTargets.forEach(t => {
      console.log(`  ${coordinateToString(t)}`);
    });
  }
}

console.log('\n=== END OF EXAMPLES ===');
