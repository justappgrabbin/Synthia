// index.js
// Synthia Core — MESSY Organism
// Entry point for the state-space-first cognitive architecture

export { EventMesh } from './packages/EventMesh.js';
export { 
  buildCoordinate, 
  resolveSemanticField, 
  coordinateToString, 
  generateMesostate,
  GATE_REGISTRY,
  LINE_SEMANTICS,
  COLOR_SEMANTICS,
  TONE_SEMANTICS,
  BASE_SEMANTICS,
  PLANETARY_SEMANTICS
} from './packages/CoordinateSystem.js';
export { AutoLing } from './packages/AutoLing.js';

// Convenience: create a complete organism instance
export function createOrganism() {
  const mesh = new EventMesh();
  const autoling = new AutoLing(mesh);
  return { mesh, autoling };
}
