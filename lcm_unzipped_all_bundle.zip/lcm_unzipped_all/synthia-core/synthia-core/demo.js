// demo.js
// Working demonstration of Synthia Core — MESSY Organism
// Run with: node demo.js

// ============================================================
// STATE SPACE DEFINITIONS
// ============================================================

const LINE_SEMANTICS = {
  1: 'introspective_foundation',
  2: 'projective_expression',
  3: 'experimental_transition',
  4: 'formulative_structure',
  5: 'universal_generalization',
  6: 'transcendent_compression'
};

const COLOR_SEMANTICS = {
  1: 'fear_motivated',
  2: 'hope_motivated',
  3: 'desire_motivated',
  4: 'need_motivated',
  5: 'guilt_motivated',
  6: 'innocence_motivated'
};

const TONE_SEMANTICS = {
  1: 'creative_perception',
  2: 'mood_perception',
  3: 'mind_perception',
  4: 'self_perception',
  5: 'social_perception',
  6: 'intuitive_perception'
};

const BASE_SEMANTICS = {
  1: 'physical_base',
  2: 'emotional_base',
  3: 'mental_base',
  4: 'spiritual_base',
  5: 'temporal_base'
};

const PLANETARY_SEMANTICS = {
  Sun: 'identity_core',
  Moon: 'emotional_liminal',
  Mercury: 'communication_pattern',
  Venus: 'relational_harmonic',
  Mars: 'action_impulse',
  Jupiter: 'expansion_growth',
  Saturn: 'constraint_structure',
  Uranus: 'disruption_innovation',
  Neptune: 'dissolution_mystery',
  Pluto: 'transformation_depth',
  NorthNode: 'evolution_future',
  SouthNode: 'ancestral_past',
  Earth: 'grounding_presence'
};

// ============================================================
// GATE SEMANTIC FIELDS (10 real gates)
// ============================================================

const GATE_REGISTRY = new Map([
  [1, {
    contributions: ['initiation', 'expression', 'direction', 'propagation'],
    quality: {
      primary: 'creative_pressure',
      secondary: ['self_expression', 'initiating_force', 'directional_drive'],
      tension: ['impatience', 'force_without_form', 'ungrounded_creation'],
      resolution: ['embodied_creation', 'directed_force', 'stable_expression'],
      spectral: { hue: 15, saturation: 0.95, value: 0.9 }
    },
    affordances: ['complementary', 'amplifying', 'harmonizing'],
    neighboringTendencies: [
      { targetGate: 8, strength: 0.85, channelType: 'Inspiration' },
      { targetGate: 2, strength: 0.7 },
      { targetGate: 43, strength: 0.6 }
    ],
    projectionBias: {
      language: 'assertive_directive',
      code: 'generative_functional',
      image: 'radiant_geometric',
      sound: 'rhythmic_pulsing',
      interface: 'directive_initiating'
    },
    hexagram: 1,
    iChingName: 'The Creative',
    hdName: 'Self-Expression',
    hdCenter: 'G',
    hdCircuit: 'Individual',
    organ: 'Liver',
    astrologicalSign: 'Mars'
  }],
  [2, {
    contributions: ['reception', 'stabilization', 'containment', 'memory'],
    quality: {
      primary: 'receptive_capacity',
      secondary: ['holding_space', 'nurturing', 'grounding_presence'],
      tension: ['passivity', 'over_containment', 'resistance_to_change'],
      resolution: ['responsive_reception', 'stable_holding', 'adaptive_containment'],
      spectral: { hue: 45, saturation: 0.6, value: 0.7 }
    },
    affordances: ['complementary', 'resolving', 'harmonizing'],
    neighboringTendencies: [
      { targetGate: 14, strength: 0.8, channelType: 'Beat' },
      { targetGate: 1, strength: 0.7 },
      { targetGate: 15, strength: 0.65 }
    ],
    projectionBias: {
      language: 'receptive_responsive',
      code: 'declarative_stable',
      image: 'contained_organic',
      sound: 'harmonic_sustained',
      interface: 'responsive_holding'
    },
    hexagram: 2,
    iChingName: 'The Receptive',
    hdName: 'Higher Knowing',
    hdCenter: 'G',
    hdCircuit: 'Collective',
    organ: 'Liver',
    astrologicalSign: 'Moon'
  }],
  [6, {
    contributions: ['opposition', 'correction', 'filtering', 'gating'],
    quality: {
      primary: 'frictional_clarity',
      secondary: ['boundary_pressure', 'conflict_resolution', 'selective_force'],
      tension: ['unnecessary_conflict', 'aggression', 'defensive_rigidity'],
      resolution: ['clear_boundaries', 'constructive_friction', 'selective_pressure'],
      spectral: { hue: 200, saturation: 0.8, value: 0.75 }
    },
    affordances: ['oppositional', 'constraining', 'redirecting'],
    neighboringTendencies: [
      { targetGate: 59, strength: 0.9, channelType: 'Mating' },
      { targetGate: 36, strength: 0.75 },
      { targetGate: 22, strength: 0.6 }
    ],
    projectionBias: {
      language: 'confrontational_precise',
      code: 'procedural_guarded',
      image: 'sharp_geometric',
      sound: 'dissonant_rhythmic',
      interface: 'directive_guarded'
    },
    hexagram: 6,
    iChingName: 'Conflict',
    hdName: 'Friction',
    hdCenter: 'SolarPlexus',
    hdCircuit: 'Tribal',
    organ: 'Kidneys',
    astrologicalSign: 'Jupiter'
  }],
  [10, {
    contributions: ['expression', 'formulation', 'direction', 'attention'],
    quality: {
      primary: 'behavioral_expression',
      secondary: ['self_presentation', 'role_play', 'adaptive_behavior'],
      tension: ['inauthenticity', 'performance_without_substance', 'role_rigidity'],
      resolution: ['embodied_expression', 'authentic_role', 'adaptive_form'],
      spectral: { hue: 30, saturation: 0.85, value: 0.85 }
    },
    affordances: ['complementary', 'amplifying', 'harmonizing'],
    neighboringTendencies: [
      { targetGate: 20, strength: 0.8, channelType: 'Awakening' },
      { targetGate: 34, strength: 0.75, channelType: 'Exploration' },
      { targetGate: 57, strength: 0.7, channelType: 'Perfected Form' }
    ],
    projectionBias: {
      language: 'performative_adaptive',
      code: 'functional_adaptive',
      image: 'adaptive_geometric',
      sound: 'rhythmic_adaptive',
      interface: 'exploratory_responsive'
    },
    hexagram: 10,
    iChingName: 'Treading',
    hdName: 'Behavior',
    hdCenter: 'G',
    hdCircuit: 'Individual',
    organ: 'Liver',
    astrologicalSign: 'Saturn'
  }],
  [17, {
    contributions: ['formulation', 'direction', 'attention', 'filtering'],
    quality: {
      primary: 'pattern_ordering',
      secondary: ['opinion_formation', 'interpretive_structure', 'conceptual_direction'],
      tension: ['rigid_opinion', 'pattern_fixation', 'interpretive_bias'],
      resolution: ['flexible_pattern', 'adaptive_opinion', 'open_interpretation'],
      spectral: { hue: 60, saturation: 0.7, value: 0.8 }
    },
    affordances: ['complementary', 'constraining', 'redirecting'],
    neighboringTendencies: [
      { targetGate: 62, strength: 0.85, channelType: 'Acceptance' },
      { targetGate: 11, strength: 0.7 },
      { targetGate: 43, strength: 0.65 }
    ],
    projectionBias: {
      language: 'interpretive_structured',
      code: 'declarative_patterned',
      image: 'structured_abstract',
      sound: 'harmonic_patterned',
      interface: 'directive_exploratory'
    },
    hexagram: 17,
    iChingName: 'Following',
    hdName: 'Opinions',
    hdCenter: 'Ajna',
    hdCircuit: 'Collective',
    organ: 'Pituitary',
    astrologicalSign: 'Mercury'
  }],
  [23, {
    contributions: ['mutation', 'decompression', 'direction', 'propagation'],
    quality: {
      primary: 'assimilative_dissolution',
      secondary: ['structural_breakdown', 'knowledge_assimilation', 'fragmentary_insight'],
      tension: ['destructive_dissolution', 'fragmentation_without_integration', 'chaotic_breakdown'],
      resolution: ['constructive_dissolution', 'assimilative_breakdown', 'integrative_fragmentation'],
      spectral: { hue: 280, saturation: 0.75, value: 0.7 }
    },
    affordances: ['destabilizing', 'redirecting', 'amplifying'],
    neighboringTendencies: [
      { targetGate: 43, strength: 0.9, channelType: 'Structuring' },
      { targetGate: 56, strength: 0.7 },
      { targetGate: 11, strength: 0.6 }
    ],
    projectionBias: {
      language: 'fragmentary_insightful',
      code: 'procedural_deconstructive',
      image: 'fragmentary_abstract',
      sound: 'dissonant_fragmentary',
      interface: 'exploratory_deconstructive'
    },
    hexagram: 23,
    iChingName: 'Splitting Apart',
    hdName: 'Assimilation',
    hdCenter: 'Throat',
    hdCircuit: 'Individual',
    organ: 'Thyroid',
    astrologicalSign: 'Saturn'
  }],
  [34, {
    contributions: ['initiation', 'propagation', 'direction', 'opposition'],
    quality: {
      primary: 'powerful_impulse',
      secondary: ['sacral_force', 'generative_power', 'directed_energy'],
      tension: ['uncontrolled_power', 'force_without_direction', 'destructive_impulse'],
      resolution: ['directed_power', 'controlled_force', 'generative_impulse'],
      spectral: { hue: 0, saturation: 0.9, value: 0.85 }
    },
    affordances: ['amplifying', 'oppositional', 'harmonizing'],
    neighboringTendencies: [
      { targetGate: 20, strength: 0.8, channelType: 'Charisma' },
      { targetGate: 57, strength: 0.75, channelType: 'Power' },
      { targetGate: 10, strength: 0.7, channelType: 'Exploration' }
    ],
    projectionBias: {
      language: 'forceful_directive',
      code: 'procedural_generative',
      image: 'powerful_geometric',
      sound: 'rhythmic_powerful',
      interface: 'directive_forceful'
    },
    hexagram: 34,
    iChingName: 'Great Power',
    hdName: 'Power',
    hdCenter: 'Sacral',
    hdCircuit: 'Individual',
    organ: 'Ovaries/Testes',
    astrologicalSign: 'Mars'
  }],
  [43, {
    contributions: ['formulation', 'expression', 'attention', 'propagation'],
    quality: {
      primary: 'insightful_breakthrough',
      secondary: ['conceptual_insight', 'pattern_breakthrough', 'structural_innovation'],
      tension: ['forced_insight', 'premature_breakthrough', 'ungrounded_innovation'],
      resolution: ['embodied_insight', 'timely_breakthrough', 'grounded_innovation'],
      spectral: { hue: 120, saturation: 0.8, value: 0.8 }
    },
    affordances: ['amplifying', 'destabilizing', 'harmonizing'],
    neighboringTendencies: [
      { targetGate: 23, strength: 0.9, channelType: 'Structuring' },
      { targetGate: 1, strength: 0.7 },
      { targetGate: 11, strength: 0.65 }
    ],
    projectionBias: {
      language: 'insightful_innovative',
      code: 'functional_innovative',
      image: 'innovative_abstract',
      sound: 'harmonic_innovative',
      interface: 'exploratory_innovative'
    },
    hexagram: 43,
    iChingName: 'Breakthrough',
    hdName: 'Insight',
    hdCenter: 'Ajna',
    hdCircuit: 'Individual',
    organ: 'Pituitary',
    astrologicalSign: 'Uranus'
  }],
  [48, {
    contributions: ['memory', 'compression', 'containment', 'filtering'],
    quality: {
      primary: 'depth_compression',
      secondary: ['knowledge_depth', 'resource_access', 'deep_structure'],
      tension: ['stagnant_depth', 'compression_without_access', 'buried_knowledge'],
      resolution: ['accessible_depth', 'living_compression', 'flowing_structure'],
      spectral: { hue: 180, saturation: 0.7, value: 0.6 }
    },
    affordances: ['complementary', 'constraining', 'resolving'],
    neighboringTendencies: [
      { targetGate: 16, strength: 0.85, channelType: 'Wavelength' },
      { targetGate: 11, strength: 0.7 },
      { targetGate: 32, strength: 0.6 }
    ],
    projectionBias: {
      language: 'deep_structured',
      code: 'declarative_compressed',
      image: 'deep_organic',
      sound: 'harmonic_deep',
      interface: 'exploratory_depth'
    },
    hexagram: 48,
    iChingName: 'The Well',
    hdName: 'Depth',
    hdCenter: 'Spleen',
    hdCircuit: 'Collective',
    organ: 'Lymphatic',
    astrologicalSign: 'Saturn'
  }],
  [61, {
    contributions: ['resonance', 'attention', 'compression', 'stabilization'],
    quality: {
      primary: 'mystical_resonance',
      secondary: ['inner_truth', 'mystical_perception', 'depth_resonance'],
      tension: ['delusional_mysticism', 'ungrounded_truth', 'escapist_depth'],
      resolution: ['embodied_mystery', 'grounded_truth', 'living_resonance'],
      spectral: { hue: 260, saturation: 0.85, value: 0.75 }
    },
    affordances: ['harmonizing', 'amplifying', 'resolving'],
    neighboringTendencies: [
      { targetGate: 24, strength: 0.9, channelType: 'Awareness' },
      { targetGate: 63, strength: 0.75 },
      { targetGate: 47, strength: 0.7 }
    ],
    projectionBias: {
      language: 'mystical_resonant',
      code: 'functional_mystical',
      image: 'mystical_abstract',
      sound: 'harmonic_mystical',
      interface: 'exploratory_mystical'
    },
    hexagram: 61,
    iChingName: 'Inner Truth',
    hdName: 'Mystery',
    hdCenter: 'Head',
    hdCircuit: 'Individual',
    organ: 'Pineal',
    astrologicalSign: 'Neptune'
  }]
]);

// ============================================================
// COORDINATE UTILITIES
// ============================================================

function buildCoordinate(gate, line, color, tone, base, planet, arc) {
  return { gate, line, color, tone, base, planet, arc };
}

function resolveSemanticField(coord) {
  const baseField = GATE_REGISTRY.get(coord.gate);
  if (!baseField) return null;

  // Deep clone
  const field = JSON.parse(JSON.stringify(baseField));

  // Apply line modifier
  const lineModifier = LINE_SEMANTICS[coord.line];
  field.hdName = `${field.hdName} [${lineModifier}]`;

  // Apply color modifier
  const colorModifier = COLOR_SEMANTICS[coord.color];
  field.quality.primary = `${field.quality.primary}_${colorModifier}`;

  // Apply tone modifier
  const toneModifier = TONE_SEMANTICS[coord.tone];
  field.projectionBias.language = `${field.projectionBias.language}_${toneModifier}`;

  // Apply base modifier
  const baseModifier = BASE_SEMANTICS[coord.base];
  field.projectionBias.code = `${field.projectionBias.code}_${baseModifier}`;

  // Apply planetary qualifier
  if (coord.planet) {
    const planetModifier = PLANETARY_SEMANTICS[coord.planet];
    field.quality.secondary.push(planetModifier);
  }

  // Apply arc modulation
  if (coord.arc) {
    const arcInfluence = (coord.arc.degree + coord.arc.minute/60 + coord.arc.second/3600) / 360;
    field.quality.spectral.hue = (field.quality.spectral.hue + arcInfluence * 30) % 360;
  }

  return field;
}

function coordinateToString(coord) {
  const parts = [`G${coord.gate}`, `L${coord.line}`, `C${coord.color}`, `T${coord.tone}`, `B${coord.base}`];
  if (coord.planet) parts.push(coord.planet);
  if (coord.arc) parts.push(`A${coord.arc.degree}.${coord.arc.minute}.${coord.arc.second}`);
  return parts.join(':');
}

function generateMesostate(coord, context) {
  const field = resolveSemanticField(coord);
  if (!field) throw new Error(`Unknown gate: ${coord.gate}`);

  let stability = 'stable';
  if (context.meshCoherence < 0.3) stability = 'unstable';
  else if (context.meshCoherence < 0.6) stability = 'metastable';
  else if (context.userPressure > 0.8) stability = 'changing';
  else if (context.meshCoherence > 0.8 && context.userPressure < 0.3) stability = 'converging';

  const lineTransitionBias = coord.line / 6;
  const timeDecay = Math.min(1, context.timeSinceLastAccess / 60000);
  const transitionReadiness = (lineTransitionBias + timeDecay + context.userPressure) / 3;

  const gradients = field.neighboringTendencies.map(n => ({
    direction: `toward_gate_${n.targetGate}`,
    strength: n.strength * context.meshCoherence,
    type: n.strength > 0.7 ? 'expressive' : n.strength > 0.4 ? 'stabilizing' : 'receptive'
  }));

  const convergence = {
    targetCoordinates: field.neighboringTendencies
      .filter(n => n.strength > 0.7)
      .map(n => buildCoordinate(n.targetGate, coord.line, coord.color, coord.tone, coord.base)),
    proximity: context.meshCoherence * (1 - transitionReadiness),
    triggerConditions: [
      `mesh_coherence > ${(context.meshCoherence + 0.2).toFixed(2)}`,
      `user_pressure < ${(context.userPressure * 0.8).toFixed(2)}`
    ]
  };

  const ambiguity = {
    candidates: [
      { coordinate: coord, probability: 0.6 },
      ...field.neighboringTendencies
        .filter(n => n.strength > 0.5)
        .map(n => ({
          coordinate: buildCoordinate(n.targetGate, coord.line, coord.color, coord.tone, coord.base),
          probability: n.strength * 0.4
        }))
    ],
    preserveAmbiguity: transitionReadiness > 0.7 && context.meshCoherence < 0.5,
    mixedDescription: `${field.hdName} with ${LINE_SEMANTICS[coord.line]} expression, ${COLOR_SEMANTICS[coord.color]} motivation, ${TONE_SEMANTICS[coord.tone]} perception`
  };

  return {
    stability,
    transitionReadiness,
    gradients,
    convergence,
    ambiguity,
    recursionDepth: context.activationHistory.filter(c => c.gate === coord.gate).length,
    at: Date.now()
  };
}

// ============================================================
// EVENT MESH
// ============================================================

class EventMesh {
  constructor() {
    this.channels = new Map();
    this.log = [];
    this.listeners = new Map();
  }

  publish(channel, sourceTool, payload) {
    const isNew = !this.channels.has(channel);
    if (isNew) {
      this.channels.set(channel, {
        createdAt: Date.now(),
        messageCount: 0,
        sourceTools: new Set()
      });
      console.log(`[MESH EMERGENCE] New channel: ${channel} from ${sourceTool}`);
    }
    const meta = this.channels.get(channel);
    meta.messageCount += 1;
    meta.sourceTools.add(sourceTool);

    const message = {
      id: Math.random().toString(36).slice(2),
      channel,
      sourceTool,
      payload,
      at: Date.now()
    };
    this.log.push(message);

    // Emit to listeners
    const handlers = this.listeners.get(channel) || [];
    handlers.forEach(h => h(message));

    // Wildcard listeners
    const wildcards = this.listeners.get('mesh:any') || [];
    wildcards.forEach(h => h(message));

    return message;
  }

  subscribe(channel, handler) {
    if (!this.listeners.has(channel)) this.listeners.set(channel, []);
    this.listeners.get(channel).push(handler);
    return () => {
      const handlers = this.listeners.get(channel);
      const idx = handlers.indexOf(handler);
      if (idx > -1) handlers.splice(idx, 1);
    };
  }

  subscribeAll(handler) {
    return this.subscribe('mesh:any', handler);
  }

  topology() {
    return Array.from(this.channels.entries()).map(([name, meta]) => ({
      channel: name,
      messageCount: meta.messageCount,
      sourceTools: Array.from(meta.sourceTools),
      ageMs: Date.now() - meta.createdAt
    }));
  }
}

// ============================================================
// AUTOLING
// ============================================================

const RECOGNITION_PATTERNS = [
  {
    triggers: ['create', 'make', 'build', 'generate', 'initiate', 'start', 'new'],
    targetGates: [1, 34, 43],
    weight: 0.9,
    lineBias: [1, 2, 4],
    colorBias: [3, 4],
    toneBias: [1, 3],
    contextModifiers: {
      preceding: ['i want to', 'let\'s', 'we need'],
      following: ['something', 'new', 'from scratch']
    }
  },
  {
    triggers: ['receive', 'hold', 'contain', 'ground', 'stable', 'nurture', 'support'],
    targetGates: [2, 48],
    weight: 0.85,
    lineBias: [1, 5, 6],
    colorBias: [1, 2],
    toneBias: [2, 4],
    contextModifiers: {
      preceding: ['i need', 'can you', 'please'],
      following: ['me', 'us', 'together']
    }
  },
  {
    triggers: ['conflict', 'friction', 'boundary', 'correct', 'judge', 'select', 'filter'],
    targetGates: [6],
    weight: 0.95,
    lineBias: [4, 5, 6],
    colorBias: [4, 5],
    toneBias: [3, 5],
    contextModifiers: {
      preceding: ['there is', 'i feel', 'this is'],
      following: ['between', 'with', 'against']
    }
  },
  {
    triggers: ['behave', 'act', 'perform', 'role', 'adapt', 'present', 'express'],
    targetGates: [10],
    weight: 0.88,
    lineBias: [2, 4, 5],
    colorBias: [3, 4, 6],
    toneBias: [1, 4, 5],
    contextModifiers: {
      preceding: ['i am', 'how do i', 'what is my'],
      following: ['myself', 'in this', 'now']
    }
  },
  {
    triggers: ['pattern', 'order', 'structure', 'organize', 'opinion', 'interpret', 'follow'],
    targetGates: [17],
    weight: 0.87,
    lineBias: [3, 4, 5],
    colorBias: [3, 5],
    toneBias: [3, 5],
    contextModifiers: {
      preceding: ['i think', 'the', 'this follows'],
      following: ['because', 'therefore', 'so']
    }
  },
  {
    triggers: ['break', 'insight', 'understand', 'see', 'realize', 'breakthrough', 'new idea'],
    targetGates: [23, 43],
    weight: 0.92,
    lineBias: [4, 5, 6],
    colorBias: [4, 6],
    toneBias: [1, 3, 6],
    contextModifiers: {
      preceding: ['suddenly', 'i see', 'now i'],
      following: ['that', 'how', 'why']
    }
  },
  {
    triggers: ['power', 'force', 'energy', 'drive', 'push', 'move', 'action'],
    targetGates: [34],
    weight: 0.9,
    lineBias: [1, 2, 4],
    colorBias: [3, 4],
    toneBias: [1, 2],
    contextModifiers: {
      preceding: ['i feel', 'there is', 'let\'s'],
      following: ['forward', 'through', 'now']
    }
  },
  {
    triggers: ['depth', 'deep', 'well', 'source', 'access', 'knowledge', 'know'],
    targetGates: [48],
    weight: 0.86,
    lineBias: [1, 5, 6],
    colorBias: [1, 4],
    toneBias: [3, 4, 6],
    contextModifiers: {
      preceding: ['i know', 'the', 'from the'],
      following: ['of', 'within', 'inside']
    }
  },
  {
    triggers: ['truth', 'mystery', 'inner', 'resonance', 'feel', 'intuit', 'sense'],
    targetGates: [61],
    weight: 0.89,
    lineBias: [1, 4, 6],
    colorBias: [2, 6],
    toneBias: [4, 6],
    contextModifiers: {
      preceding: ['i sense', 'there is', 'the'],
      following: ['within', 'between', 'of']
    }
  }
];

class AutoLing {
  constructor(mesh) {
    this.mesh = mesh;
    this.activationHistory = [];
  }

  recognize(text) {
    const tokens = text.toLowerCase().split(/\s+/);
    const candidates = [];

    for (const pattern of RECOGNITION_PATTERNS) {
      const matchedTriggers = pattern.triggers.filter(t => tokens.includes(t));
      if (matchedTriggers.length === 0) continue;

      let confidence = pattern.weight * (matchedTriggers.length / pattern.triggers.length);

      for (const preceding of pattern.contextModifiers.preceding) {
        const precedingTokens = preceding.toLowerCase().split(/\s+/);
        const matchCount = precedingTokens.filter(t => tokens.includes(t)).length;
        confidence += matchCount * 0.05;
      }

      for (const following of pattern.contextModifiers.following) {
        const followingTokens = following.toLowerCase().split(/\s+/);
        const matchCount = followingTokens.filter(t => tokens.includes(t)).length;
        confidence += matchCount * 0.05;
      }

      for (const gate of pattern.targetGates) {
        const line = pattern.lineBias ? 
          pattern.lineBias[Math.floor(Math.random() * pattern.lineBias.length)] : 
          Math.floor(Math.random() * 6) + 1;
        const color = pattern.colorBias ? 
          pattern.colorBias[Math.floor(Math.random() * pattern.colorBias.length)] : 
          Math.floor(Math.random() * 6) + 1;
        const tone = pattern.toneBias ? 
          pattern.toneBias[Math.floor(Math.random() * pattern.toneBias.length)] : 
          Math.floor(Math.random() * 6) + 1;
        const base = Math.floor(Math.random() * 5) + 1;

        const coord = buildCoordinate(gate, line, color, tone, base);
        const field = resolveSemanticField(coord);
        if (!field) continue;

        const mesostate = generateMesostate(coord, {
          activationHistory: this.activationHistory,
          meshCoherence: 0.5,
          userPressure: confidence,
          timeSinceLastAccess: 0
        });

        candidates.push({
          coordinate: coord,
          confidence: Math.min(1, confidence),
          semanticField: field,
          mesostate
        });
      }
    }

    candidates.sort((a, b) => b.confidence - a.confidence);

    const topCandidate = candidates[0];
    const ambiguityThreshold = 0.15;
    const ambiguousCandidates = candidates.filter(c => 
      topCandidate.confidence - c.confidence < ambiguityThreshold
    );

    if (ambiguousCandidates.length > 1) {
      return {
        ok: true,
        mode: 'recognize',
        candidates: ambiguousCandidates,
        activation: {
          coordinate: topCandidate.coordinate,
          strength: topCandidate.confidence,
          propagationTargets: ambiguousCandidates.slice(1).map(c => c.coordinate)
        }
      };
    }

    return {
      ok: true,
      mode: 'recognize',
      candidates: candidates.slice(0, 3),
      activation: topCandidate ? {
        coordinate: topCandidate.coordinate,
        strength: topCandidate.confidence,
        propagationTargets: candidates.slice(1, 3).map(c => c.coordinate)
      } : undefined
    };
  }

  generate(coord, media = 'language') {
    const field = resolveSemanticField(coord);
    if (!field) {
      return { ok: false, mode: 'generate', error: `Unknown gate: ${coord.gate}` };
    }

    const mesostate = generateMesostate(coord, {
      activationHistory: this.activationHistory,
      meshCoherence: 0.5,
      userPressure: 0.5,
      timeSinceLastAccess: 0
    });

    const lineDesc = LINE_SEMANTICS[coord.line];
    const colorDesc = COLOR_SEMANTICS[coord.color];
    const toneDesc = TONE_SEMANTICS[coord.tone];
    const baseDesc = BASE_SEMANTICS[coord.base];

    let surface;
    if (mesostate.stability === 'stable') {
      surface = `${field.hdName} at ${coordinateToString(coord)}: ${field.quality.primary} with ${colorDesc} motivation, ${toneDesc} perception, grounded in ${baseDesc}.`;
    } else if (mesostate.stability === 'changing') {
      surface = `${field.hdName} in flux at ${coordinateToString(coord)}: ${field.quality.tension[0]} transitioning toward ${field.quality.resolution[0]}.`;
    } else {
      surface = `${field.hdName} potential [${lineDesc}]: ${mesostate.ambiguity.mixedDescription}`;
    }

    return {
      ok: true,
      mode: 'generate',
      surface,
      activation: {
        coordinate: coord,
        strength: 0.7,
        propagationTargets: field.neighboringTendencies
          .filter(n => n.strength > 0.5)
          .map(n => buildCoordinate(n.targetGate, coord.line, coord.color, coord.tone, coord.base))
      }
    };
  }

  run(input) {
    if (input.mode === 'recognize') {
      if (!input.text) {
        return { ok: false, mode: 'recognize', error: 'Text required for recognition' };
      }
      const result = this.recognize(input.text);

      if (result.activation) {
        this.mesh.publish('autoling:recognition', 'AutoLing', {
          coordinate: result.activation.coordinate,
          strength: result.activation.strength,
          candidates: result.candidates
        });
        this.activationHistory.push(result.activation.coordinate);
      }

      return result;
    }

    if (input.mode === 'generate') {
      if (!input.coordinate) {
        return { ok: false, mode: 'generate', error: 'Coordinate required for generation' };
      }
      const result = this.generate(input.coordinate, input.media || 'language');

      if (result.activation) {
        this.mesh.publish('autoling:generation', 'AutoLing', {
          coordinate: result.activation.coordinate,
          strength: result.activation.strength,
          surface: result.surface
        });
        this.activationHistory.push(result.activation.coordinate);
      }

      return result;
    }

    return { ok: false, mode: input.mode, error: 'Mode must be recognize or generate' };
  }

  codegen(coord) {
    const field = resolveSemanticField(coord);
    if (!field) return `// Unknown gate: ${coord.gate}`;

    const mesostate = generateMesostate(coord, {
      activationHistory: this.activationHistory,
      meshCoherence: 0.5,
      userPressure: 0.5,
      timeSinceLastAccess: 0
    });

    const traversalCode = [
      `// State-space traversal for ${field.hdName}`,
      `// Coordinate: ${coordinateToString(coord)}`,
      `// Stability: ${mesostate.stability}`,
      `// Transition readiness: ${mesostate.transitionReadiness.toFixed(3)}`,
      ``,
      `export function traverse_${coord.gate}_${coord.line}_${coord.color}_${coord.tone}_${coord.base}() {`,
      `  // Intrinsic contributions: ${field.contributions.join(', ')}`,
      `  // Primary quality: ${field.quality.primary}`,
      `  //`,
      `  // Neighboring tendencies:`,
      ...field.neighboringTendencies.map(n => 
        `  //   Gate ${n.targetGate}: strength ${n.strength.toFixed(2)}${n.channelType ? ' [' + n.channelType + ']' : ''}`
      ),
      `  //`,
      `  // Propagation targets:`,
      ...field.neighboringTendencies
        .filter(n => n.strength > 0.5)
        .map(n => `  //   buildCoordinate(${n.targetGate}, ${coord.line}, ${coord.color}, ${coord.tone}, ${coord.base})`),
      `  //`,
      `  // Mesostate gradients:`,
      ...mesostate.gradients.map(g => 
        `  //   ${g.direction}: strength ${g.strength.toFixed(2)} [${g.type}]`
      ),
      `  //`,
      `  // Convergence targets:`,
      ...mesostate.convergence.targetCoordinates.map(c => 
        `  //   ${coordinateToString(c)}`
      ),
      `  //`,
      `  return {`,
      `    coordinate: ${JSON.stringify(coord)},`,
      `    semanticField: "${field.quality.primary}",`,
      `    neighbors: [${field.neighboringTendencies.map(n => n.targetGate).join(', ')}],`,
      `    stability: "${mesostate.stability}",`,
      `    transitionReadiness: ${mesostate.transitionReadiness.toFixed(3)},`,
      `    gradients: ${JSON.stringify(mesostate.gradients)}`,
      `  };`,
      `}`,
      ``
    ].join('\n');

    const activationCode = [
      `// Mesh activation for ${field.hdName}`,
      `export function activate_${coord.gate}_${coord.line}_${coord.color}_${coord.tone}_${coord.base}(mesh) {`,
      `  // Publish to autoling:activation channel`,
      `  mesh.publish('autoling:activation', 'AutoLing', {`,
      `    coordinate: ${JSON.stringify(coord)},`,
      `    strength: 0.7,`,
      `    semanticField: "${field.quality.primary}",`,
      `    contributions: ${JSON.stringify(field.contributions)}`,
      `  });`,
      `  `,
      `  // Propagate to neighbors`,
      ...field.neighboringTendencies
        .filter(n => n.strength > 0.5)
        .map(n => 
          `  mesh.publish('channel:emergence', 'AutoLing', {` +
          `source: ${coord.gate}, target: ${n.targetGate}, strength: ${n.strength.toFixed(2)}});`
        ),
      `}`,
      ``
    ].join('\n');

    const projectionCode = [
      `// Projection for ${field.hdName}`,
      `export function project_${coord.gate}_${coord.line}_${coord.color}_${coord.tone}_${coord.base}(media) {`,
      `  const projections = {`,
      `    language: "${field.projectionBias.language}",`,
      `    code: "${field.projectionBias.code}",`,
      `    image: "${field.projectionBias.image}",`,
      `    sound: "${field.projectionBias.sound}",`,
      `    interface: "${field.projectionBias.interface}"`,
      `  };`,
      `  return projections[media] || projections.language;`,
      `}`,
      ``
    ].join('\n');

    return [traversalCode, activationCode, projectionCode].join('\n');
  }
}

// ============================================================
// DEMO
// ============================================================

console.log('╔══════════════════════════════════════════════════════════════════════╗');
console.log('║  SYNTHIA CORE — MESSY Organism Demo                                  ║');
console.log('║  State-space first. Activation before computation.                   ║');
console.log('╚══════════════════════════════════════════════════════════════════════╝');

const mesh = new EventMesh();
const autoling = new AutoLing(mesh);

// Subscribe to mesh events
mesh.subscribeAll((msg) => {
  console.log(`\n[MESH] ${msg.channel} | ${msg.sourceTool} | ${JSON.stringify(msg.payload).slice(0, 100)}...`);
});

// ──────────────────────────────────────────────────────────────────────
// EXAMPLE 1: RECOGNITION
// ──────────────────────────────────────────────────────────────────────
console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('EXAMPLE 1: RECOGNITION');
console.log('User input: "I want to build something new"');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

const recResult = autoling.run({ mode: 'recognize', text: 'I want to build something new' });

if (recResult.ok && recResult.candidates) {
  console.log('\nRecognition candidates:');
  recResult.candidates.forEach((c, i) => {
    console.log(`\n  ${i + 1}. ${coordinateToString(c.coordinate)}`);
    console.log(`     Confidence: ${(c.confidence * 100).toFixed(1)}%`);
    console.log(`     Gate: ${c.semanticField.hdName} (${c.semanticField.iChingName})`);
    console.log(`     Center: ${c.semanticField.hdCenter} | Circuit: ${c.semanticField.hdCircuit}`);
    console.log(`     Contributions: ${c.semanticField.contributions.join(', ')}`);
    console.log(`     Quality: ${c.semanticField.quality.primary}`);
    console.log(`     Stability: ${c.mesostate.stability} | Transition: ${(c.mesostate.transitionReadiness * 100).toFixed(1)}%`);
    console.log(`     Gradients: ${c.mesostate.gradients.map(g => `${g.direction}(${g.strength.toFixed(2)})`).join(', ')}`);
    console.log(`     Ambiguity: ${c.mesostate.ambiguity.preserveAmbiguity ? 'PRESERVED' : 'RESOLVED'}`);
    if (c.mesostate.ambiguity.candidates.length > 1) {
      console.log(`     Ambiguous: ${c.mesostate.ambiguity.candidates.map(cand => `${coordinateToString(cand.coordinate)}(${cand.probability.toFixed(2)})`).join(', ')}`);
    }
  });

  if (recResult.activation) {
    console.log(`\n  Mesh activation: ${coordinateToString(recResult.activation.coordinate)}`);
    console.log(`  Strength: ${(recResult.activation.strength * 100).toFixed(1)}%`);
    console.log(`  Propagation: ${recResult.activation.propagationTargets.map(coordinateToString).join(', ')}`);
  }
}

// ──────────────────────────────────────────────────────────────────────
// EXAMPLE 2: GENERATION (User's verified address)
// ──────────────────────────────────────────────────────────────────────
console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('EXAMPLE 2: GENERATION');
console.log('Coordinate: 6.4.4.5.2 (Gate 6, Line 4, Color 4, Tone 5, Base 2)');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

const userCoord = buildCoordinate(6, 4, 4, 5, 2, 'Jupiter');
const genResult = autoling.run({ mode: 'generate', coordinate: userCoord, media: 'language' });

if (genResult.ok && genResult.surface) {
  console.log(`\n  Generated: ${genResult.surface}`);

  const field = resolveSemanticField(userCoord);
  if (field) {
    console.log(`\n  Semantic field:`);
    console.log(`    Gate: ${field.hdName} (${field.iChingName})`);
    console.log(`    Hexagram: ${field.hexagram}`);
    console.log(`    Center: ${field.hdCenter} | Circuit: ${field.hdCircuit}`);
    console.log(`    Organ: ${field.organ} | Astrological: ${field.astrologicalSign}`);
    console.log(`    Contributions: ${field.contributions.join(', ')}`);
    console.log(`    Quality primary: ${field.quality.primary}`);
    console.log(`    Secondary: ${field.quality.secondary.join(', ')}`);
    console.log(`    Tension: ${field.quality.tension.join(', ')}`);
    console.log(`    Resolution: ${field.quality.resolution.join(', ')}`);
    console.log(`    Spectral: HSL(${field.quality.spectral.hue.toFixed(1)}, ${(field.quality.spectral.saturation * 100).toFixed(0)}%, ${(field.quality.spectral.value * 100).toFixed(0)}%)`);
    console.log(`    Affordances: ${field.affordances.join(', ')}`);
    console.log(`    Neighbors: ${field.neighboringTendencies.map(n => `Gate ${n.targetGate}(${n.strength.toFixed(2)}${n.channelType ? ' [' + n.channelType + ']' : ''})`).join(', ')}`);
    console.log(`    Projection: ${JSON.stringify(field.projectionBias)}`);

    const mesostate = generateMesostate(userCoord, {
      activationHistory: [],
      meshCoherence: 0.7,
      userPressure: 0.8,
      timeSinceLastAccess: 0
    });

    console.log(`\n  Mesostate:`);
    console.log(`    Stability: ${mesostate.stability}`);
    console.log(`    Transition readiness: ${(mesostate.transitionReadiness * 100).toFixed(1)}%`);
    console.log(`    Gradients: ${mesostate.gradients.map(g => `${g.direction}(${g.strength.toFixed(2)})[${g.type}]`).join(', ')}`);
    console.log(`    Convergence proximity: ${(mesostate.convergence.proximity * 100).toFixed(1)}%`);
    console.log(`    Convergence targets: ${mesostate.convergence.targetCoordinates.map(coordinateToString).join(', ')}`);
    console.log(`    Ambiguity preserved: ${mesostate.ambiguity.preserveAmbiguity}`);
    console.log(`    Ambiguity candidates: ${mesostate.ambiguity.candidates.map(c => `${coordinateToString(c.coordinate)}(${c.probability.toFixed(2)})`).join(', ')}`);
    console.log(`    Recursion depth: ${mesostate.recursionDepth}`);
  }

  if (genResult.activation) {
    console.log(`\n  Mesh activation: ${coordinateToString(genResult.activation.coordinate)}`);
    console.log(`  Strength: ${(genResult.activation.strength * 100).toFixed(1)}%`);
    console.log(`  Propagation: ${genResult.activation.propagationTargets.map(coordinateToString).join(', ')}`);
  }
}

// ──────────────────────────────────────────────────────────────────────
// EXAMPLE 3: CODEGEN
// ──────────────────────────────────────────────────────────────────────
console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('EXAMPLE 3: CODEGEN');
console.log('Generating code for coordinate 6.4.4.5.2');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

const generatedCode = autoling.codegen(userCoord);
console.log(generatedCode);

// ──────────────────────────────────────────────────────────────────────
// EXAMPLE 4: MESH TOPOLOGY
// ──────────────────────────────────────────────────────────────────────
console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('EXAMPLE 4: MESH TOPOLOGY');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

const topology = mesh.topology();
console.log(`\nTotal channels: ${topology.length}`);
topology.forEach(t => {
  console.log(`  ${t.channel}: ${t.messageCount} messages from [${t.sourceTools.join(', ')}] (age: ${t.ageMs}ms)`);
});

// ──────────────────────────────────────────────────────────────────────
// EXAMPLE 5: COMPLEX INPUT (AMBIGUITY)
// ──────────────────────────────────────────────────────────────────────
console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('EXAMPLE 5: COMPLEX INPUT (AMBIGUITY PRESERVATION)');
console.log('User input: "I feel a breakthrough coming but I need to understand the depth first"');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

const complexResult = autoling.run({
  mode: 'recognize',
  text: 'I feel a breakthrough coming but I need to understand the depth first'
});

if (complexResult.ok && complexResult.candidates) {
  console.log('\nRecognition candidates:');
  complexResult.candidates.forEach((c, i) => {
    console.log(`\n  ${i + 1}. ${coordinateToString(c.coordinate)}`);
    console.log(`     Confidence: ${(c.confidence * 100).toFixed(1)}%`);
    console.log(`     Gate: ${c.semanticField.hdName}`);
    console.log(`     Stability: ${c.mesostate.stability}`);
    console.log(`     Ambiguity: ${c.mesostate.ambiguity.preserveAmbiguity ? 'PRESERVED' : 'RESOLVED'}`);
    if (c.mesostate.ambiguity.candidates.length > 1) {
      console.log(`     Ambiguous candidates: ${c.mesostate.ambiguity.candidates.map(cand => `${coordinateToString(cand.coordinate)}(${cand.probability.toFixed(2)})`).join(', ')}`);
    }
  });

  if (complexResult.activation && complexResult.activation.propagationTargets.length > 0) {
    console.log(`\n  Propagation targets (ambiguous state):`);
    complexResult.activation.propagationTargets.forEach(t => {
      console.log(`    ${coordinateToString(t)}`);
    });
  }
}

console.log('\n╔══════════════════════════════════════════════════════════════════════╗');
console.log('║  DEMO COMPLETE                                                       ║');
console.log('╚══════════════════════════════════════════════════════════════════════╝');
