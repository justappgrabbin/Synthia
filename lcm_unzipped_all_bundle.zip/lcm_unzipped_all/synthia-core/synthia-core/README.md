# Synthia Core — MESSY Organism

Local-first digital organism for alignment, activation, and expression.

## Architecture

```
packages/
  StateSpace.ts          — Ontological constitution (coordinates, semantic fields, mesostates)
  CoordinateSystem.ts    — 10 real gates with full semantic fields, line/color/tone/base semantics, resonance computation
  AutoLing.ts            — Bidirectional recognition/generation at coordinate level (Klein 1968)
  EventMesh.ts           — Emergent channel mesh (channels materialize on first use)
  IntegrationExample.ts  — Working demo of full flow
```

## Quick Start

```bash
npm install
npm run build
npm run demo
```

## What This Does

### 1. State-Space Definition
- **Canonical coordinate schema**: gate (1-64) × line (1-6) × color (1-6) × tone (1-6) × base (1-5) × planet (13) × arc (degree/minute/second)
- **Semantic field**: intrinsic node contributions, quality cluster, relational affordances, argument tendencies, neighboring tendencies, projection bias
- **Mesostate model**: stability regime, transition readiness, gradients, convergence state, ambiguity preservation
- **State region**: macrostate (hexagram/gate) as bounded region with internal microstates, stable zones, transition bands, instability ridges

### 2. AutoLing (Bidirectional)
- **Recognition**: semantic pattern matching (not regex) — surface text → candidate coordinates with confidence
- **Generation**: semantic field-driven expression (not templates) — coordinate → surface text with mesostate awareness
- **Ambiguity preservation**: when top candidates are close, preserves mixed state instead of forcing resolution
- **Mesh activation**: both recognition and generation publish to the mesh, activating coordinates and propagating

### 3. Mesh (Emergent)
- Channels materialize on first use — no pre-declaration
- `mesh:emergence` events fire when new topology forms
- Messages carry ontological qualification (source tool, coordinate, strength)
- Topology inspection shows all channels, message counts, source tools, ages

### 4. Codegen
- Generates state-space traversal functions (neighbor exploration, gradient following)
- Generates mesh activation functions (publishing to channels, propagation targets)
- Generates projection functions (language/code/image/sound/interface expression)

## Gates Defined (10)

| Gate | I Ching | HD Name | Center | Circuit | Planet | Organ |
|------|---------|---------|--------|---------|--------|-------|
| 1 | The Creative | Self-Expression | G | Individual | Mars | Liver |
| 2 | The Receptive | Higher Knowing | G | Collective | Moon | Liver |
| 6 | Conflict | Friction | Solar Plexus | Tribal | Jupiter | Kidneys |
| 10 | Treading | Behavior | G | Individual | Saturn | Liver |
| 17 | Following | Opinions | Ajna | Collective | Mercury | Pituitary |
| 23 | Splitting Apart | Assimilation | Throat | Individual | Saturn | Thyroid |
| 34 | Great Power | Power | Sacral | Individual | Mars | Ovaries/Testes |
| 43 | Breakthrough | Insight | Ajna | Individual | Uranus | Pituitary |
| 48 | The Well | Depth | Spleen | Collective | Saturn | Lymphatic |
| 61 | Inner Truth | Mystery | Head | Individual | Neptune | Pineal |

## Verified Address

User's verified coordinate: **6.4.4.5.2** (Gate 6, Line 4, Color 4, Tone 5, Base 2)
- Gate 6: Conflict (Song) — Friction, boundary, correction, selective pressure
- Line 4: Formulative structure — structured, pattern-forming
- Color 4: Need-motivated — requirement-driven, necessary
- Tone 5: Social perception — sees relation, interpersonal
- Base 2: Emotional base — feeling, relational, responsive

## Next Steps

1. Complete 64-gate semantic field table
2. Build DISEMINER (co-occurrence inference, composite relation formation)
3. Build NovelWriter (narrative projection from activated coordinates)
4. Build MESSY state-transition substrate (mesostate management, convergence, recursion)
5. Integrate with real ephemeris (`real_ephemeris.py`) for birth-data coordinate computation
6. Integrate with oracle (`oracle.py`) for HD chart interpretation
7. Build browser shell for multimodal projection

## Principles

- **State space first**: All possible forms exist as latent structure before expression
- **Activation before computation**: Locate and activate relevant state before heavy inference
- **Mesh before direct calls**: Subsystems communicate through emergent channels, not point-to-point
- **Morph through message passing**: Messages change receiver state, not just inform
- **Meaning is proportional**: Derived through correspondences among isomorphic qualities across domains
- **Color is semantic state**: Not decoration — affects activation and expression
- **Identity is a center**: User anchors alignment and hosts model/tool bridges
- **Local first**: Core organism operates locally; external services are optional amplifiers

## License

MIT
