
// Synthia AST Engine — Acode Plugin Entry Point
// Loads the AST engine UI as a custom editor/sidebar panel

const plugin = {
  id: 'synthia-ast-engine',

  async init($page, cacheFile, cacheFileUrl) {
    // Add sidebar panel
    acode.addIcon('synthia-ast', {
      name: 'Synthia AST',
      icon: 'icon-ast',
      onselect: () => this.openAstPanel()
    });

    // Add context menu item for "Analyze with AST"
    acode.addContextMenuItem({
      id: 'synthia-analyze',
      text: '🔬 Analyze with AST',
      onclick: () => this.analyzeCurrentFile()
    });

    // Add command palette command
    acode.addCommand('synthia-ast-open', {
      name: 'Synthia: Open AST Explorer',
      exec: () => this.openAstPanel()
    });

    acode.addCommand('synthia-ast-analyze', {
      name: 'Synthia: Analyze Current File',
      exec: () => this.analyzeCurrentFile()
    });

    toast('Synthia AST Engine loaded');
  },

  openAstPanel() {
    // Open AST explorer in a new editor tab
    const file = {
      name: 'Synthia AST Engine',
      uri: 'synthia-ast://explorer',
      type: 'editor',
      render: () => this.renderAstUI()
    };
    editorManager.addNewFile(file.name, file);
  },

  async analyzeCurrentFile() {
    const activeFile = editorManager.activeFile;
    if (!activeFile) {
      toast('No file open', 3000);
      return;
    }

    const content = activeFile.session.getValue();
    const filename = activeFile.filename;

    // Store for the AST UI to pick up
    localStorage.setItem('synthia-ast-target', JSON.stringify({
      name: filename,
      content: content,
      timestamp: Date.now()
    }));

    this.openAstPanel();
    toast('Analyzing ' + filename + '...');
  },

  renderAstUI() {
    // Return iframe pointing to the plugin's www/index.html
    const pluginUrl = acode.getPluginUrl('synthia-ast-engine');
    return `<iframe src="${pluginUrl}/www/index.html" style="width:100%;height:100%;border:none;"></iframe>`;
  },

  async destroy() {
    // Cleanup
  }
};

export default plugin;
