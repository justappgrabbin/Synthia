# DOCS INDEX

This bundle collects the current canonical doctrine and merge documents in one place.

## Core doctrine
- FOUNDATION.md
- ONTOLOGY.md
- MESH.md
- STATE_SPACE_MECHANICS.md
- NODE_FUNCTIONS.md

## Repo / implementation docs
- MIGRATION_MAP.md
- ARCHIVE_POLICY.md
- MERGE_PLAN.md

## Recommended reading order
1. FOUNDATION.md
2. ONTOLOGY.md
3. STATE_SPACE_MECHANICS.md
4. NODE_FUNCTIONS.md
5. MESH.md
6. MERGE_PLAN.md
7. MIGRATION_MAP.md
8. ARCHIVE_POLICY.md
