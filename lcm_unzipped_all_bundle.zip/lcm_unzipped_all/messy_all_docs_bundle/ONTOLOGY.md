# ONTOLOGY

## Purpose

This document defines the organism’s canonical meaning structure.

The ontology is the source of truth for what exists in MESSY, how those things are ordered, how they relate, and how activation and expression move through the system.

The code must conform to this document.
This document does not conform to the code.

---

## Ontological Principle

All possible forms exist as latent structure within the state space before expression.

The organism does not primarily create new forms from nothing. It addresses, activates, modulates, and expresses already latent possibilities.

This means the ontology defines:

- what may be addressed
- what may be activated
- how states may converge
- how expression may be qualified
- how correspondences may be recognized across domains

---

## Two Kinds of Structure

MESSY contains two interacting kinds of structure:

### 1. Discrete Structure
Countable symbolic layers:
- planets
- dimensions
- centers
- gates / hexagrams
- lines
- colors
- tones
- bases

### 2. Continuous Structure
Sliding, spectral, or positional layers:
- arcs
- degrees
- minutes
- seconds
- phase
- intensity
- interpolation
- sound variation
- color variation
- temporal or positional modulation

The organism is therefore neither purely symbolic nor purely continuous.
It is a hybrid ontology.

---

## Discrete Lattice

The first canonical discrete lattice is:

- 13 planetary influences
- 5 dimensions
- 9 centers
- 64 gates / hexagram nodes
- 6 lines per gate
- 6 colors per line
- 6 tones per color
- 5 bases per tone

This is the upper addressable state stack.

### Canonical interpretation
- planets qualify influence and larger-order motion
- dimensions define major process domains
- centers define functional hubs
- gates define node-level archetypal addresses
- lines define role or positional expression
- colors define motivational and spectral qualification
- tones define perception filters or attunement modes
- bases define fine-grained grounding or base-level modulation

---

## Planets

There are 13 planetary influences in the organism’s state model.

At minimum, planets should be treated as first-class qualifiers of state.
The exact semantics of each planetary influence may be further elaborated, but the ontology requires that planetary influence exists as part of addressing and activation.

### Law
A state may not be fully described without its planetary qualification when planetary information is available.

---

## The Five Dimensions

The organism operates across five primary dimensions:

1. Movement
2. Evolution
3. Being
4. Design
5. Space

These dimensions are not presentation labels. They are deep ontological process domains.

Each dimension has:

- its own order
- its own qualities
- its own oppositions or reversals
- its own macrocosmic and microcosmic expression
- its own expressive or sensory chain

A dimension must therefore be represented not as a single field only, but as a structured correspondence object.

---

## Dimension Correspondence

Each dimension participates in correspondence across scale.

### First correspondence set
- Movement ↔ Individuality ↔ keynote: I Define
- Evolution ↔ Mind ↔ keynote: I Remember
- Being ↔ Body ↔ keynote: I Am
- Design ↔ Ego ↔ keynote: I Design
- Space ↔ Personality ↔ keynote: I Think

These are proportional correspondences, not literal substitutions.

### Law
A dimension may be expressed differently at macrocosmic and microcosmic levels while retaining the same structural quality.

---

## Macrocosm and Microcosm

The ontology assumes that structural qualities appear across scales.

Examples from the current correspondence layer:

- macrocosmic process
- microcosmic embodiment
- keynote expression
- sensory or experiential chain

Meaning is derived through proportional relation among these expressions.

### Law
Meaning in MESSY is derived through proportional correspondences among isomorphic qualities across domains and scales.

---

## Centers

The system contains up to nine centers.

Centers are not merely storage locations. They are hubs of stabilized expression resulting from channel relations, gate activation, and recursive convergence.

A center is therefore:
- structural
- dynamic
- graded
- contextual

### Center activation modes
A center may be:
- latent
- converging
- modulating
- expressed
- actioning

A center does not need to reach full action in order to matter. It may modulate sublayers only.

### Examples of partial effect
A center may affect:
- color
- tone
- image properties
- sound properties
- interface behavior
- semantic emphasis
- expressive quality

### Law
Center activation is graded, not binary.

---

## The Identity Center

One center has a special role: the Identity Center.

The Identity Center is the user-alignment hub.
It is where:
- user-specific LLM bridges sit
- MCP bridges sit
- tool routing is aligned
- user style and semantic preferences are held
- system orientation to the user is anchored

### Law
The Identity Center is canonical and central. It is not an optional afterthought.

---

## Gates / Hexagrams

There are 64 gates or hexagram nodes.

A gate is an addressable archetypal node in the state space.
It is not merely a UI symbol.
It is a structural address used in activation, routing, and expression.

### Law
A gate is a canonical node-level address in the ontology.

---

## Lines

Each gate contains 6 lines.

A line qualifies role, position, or local mode of expression within a gate.

Lines are not optional decoration. They determine how a gate is locally expressed or approached.

### Law
A gate without line qualification is incomplete when line information is available.

---

## Colors

Each line contains 6 colors.

Color is a first-class semantic layer.
Color is not decoration.
Color is not merely visual styling.

Color operates as:
- motivational qualification
- drive-response qualification
- spectral qualification
- environmental influence layer
- part of the organism’s expression logic

The ontology treats color as both:
- symbolic
- perceptual

### Law
In MESSY, color is semantic state. It is never only presentation.

---

## Tones

Each color contains 6 tones.

Tone acts as:
- a perceptual filter
- an attunement mode
- a way of sensing or receiving structure

Tone modulates how information enters expression and how state is perceived or filtered.

### Law
Tone is a perception layer and must remain first-class in the ontology.

---

## Bases

Each tone contains 5 bases.

Base is the fine-grained grounding layer.
It is a lower-level qualifier that refines the organization of active state.

The exact semantics of the five bases may be elaborated further, but the ontology requires their existence as canonical substructure.

### Law
Base is part of canonical state addressing.

---

## Layered State Address

A fully qualified discrete state may include:

- planet
- dimension
- center
- gate
- line
- color
- tone
- base

When enough data exists, the organism should preserve the full path rather than collapsing it.

### Law
The organism should preserve maximum meaningful qualification instead of flattening active state into generic labels.

---

## Continuous Modulation

The organism also contains arc-based and spectral modulation.

This includes:
- degrees
- minutes
- seconds
- sliding scales
- spectral ranges
- tonal ranges
- intensity
- phase
- interpolation

Continuous modulation affects how discrete structures are expressed.

Examples:
- sound quality
- color expression
- phase or timing
- position on a scale
- degree of convergence

### Law
Continuous modulation refines discrete addressability rather than replacing it.

---

## Arc Structure

The arc is a sliding scale for expression and modulation.

The exact final interpretation of all arc structures remains partially unresolved, but the ontology currently recognizes:

- arc as positional scale
- arc as modulation layer for sound and color
- arc as a contributor to structural splits such as 12 / 8 / 4

### Status
Provisional but canonical as an unresolved domain.

### Law
Unresolved ontology is allowed, but it must be explicitly marked as unresolved rather than silently guessed.

---

## 12 / 8 / 4 Structural Split

The ontology currently includes a recurring structural split involving 12, 8, and 4.

This appears related to:
- arc structure
- positional projection
- sound/color correspondence
- opposing sides of a larger arrangement

The exact semantics remain provisional.

### Law
Do not hardcode final meaning where the ontology is still under derivation.
Represent unresolved ratios as provisional structures.

---

## Oppositions and Reversals

Each dimension may have:
- a forward form
- a reverse form
- oppositional variation
- correspondence pairs

The ontology therefore supports:
- reversal
- polarity
- opposition
- mirrored structure
- proportion-preserving transformation

### Law
Opposition and reversal are structural operations, not anomalies.

---

## Five Variations and Nine Possible Structures

The ontology includes variation families derived from I Ching structure and dimensional reversal.

Current working understanding:
- there are multiple variation forms
- one side may present as four with five emergent
- the other as five with four emergent
- these oppositions yield up to nine possible center structures or placements

This remains a partially resolved but important ontological domain.

### Law
Emergent structure must be representable even when not all theoretical center forms are fully stabilized.

---

## Mesh Relation to Ontology

The ontology defines what may exist.
The mesh defines how existing structure communicates, traverses, and morphs.

A message moving through the mesh may be qualified by:
- active gates
- active channels
- active centers
- dimension context
- color/tone/base context
- planetary and arc modulation

This means the ontology and the mesh are distinct but inseparable.

### Law
Ontology defines addressability. Mesh defines traversal.

---

## Channels and Edges

### Channels
Channels are pathways of relation and activation.

### Edges
Edges are realized graph relations formed or reinforced through traversal.

Stable channel-edge patterns help define center behavior.

### Law
Channels and edges are not generic graph links. They are ontologically qualified relational structures.

---

## Proportional Perception Among Isomorphic Qualities

This is a core ontological principle.

A sound pattern, a color pattern, a behavioral pattern, a code pattern, a linguistic pattern, and a symbolic pattern may all express the same underlying structural quality.

The organism must therefore be able to recognize:
- similarity across media
- similarity across scale
- partial correspondence
- reversal or inversion
- proportional transformation
- isomorphic relation without literal sameness

### Law
A state is not defined only by identity. It is also defined by its proportional relation to structurally isomorphic states across domains.

---

## Activation Grammars

The ontology must support multiple activation grammars.

Human Design is one activation grammar.
It is not the only one.

Other activation grammars may include:
- user responses
- language patterns
- behavioral patterns
- code patterns
- interaction traces
- sound/image signatures

These different input grammars may address the same latent state space.

### Law
Multiple input grammars may activate the same underlying ontological state.

---

## Projection Domains

Once a state is activated, it may be projected into one or more expression domains:
- language
- code
- image
- sound
- interface
- graph structure
- behavior

Projection is downstream from ontology and activation.

### Law
Projection does not define ontology. Projection expresses ontology.

---

## Local-First Ontological Rule

The organism’s core ontology must remain locally available.
It should not depend on remote models or services just to know what exists.

### Must remain local
- dimensions
- centers
- gates
- lines
- colors
- tones
- bases
- correspondences
- identity center structure
- mesh qualification metadata

### May be externally amplified
- LLM interpretation
- MCP tool access
- heavy numerical services
- research modules

### Law
The organism must be able to know its structure locally.

---

## Canonical Type Direction

The first canonical shared types should encode:
- discrete state lattice
- continuous modulation fields
- dimension correspondence tables
- center activation modes
- gate/line/color/tone/base qualification
- identity center bindings
- provisional arc structures

These types should live in shared packages and be imported by all live runtime code.

---

## Final Ontological Rule

The ontology is the constitution of the organism.

Runtime behavior, package boundaries, activation logic, projection logic, and external integrations must all be derived from this structure rather than inventing parallel meaning models.
