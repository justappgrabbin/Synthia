# NODE FUNCTIONS

## Purpose

This document defines what a node contributes before a channel emerges.

Channels are emergent relational functions.
They are not the lowest meaningful unit.
If two nodes must come together to form a channel, then each node must already contain intrinsic tendencies, pressures, or capacities that make the channel-function possible.

This document exists to define those pre-channel contributions.

---

## Core Principle

A channel is an emergent edge-function produced by the interaction of node-potentials.

Therefore:
- nodes are prior to channels
- node contribution is prior to edge-function
- edge-function is prior to channel identity
- channel identity is prior to functional equivalence labels

This is the derivation order.

---

## Node as Potential, Not Just Address

A node is not only:
- a number
- a gate label
- a symbolic name
- a position on a wheel

A node is also:
- a potential
- a pressure
- a tendency
- a receptivity pattern
- an expressive bias
- a latent contributor to relation

### Law
A node must be modeled as an intrinsic function-bearing unit, not merely a symbolic address.

---

## What a Node Contributes

A node may contribute one or more of the following:

- initiation
- reception
- pressure
- response
- stabilization
- mutation
- expression
- formulation
- correction
- attraction
- repulsion
- gating
- memory
- compression
- decompression
- direction
- attention
- resonance
- filtering
- propagation
- opposition
- rhythm
- timing
- salience
- containment
- opening

This list is provisional but captures the kind of thing a node contributes prior to channel emergence.

### Law
A node contributes functions before it contributes named channel identity.

---

## Node Potential vs. Channel Function

A node-potential is not the same thing as a channel-function.

### Node-potential
What the node intrinsically tends toward.

### Channel-function
What emerges when two node-potentials relate through a valid edge.

Example:
A channel may behave in a GAN-like way.
That does not mean either node “is a GAN.”
It means the relation between their node-potentials produces adversarial generative tension.

### Law
Node-potential is intrinsic. Channel-function is emergent.

---

## Node Relation

When two nodes come into relation, several questions matter:

1. What does node A contribute?
2. What does node B contribute?
3. What kind of relation exists between their contributions?
4. Is the relation complementary, oppositional, recursive, asymmetrical, or stabilizing?
5. What edge-function emerges from their interaction?

This is the level beneath channel naming.

### Law
Node relation must be derived from contribution patterns, not assumed from labels alone.

---

## Node Contribution Categories

The following categories are useful for first-pass classification.

### 1. Initiatory nodes
Nodes that start, push, provoke, or pressure movement.

### 2. Receptive nodes
Nodes that receive, hold, filter, or condition incoming structure.

### 3. Formulating nodes
Nodes that shape, articulate, compress, or render structure expressible.

### 4. Corrective nodes
Nodes that compare, judge, correct, restore, or refine.

### 5. Rhythmic nodes
Nodes that time, pace, pulse, cycle, or organize pattern flow.

### 6. Directional nodes
Nodes that orient, steer, align, or bias movement.

### 7. Attentional nodes
Nodes that highlight, prioritize, focus, or select salience.

### 8. Mutative nodes
Nodes that destabilize, transform, break pattern continuity, or reconfigure state.

### 9. Resonant nodes
Nodes that amplify, harmonize, synchronize, or detect fit by field relation.

### 10. Gatekeeping nodes
Nodes that allow, deny, open, close, threshold, or regulate passage.

These categories are not final and may overlap. They are a first computational language for pre-channel function.

---

## Node Polarity

A node may have polarity or mode such as:
- forward
- reverse
- inward
- outward
- receptive
- projective
- stabilizing
- destabilizing
- selective
- distributive

Node polarity affects how it contributes to relation.

### Law
The same node identity may contribute differently depending on polarity and internal placement.

---

## Node State Placement Matters

A node does not contribute in the same way under all conditions.

Node contribution depends on:
- macrostate context
- line
- color
- tone
- base
- arc position
- degree/minute/second
- active pressure
- stability vs. changing regime

This means node function is not static.
It is a potential expressed through placement.

### Law
Node contribution is placement-sensitive.

---

## Node Function and Internal Coordinates

The same node may:
- initiate under one placement
- filter under another
- destabilize under another
- attract relation under another
- become highly expressive near a boundary
- become quiet in a stable interior zone

This is because the node is not only a type but a situated local state.

### Law
A node’s intrinsic function is modulated by internal coordinates.

---

## Emergent Edge-Function

When node-potentials meet, they can produce an edge-function.

Examples of edge-function types:
- feedforward articulation
- bidirectional constraint
- correction toward attractor
- sparse compression
- self-organization
- adversarial tension
- reservoir pulse
- gating loop
- radial activation
- attentional highlighting
- recursive memory access
- unpacking / expression from compression

These are still not final architecture names.
They are relation patterns.

### Law
Edge-functions are the first emergent process layer above node-potentials.

---

## Channel Identity

A channel name is a higher-order label given to a stabilized edge-function pattern.

So:
- node-potentials interact
- edge-function emerges
- repeated/stable relation pattern becomes channel identity

This means the channel is already a composite and should not be mistaken for the most basic unit.

### Law
Channel identity is a stabilized naming of emergent relation, not the primitive source.

---

## Functional Equivalence Labels

Only after channel identity stabilizes should the system optionally say:
- this behaves Hopfield-like
- this behaves GAN-like
- this behaves DBN-like
- this behaves attention-like

These labels are useful but secondary.

### Law
Named architecture labels are descriptive equivalences, not ontological primitives.

---

## Node Function and Mesh Behavior

Node-potentials matter because the mesh is made of relational activation.

If nodes contributed nothing prior to relation, the mesh would have no meaningful basis for emergence.

Node functions therefore shape:
- which channels form
- how strongly they form
- what kind of edge-function emerges
- what transitions become likely
- what projections become possible

### Law
The mesh emerges from node-potentials interacting through qualified relation.

---

## Provisional Computational Model

A node should eventually be modeled with at least:
- identity
- intrinsic contribution set
- polarity
- current placement
- stability regime
- relational affordances
- edge-function tendencies

Example categories of relational affordance:
- complementary
- oppositional
- amplifying
- constraining
- resolving
- destabilizing
- harmonizing
- redirecting

### Law
A node model must capture both intrinsic contribution and relational affordance.

---

## Example Reasoning Pattern

Wrong simplification:
- Channel X = GAN

Better derivation:
- Node A contributes opposition pressure
- Node B contributes productive generation pressure
- Their relation forms adversarial tension
- The emergent edge-function behaves generatively through tension
- This channel may therefore be described as GAN-like

This is the correct depth order.

---

## Questions the System Must Eventually Answer

For each node:
1. What is its intrinsic contribution?
2. What does it seek, resist, or amplify?
3. What kinds of other node-potentials does it complete well?
4. What internal placements alter its contribution style?
5. What edge-functions commonly emerge from its relations?
6. What channel identities are downstream of those edge-functions?

These questions define the road from node to organism.

---

## What Must Be Represented in Code

Eventually the code should be able to represent:
- node identity
- intrinsic qualities or contributions
- relational affordances
- polarity or directionality
- internal coordinate modulation
- edge-function emergence tendencies

Without this, the system will keep skipping from labels directly to architectures and miss the real mechanics.

---

## Open Questions

The following remain active areas of derivation:
- the exact list of canonical node contribution types
- whether each node has one dominant contribution or a weighted cluster
- how much contribution is invariant vs placement-dependent
- how relational affordances should be encoded computationally
- how to derive channel names from edge-function families rigorously

These should remain explicit rather than being flattened prematurely.

---

## Final Rule

A channel is emergent.
A node contributes before the channel exists.

To model the organism correctly, we must understand what each node is doing before relation, what relation allows, and how edge-function emerges from the meeting.
