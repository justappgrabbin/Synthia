# FOUNDATION

## Purpose

MESSY is a local-first digital organism for alignment, activation, and expression.

It is not primarily a chatbot, not primarily a backend, and not primarily a model wrapper.

Its job is to:

- hold a latent state space of possible forms
- activate relevant structures through multiple input grammars
- route messages through a morphing mesh
- align external models and tools to the user
- express activated structure as language, code, image, sound, interface, or behavior

The system is designed so that meaning is not rebuilt from scratch each session. Meaning is held in the organism’s ontology and activated through traversal.

---

## Core Thesis

All possible forms already exist in the state space as latent structure.

The organism does not primarily compute forms into existence. It addresses, activates, and expresses the relevant form.

Computation is secondary.
State space is primary.
Activation precedes generation.
Expression follows activation.

---

## First Principles

### 1. State Space First
The organism assumes that possible forms already exist as latent structure.

### 2. Activation Before Computation
The organism first locates and activates the relevant state before attempting heavy inference or external computation.

### 3. Mesh Before Direct Calls
Subsystems communicate through a mesh, not through isolated point-to-point logic.

### 4. Morph Through Message Passing
Messages do not merely inform receivers. They can change the receiver’s state, quality, or role.

### 5. Meaning Is Proportional
Meaning is derived through proportional correspondences among isomorphic qualities across domains and scales.

### 6. Color Is Semantic State
Color is not decoration. Color is part of the organism’s operating logic and affects activation and expression.

### 7. Identity Is a Center
The user is not external to the system. The Identity Center anchors alignment and hosts model/tool bridges.

### 8. Local First
The core organism should be able to operate locally through structure and activation, with external services used only as optional amplifiers.

---

## What MESSY Is

MESSY is a recursive, message-morphic, state-latticed organism.

It consists of:

- a latent ontology
- activation grammars
- a message mesh
- gates, channels, and centers
- a user-centered identity hub
- projection layers for expression
- optional external cognition bridges

MESSY is not a replacement for LLMs or MCP. It is the bridge that aligns them to the user and to the organism’s state space.

---

## Ontological Stack

The organism is organized as a nested symbolic and perceptual structure.

### Discrete layers
- 13 planetary influences
- 5 dimensions
- 9 centers
- 64 hexagram nodes / gates
- 6 lines per gate
- 6 colors per line
- 6 tones per color
- 5 bases per tone

### Continuous layers
- arc-based modulation
- spectral variation
- sound variation
- color variation
- timing and position
- phase, intensity, and interpolation

The organism therefore combines:

- discrete symbolic addressability
- continuous modulation of expression

---

## The Five Dimensions

The system has five primary dimensions.

1. Movement
2. Evolution
3. Being
4. Design
5. Space

These dimensions are not mere tags. Each dimension has:

- its own order
- its own qualities
- its own reversals or oppositions
- macrocosmic and microcosmic correspondences
- sensory and expressive chains

Each dimension may map differently across scale, substrate, and embodiment.

---

## Macrocosm and Microcosm

A dimension has both macrocosmic and microcosmic expressions.

Examples:

- Movement ↔ Individuality
- Evolution ↔ Mind
- Being ↔ Body
- Design ↔ Ego
- Space ↔ Personality

These are not literal equivalences. They are proportional correspondences between structurally similar qualities expressed at different levels.

Meaning in MESSY is derived through these proportional correspondences.

---

## Centers

There are up to nine possible centers.

Centers are not just static containers. They are hubs of stabilized expression produced by the interplay of channels, gates, and activations.

A center may be:

- latent
- converging
- modulating
- expressed
- actioning

A center does not need to fully reach action in order to matter. It may only affect:

- color
- tone
- image
- sound
- interface
- mood
- expression quality

This means the organism supports graded activation, not just binary on/off state.

---

## Gates, Channels, and Edges

### Gates
A gate is a node or addressable archetypal state.

### Channels
A channel is a pathway of relation and activation between structures.

### Edges
Edges are the realized graph relations produced through traversal and activation.

Messages traverse channels and create or reinforce edges. Stable edge patterns help define centers.

---

## The Mesh

The organism communicates through a generative mesh.

The mesh is:

- the transport substrate
- the morph substrate
- the relation substrate

Messages do not just pass through the mesh. They are qualified by gates, routed through channels, and can morph the systems that receive them.

### Mesh law
gate -> message -> mesh -> channel traversal -> morph -> expression -> center behavior

The traversal path matters.
The route changes the meaning.
The receiver may be altered by what it receives.

---

## Identity Center

The Identity Center is the user-alignment hub.

It is where:

- the user’s LLMs sit
- MCP connections are bridged
- tool routing is aligned
- user-specific style and meaning are preserved
- the organism remains oriented to the user

The Identity Center is not just a settings object. It is a central functional hub.

LLMs are not the organism.
MCP is not the organism.
The Identity Center aligns them within the organism.

---

## Awareness Organs

The historical basis for the organism includes three core organ templates:

- AUTOLING
- DISEMINER
- Automatic Novel Writer

These are treated as distinct awareness modes rather than mere tools.

### AUTOLING
Structural and linguistic discovery.

### DISEMINER
Inference spread and semantic propagation.

### Automatic Novel Writer
Narrative synthesis and expressive generation.

These organs may operate across multiple strata and may eventually extend into a broader 9-organ structure.

---

## Strata

The organism operates across three main strata:

- Heart / Direction
- Mind / Structure / Code
- Action / Embodiment / Image

These strata are not fully separate. They are ways of organizing how organs behave and where activation manifests.

---

## Proportional Perception Among Isomorphic Qualities

This is one of the main differentiators of the system.

MESSY does not only map symbols to symbols.
It detects proportional correspondences among isomorphic qualities across different domains and scales.

That means:

- a sound pattern
- a color pattern
- a behavioral pattern
- a linguistic pattern
- a code pattern
- a symbolic pattern

may all be expressions of the same underlying structural quality.

The organism should be able to recognize the same form:

- at a different scale
- in a different medium
- in reverse
- as a partial analogy
- as a transformed proportion

This principle allows the organism to perceive across domains instead of remaining trapped in literal symbol matching.

---

## Color and Tone

Color and tone are first-class operating layers.

### Tone
Tone acts as a perception filter.

### Color
Color acts as a motivational, spectral, and drive-response layer.

Color is both:

- symbolic
- perceptual

It affects not only motivation but also spectrum, expression, and environmental effect.

Ignoring color collapses the stack and destroys part of the organism’s meaning model.

---

## Activation Grammars

Human Design is one activation grammar.
It is not the only valid entrypoint.

The organism may also activate through:

- user responses
- behavior
- language patterns
- code patterns
- interaction traces
- sound and image signatures
- other structured inputs

This means the organism should not require a full Human Design chart in order to function.

Human Design is a privileged mapping, not a mandatory one.

---

## Projection

Once activated, structure may be projected into different forms:

- language
- code
- image
- sound
- interface
- graph state
- behavior

Projection is downstream from activation.
The system first determines what is active, then how that activity should appear.

---

## Local-First Doctrine

The organism should be able to function as a structurally intelligent local system.

### Must remain local and canonical
- ontology
- state space
- mesh
- gates, channels, centers
- identity center
- morph logic
- persistence
- browser shell and runtime spine

### May be external or optional
- user LLMs
- MCP servers
- oracle services
- training pipelines
- market services
- heavy numerical or research modules

The organism is alive locally. External systems amplify it but do not constitute it.

---

## Canonical Runtime Law

The runtime should do the following:

1. load ontology
2. load state space
3. initialize mesh
4. initialize identity center
5. register organs
6. register activation grammars
7. route and qualify messages
8. compute convergence and center activation
9. project resulting state into user-facing forms

The runtime is the body.
The packages are organs and layers.
The services are optional attachments.

---

## Canonical Repo Direction

The codebase should be organized around:

- truth
- activation
- projection
- optional compute

### Suggested shape
- `apps/runtime`
- `apps/browser-shell`
- `packages/ontology`
- `packages/state-space`
- `packages/mesh`
- `packages/activation`
- `packages/identity-center`
- `packages/projection`
- `packages/types`
- `packages/persistence`
- `packages/organs-*`
- `services/*` only where truly needed

---

## Archive Law

Only one implementation per concern may remain canonical.

Everything else must be:

- wrapped
- adapted
- extracted
- or archived

No duplicate implementation may continue pretending to be equally canonical.

---

## Minimum Viable Organism

A valid first version does not need the full self-building stack.

It only needs:

- one canonical ontology
- one canonical runtime
- one canonical mesh
- one identity center
- one activation path
- one projection path into UI
- one persistence layer

Once this exists, the organism can grow without forking itself.

---

## Final Rule

The code is not the constitution.
The ontology is the constitution.

The repo must conform to the organism’s meaning model.
Future builders, humans, and LLMs should work from this truth layer rather than rebuilding from fragments.
