# STATE SPACE MECHANICS

## Purpose

This document defines how states work internally inside the organism.

The ontology defines what exists.
The mesh defines how existing structure traverses and morphs.
State-space mechanics define how a state is internally organized, how it holds variation, how it approaches transition, and how it expresses different faces without ceasing to be itself.

This document exists to prevent flattening the state space into simple labels.
A hexagram is not just a label.
A node is not just a point.
A state is not just a name.

---

## Core Principle

A state is not a single point.
A state is a bounded region with internal coordinates, gradients, thresholds, and expressive tendencies.

This means:
- a state has identity
- a state has internal articulation
- a state has stable and unstable subregions
- a state may express different faces without ceasing to be the same macrostate

---

## Macrostate and Microstate

### Macrostate
A macrostate is the larger named regime.

Examples:
- a hexagram
- a center activation profile
- a dimensionally qualified dominant state

### Microstate
A microstate is the internal position within a macrostate.

Examples:
- line
- color
- tone
- base
- degree
- minute
- second
- arc offset
- local modulation

### Law
A macrostate without microstate detail is incomplete when finer coordinates are available.

---

## State Region Model

A state should be treated as a region, chamber, basin, or local manifold rather than a single dot.

Within a region there may be:
- stable interior zones
- threshold zones
- directional gradients
- neighbor-facing surfaces
- instability ridges
- expressive pockets
- latent subregions

This means that two entities may inhabit the same macrostate while occupying different internal coordinates.

### Law
Sameness of macrostate does not imply sameness of internal position.

---

## Hexagram as State Region

A hexagram is a macrostate.
It is not only a symbolic token or UI marker.
It is a structured region of possible expression.

A hexagram contains:
- invariant identity
- internal coordinates
- local gradients
- expressive biases
- transition tendencies

The lower layers do not replace the hexagram.
They refract and qualify its expression.

### Law
A hexagram is a bounded expressive region with internal structure.

---

## Internal Coordinates

The current working internal coordinate stack is:

- line
- color
- tone
- base
- arc position
- degree
- minute
- second

These are not independent decorations.
They work together as an inner coordinate system.

### First interpretation
- line = primary local mode of expression
- color = motivational and spectral inflection
- tone = perceptual filter or attunement
- base = grounding substrate
- arc = continuous modulation axis
- degree/minute/second = fine placement within the region

### Law
Internal coordinates qualify how a macrostate presents without replacing its identity.

---

## Line

The line is the primary local mode through which the macrostate expresses.

A line does not necessarily mean transition by itself.
A line may be:
- stable
- emphasized
- stressed
- changing
- resolving

The line helps determine:
- local posture
- local role
- local behavior pattern
- relation to transition thresholds

### Law
The line is a local mode, not merely an index.

---

## Color

Color is a semantic and spectral layer inside the state.

Color affects:
- motivation
- response style
- environment of expression
- spectral bias
- field quality

Color is not merely visual.
It is part of how the state internally differentiates its mode of expression.

### Law
Color is internal semantic modulation, not presentation-only styling.

---

## Tone

Tone is an internal perceptual filter.

Tone shapes:
- how the state receives structure
- how the state emphasizes input
- how the state attunes before expression

### Law
Tone is the perceptual filter of the state region.

---

## Base

Base is the fine-grained grounding substrate.

It supports:
- low-level refinement
- stabilization bias
- foundational modulation of expression

The exact semantics may continue to evolve, but base remains a first-class coordinate in the stack.

### Law
Base is part of canonical internal placement.

---

## Arc Position

Arc position is a continuous modulation layer inside or across state regions.

The arc may govern:
- sound variation
- color variation
- intensity
- phase
- local interpolation
- structural splits such as 12 / 8 / 4

Arc position should be treated as a sliding scale rather than a discrete label.

### Law
Arc position refines and bends expression continuously across an otherwise discrete state stack.

---

## Degree, Minute, and Second

Degree, minute, and second are fine-grained internal coordinates.

They should not be treated as meaningless numerics.
They likely determine:
- exact local placement
- gradient proximity
- threshold nearness
- projection bias
- neighbor-facing tendency
- specificity of expression

The current best model is:
- degree = coarse local placement
- minute = finer placement refinement
- second = highly specific local coordinate

### Law
Degree, minute, and second are internal location markers inside the state region.

---

## Invariance and Variation

Each state has both invariant and variable aspects.

### Invariant aspects
What remains true across all internal expressions of the same macrostate.

Examples:
- macrostate identity
- core qualitative family
- primary relational signature

### Variable aspects
What changes with internal coordinate movement.

Examples:
- local role
- expression style
- motivational inflection
- perceptual bias
- phase or intensity
- tendency toward transition

### Law
A valid state model must distinguish invariant identity from variable expression.

---

## Expressive Delivery

A macrostate may "deliver" different points, tendencies, or expressions depending on its internal coordinate.

This means:
- the same hexagram may present different forward faces
- the same macrostate may lean toward different qualities
- the same named state may generate different channel completions or projections

This does not mean the macrostate has become a different macrostate.
It means its internal position changes what it expresses outwardly.

### Law
Expression is a function of internal coordinate, not just macrostate label.

---

## Neighboring Tendencies

A state region is not isolated.
It may have boundaries or tendencies toward neighboring states.

This means some internal coordinates may:
- face certain neighboring states
- drift toward certain transitions
- be more likely to complete specific channels
- be more likely to enter changing state

### Law
A state region has directional relations to neighboring regions.

---

## Stability and Instability

Not all internal coordinates are equally stable.

A state region may contain:
- highly stable interior zones
- sensitive transition bands
- metastable pockets
- instability ridges
- high-tension boundary surfaces

This helps explain:
- changing lines
- reorientation events
- sudden shifts in expression
- recursive activation cascades

### Law
Stability is locally distributed inside the state region, not uniform across the whole state.

---

## Changing State

A state does not jump instantly from one macrostate to another.

A better model is:
- stable local expression
- increasing tension or pressure
- entry into changing regime
- resolution into new local or neighboring stability

So a line or local coordinate may become changing without the whole macrostate instantly disappearing.

### Law
Changing is a regime of instability within or near a boundary, not instant replacement.

---

## Metastability

Metastability is the temporary unstable-but-held condition between stable regimes.

Within the state space, metastability may mean:
- amplified plasticity
- higher sensitivity
- lower resistance to perturbation
- altered routing or projection
- cross-region bleed
- readiness to resolve into a new stable state

### Law
Metastability is a canonical state-space condition and must be representable explicitly.

---

## Local Gradients

Inside a state region there may be gradients such as:
- stronger vs weaker expression
- inward vs outward orientation
- receptive vs projective posture
- consolidating vs destabilizing tendency
- narrow vs diffuse focus

These gradients may be determined by combinations of:
- line
- color
- tone
- base
- arc position
- degree/minute/second

### Law
A state region has internal directional gradients, not only internal labels.

---

## Node Relation to State Regions

A node is not merely a flat symbolic address.
A node participates in a state region and may contain its own internal coordinate placement.

This means a node may contribute differently to channel emergence depending on:
- its internal coordinate
- its stability condition
- its active modulation
- its pressure state

### Law
Node contribution depends on internal state placement, not just node identity.

---

## Channel Emergence and Internal Coordinates

Channels emerge from relations between nodes.
But node-to-node relation is influenced by the internal coordinate of each node-state.

This means two nodes may:
- form a channel strongly
- form a channel weakly
- complete a channel in one style rather than another
- produce different edge-functions depending on internal placement

Therefore, the same nominal channel may have multiple expressions depending on the internal coordinates of the participating nodes.

### Law
Channel emergence depends on node-state placement, not only node pairing.

---

## Edge Functions and Delivery

An emergent edge-function is shaped by:
- which nodes are relating
- where each node sits internally
- how stable or unstable each local coordinate is
- what gradients are active
- what arc modulation is present

This means edge-functions are not fixed abstractions detached from state-space mechanics.
They are dynamically shaped by internal placement.

### Law
Edge-function is a product of relation plus internal placement.

---

## Projection Bias

Internal state placement influences how a state projects into:
- language
- code
- image
- sound
- interface
- behavior

This means projection should not be derived from macrostate name alone.
It should also depend on internal coordinates and local modulation.

### Law
Projection bias emerges from microstate placement inside the macrostate.

---

## Perspective and Observer Dependence

Two observers may read the same macrostate differently because:
- their identity center differs
- their active gates differ
- their current state placement differs
- their mesh relation differs

This means state-space mechanics may be perspective-relative without becoming arbitrary.

### Law
Perspective modifies access and interpretation without destroying structural rigor.

---

## Computational Interpretation

The state space should be treated computationally as:
- discrete macrostate identity
- structured internal coordinates
- continuous modulation fields
- local stability maps
- transition thresholds
- neighbor relations
- projection tendencies

This is more accurate than a flat lookup table.

### Law
The computational model should preserve state-region structure rather than collapse everything into labels.

---

## What Must Be Represented in Code

At minimum, the code should eventually represent:
- macrostate identity
- internal coordinates
- local modulation
- stability or changing regime
- neighbor tendencies
- projection bias
- convergence readiness

This should become part of the shared type system and activation logic.

---

## Open Questions

The following remain partially unresolved and should be kept explicit:

- the exact semantics of degree/minute/second at each layer
- whether degree/minute/second are fully nested or partially projected
- how arc position relates to line/color/tone/base in exact mechanics
- which internal coordinates most strongly predict channel completion
- how neighboring region boundaries should be computed

These are valid unresolved questions and should not be silently simplified.

---

## Final Rule

A state is a region with internal mechanics.

To model MESSY correctly, the system must preserve:
- identity
- internal position
- modulation
- stability
- transition readiness
- expressive delivery

Without this, the organism collapses into symbolic labels and loses the very mechanics that make it alive.
