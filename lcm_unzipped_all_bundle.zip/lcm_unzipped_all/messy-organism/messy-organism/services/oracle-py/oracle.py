"""
MESSY Organism - Oracle Service

Real planetary positions using Skyfield + JPL ephemeris.
This is the canonical ephemeris service for the organism.
"""

from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Literal, Dict, Any, Optional
import os
import urllib.request
import json
from http.server import HTTPServer, BaseHTTPRequestHandler

from skyfield.api import load

# ============================================================
# CONFIGURATION
# ============================================================

KERNEL_PATH = "de421.bsp"
KERNEL_URL = "https://ssd.jpl.nasa.gov/ftp/eph/planets/bsp/de421.bsp"

GATE_DEG = 5.625
LINE_DEG = GATE_DEG / 6
COLOR_DEG = LINE_DEG / 6
TONE_DEG = COLOR_DEG / 6
BASE_DEG = TONE_DEG / 6

HD_WHEEL_ORDER = [
    41, 19, 13, 49, 30, 55, 37, 63, 22, 36, 25, 17, 21, 51, 42, 3,
    27, 24, 2, 23, 8, 20, 16, 35, 45, 12, 15, 52, 39, 53, 62, 56,
    31, 33, 7, 4, 29, 59, 40, 64, 47, 6, 46, 18, 48, 57, 32, 50,
    28, 44, 1, 43, 14, 34, 9, 5, 26, 11, 10, 58, 38, 54, 61, 60,
]
WHEEL_START_DEG = 302.0

PLANET_NAMES = {
    "sun": "sun", "moon": "moon", "mercury": "mercury barycenter",
    "venus": "venus barycenter", "mars": "mars barycenter",
    "jupiter": "jupiter barycenter", "saturn": "saturn barycenter",
    "uranus": "uranus barycenter", "neptune": "neptune barycenter",
    "pluto": "pluto barycenter",
}

# ============================================================
# DATA CLASSES
# ============================================================

@dataclass
class GateAddress:
    gate: int
    line: int
    color: int
    tone: int
    base: int
    longitude: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "gate": self.gate,
            "line": self.line,
            "color": self.color,
            "tone": self.tone,
            "base": self.base,
            "longitude": self.longitude,
            "longitude_dms": self.format_dms(),
        }

    def format_dms(self) -> str:
        degrees = int(self.longitude)
        remainder = abs(self.longitude - degrees) * 60
        minutes = int(remainder)
        seconds = (remainder - minutes) * 60
        return f"{degrees}°{minutes:02d}'{seconds:05.2f}""


@dataclass
class ChartPoint:
    planet: str
    gate_address: GateAddress
    longitude: float


# ============================================================
# EPHEMERIS ENGINE
# ============================================================

def download_kernel() -> None:
    """One-time download from NASA JPL."""
    if os.path.exists(KERNEL_PATH):
        return
    print(f"Downloading JPL ephemeris kernel from {KERNEL_URL}...")
    urllib.request.urlretrieve(KERNEL_URL, KERNEL_PATH)
    print("Download complete.")


def longitude_to_address(longitude: float) -> GateAddress:
    """Convert tropical ecliptic longitude to gate/line/color/tone/base."""
    offset = (longitude - WHEEL_START_DEG) % 360
    wheel_index = int(offset // GATE_DEG)
    within_gate = offset % GATE_DEG

    gate = HD_WHEEL_ORDER[wheel_index]
    line = int(within_gate // LINE_DEG) + 1
    within_line = within_gate % LINE_DEG
    color = int(within_line // COLOR_DEG) + 1
    within_color = within_line % COLOR_DEG
    tone = int(within_color // TONE_DEG) + 1
    within_tone = within_color % TONE_DEG
    base = int(within_tone // BASE_DEG) + 1

    return GateAddress(gate, line, color, tone, base, longitude)


class RealEphemeris:
    """Actual planetary positions from JPL data."""

    def __init__(self, kernel_path: str = KERNEL_PATH):
        download_kernel()
        self.planets = load(kernel_path)
        self.ts = load.timescale()
        self.earth = self.planets["earth"]

    def longitude(self, planet: str, dt: datetime) -> float:
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        t = self.ts.from_datetime(dt)
        body = self.planets[PLANET_NAMES[planet]]
        astrometric = self.earth.at(t).observe(body)
        _, lon, _ = astrometric.ecliptic_latlon()
        return lon.degrees

    def gate_address(self, planet: str, dt: datetime) -> GateAddress:
        return longitude_to_address(self.longitude(planet, dt))

    def mean_lunar_node(self, dt: datetime) -> float:
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        t = self.ts.from_datetime(dt)
        T = (t.tt - 2451545.0) / 36525.0
        omega = (125.04452 - 1934.136261 * T + 0.0020708 * T**2 + T**3 / 450000.0)
        return omega % 360

    def north_node_longitude(self, dt: datetime) -> float:
        return self.mean_lunar_node(dt)

    def south_node_longitude(self, dt: datetime) -> float:
        return (self.mean_lunar_node(dt) + 180.0) % 360

    def earth_longitude(self, dt: datetime) -> float:
        return (self.longitude('sun', dt) + 180.0) % 360

    def full_chart(self, dt: datetime) -> Dict[str, Any]:
        """All 13 HD activation points."""
        result = {}
        for p in ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter',
                  'saturn', 'uranus', 'neptune', 'pluto']:
            result[p] = self.gate_address(p, dt).to_dict()
        result['earth'] = longitude_to_address(self.earth_longitude(dt)).to_dict()
        result['north_node'] = longitude_to_address(self.north_node_longitude(dt)).to_dict()
        result['south_node'] = longitude_to_address(self.south_node_longitude(dt)).to_dict()
        return result

    def design_sun_datetime(self, birth_dt: datetime) -> datetime:
        birth_lon = self.longitude("sun", birth_dt)
        target = (birth_lon - 88.0) % 360
        probe = birth_dt - timedelta(days=88)
        for _ in range(6):
            probe_lon = self.longitude("sun", probe)
            diff = (probe_lon - target + 180) % 360 - 180
            probe -= timedelta(days=diff)
        return probe


# ============================================================
# HTTP API SERVER
# ============================================================

class OracleHandler(BaseHTTPRequestHandler):
    eph = RealEphemeris()

    def log_message(self, format, *args):
        # Suppress default logging
        pass

    def _send_json(self, data: Dict[str, Any], status: int = 200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def do_GET(self):
        try:
            if self.path == '/health':
                self._send_json({"status": "ok", "service": "messy-oracle"})

            elif self.path.startswith('/chart/'):
                # /chart/YYYY-MM-DDTHH:MM:SS
                dt_str = self.path.split('/chart/')[1]
                dt = datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
                chart = self.eph.full_chart(dt)
                self._send_json({"chart": chart, "timestamp": dt.isoformat()})

            elif self.path.startswith('/planet/'):
                # /planet/sun/YYYY-MM-DDTHH:MM:SS
                parts = self.path.split('/')
                planet = parts[2]
                dt_str = parts[3]
                dt = datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
                address = self.eph.gate_address(planet, dt)
                self._send_json({
                    "planet": planet,
                    "address": address.to_dict(),
                    "timestamp": dt.isoformat(),
                })

            elif self.path.startswith('/design/'):
                # /design/YYYY-MM-DDTHH:MM:SS
                dt_str = self.path.split('/design/')[1]
                birth_dt = datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
                design_dt = self.eph.design_sun_datetime(birth_dt)
                chart = self.eph.full_chart(design_dt)
                self._send_json({
                    "design_chart": chart,
                    "birth_timestamp": birth_dt.isoformat(),
                    "design_timestamp": design_dt.isoformat(),
                })

            else:
                self._send_json({"error": "Unknown endpoint"}, 404)

        except Exception as e:
            self._send_json({"error": str(e)}, 500)

    def do_POST(self):
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            data = json.loads(body) if body else {}

            if self.path == '/chart':
                dt_str = data.get('datetime', datetime.now(timezone.utc).isoformat())
                dt = datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
                chart = self.eph.full_chart(dt)
                self._send_json({"chart": chart, "timestamp": dt.isoformat()})

            elif self.path == '/verify':
                # Verify against 2017 eclipse
                dt = datetime(2017, 8, 21, 18, 26, 40, tzinfo=timezone.utc)
                sun_lon = self.eph.longitude("sun", dt)
                moon_lon = self.eph.longitude("moon", dt)
                diff = abs(sun_lon - moon_lon)
                self._send_json({
                    "verified": diff < 0.5,
                    "sun_longitude": sun_lon,
                    "moon_longitude": moon_lon,
                    "difference": diff,
                    "event": "2017 total solar eclipse",
                })

            else:
                self._send_json({"error": "Unknown endpoint"}, 404)

        except Exception as e:
            self._send_json({"error": str(e)}, 500)


def run_server(port: int = 8001):
    server = HTTPServer(('0.0.0.0', port), OracleHandler)
    print(f"MESSY Oracle Service running on port {port}")
    print("Endpoints:")
    print("  GET /health")
    print("  GET /chart/<ISO-datetime>")
    print("  GET /planet/<name>/<ISO-datetime>")
    print("  GET /design/<birth-ISO-datetime>")
    print("  POST /chart")
    print("  POST /verify")
    server.serve_forever()


if __name__ == "__main__":
    run_server()
