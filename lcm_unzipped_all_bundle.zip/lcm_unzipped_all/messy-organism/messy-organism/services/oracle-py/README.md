# MESSY Oracle Service

Real planetary positions using NASA JPL ephemeris (de421.bsp).

## Setup

```bash
pip install -r requirements.txt
python oracle.py
```

## Endpoints

- `GET /health` - Service health
- `GET /chart/<ISO-datetime>` - Full 13-point chart
- `GET /planet/<name>/<ISO-datetime>` - Single planet position
- `GET /design/<birth-ISO-datetime>` - Design chart
- `POST /chart` - Chart from JSON body
- `POST /verify` - Verify against 2017 eclipse

## Precision

- Gate: 5.625° (360/64)
- Line: 0.9375° (5.625/6)
- Color: 9.375 arcmin (0.9375°/6)
- Tone: 93.75 arcsec (9.375'/6)
- Base: 15.625 arcsec (93.75"/6)
