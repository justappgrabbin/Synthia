# MESSY Organism

A local-first digital organism for alignment, activation, and expression.

## Architecture

```
messy-organism/
├── apps/
│   ├── runtime/          # Organism body - boot, mesh, bus, organs
│   └── browser-shell/    # React UI - state rendering, interaction
├── packages/
│   ├── ontology/         # Canonical truth: 64 gates, 9 centers, 5D
│   ├── state-space/      # 40M state regions, gradients, transitions
│   ├── mesh/             # Message morphing substrate, 36 channels
│   ├── bus/              # Event transport, organ registration
│   ├── activation/       # HD, language, code activation grammars
│   ├── projection/       # Language, code, image, sound, UI output
│   ├── identity-center/  # User alignment, LLM/MCP bridges
│   ├── persistence/      # SQLite/Memory storage, snapshots
│   ├── ingestion/        # File/text ingestion, AST, learning
│   ├── hd-graph/         # Tensor graph, traversal, resonance
│   ├── self-supervised/  # Learning rules, mutations, growth
│   ├── resonance-core/   # Pattern matching, field analysis
│   ├── types/            # Shared TypeScript contracts
│   └── ui/               # Shared React components, theme
├── services/
│   ├── oracle-py/        # Real JPL ephemeris (Skyfield)
│   ├── resonance-market-api/  # External market integration
│   └── chart-oracle/     # Chart computation bridge
└── shared/
    ├── config/           # Ontological constants
    ├── schemas/          # Zod validation schemas
    └── utils/            # Core utilities, resonance math
```

## Quick Start

```bash
# Install dependencies
pnpm install

# Boot the organism
pnpm organism:boot

# Start the browser shell
pnpm organism:shell

# Run everything
pnpm organism:full
```

## Core Principles

1. **State Space First** - 40,435,200 possible states exist as latent structure
2. **Activation Before Computation** - Locate and activate before heavy inference
3. **Mesh Before Direct Calls** - All communication through the morphing mesh
4. **Morph Through Message Passing** - Messages change receiver state
5. **Meaning Is Proportional** - Isomorphic qualities across domains
6. **Color Is Semantic State** - Not decoration, part of operating logic
7. **Identity Is a Center** - User anchors alignment and tool bridges
8. **Local First** - Core operates locally, external services are amplifiers

## The Five Dimensions

| Dimension | Macro | Micro | Keynote |
|-----------|-------|-------|---------|
| Movement | Individuality | Individual | I Define |
| Evolution | Mind | Mental | I Remember |
| Being | Body | Physical | I Am |
| Design | Ego | Egoic | I Design |
| Space | Personality | Personality | I Think |

## Mesh Law

```
gate → message → mesh → channel traversal → edge formation → 
morph → convergence → expression → center behavior
```

## License

MIT
