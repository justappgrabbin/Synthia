/**
 * MESSY Organism - Browser Shell App
 * 
 * The browser-facing interface for the organism.
 * Renders organism state, presents centers/channels/gates/views,
 * handles user interaction.
 */

import React, { useState, useEffect, useCallback } from 'react';
import ReactDOM from 'react-dom/client';

// ============================================================
// ORGANISM STATE HOOK
// ============================================================

function useOrganismState() {
  const [status, setStatus] = useState({
    state: 'dormant',
    mode: 'observation',
    activeGates: [],
    activeChannels: [],
    convergenceLevel: 0,
    semanticCoherence: 0.5,
  });

  const [context, setContext] = useState<any>(null);
  const [isConnected, setIsConnected] = useState(false);

  // Connect to runtime via WebSocket or API
  useEffect(() => {
    // In a real implementation, this would connect to the runtime
    // For now, simulate with polling
    const interval = setInterval(() => {
      fetch('/api/status')
        .then(res => res.json())
        .then(data => {
          setStatus(data.status);
          setContext(data.context);
          setIsConnected(true);
        })
        .catch(() => setIsConnected(false));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const activate = useCallback((input: string) => {
    fetch('/api/activate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ input }),
    });
  }, []);

  const ingest = useCallback((content: string) => {
    fetch('/api/ingest', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content }),
    });
  }, []);

  return { status, context, isConnected, activate, ingest };
}

// ============================================================
// MAIN APP COMPONENT
// ============================================================

function App() {
  const { status, context, isConnected, activate, ingest } = useOrganismState();
  const [input, setInput] = useState('');
  const [activeTab, setActiveTab] = useState('overview');

  const handleActivate = () => {
    if (input.trim()) {
      activate(input);
      setInput('');
    }
  };

  const handleIngest = () => {
    if (input.trim()) {
      ingest(input);
      setInput('');
    }
  };

  return (
    <div style={styles.container}>
      {/* Header */}
      <header style={styles.header}>
        <h1 style={styles.title}>MESSY Organism</h1>
        <div style={styles.status}>
          <span style={styles.statusDot(isConnected)} />
          {status.state} | {status.mode}
        </div>
      </header>

      {/* Navigation */}
      <nav style={styles.nav}>
        {['overview', 'gates', 'channels', 'centers', 'mesh', 'projection', 'growth'].map(tab => (
          <button
            key={tab}
            style={styles.navButton(activeTab === tab)}
            onClick={() => setActiveTab(tab)}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </nav>

      {/* Main Content */}
      <main style={styles.main}>
        {activeTab === 'overview' && <OverviewView status={status} context={context} />}
        {activeTab === 'gates' && <GatesView context={context} />}
        {activeTab === 'channels' && <ChannelsView context={context} />}
        {activeTab === 'centers' && <CentersView context={context} />}
        {activeTab === 'mesh' && <MeshView context={context} />}
        {activeTab === 'projection' && <ProjectionView context={context} />}
        {activeTab === 'growth' && <GrowthView context={context} />}
      </main>

      {/* Input Bar */}
      <div style={styles.inputBar}>
        <input
          style={styles.input}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleActivate()}
          placeholder="Activate, ingest, or command the organism..."
        />
        <button style={styles.button} onClick={handleActivate}>Activate</button>
        <button style={styles.button} onClick={handleIngest}>Ingest</button>
      </div>
    </div>
  );
}

// ============================================================
// VIEW COMPONENTS
// ============================================================

function OverviewView({ status, context }: { status: any; context: any }) {
  return (
    <div style={styles.view}>
      <h2 style={styles.viewTitle}>Organism Overview</h2>

      <div style={styles.grid}>
        <StatCard title="State" value={status.state} />
        <StatCard title="Mode" value={status.mode} />
        <StatCard title="Convergence" value={`${(status.convergenceLevel * 100).toFixed(1)}%`} />
        <StatCard title="Coherence" value={`${(status.semanticCoherence * 100).toFixed(1)}%`} />
        <StatCard title="Active Gates" value={status.activeGates?.length || 0} />
        <StatCard title="Active Channels" value={status.activeChannels?.length || 0} />
      </div>

      {context && (
        <div style={styles.contextPanel}>
          <h3>Runtime Context</h3>
          <pre style={styles.pre}>{JSON.stringify(context, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}

function StatCard({ title, value }: { title: string; value: any }) {
  return (
    <div style={styles.card}>
      <div style={styles.cardTitle}>{title}</div>
      <div style={styles.cardValue}>{value}</div>
    </div>
  );
}

function GatesView({ context }: { context: any }) {
  const graph = context?.graph;
  if (!graph) return <div style={styles.view}>No graph data</div>;

  return (
    <div style={styles.view}>
      <h2 style={styles.viewTitle}>64 Gates</h2>
      <div style={styles.gateGrid}>
        {Array.from({ length: 64 }, (_, i) => {
          const gateId = i + 1;
          const isActive = graph.activeNodes > 0; // Simplified
          return (
            <div
              key={gateId}
              style={styles.gateCell(isActive)}
              title={`Gate ${gateId}`}
            >
              {gateId}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ChannelsView({ context }: { context: any }) {
  return (
    <div style={styles.view}>
      <h2 style={styles.viewTitle}>36 Channels</h2>
      <div style={styles.channelList}>
        {Array.from({ length: 36 }, (_, i) => (
          <div key={i} style={styles.channelRow}>
            Channel {i + 1}
          </div>
        ))}
      </div>
    </div>
  );
}

function CentersView({ context }: { context: any }) {
  const centers = ['Head', 'Ajna', 'Throat', 'G (Identity)', 'Heart', 'Solar Plexus', 'Sacral', 'Spleen', 'Root'];

  return (
    <div style={styles.view}>
      <h2 style={styles.viewTitle}>9 Centers</h2>
      <div style={styles.centerList}>
        {centers.map((name, i) => (
          <div key={i} style={styles.centerRow(i === 3)}>
            <span>{name}</span>
            <span style={styles.centerMode}>latent</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function MeshView({ context }: { context: any }) {
  const mesh = context?.mesh;

  return (
    <div style={styles.view}>
      <h2 style={styles.viewTitle}>Mesh Activity</h2>
      {mesh && (
        <div style={styles.meshStats}>
          <StatCard title="Active Messages" value={mesh.activeMessages} />
          <StatCard title="Active Channels" value={mesh.activeChannels} />
          <StatCard title="Persistent Edges" value={mesh.persistentEdges} />
        </div>
      )}
    </div>
  );
}

function ProjectionView({ context }: { context: any }) {
  const projection = context?.projection;

  return (
    <div style={styles.view}>
      <h2 style={styles.viewTitle}>Projections</h2>
      {projection && (
        <div>
          <div style={styles.grid}>
            {Object.entries(projection.byDomain || {}).map(([domain, count]) => (
              <StatCard key={domain} title={domain} value={count} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function GrowthView({ context }: { context: any }) {
  const selfSupervised = context?.selfSupervised;

  return (
    <div style={styles.view}>
      <h2 style={styles.viewTitle}>Self-Growth</h2>
      {selfSupervised && (
        <div style={styles.grid}>
          <StatCard title="Learning Rules" value={selfSupervised.learningRules} />
          <StatCard title="Mutations" value={selfSupervised.mutations} />
          <StatCard title="Applied" value={selfSupervised.appliedMutations} />
        </div>
      )}
    </div>
  );
}

// ============================================================
// STYLES
// ============================================================

const styles: Record<string, any> = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    backgroundColor: '#0a0a0f',
    color: '#e2e8f0',
    fontFamily: 'ui-sans-serif, system-ui, -apple-system, sans-serif',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '1rem 1.5rem',
    borderBottom: '1px solid #27272a',
    backgroundColor: '#12121a',
  },
  title: {
    margin: 0,
    fontSize: '1.5rem',
    fontWeight: 700,
    background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
  },
  status: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
    fontSize: '0.875rem',
    color: '#94a3b8',
  },
  statusDot: (connected: boolean) => ({
    width: 8,
    height: 8,
    borderRadius: '50%',
    backgroundColor: connected ? '#22c55e' : '#ef4444',
  }),
  nav: {
    display: 'flex',
    gap: '0.5rem',
    padding: '0.75rem 1.5rem',
    borderBottom: '1px solid #27272a',
    backgroundColor: '#12121a',
    overflowX: 'auto',
  },
  navButton: (active: boolean) => ({
    padding: '0.5rem 1rem',
    borderRadius: '0.5rem',
    border: 'none',
    backgroundColor: active ? '#6366f1' : 'transparent',
    color: active ? '#fff' : '#94a3b8',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: 500,
    transition: 'all 0.2s',
    ':hover': {
      backgroundColor: active ? '#6366f1' : '#1a1a25',
    },
  }),
  main: {
    flex: 1,
    overflow: 'auto',
    padding: '1.5rem',
  },
  view: {
    maxWidth: 1200,
    margin: '0 auto',
  },
  viewTitle: {
    margin: '0 0 1.5rem 0',
    fontSize: '1.25rem',
    fontWeight: 600,
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
    gap: '1rem',
    marginBottom: '1.5rem',
  },
  card: {
    backgroundColor: '#12121a',
    border: '1px solid #27272a',
    borderRadius: '0.75rem',
    padding: '1rem',
  },
  cardTitle: {
    fontSize: '0.75rem',
    textTransform: 'uppercase',
    color: '#94a3b8',
    marginBottom: '0.5rem',
  },
  cardValue: {
    fontSize: '1.5rem',
    fontWeight: 700,
    color: '#e2e8f0',
  },
  contextPanel: {
    backgroundColor: '#12121a',
    border: '1px solid #27272a',
    borderRadius: '0.75rem',
    padding: '1rem',
  },
  pre: {
    margin: 0,
    fontSize: '0.75rem',
    overflow: 'auto',
    maxHeight: 400,
  },
  inputBar: {
    display: 'flex',
    gap: '0.5rem',
    padding: '1rem 1.5rem',
    borderTop: '1px solid #27272a',
    backgroundColor: '#12121a',
  },
  input: {
    flex: 1,
    padding: '0.75rem 1rem',
    borderRadius: '0.5rem',
    border: '1px solid #27272a',
    backgroundColor: '#0a0a0f',
    color: '#e2e8f0',
    fontSize: '0.875rem',
    outline: 'none',
  },
  button: {
    padding: '0.75rem 1.5rem',
    borderRadius: '0.5rem',
    border: 'none',
    backgroundColor: '#6366f1',
    color: '#fff',
    fontSize: '0.875rem',
    fontWeight: 600,
    cursor: 'pointer',
  },
  gateGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(8, 1fr)',
    gap: '0.5rem',
  },
  gateCell: (active: boolean) => ({
    aspectRatio: '1',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '0.5rem',
    backgroundColor: active ? '#6366f1' : '#12121a',
    border: '1px solid #27272a',
    fontSize: '0.75rem',
    fontWeight: 600,
    cursor: 'pointer',
    transition: 'all 0.2s',
  }),
  channelList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.5rem',
  },
  channelRow: {
    padding: '0.75rem 1rem',
    backgroundColor: '#12121a',
    border: '1px solid #27272a',
    borderRadius: '0.5rem',
    fontSize: '0.875rem',
  },
  centerList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.5rem',
  },
  centerRow: (isIdentity: boolean) => ({
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '0.75rem 1rem',
    backgroundColor: isIdentity ? '#6366f1' : '#12121a',
    border: '1px solid #27272a',
    borderRadius: '0.5rem',
    fontSize: '0.875rem',
  }),
  centerMode: {
    fontSize: '0.75rem',
    color: '#94a3b8',
    textTransform: 'uppercase',
  },
  meshStats: {
    display: 'grid',
    gridTemplateColumns: 'repeat(3, 1fr)',
    gap: '1rem',
  },
};

// ============================================================
// MOUNT
// ============================================================

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);

export default App;
