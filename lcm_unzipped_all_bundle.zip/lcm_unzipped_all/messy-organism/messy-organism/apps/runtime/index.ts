/**
 * MESSY Organism - Runtime App
 * 
 * The organism body. Responsible for:
 * - Booting the organism
 * - Loading ontology/state-space
 * - Initializing mesh and bus
 * - Initializing persistence
 * - Mounting identity center
 * - Wiring all modules
 * - Exposing runtime control surface
 */

import { Logger, LogLevel, now, sleep } from '@messy/utils';
import { ORGANISM_CONFIG } from '@messy/config';
import { ontology } from '@messy/ontology';
import { stateSpace } from '@messy/state-space';
import { mesh } from '@messy/mesh';
import { bus } from '@messy/bus';
import { activation } from '@messy/activation';
import { projection } from '@messy/projection';
import { initializeIdentityCenter, identityCenter } from '@messy/identity-center';
import { initializePersistence, persistence } from '@messy/persistence';
import { ingestion } from '@messy/ingestion';
import { hdGraph } from '@messy/hd-graph';
import { selfSupervised } from '@messy/self-supervised';
import { resonanceCore } from '@messy/resonance-core';
import { RuntimeContext, OrganismStatus } from '@messy/types';

// ============================================================
// ORGANISM RUNTIME
// ============================================================

export class OrganismRuntime {
  private logger = new Logger('Runtime', LogLevel.INFO);
  private started = false;
  private startTime = 0;
  private tickInterval: ReturnType<typeof setInterval> | null = null;
  private status: OrganismStatus = {
    state: 'dormant',
    mode: 'observation',
    uptime: 0,
    activeGates: [],
    activeChannels: [],
    activeCenters: [],
    convergenceLevel: 0,
    semanticCoherence: 0.5,
    lastActivity: 0,
  };

  constructor() {
    this.logger.info('MESSY Organism Runtime initialized');
  }

  // Boot the organism
  async boot(options: {
    userId?: string;
    logLevel?: LogLevel;
    persistenceAdapter?: 'memory' | 'sqlite';
  } = {}): Promise<void> {
    if (this.started) {
      this.logger.warn('Organism already booted');
      return;
    }

    this.logger.info('=== BOOTING MESSY ORGANISM ===');
    this.status.state = 'initializing';
    this.startTime = now();

    // Set log level
    if (options.logLevel !== undefined) {
      this.logger.setLevel(options.logLevel);
    }

    // 1. Load ontology (already loaded in module)
    this.logger.info('1. Ontology loaded: 64 gates, 9 centers, 5 dimensions, 13 planets');

    // 2. Initialize state space
    this.logger.info('2. State space initialized: 40,435,200 possible states');

    // 3. Initialize mesh
    this.logger.info('3. Mesh initialized: 36 channels');

    // 4. Initialize bus
    this.logger.info('4. Bus initialized');

    // 5. Initialize persistence
    const adapter = options.persistenceAdapter === 'sqlite' 
      ? new (await import('@messy/persistence')).SQLiteAdapter()
      : undefined;
    initializePersistence(adapter);
    await persistence.initialize();
    this.logger.info('5. Persistence initialized');

    // 6. Mount identity center
    initializeIdentityCenter(options.userId);
    this.logger.info('6. Identity center mounted');

    // 7. Register organs
    this.registerOrgans();
    this.logger.info('7. Organs registered');

    // 8. Register activation grammars
    this.logger.info('8. Activation grammars registered: humanDesign, languagePattern, codePattern');

    // 9. Wire mesh events
    this.wireMeshEvents();
    this.logger.info('9. Mesh events wired');

    // 10. Start main loop
    this.startMainLoop();
    this.logger.info('10. Main loop started');

    this.started = true;
    this.status.state = 'active';
    this.status.lastActivity = now();

    this.logger.info('=== MESSY ORGANISM BOOTED ===');
    this.logger.info(`State space: ${ontology.getStateSpaceSize().toLocaleString()} states`);
    this.logger.info(`Ready for activation`);
  }

  private registerOrgans(): void {
    // Register all organs with the bus
    bus.registerOrgan('Ontology', ['getGate', 'getCenter', 'getDimension', 'validateAddress']);
    bus.registerOrgan('StateSpace', ['getRegion', 'computePosition', 'isChanging']);
    bus.registerOrgan('Mesh', ['emitMessage', 'getActiveChannels', 'getStats']);
    bus.registerOrgan('Activation', ['activate', 'getHistory', 'getStats']);
    bus.registerOrgan('Projection', ['project', 'getHistory', 'getStats']);
    bus.registerOrgan('HDGraph', ['activateGate', 'getGraphState', 'getStats']);
    bus.registerOrgan('Ingestion', ['ingestFile', 'ingestText', 'getStats']);
    bus.registerOrgan('SelfSupervised', ['processEvent', 'getLearningRules', 'getStats']);
    bus.registerOrgan('ResonanceCore', ['matchPatterns', 'computeFieldState', 'getStats']);
  }

  private wireMeshEvents(): void {
    // Wire mesh convergence to projection
    mesh.on('convergenceReached', ({ messages, level }) => {
      this.status.convergenceLevel = level;
      this.status.lastActivity = now();

      for (const message of messages) {
        if (message.payload && typeof message.payload === 'object') {
          const state = message.payload as any;
          if (state.gateId) {
            this.status.activeGates.push(state.gateId);
            // Keep only unique recent gates
            this.status.activeGates = [...new Set(this.status.activeGates)].slice(-20);
          }
        }
      }
    });

    // Wire center activation
    mesh.on('centerActivated', ({ centerId, level }) => {
      this.status.activeCenters.push(centerId);
      this.status.activeCenters = [...new Set(this.status.activeCenters)].slice(-10);
    });

    // Wire edge formation
    mesh.on('edgeFormed', ({ edge }) => {
      if (edge.channelId) {
        this.status.activeChannels.push(edge.channelId);
        this.status.activeChannels = [...new Set(this.status.activeChannels)].slice(-20);
      }
    });
  }

  private startMainLoop(): void {
    const tickMs = ORGANISM_CONFIG.runtime.meshTickMs;

    this.tickInterval = setInterval(() => {
      this.tick();
    }, tickMs);
  }

  private tick(): void {
    // Update uptime
    this.status.uptime = now() - this.startTime;

    // Update semantic coherence from identity center
    if (identityCenter) {
      this.status.semanticCoherence = identityCenter.getIdentity().semanticCoherence;
    }

    // Periodically clean up mesh
    if (this.status.uptime % 60000 < tickMs) {
      mesh.cleanup();
    }

    // Periodically save state snapshot
    if (this.status.uptime % ORGANISM_CONFIG.persistence.snapshotIntervalMs < tickMs) {
      this.saveSnapshot();
    }
  }

  private async saveSnapshot(): Promise<void> {
    try {
      const snapshot = await persistence.snapshot();
      this.logger.debug('State snapshot saved:', snapshot);
    } catch (err) {
      this.logger.error('Snapshot failed:', err);
    }
  }

  // Get full runtime context
  getContext(): RuntimeContext {
    return {
      organism: { ...this.status },
      mesh: mesh.getStats() as any,
      activation: activation.getStats() as any,
      projection: projection.getStats() as any,
      identity: identityCenter ? identityCenter.getStats() as any : { userId: 'none', llmBridges: 0, mcpBridges: 0, semanticCoherence: 0 },
      persistence: persistence ? persistence.getStats() as any : { adapter: 'none' },
      ingestion: ingestion.getStats() as any,
      selfSupervised: selfSupervised.getStats() as any,
      resonance: resonanceCore.getStats() as any,
      graph: hdGraph.getStats() as any,
    };
  }

  // Get organism status
  getStatus(): OrganismStatus {
    return { ...this.status };
  }

  // Activate from input
  activate(input: unknown, grammar?: string): any {
    this.status.state = 'processing';
    this.status.lastActivity = now();

    let results;
    if (grammar) {
      results = activation.activateWithGrammar(input, grammar);
    } else {
      results = activation.activate(input);
    }

    this.status.state = 'active';
    return results;
  }

  // Ingest content
  async ingest(content: string, type: 'text' | 'file' = 'text'): Promise<any> {
    if (type === 'text') {
      return ingestion.ingestText(content);
    }
    return ingestion.ingestFile('inline', content);
  }

  // Project current state
  project(domain?: string): any {
    this.status.state = 'expressing';

    // Get active states and project them
    const activeGates = this.status.activeGates;
    const projections: any[] = [];

    for (const gateId of activeGates.slice(-5)) {
      const gate = ontology.getGate(gateId);
      if (!gate) continue;

      const state = {
        identity: gate.name,
        gateId: gate.id,
        stability: 'stable',
      };

      const qual = {
        activeGates: [gateId],
        sourceOrgan: 'Runtime',
      };

      const projs = projection.project(state, qual, domain);
      projections.push(...projs);
    }

    this.status.state = 'active';
    return projections;
  }

  // Shutdown
  async shutdown(): Promise<void> {
    this.logger.info('=== SHUTTING DOWN MESSY ORGANISM ===');
    this.status.state = 'sleeping';

    if (this.tickInterval) {
      clearInterval(this.tickInterval);
    }

    if (persistence) {
      await persistence.dispose();
    }

    if (bus) {
      bus.dispose();
    }

    this.started = false;
    this.logger.info('=== MESSY ORGANISM SHUTDOWN ===');
  }

  // Health check
  health(): { healthy: boolean; checks: Record<string, boolean> } {
    return {
      healthy: this.started,
      checks: {
        booted: this.started,
        ontology: ontology.getAllGates().length === 64,
        mesh: mesh.getStats().activeChannels !== undefined,
        persistence: persistence !== undefined,
        identity: identityCenter !== undefined,
      },
    };
  }
}

// Singleton
export const runtime = new OrganismRuntime();

// Export boot function for direct use
export async function bootOrganism(options?: Parameters<OrganismRuntime['boot']>[0]): Promise<void> {
  await runtime.boot(options);
}

// Export for CLI
if (require.main === module) {
  bootOrganism({ logLevel: LogLevel.DEBUG }).then(() => {
    console.log('Organism running. Press Ctrl+C to shutdown.');

    // Keep alive
    process.on('SIGINT', async () => {
      await runtime.shutdown();
      process.exit(0);
    });
  }).catch(err => {
    console.error('Boot failed:', err);
    process.exit(1);
  });
}
