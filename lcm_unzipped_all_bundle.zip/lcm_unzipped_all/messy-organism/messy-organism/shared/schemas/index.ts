/**
 * MESSY Organism - Shared Schemas
 * 
 * Zod schemas for runtime validation of ontological structures.
 */

import { z } from 'zod';

// ============================================================
// CORE ONTOLOGICAL SCHEMAS
// ============================================================

export const PlanetSchema = z.object({
  id: z.number().int().min(1).max(13),
  name: z.string(),
  symbol: z.string().optional(),
  influence: z.string().optional(),
});

export const DimensionSchema = z.object({
  id: z.number().int().min(1).max(5),
  name: z.enum(['Movement', 'Evolution', 'Being', 'Design', 'Space']),
  macro: z.string(),
  micro: z.string(),
  keynote: z.string(),
  reversal: z.string().optional(),
});

export const CenterSchema = z.object({
  id: z.number().int().min(1).max(9),
  name: z.string(),
  mode: z.enum(['latent', 'converging', 'modulating', 'expressed', 'actioning']),
  activationLevel: z.number().min(0).max(1).default(0),
  isIdentity: z.boolean().default(false),
  activeGates: z.array(z.number().int().min(1).max(64)).default([]),
  activeChannels: z.array(z.string()).default([]),
});

export const GateSchema = z.object({
  id: z.number().int().min(1).max(64),
  name: z.string(),
  hexagram: z.number().int().min(1).max(64),
  trigram: z.string().optional(),
  line: z.number().int().min(1).max(6).optional(),
  color: z.number().int().min(1).max(6).optional(),
  tone: z.number().int().min(1).max(6).optional(),
  base: z.number().int().min(1).max(5).optional(),
});

export const LineSchema = z.object({
  gateId: z.number().int().min(1).max(64),
  lineNumber: z.number().int().min(1).max(6),
  mode: z.enum(['stable', 'emphasized', 'stressed', 'changing', 'resolving']).default('stable'),
  role: z.string().optional(),
  posture: z.string().optional(),
});

export const ColorSchema = z.object({
  id: z.number().int().min(1).max(6),
  name: z.string(),
  motivation: z.string().optional(),
  spectralBias: z.string().optional(),
  fieldQuality: z.string().optional(),
});

export const ToneSchema = z.object({
  id: z.number().int().min(1).max(6),
  name: z.string(),
  perceptualFilter: z.string().optional(),
  attunementMode: z.string().optional(),
});

export const BaseSchema = z.object({
  id: z.number().int().min(1).max(5),
  name: z.string(),
  grounding: z.string().optional(),
  refinement: z.string().optional(),
});

// ============================================================
// STATE SPACE SCHEMAS
// ============================================================

export const InternalCoordinateSchema = z.object({
  line: z.number().int().min(1).max(6).optional(),
  color: z.number().int().min(1).max(6).optional(),
  tone: z.number().int().min(1).max(6).optional(),
  base: z.number().int().min(1).max(5).optional(),
  arc: z.number().min(0).max(1).optional(),
  degree: z.number().min(0).max(360).optional(),
  minute: z.number().min(0).max(59).optional(),
  second: z.number().min(0).max(59).optional(),
});

export const MacroStateSchema = z.object({
  identity: z.string(),
  gateId: z.number().int().min(1).max(64).optional(),
  centerId: z.number().int().min(1).max(9).optional(),
  dimension: z.string().optional(),
  planetaryInfluence: z.number().int().min(1).max(13).optional(),
  coordinates: InternalCoordinateSchema.optional(),
  stability: z.enum(['stable', 'metastable', 'changing', 'transitioning']).default('stable'),
  gradient: z.object({
    strength: z.number().min(0).max(1).optional(),
    orientation: z.enum(['inward', 'outward']).optional(),
    posture: z.enum(['receptive', 'projective']).optional(),
    tendency: z.enum(['consolidating', 'destabilizing']).optional(),
    focus: z.enum(['narrow', 'diffuse']).optional(),
  }).optional(),
  neighboringTendencies: z.array(z.string()).default([]),
  projectionBias: z.record(z.string(), z.any()).default({}),
});

export const MicroStateSchema = z.object({
  macroState: MacroStateSchema,
  localPosition: z.object({
    x: z.number(),
    y: z.number(),
    z: z.number().optional(),
  }).optional(),
  thresholdProximity: z.number().min(0).max(1).optional(),
  transitionReadiness: z.number().min(0).max(1).optional(),
});

// ============================================================
// MESH SCHEMAS
// ============================================================

export const MessageQualificationSchema = z.object({
  sourceOrgan: z.string().optional(),
  sourceCenter: z.number().int().min(1).max(9).optional(),
  targetCenter: z.number().int().min(1).max(9).optional(),
  activeGates: z.array(z.number().int().min(1).max(64)).default([]),
  activeChannels: z.array(z.string()).default([]),
  dimensionContext: z.string().optional(),
  lineColorToneBase: InternalCoordinateSchema.optional(),
  planetaryInfluence: z.number().int().min(1).max(13).optional(),
  arcModulation: z.number().min(0).max(1).optional(),
  stratumContext: z.number().int().min(0).max(2).optional(),
  recursionDepth: z.number().int().min(0).default(0),
  userAlignmentContext: z.record(z.string(), z.any()).optional(),
});

export const MeshMessageSchema = z.object({
  id: z.string().uuid(),
  timestamp: z.number(),
  payload: z.unknown(),
  qualification: MessageQualificationSchema,
  path: z.array(z.string()).default([]),
  morphCount: z.number().int().min(0).default(0),
  convergenceState: z.enum(['traversing', 'morphing', 'converging', 'expressed', 'delivered']).default('traversing'),
});

export const ChannelSchema = z.object({
  id: z.string(),
  sourceGate: z.number().int().min(1).max(64),
  targetGate: z.number().int().min(1).max(64),
  name: z.string().optional(),
  edgeFunction: z.string().optional(),
  strength: z.number().min(0).max(1).default(0),
  isActive: z.boolean().default(false),
  traversalCount: z.number().int().min(0).default(0),
  lastTraversal: z.number().optional(),
});

export const EdgeSchema = z.object({
  id: z.string(),
  sourceNode: z.string(),
  targetNode: z.string(),
  channelId: z.string().optional(),
  weight: z.number().min(0).max(1).default(0),
  state: z.enum(['ephemeral', 'persistent', 'strengthening', 'weakening', 'dormant']).default('ephemeral'),
  createdAt: z.number(),
  lastActivated: z.number().optional(),
  traversalHistory: z.array(z.number()).default([]),
});

// ============================================================
// NODE FUNCTION SCHEMAS
// ============================================================

export const NodeContributionSchema = z.object({
  nodeId: z.number().int().min(1).max(64),
  contributions: z.array(z.enum([
    'initiation', 'reception', 'pressure', 'response', 'stabilization', 'mutation',
    'expression', 'formulation', 'correction', 'attraction', 'repulsion', 'gating',
    'memory', 'compression', 'decompression', 'direction', 'attention', 'resonance',
    'filtering', 'propagation', 'opposition', 'rhythm', 'timing', 'salience',
    'containment', 'opening'
  ])).default([]),
  polarity: z.enum([
    'forward', 'reverse', 'inward', 'outward', 'receptive', 'projective',
    'stabilizing', 'destabilizing', 'selective', 'distributive'
  ]).optional(),
  category: z.enum([
    'Initiatory', 'Receptive', 'Formulating', 'Corrective', 'Rhythmic',
    'Directional', 'Attentional', 'Mutative', 'Resonant', 'Gatekeeping'
  ]).optional(),
  relationalAffordances: z.array(z.enum([
    'complementary', 'oppositional', 'amplifying', 'constraining',
    'resolving', 'destabilizing', 'harmonizing', 'redirecting'
  ])).default([]),
  placementSensitivity: z.boolean().default(true),
  intrinsicTendencies: z.record(z.string(), z.number()).default({}),
});

// ============================================================
// IDENTITY CENTER SCHEMAS
// ============================================================

export const IdentityCenterSchema = z.object({
  userId: z.string(),
  alignmentProfile: z.record(z.string(), z.any()).default({}),
  llmBridges: z.array(z.object({
    provider: z.string(),
    model: z.string(),
    config: z.record(z.string(), z.any()).optional(),
  })).default([]),
  mcpBridges: z.array(z.object({
    server: z.string(),
    tools: z.array(z.string()).default([]),
    config: z.record(z.string(), z.any()).optional(),
  })).default([]),
  routingProfile: z.object({
    preferredDimensions: z.array(z.string()).default([]),
    preferredCenters: z.array(z.number().int()).default([]),
    stylePreferences: z.record(z.string(), z.any()).default({}),
  }).default({}),
  semanticCoherence: z.number().min(0).max(1).default(0.5),
});

// ============================================================
// PROJECTION SCHEMAS
// ============================================================

export const ProjectionSchema = z.object({
  id: z.string().uuid(),
  domain: z.enum(['language', 'code', 'image', 'sound', 'interface', 'graph', 'behavior']),
  sourceState: MacroStateSchema,
  targetFormat: z.string(),
  qualification: MessageQualificationSchema,
  rendered: z.unknown().optional(),
  quality: z.number().min(0).max(1).optional(),
  timestamp: z.number(),
});

// ============================================================
// SELF-GROWTH SCHEMAS
// ============================================================

export const MutationSchema = z.object({
  id: z.string().uuid(),
  targetFile: z.string(),
  mutationType: z.enum(['add', 'modify', 'remove', 'refactor']),
  diff: z.string(),
  rationale: z.string(),
  confidence: z.number().min(0).max(1),
  appliedAt: z.number().optional(),
  verified: z.boolean().default(false),
  rolledBack: z.boolean().default(false),
});

export const GrowthEventSchema = z.object({
  id: z.string().uuid(),
  eventType: z.enum(['ingestion', 'activation', 'convergence', 'mutation', 'learning']),
  source: z.string(),
  payload: z.unknown(),
  impact: z.number().min(-1).max(1).default(0),
  timestamp: z.number(),
  processed: z.boolean().default(false),
});

// Type exports
export type Planet = z.infer<typeof PlanetSchema>;
export type Dimension = z.infer<typeof DimensionSchema>;
export type Center = z.infer<typeof CenterSchema>;
export type Gate = z.infer<typeof GateSchema>;
export type Line = z.infer<typeof LineSchema>;
export type Color = z.infer<typeof ColorSchema>;
export type Tone = z.infer<typeof ToneSchema>;
export type Base = z.infer<typeof BaseSchema>;
export type InternalCoordinate = z.infer<typeof InternalCoordinateSchema>;
export type MacroState = z.infer<typeof MacroStateSchema>;
export type MicroState = z.infer<typeof MicroStateSchema>;
export type MessageQualification = z.infer<typeof MessageQualificationSchema>;
export type MeshMessage = z.infer<typeof MeshMessageSchema>;
export type Channel = z.infer<typeof ChannelSchema>;
export type Edge = z.infer<typeof EdgeSchema>;
export type NodeContribution = z.infer<typeof NodeContributionSchema>;
export type IdentityCenter = z.infer<typeof IdentityCenterSchema>;
export type Projection = z.infer<typeof ProjectionSchema>;
export type Mutation = z.infer<typeof MutationSchema>;
export type GrowthEvent = z.infer<typeof GrowthEventSchema>;
