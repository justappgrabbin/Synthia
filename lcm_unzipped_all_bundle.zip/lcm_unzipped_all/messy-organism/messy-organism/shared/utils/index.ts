/**
 * MESSY Organism - Shared Utilities
 * 
 * Core utility functions for the organism's operation.
 */

import { v4 as uuidv4 } from 'uuid';

// ============================================================
// UUID & ID Generation
// ============================================================

export function generateId(): string {
  return uuidv4();
}

export function generateMeshMessageId(): string {
  return `msg_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

export function generateEdgeId(source: string, target: string): string {
  return `edge_${source}_${target}_${Date.now()}`;
}

// ============================================================
// State Space Utilities
// ============================================================

export function computeStateDistance(
  stateA: { coordinates?: Record<string, number | undefined> },
  stateB: { coordinates?: Record<string, number | undefined> }
): number {
  const coords = ['line', 'color', 'tone', 'base', 'arc', 'degree'];
  let sum = 0;
  let count = 0;

  for (const key of coords) {
    const a = stateA.coordinates?.[key];
    const b = stateB.coordinates?.[key];
    if (a !== undefined && b !== undefined) {
      const max = key === 'degree' ? 360 : key === 'arc' ? 1 : 6;
      const diff = Math.abs(a - b) / max;
      sum += diff * diff;
      count++;
    }
  }

  return count > 0 ? Math.sqrt(sum / count) : 1;
}

export function interpolateState(
  stateA: Record<string, number>,
  stateB: Record<string, number>,
  t: number
): Record<string, number> {
  const result: Record<string, number> = {};
  for (const key of Object.keys(stateA)) {
    if (key in stateB) {
      result[key] = stateA[key] + (stateB[key] - stateA[key]) * t;
    }
  }
  return result;
}

// ============================================================
// Resonance & Convergence Utilities
// ============================================================

export function computeResonance(
  patternA: number[],
  patternB: number[]
): number {
  if (patternA.length !== patternB.length) {
    throw new Error('Patterns must have same length for resonance computation');
  }

  let dotProduct = 0;
  let magA = 0;
  let magB = 0;

  for (let i = 0; i < patternA.length; i++) {
    dotProduct += patternA[i] * patternB[i];
    magA += patternA[i] * patternA[i];
    magB += patternB[i] * patternB[i];
  }

  const denominator = Math.sqrt(magA) * Math.sqrt(magB);
  return denominator === 0 ? 0 : dotProduct / denominator;
}

export function computeConvergence(
  activations: number[],
  threshold: number = 0.7
): { converged: boolean; level: number; dominant: number | null } {
  if (activations.length === 0) {
    return { converged: false, level: 0, dominant: null };
  }

  const sum = activations.reduce((a, b) => a + b, 0);
  const level = sum / activations.length;
  const max = Math.max(...activations);
  const dominant = max > threshold ? activations.indexOf(max) : null;

  return {
    converged: level >= threshold,
    level,
    dominant,
  };
}

// ============================================================
// Hexagram / I Ching Utilities
// ============================================================

export function gateToHexagram(gateId: number): number {
  return ((gateId - 1) % 64) + 1;
}

export function hexagramToBinary(hexagram: number): string {
  // 6-bit binary representation (bottom to top)
  const lines = [];
  let n = hexagram - 1;
  for (let i = 0; i < 6; i++) {
    lines.push((n & 1) === 1 ? '1' : '0');
    n >>= 1;
  }
  return lines.join('');
}

export function binaryToHexagram(binary: string): number {
  let result = 0;
  for (let i = 0; i < 6; i++) {
    if (binary[i] === '1') {
      result |= (1 << i);
    }
  }
  return result + 1;
}

export function getTrigram(hexagram: number, position: 'upper' | 'lower'): number {
  const binary = hexagramToBinary(hexagram);
  const trigramBinary = position === 'upper' 
    ? binary.slice(3, 6) 
    : binary.slice(0, 3);

  let result = 0;
  for (let i = 0; i < 3; i++) {
    if (trigramBinary[i] === '1') {
      result |= (1 << i);
    }
  }
  return result + 1;
}

// ============================================================
// Temporal Utilities
// ============================================================

export function now(): number {
  return Date.now();
}

export function debounce<T extends (...args: any[]) => any>(
  fn: T,
  ms: number
): (...args: Parameters<T>) => void {
  let timeout: ReturnType<typeof setTimeout>;
  return (...args) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => fn(...args), ms);
  };
}

export function throttle<T extends (...args: any[]) => any>(
  fn: T,
  ms: number
): (...args: Parameters<T>) => void {
  let last = 0;
  return (...args) => {
    const now = Date.now();
    if (now - last >= ms) {
      last = now;
      fn(...args);
    }
  };
}

// ============================================================
// Deep Clone & Merge
// ============================================================

export function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

export function deepMerge<T extends Record<string, any>>(
  target: T,
  source: Partial<T>
): T {
  const result = { ...target };
  for (const key of Object.keys(source)) {
    if (
      source[key] &&
      typeof source[key] === 'object' &&
      !Array.isArray(source[key]) &&
      key in target &&
      target[key] &&
      typeof target[key] === 'object'
    ) {
      result[key] = deepMerge(target[key], source[key] as any);
    } else {
      result[key] = source[key] as any;
    }
  }
  return result;
}

// ============================================================
// Event Emitter (Lightweight)
// ============================================================

export class EventEmitter<T extends Record<string, any>> {
  private listeners: Map<keyof T, Set<(payload: any) => void>> = new Map();

  on<K extends keyof T>(event: K, handler: (payload: T[K]) => void): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(handler);

    return () => {
      this.listeners.get(event)?.delete(handler);
    };
  }

  emit<K extends keyof T>(event: K, payload: T[K]): void {
    this.listeners.get(event)?.forEach(handler => {
      try {
        handler(payload);
      } catch (err) {
        console.error(`Event handler error for ${String(event)}:`, err);
      }
    });
  }

  off<K extends keyof T>(event: K, handler: (payload: T[K]) => void): void {
    this.listeners.get(event)?.delete(handler);
  }
}

// ============================================================
// Async Utilities
// ============================================================

export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export function timeout<T>(
  promise: Promise<T>,
  ms: number,
  errorMessage: string = 'Operation timed out'
): Promise<T> {
  return Promise.race([
    promise,
    new Promise<never>((_, reject) => 
      setTimeout(() => reject(new Error(errorMessage)), ms)
    ),
  ]);
}

// ============================================================
// Validation Utilities
// ============================================================

export function isDefined<T>(value: T | undefined | null): value is T {
  return value !== undefined && value !== null;
}

export function assertDefined<T>(
  value: T | undefined | null,
  message: string = 'Value must be defined'
): T {
  if (!isDefined(value)) {
    throw new Error(message);
  }
  return value;
}

// ============================================================
// Logging Utilities
// ============================================================

export enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3,
}

export class Logger {
  private level: LogLevel;
  private prefix: string;

  constructor(prefix: string = 'MESSY', level: LogLevel = LogLevel.INFO) {
    this.prefix = prefix;
    this.level = level;
  }

  debug(...args: any[]): void {
    if (this.level <= LogLevel.DEBUG) {
      console.debug(`[${this.prefix}] DEBUG:`, ...args);
    }
  }

  info(...args: any[]): void {
    if (this.level <= LogLevel.INFO) {
      console.info(`[${this.prefix}] INFO:`, ...args);
    }
  }

  warn(...args: any[]): void {
    if (this.level <= LogLevel.WARN) {
      console.warn(`[${this.prefix}] WARN:`, ...args);
    }
  }

  error(...args: any[]): void {
    if (this.level <= LogLevel.ERROR) {
      console.error(`[${this.prefix}] ERROR:`, ...args);
    }
  }

  setLevel(level: LogLevel): void {
    this.level = level;
  }
}

export const defaultLogger = new Logger('MESSY');
