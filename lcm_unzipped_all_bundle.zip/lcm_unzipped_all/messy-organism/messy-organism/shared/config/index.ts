/**
 * MESSY Organism - Shared Configuration
 * 
 * Canonical configuration for all organism subsystems.
 * This is the constitution's runtime manifestation.
 */

export const ORGANISM_CONFIG = {
  name: 'MESSY',
  version: '1.0.0',

  // Ontological constants
  ontology: {
    planets: 13,
    dimensions: 5,
    centers: 9,
    gates: 64,
    linesPerGate: 6,
    colorsPerLine: 6,
    tonesPerColor: 6,
    basesPerTone: 5,
  },

  // State space coordinates
  coordinates: {
    canonical: ['line', 'color', 'tone', 'base', 'arc', 'degree', 'minute', 'second'],
    discrete: ['line', 'color', 'tone', 'base'],
    continuous: ['arc', 'degree', 'minute', 'second'],
  },

  // Center activation modes
  centerModes: ['latent', 'converging', 'modulating', 'expressed', 'actioning'],

  // Strata
  strata: [
    { name: 'Heart', domain: 'Direction', index: 0 },
    { name: 'Mind', domain: 'Structure/Code', index: 1 },
    { name: 'Action', domain: 'Embodiment/Image', index: 2 },
  ],

  // Dimensions with correspondences
  dimensions: [
    { name: 'Movement', macro: 'Individuality', micro: 'Individual', keynote: 'I Define' },
    { name: 'Evolution', macro: 'Mind', micro: 'Mental', keynote: 'I Remember' },
    { name: 'Being', macro: 'Body', micro: 'Physical', keynote: 'I Am' },
    { name: 'Design', macro: 'Ego', micro: 'Egoic', keynote: 'I Design' },
    { name: 'Space', macro: 'Personality', micro: 'Personality', keynote: 'I Think' },
  ],

  // Mesh law sequence
  meshLaw: [
    'gate',
    'message', 
    'mesh',
    'channelTraversal',
    'edgeFormation',
    'morph',
    'convergence',
    'expression',
    'centerBehavior'
  ],

  // Organs
  organs: ['AUTOLING', 'DISEMINER', 'AutomaticNovelWriter'],

  // Projection domains
  projectionDomains: ['language', 'code', 'image', 'sound', 'interface', 'graph', 'behavior'],

  // Activation grammars
  activationGrammars: [
    'humanDesign',
    'userResponse',
    'behavior',
    'languagePattern',
    'codePattern',
    'interactionTrace',
    'soundSignature',
    'imageSignature',
  ],

  // Node contribution categories
  nodeCategories: [
    'Initiatory',
    'Receptive', 
    'Formulating',
    'Corrective',
    'Rhythmic',
    'Directional',
    'Attentional',
    'Mutative',
    'Resonant',
    'Gatekeeping',
  ],

  // Edge function types
  edgeFunctionTypes: [
    'feedforwardArticulation',
    'bidirectionalConstraint',
    'correctionTowardAttractor',
    'sparseCompression',
    'selfOrganization',
    'adversarialTension',
    'reservoirPulse',
    'gatingLoop',
    'radialActivation',
    'attentionalHighlighting',
    'recursiveMemoryAccess',
    'unpackingExpression',
  ],

  // Runtime
  runtime: {
    meshTickMs: 16,      // ~60fps mesh update
    convergenceThreshold: 0.7,
    maxRecursionDepth: 64,
    defaultLogLevel: 'info',
  },

  // Persistence
  persistence: {
    engine: 'sqlite',     // local-first
    path: './data/messy.db',
    snapshotIntervalMs: 30000,
  },

  // Self-growth
  selfGrowth: {
    enabled: true,
    autoEdit: true,
    learningRate: 0.01,
    maxMutationPerCycle: 0.05,
  },
} as const;

export type OrganismConfig = typeof ORGANISM_CONFIG;
export type DimensionName = typeof ORGANISM_CONFIG.dimensions[number]['name'];
export type CenterMode = typeof ORGANISM_CONFIG.centerModes[number];
export type StratumName = typeof ORGANISM_CONFIG.strata[number]['name'];
export type OrganName = typeof ORGANISM_CONFIG.organs[number];
export type ProjectionDomain = typeof ORGANISM_CONFIG.projectionDomains[number];
export type ActivationGrammar = typeof ORGANISM_CONFIG.activationGrammars[number];
export type NodeCategory = typeof ORGANISM_CONFIG.nodeCategories[number];
export type EdgeFunctionType = typeof ORGANISM_CONFIG.edgeFunctionTypes[number];

// Environment-aware config loader
export function loadConfig(env: Record<string, string | undefined> = process.env): OrganismConfig {
  return {
    ...ORGANISM_CONFIG,
    runtime: {
      ...ORGANISM_CONFIG.runtime,
      logLevel: (env.LOG_LEVEL as any) || ORGANISM_CONFIG.runtime.defaultLogLevel,
    },
    persistence: {
      ...ORGANISM_CONFIG.persistence,
      path: env.MESSY_DB_PATH || ORGANISM_CONFIG.persistence.path,
    },
  };
}
