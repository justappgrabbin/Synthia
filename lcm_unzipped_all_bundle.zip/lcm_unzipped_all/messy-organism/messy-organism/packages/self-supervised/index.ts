/**
 * MESSY Organism - Self-Supervised Package
 * 
 * Self-supervised engine logic, training and adaptation hooks,
 * optional local learning logic.
 */

import { GrowthEvent, Mutation } from '@messy/schemas';
import { Logger, LogLevel, generateId, now, deepClone } from '@messy/utils';
import { ORGANISM_CONFIG } from '@messy/config';
import { bus } from '@messy/bus';
import { mesh } from '@messy/mesh';

// ============================================================
// SELF-SUPERVISED ENGINE
// ============================================================

export interface LearningRule {
  id: string;
  condition: (event: GrowthEvent) => boolean;
  action: (event: GrowthEvent) => void;
  confidence: number;
  createdAt: number;
  lastApplied: number;
  applicationCount: number;
}

export class SelfSupervisedEngine {
  private logger = new Logger('SelfSupervised', LogLevel.INFO);
  private learningRules: LearningRule[] = [];
  private mutations: Mutation[] = [];
  private growthEvents: GrowthEvent[] = [];
  private learningRate = ORGANISM_CONFIG.selfGrowth.learningRate;
  private autoEdit = ORGANISM_CONFIG.selfGrowth.autoEdit;
  private maxMutationPerCycle = ORGANISM_CONFIG.selfGrowth.maxMutationPerCycle;

  constructor() {
    this.initializeDefaultRules();
    this.connectToMesh();
    this.registerWithBus();
  }

  private initializeDefaultRules(): void {
    // Rule 1: High-quality ingestion increases activation thresholds
    this.learningRules.push({
      id: generateId(),
      condition: (event) => 
        event.eventType === 'ingestion' && 
        event.impact > 0.5,
      action: (event) => {
        this.logger.info('Learning: High-quality ingestion detected, adapting thresholds');
        // In a real implementation, this would modify activation thresholds
      },
      confidence: 0.7,
      createdAt: now(),
      lastApplied: 0,
      applicationCount: 0,
    });

    // Rule 2: Convergence events strengthen mesh edges
    this.learningRules.push({
      id: generateId(),
      condition: (event) => 
        event.eventType === 'convergence' &&
        event.impact > 0.3,
      action: (event) => {
        this.logger.info('Learning: Convergence detected, reinforcing pathways');
        // Would strengthen mesh edges in the real implementation
      },
      confidence: 0.8,
      createdAt: now(),
      lastApplied: 0,
      applicationCount: 0,
    });

    // Rule 3: Repeated activation patterns create new rules
    this.learningRules.push({
      id: generateId(),
      condition: (event) => {
        const recent = this.growthEvents
          .filter(e => e.eventType === event.eventType)
          .slice(-5);
        return recent.length >= 3;
      },
      action: (event) => {
        this.logger.info('Learning: Pattern repetition detected, creating new rule');
        this.createPatternRule(event);
      },
      confidence: 0.6,
      createdAt: now(),
      lastApplied: 0,
      applicationCount: 0,
    });
  }

  private connectToMesh(): void {
    mesh.on('convergenceReached', ({ messages, level }) => {
      const event: GrowthEvent = {
        id: generateId(),
        eventType: 'convergence',
        source: 'mesh',
        payload: { messages: messages.length, level },
        impact: level,
        timestamp: now(),
        processed: false,
      };
      this.processEvent(event);
    });

    mesh.on('centerActivated', ({ centerId, level }) => {
      const event: GrowthEvent = {
        id: generateId(),
        eventType: 'activation',
        source: 'mesh',
        payload: { centerId, level },
        impact: level,
        timestamp: now(),
        processed: false,
      };
      this.processEvent(event);
    });
  }

  private registerWithBus(): void {
    bus.registerOrgan('SelfSupervised', [
      'processEvent',
      'getLearningRules',
      'getMutations',
      'applyMutation',
      'rollbackMutation',
    ]);
  }

  // Process a growth event
  processEvent(event: GrowthEvent): void {
    this.growthEvents.push(event);

    // Apply learning rules
    for (const rule of this.learningRules) {
      if (rule.condition(event)) {
        try {
          rule.action(event);
          rule.lastApplied = now();
          rule.applicationCount++;
          rule.confidence = Math.min(1, rule.confidence + this.learningRate);
        } catch (err) {
          this.logger.error(`Rule ${rule.id} failed:`, err);
          rule.confidence = Math.max(0, rule.confidence - this.learningRate * 2);
        }
      }
    }

    // Check for self-growth opportunities
    if (this.autoEdit && event.impact > 0.5) {
      this.considerMutation(event);
    }

    event.processed = true;
  }

  // Create a new rule from a pattern
  private createPatternRule(event: GrowthEvent): void {
    const rule: LearningRule = {
      id: generateId(),
      condition: (e) => 
        e.eventType === event.eventType &&
        e.source === event.source,
      action: (e) => {
        this.logger.info(`Auto-rule: Handling ${e.eventType} from ${e.source}`);
      },
      confidence: 0.3,
      createdAt: now(),
      lastApplied: 0,
      applicationCount: 0,
    };

    this.learningRules.push(rule);
    this.logger.info(`Created new learning rule: ${rule.id}`);
  }

  // Consider a mutation based on growth event
  private considerMutation(event: GrowthEvent): void {
    const mutation: Mutation = {
      id: generateId(),
      targetFile: 'system/behavior',
      mutationType: 'add',
      diff: `// Auto-generated from event ${event.id}
// Impact: ${event.impact}`,
      rationale: `High-impact ${event.eventType} event suggests system adaptation`,
      confidence: Math.min(1, event.impact * 0.8),
      appliedAt: undefined,
      verified: false,
      rolledBack: false,
    };

    this.mutations.push(mutation);

    if (mutation.confidence > 0.7) {
      this.applyMutation(mutation.id);
    }
  }

  // Apply a mutation
  applyMutation(mutationId: string): boolean {
    const mutation = this.mutations.find(m => m.id === mutationId);
    if (!mutation) return false;

    mutation.appliedAt = now();
    mutation.verified = true;

    this.logger.info(`Applied mutation ${mutationId} to ${mutation.targetFile}`);

    bus.publish({
      type: 'event',
      topic: 'organism:mutation',
      payload: mutation,
      source: 'SelfSupervised',
    });

    return true;
  }

  // Rollback a mutation
  rollbackMutation(mutationId: string): boolean {
    const mutation = this.mutations.find(m => m.id === mutationId);
    if (!mutation || !mutation.appliedAt) return false;

    mutation.rolledBack = true;
    this.logger.info(`Rolled back mutation ${mutationId}`);

    return true;
  }

  // Get learning rules
  getLearningRules(): LearningRule[] {
    return [...this.learningRules];
  }

  // Get mutations
  getMutations(): Mutation[] {
    return [...this.mutations];
  }

  // Get stats
  getStats(): object {
    return {
      learningRules: this.learningRules.length,
      mutations: this.mutations.length,
      appliedMutations: this.mutations.filter(m => m.appliedAt && !m.rolledBack).length,
      growthEvents: this.growthEvents.length,
      avgRuleConfidence: this.learningRules.reduce((s, r) => s + r.confidence, 0) / (this.learningRules.length || 1),
    };
  }
}

// Singleton
export const selfSupervised = new SelfSupervisedEngine();
