/**
 * MESSY Organism - Projection Package
 * 
 * Projection into language, code, image, sound, interface, graph, and behavior.
 * Projection is downstream from activation.
 */

import { MacroState, Projection, MessageQualification } from '@messy/schemas';
import { Logger, LogLevel, generateId, now, deepClone } from '@messy/utils';
import { ORGANISM_CONFIG } from '@messy/config';
import { stateSpace } from '@messy/state-space';
import { mesh } from '@messy/mesh';

// ============================================================
# PROJECTION ENGINE
# ============================================================

export interface ProjectionRenderer {
  domain: string;
  canRender(state: MacroState): boolean;
  render(state: MacroState, qualification: MessageQualification): unknown;
}

export class ProjectionEngine {
  private logger = new Logger('Projection', LogLevel.INFO);
  private renderers: Map<string, ProjectionRenderer> = new Map();
  private projectionHistory: Projection[] = [];

  constructor() {
    this.registerDefaultRenderers();
    this.connectToMesh();
  }

  private connectToMesh(): void {
    mesh.on('convergenceReached', ({ messages, level }) => {
      for (const message of messages) {
        if (message.payload && typeof message.payload === 'object') {
          const state = message.payload as MacroState;
          this.project(state, message.qualification);
        }
      }
    });
  }

  private registerDefaultRenderers(): void {
    // Language projection renderer
    this.registerRenderer({
      domain: 'language',
      canRender: (state) => true,
      render: (state, qualification) => {
        const bias = stateSpace.getProjectionBias(state);
        const gate = state.gateId ? require('@messy/ontology').ontology.getGate(state.gateId) : null;

        return {
          text: this.generateLanguageExpression(state, qualification),
          tone: this.inferTone(state),
          style: this.inferStyle(state, qualification),
          confidence: bias.language || 0.5,
        };
      },
    });

    // Code projection renderer
    this.registerRenderer({
      domain: 'code',
      canRender: (state) => state.gateId !== undefined,
      render: (state, qualification) => {
        return {
          snippet: this.generateCodeExpression(state),
          language: 'typescript',
          pattern: this.inferCodePattern(state),
          confidence: 0.6,
        };
      },
    });

    // Interface projection renderer
    this.registerRenderer({
      domain: 'interface',
      canRender: (state) => true,
      render: (state, qualification) => {
        return {
          component: this.inferUIComponent(state),
          theme: this.inferTheme(state),
          layout: this.inferLayout(state),
          confidence: 0.7,
        };
      },
    });

    // Graph projection renderer
    this.registerRenderer({
      domain: 'graph',
      canRender: (state) => state.gateId !== undefined,
      render: (state, qualification) => {
        return {
          nodes: state.gateId ? [{ id: state.gateId, label: state.identity }] : [],
          edges: [],
          layout: 'force-directed',
          confidence: 0.8,
        };
      },
    });

    this.logger.info(`Registered ${this.renderers.size} projection renderers`);
  }

  // Register a renderer
  registerRenderer(renderer: ProjectionRenderer): void {
    this.renderers.set(renderer.domain, renderer);
  }

  // Project a state into a domain
  project(state: MacroState, qualification: MessageQualification, domain?: string): Projection[] {
    const projections: Projection[] = [];
    const domains = domain ? [domain] : ORGANISM_CONFIG.projectionDomains;

    for (const d of domains) {
      const renderer = this.renderers.get(d);
      if (!renderer || !renderer.canRender(state)) continue;

      try {
        const rendered = renderer.render(state, qualification);
        const projection: Projection = {
          id: generateId(),
          domain: d as any,
          sourceState: deepClone(state),
          targetFormat: d,
          qualification: deepClone(qualification),
          rendered,
          quality: (rendered as any).confidence || 0.5,
          timestamp: now(),
        };

        projections.push(projection);
        this.projectionHistory.push(projection);
      } catch (err) {
        this.logger.error(`Projection to ${d} failed:`, err);
      }
    }

    return projections;
  }

  // Generate language expression from state
  private generateLanguageExpression(state: MacroState, qualification: MessageQualification): string {
    const gate = state.gateId ? require('@messy/ontology').ontology.getGate(state.gateId) : null;
    const dimension = qualification.dimensionContext || 'Being';

    if (!gate) {
      return `State ${state.identity} is active in the ${dimension} dimension.`;
    }

    const line = state.coordinates?.line || 1;
    const lineDescriptions = [
      'initiating from the foundation',
      'responding with care',
      'adapting through trial',
      'manifesting outwardly',
      'generalizing the pattern',
      'transcending the form',
    ];

    return `The ${gate.name} (${gate.id}) is ${lineDescriptions[line - 1]} in the ${dimension} dimension.`;
  }

  // Infer tone from state
  private inferTone(state: MacroState): string {
    const stability = state.stability;
    switch (stability) {
      case 'stable': return 'grounded';
      case 'changing': return 'tense';
      case 'metastable': return 'poised';
      case 'transitioning': return 'fluid';
      default: return 'neutral';
    }
  }

  // Infer style from state and qualification
  private inferStyle(state: MacroState, qualification: MessageQualification): string {
    const depth = qualification.userAlignmentContext?.depth || 0;
    if (depth > 0.5) return 'intimate';
    if (depth > 0.2) return 'personal';
    return 'neutral';
  }

  // Generate code expression from state
  private generateCodeExpression(state: MacroState): string {
    const gate = state.gateId ? require('@messy/ontology').ontology.getGate(state.gateId) : null;
    if (!gate) return '// Unknown state';

    return `// ${gate.name} (${gate.id})
// Stability: ${state.stability}
function activateState_${gate.id}() {
  return {
    identity: '${gate.name}',
    gateId: ${gate.id},
    coordinates: ${JSON.stringify(state.coordinates || {})},
  };
}`;
  }

  // Infer code pattern from state
  private inferCodePattern(state: MacroState): string {
    const gateId = state.gateId || 0;
    const patterns = [
      'singleton', 'factory', 'observer', 'strategy', 'decorator',
      'adapter', 'facade', 'proxy', 'bridge', 'composite',
    ];
    return patterns[gateId % patterns.length];
  }

  // Infer UI component from state
  private inferUIComponent(state: MacroState): string {
    const gateId = state.gateId || 0;
    const components = [
      'Card', 'Button', 'Input', 'Modal', 'List',
      'Chart', 'Table', 'Timeline', 'Graph', 'Panel',
    ];
    return components[gateId % components.length];
  }

  // Infer theme from state
  private inferTheme(state: MacroState): object {
    const color = state.coordinates?.color || 1;
    const colors = [
      { primary: '#ef4444', secondary: '#fca5a5', name: 'red' },
      { primary: '#f97316', secondary: '#fdba74', name: 'orange' },
      { primary: '#eab308', secondary: '#fde047', name: 'yellow' },
      { primary: '#22c55e', secondary: '#86efac', name: 'green' },
      { primary: '#3b82f6', secondary: '#93c5fd', name: 'blue' },
      { primary: '#a855f7', secondary: '#d8b4fe', name: 'violet' },
    ];
    return colors[(color - 1) % colors.length];
  }

  // Infer layout from state
  private inferLayout(state: MacroState): string {
    const stability = state.stability;
    switch (stability) {
      case 'stable': return 'grid';
      case 'changing': return 'flow';
      case 'metastable': return 'flex';
      case 'transitioning': return 'absolute';
      default: return 'block';
    }
  }

  // Get projection history
  getHistory(domain?: string, limit: number = 100): Projection[] {
    let filtered = this.projectionHistory;
    if (domain) {
      filtered = filtered.filter(p => p.domain === domain);
    }
    return filtered.slice(-limit);
  }

  // Get stats
  getStats(): object {
    const domains = new Map<string, number>();
    for (const p of this.projectionHistory) {
      domains.set(p.domain, (domains.get(p.domain) || 0) + 1);
    }

    return {
      registeredRenderers: Array.from(this.renderers.keys()),
      totalProjections: this.projectionHistory.length,
      byDomain: Object.fromEntries(domains),
    };
  }
}

// Singleton
export const projection = new ProjectionEngine();
