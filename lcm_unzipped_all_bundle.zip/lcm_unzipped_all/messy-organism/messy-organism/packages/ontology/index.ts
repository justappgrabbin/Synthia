/**
 * MESSY Organism - Ontology Package
 * 
 * The canonical source of truth for what exists in the organism.
 * This package defines the complete discrete and continuous state lattice.
 * 
 * Ontological Principle: All possible forms exist as latent structure
 * within the state space before expression.
 */

import { 
  Planet, Dimension, Center, Gate, Line, Color, Tone, Base,
  PlanetSchema, DimensionSchema, CenterSchema, GateSchema,
  LineSchema, ColorSchema, ToneSchema, BaseSchema
} from '@messy/schemas';
import { ORGANISM_CONFIG } from '@messy/config';

// ============================================================
// CANONICAL ONTOLOGY DATA
// ============================================================

// 13 Planetary Influences
export const PLANETS: Planet[] = [
  { id: 1, name: 'Sun', symbol: '☉', influence: 'core_identity' },
  { id: 2, name: 'Earth', symbol: '⊕', influence: 'grounding' },
  { id: 3, name: 'Moon', symbol: '☽', influence: 'cyclic_drive' },
  { id: 4, name: 'North Node', symbol: '☊', influence: 'destiny_direction' },
  { id: 5, name: 'South Node', symbol: '☋', influence: 'karma_release' },
  { id: 6, name: 'Mercury', symbol: '☿', influence: 'communication' },
  { id: 7, name: 'Venus', symbol: '♀', influence: 'values_relating' },
  { id: 8, name: 'Mars', symbol: '♂', influence: 'action_drive' },
  { id: 9, name: 'Jupiter', symbol: '♃', influence: 'expansion_law' },
  { id: 10, name: 'Saturn', symbol: '♄', influence: 'discipline_structure' },
  { id: 11, name: 'Uranus', symbol: '♅', influence: 'mutation_breakthrough' },
  { id: 12, name: 'Neptune', symbol: '♆', influence: 'dream_dissolution' },
  { id: 13, name: 'Pluto', symbol: '♇', influence: 'transformation_truth' },
];

// 5 Dimensions with full correspondences
export const DIMENSIONS: Dimension[] = [
  { 
    id: 1, 
    name: 'Movement', 
    macro: 'Individuality', 
    micro: 'Individual', 
    keynote: 'I Define',
    reversal: 'Stillness'
  },
  { 
    id: 2, 
    name: 'Evolution', 
    macro: 'Mind', 
    micro: 'Mental', 
    keynote: 'I Remember',
    reversal: 'Devolution'
  },
  { 
    id: 3, 
    name: 'Being', 
    macro: 'Body', 
    micro: 'Physical', 
    keynote: 'I Am',
    reversal: 'Non-being'
  },
  { 
    id: 4, 
    name: 'Design', 
    macro: 'Ego', 
    micro: 'Egoic', 
    keynote: 'I Design',
    reversal: 'Chaos'
  },
  { 
    id: 5, 
    name: 'Space', 
    macro: 'Personality', 
    micro: 'Personality', 
    keynote: 'I Think',
    reversal: 'Contraction'
  },
];

// 9 Centers
export const CENTERS: Center[] = [
  { id: 1, name: 'Head', mode: 'latent', activationLevel: 0, isIdentity: false, activeGates: [], activeChannels: [] },
  { id: 2, name: 'Ajna', mode: 'latent', activationLevel: 0, isIdentity: false, activeGates: [], activeChannels: [] },
  { id: 3, name: 'Throat', mode: 'latent', activationLevel: 0, isIdentity: false, activeGates: [], activeChannels: [] },
  { id: 4, name: 'G', mode: 'latent', activationLevel: 0, isIdentity: true, activeGates: [], activeChannels: [] },
  { id: 5, name: 'Heart', mode: 'latent', activationLevel: 0, isIdentity: false, activeGates: [], activeChannels: [] },
  { id: 6, name: 'Solar Plexus', mode: 'latent', activationLevel: 0, isIdentity: false, activeGates: [], activeChannels: [] },
  { id: 7, name: 'Sacral', mode: 'latent', activationLevel: 0, isIdentity: false, activeGates: [], activeChannels: [] },
  { id: 8, name: 'Spleen', mode: 'latent', activationLevel: 0, isIdentity: false, activeGates: [], activeChannels: [] },
  { id: 9, name: 'Root', mode: 'latent', activationLevel: 0, isIdentity: false, activeGates: [], activeChannels: [] },
];

// 6 Colors (semantic/spectral layer)
export const COLORS: Color[] = [
  { id: 1, name: 'Red', motivation: 'survival', spectralBias: 'warm_aggressive', fieldQuality: 'urgent' },
  { id: 2, name: 'Orange', motivation: 'desire', spectralBias: 'warm_active', fieldQuality: 'energetic' },
  { id: 3, name: 'Yellow', motivation: 'curiosity', spectralBias: 'warm_receptive', fieldQuality: 'illuminating' },
  { id: 4, name: 'Green', motivation: 'growth', spectralBias: 'cool_harmonizing', fieldQuality: 'balancing' },
  { id: 5, name: 'Blue', motivation: 'truth', spectralBias: 'cool_receptive', fieldQuality: 'clarifying' },
  { id: 6, name: 'Violet', motivation: 'transcendence', spectralBias: 'cool_active', fieldQuality: 'transforming' },
];

// 6 Tones (perceptual filters)
export const TONES: Tone[] = [
  { id: 1, name: 'C', perceptualFilter: 'direct_perception', attunementMode: 'immediate' },
  { id: 2, name: 'D', perceptualFilter: 'relational_perception', attunementMode: 'responsive' },
  { id: 3, name: 'E', perceptualFilter: 'emotional_perception', attunementMode: 'feeling' },
  { id: 4, name: 'F', perceptualFilter: 'analytical_perception', attunementMode: 'discerning' },
  { id: 5, name: 'G', perceptualFilter: 'intuitive_perception', attunementMode: 'knowing' },
  { id: 6, name: 'A', perceptualFilter: 'synthetic_perception', attunementMode: 'integrating' },
];

// 5 Bases (grounding substrate)
export const BASES: Base[] = [
  { id: 1, name: 'Alpha', grounding: 'physical', refinement: 'sensory' },
  { id: 2, name: 'Beta', grounding: 'emotional', refinement: 'affective' },
  { id: 3, name: 'Gamma', grounding: 'mental', refinement: 'conceptual' },
  { id: 4, name: 'Delta', grounding: 'spiritual', refinement: 'intuitive' },
  { id: 5, name: 'Epsilon', grounding: 'transcendent', refinement: 'unitive' },
];

// 64 Gates with I Ching mapping
export const GATES: Gate[] = Array.from({ length: 64 }, (_, i) => {
  const gateId = i + 1;
  const hexagram = gateId;

  // Gate names based on I Ching hexagrams
  const gateNames: Record<number, string> = {
    1: 'The Creative', 2: 'The Receptive', 3: 'Difficulty at the Beginning',
    4: 'Youthful Folly', 5: 'Waiting', 6: 'Conflict', 7: 'The Army',
    8: 'Holding Together', 9: 'Small Taming', 10: 'Treading',
    11: 'Peace', 12: 'Standstill', 13: 'Fellowship', 14: 'Great Possession',
    15: 'Modesty', 16: 'Enthusiasm', 17: 'Following', 18: 'Work on Decay',
    19: 'Approach', 20: 'Contemplation', 21: 'Biting Through', 22: 'Grace',
    23: 'Splitting Apart', 24: 'Return', 25: 'Innocence', 26: 'Great Taming',
    27: 'Nourishment', 28: 'Great Exceeding', 29: 'The Abysmal', 30: 'The Clinging',
    31: 'Influence', 32: 'Duration', 33: 'Retreat', 34: 'Great Power',
    35: 'Progress', 36: 'Darkening of the Light', 37: 'The Family', 38: 'Opposition',
    39: 'Obstruction', 40: 'Deliverance', 41: 'Decrease', 42: 'Increase',
    43: 'Breakthrough', 44: 'Coming to Meet', 45: 'Gathering Together', 46: 'Pushing Upward',
    47: 'Exhaustion', 48: 'The Well', 49: 'Revolution', 50: 'The Cauldron',
    51: 'The Arousing', 52: 'Keeping Still', 53: 'Gradual Progress', 54: 'The Marrying Maiden',
    55: 'Abundance', 56: 'The Wanderer', 57: 'The Gentle', 58: 'The Joyous',
    59: 'Dispersion', 60: 'Limitation', 61: 'Inner Truth', 62: 'Small Exceeding',
    63: 'After Completion', 64: 'Before Completion',
  };

  return {
    id: gateId,
    name: gateNames[gateId] || `Gate ${gateId}`,
    hexagram,
    trigram: undefined,
  };
});

// ============================================================
// ONTOLOGY ENGINE
// ============================================================

export class OntologyEngine {
  private gates: Map<number, Gate> = new Map();
  private centers: Map<number, Center> = new Map();
  private dimensions: Map<number, Dimension> = new Map();
  private planets: Map<number, Planet> = new Map();

  constructor() {
    this.initialize();
  }

  private initialize(): void {
    GATES.forEach(g => this.gates.set(g.id, g));
    CENTERS.forEach(c => this.centers.set(c.id, c));
    DIMENSIONS.forEach(d => this.dimensions.set(d.id, d));
    PLANETS.forEach(p => this.planets.set(p.id, p));
  }

  getGate(id: number): Gate | undefined {
    return this.gates.get(id);
  }

  getCenter(id: number): Center | undefined {
    return this.centers.get(id);
  }

  getDimension(id: number): Dimension | undefined {
    return this.dimensions.get(id);
  }

  getPlanet(id: number): Planet | undefined {
    return this.planets.get(id);
  }

  getAllGates(): Gate[] {
    return Array.from(this.gates.values());
  }

  getAllCenters(): Center[] {
    return Array.from(this.centers.values());
  }

  getIdentityCenter(): Center | undefined {
    return Array.from(this.centers.values()).find(c => c.isIdentity);
  }

  getDimensionByName(name: string): Dimension | undefined {
    return Array.from(this.dimensions.values()).find(d => d.name === name);
  }

  // Compute dimensional correspondence
  getCorrespondence(dimensionName: string, scale: 'macro' | 'micro'): string | undefined {
    const dim = this.getDimensionByName(dimensionName);
    if (!dim) return undefined;
    return scale === 'macro' ? dim.macro : dim.micro;
  }

  // Validate a fully qualified state address
  validateAddress(address: {
    planet?: number;
    dimension?: number;
    center?: number;
    gate?: number;
    line?: number;
    color?: number;
    tone?: number;
    base?: number;
  }): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (address.planet && (address.planet < 1 || address.planet > 13)) {
      errors.push(`Invalid planet: ${address.planet}`);
    }
    if (address.dimension && (address.dimension < 1 || address.dimension > 5)) {
      errors.push(`Invalid dimension: ${address.dimension}`);
    }
    if (address.center && (address.center < 1 || address.center > 9)) {
      errors.push(`Invalid center: ${address.center}`);
    }
    if (address.gate && (address.gate < 1 || address.gate > 64)) {
      errors.push(`Invalid gate: ${address.gate}`);
    }
    if (address.line && (address.line < 1 || address.line > 6)) {
      errors.push(`Invalid line: ${address.line}`);
    }
    if (address.color && (address.color < 1 || address.color > 6)) {
      errors.push(`Invalid color: ${address.color}`);
    }
    if (address.tone && (address.tone < 1 || address.tone > 6)) {
      errors.push(`Invalid tone: ${address.tone}`);
    }
    if (address.base && (address.base < 1 || address.base > 5)) {
      errors.push(`Invalid base: ${address.base}`);
    }

    return { valid: errors.length === 0, errors };
  }

  // Compute total discrete state space size
  getStateSpaceSize(): number {
    return (
      ORGANISM_CONFIG.ontology.planets *
      ORGANISM_CONFIG.ontology.dimensions *
      ORGANISM_CONFIG.ontology.centers *
      ORGANISM_CONFIG.ontology.gates *
      ORGANISM_CONFIG.ontology.linesPerGate *
      ORGANISM_CONFIG.ontology.colorsPerLine *
      ORGANISM_CONFIG.ontology.tonesPerColor *
      ORGANISM_CONFIG.ontology.basesPerTone
    );
  }
}

// Singleton instance
export const ontology = new OntologyEngine();

// ============================================================
// CORRESPONDENCE TABLES
// ============================================================

export const DIMENSIONAL_CORRESPONDENCES = {
  macrocosm: {
    Movement: 'Individuality',
    Evolution: 'Mind',
    Being: 'Body',
    Design: 'Ego',
    Space: 'Personality',
  },
  microcosm: {
    Movement: 'Individual',
    Evolution: 'Mental',
    Being: 'Physical',
    Design: 'Egoic',
    Space: 'Personality',
  },
  keynotes: {
    Movement: 'I Define',
    Evolution: 'I Remember',
    Being: 'I Am',
    Design: 'I Design',
    Space: 'I Think',
  },
  sensory: {
    Movement: 'kinesthetic',
    Evolution: 'auditory_digital',
    Being: 'somatic',
    Design: 'visual_constructed',
    Space: 'auditory_tone',
  },
} as const;

export const CENTER_GATE_MAP: Record<number, number[]> = {
  1: [64, 61, 63, 24, 4, 17],           // Head
  2: [43, 11, 56, 47, 4, 17],           // Ajna
  3: [62, 23, 56, 35, 12, 45, 33, 8, 31, 20, 16, 2], // Throat
  4: [1, 13, 25, 46, 10, 15, 7],       // G (Identity)
  5: [21, 40, 26, 51, 44],              // Heart
  6: [55, 30, 36, 22, 6, 37, 49, 50],  // Solar Plexus
  7: [5, 14, 29, 59, 9, 3, 42, 27, 34], // Sacral
  8: [48, 18, 28, 57, 32, 50, 44, 10], // Spleen
  9: [53, 54, 60, 38, 58, 52, 19, 39, 41], // Root
};

export const CHANNEL_DEFINITIONS: Record<string, { gates: [number, number]; type: string; description: string }> = {
  '1-8': { gates: [1, 8], type: 'inspiration', description: 'The channel of inspiration' },
  '2-14': { gates: [2, 14], type: 'beat', description: 'The channel of the beat' },
  '3-60': { gates: [3, 60], type: 'mutation', description: 'The channel of mutation' },
  '4-63': { gates: [4, 63], type: 'logic', description: 'The channel of logic' },
  '5-15': { gates: [5, 15], type: 'rhythm', description: 'The channel of rhythm' },
  '6-59': { gates: [6, 59], type: 'intimacy', description: 'The channel of intimacy' },
  '7-31': { gates: [7, 31], type: 'alpha', description: 'The channel of the alpha' },
  '9-52': { gates: [9, 52], type: 'concentration', description: 'The channel of concentration' },
  '10-20': { gates: [10, 20], type: 'awakening', description: 'The channel of awakening' },
  '10-34': { gates: [10, 34], type: 'exploration', description: 'The channel of exploration' },
  '10-57': { gates: [10, 57], type: 'perfected_form', description: 'The channel of perfected form' },
  '11-56': { gates: [11, 56], type: 'curiosity', description: 'The channel of curiosity' },
  '12-22': { gates: [12, 22], type: 'openness', description: 'The channel of openness' },
  '13-33': { gates: [13, 33], type: 'prodigal', description: 'The channel of the prodigal' },
  '16-48': { gates: [16, 48], type: 'wavelength', description: 'The channel of the wavelength' },
  '17-62': { gates: [17, 62], type: 'acceptance', description: 'The channel of acceptance' },
  '18-58': { gates: [18, 58], type: 'judgment', description: 'The channel of judgment' },
  '19-49': { gates: [19, 49], type: 'synthesis', description: 'The channel of synthesis' },
  '20-34': { gates: [20, 34], type: 'charisma', description: 'The channel of charisma' },
  '20-57': { gates: [20, 57], type: 'brainwave', description: 'The channel of the brainwave' },
  '21-45': { gates: [21, 45], type: 'money', description: 'The channel of money' },
  '23-43': { gates: [23, 43], type: 'structuring', description: 'The channel of structuring' },
  '24-61': { gates: [24, 61], type: 'awareness', description: 'The channel of awareness' },
  '25-51': { gates: [25, 51], type: 'initiation', description: 'The channel of initiation' },
  '26-44': { gates: [26, 44], type: 'surrender', description: 'The channel of surrender' },
  '27-50': { gates: [27, 50], type: 'preservation', description: 'The channel of preservation' },
  '28-38': { gates: [28, 38], type: 'struggle', description: 'The channel of struggle' },
  '29-46': { gates: [29, 46], type: 'discovery', description: 'The channel of discovery' },
  '30-41': { gates: [30, 41], type: 'recognition', description: 'The channel of recognition' },
  '32-54': { gates: [32, 54], type: 'transformation', description: 'The channel of transformation' },
  '34-57': { gates: [34, 57], type: 'power', description: 'The channel of power' },
  '35-36': { gates: [35, 36], type: 'transitoriness', description: 'The channel of transitoriness' },
  '37-40': { gates: [37, 40], type: 'community', description: 'The channel of community' },
  '39-55': { gates: [39, 55], type: 'emotion', description: 'The channel of emotion' },
  '42-53': { gates: [42, 53], type: 'maturation', description: 'The channel of maturation' },
  '47-64': { gates: [47, 64], type: 'abstraction', description: 'The channel of abstraction' },
};

// ============================================================
// PROPORTIONAL PERCEPTION UTILITIES
// ============================================================

export function findIsomorphicQualities(
  quality: string,
  domain: 'sound' | 'color' | 'behavior' | 'linguistic' | 'code' | 'symbolic'
): string[] {
  // This is a placeholder for the full proportional perception engine
  // In the full implementation, this would use the resonance-core package
  const mappings: Record<string, Record<string, string[]>> = {
    'movement': {
      sound: ['rhythm', 'pulse', 'acceleration'],
      color: ['red', 'orange', 'warm_gradient'],
      behavior: ['initiation', 'push', 'drive'],
      linguistic: ['action_verbs', 'imperative_mood'],
      code: ['loop', 'iteration', 'async'],
      symbolic: ['arrow', 'path', 'trajectory'],
    },
    'stability': {
      sound: ['drone', 'sustain', 'root_note'],
      color: ['blue', 'green', 'cool_gradient'],
      behavior: ['holding', 'waiting', 'grounding'],
      linguistic: ['state_verbs', 'descriptive_mood'],
      code: ['constant', 'singleton', 'cache'],
      symbolic: ['square', 'foundation', 'anchor'],
    },
  };

  return mappings[quality]?.[domain] || [];
}

export function detectProportionalCorrespondence(
  patternA: Record<string, number>,
  patternB: Record<string, number>
): { isCorresponding: boolean; similarity: number; transform: string } {
  const keysA = Object.keys(patternA);
  const keysB = Object.keys(patternB);

  if (keysA.length === 0 || keysB.length === 0) {
    return { isCorresponding: false, similarity: 0, transform: 'none' };
  }

  // Compute proportional similarity (not literal equality)
  const ratiosA = keysA.slice(1).map((k, i) => patternA[k] / (patternA[keysA[i]] || 1));
  const ratiosB = keysB.slice(1).map((k, i) => patternB[k] / (patternB[keysB[i]] || 1));

  let similarity = 0;
  const minLen = Math.min(ratiosA.length, ratiosB.length);
  for (let i = 0; i < minLen; i++) {
    similarity += 1 - Math.abs(ratiosA[i] - ratiosB[i]) / Math.max(ratiosA[i], ratiosB[i], 1);
  }
  similarity = similarity / (minLen || 1);

  return {
    isCorresponding: similarity > 0.7,
    similarity,
    transform: similarity > 0.9 ? 'identity' : similarity > 0.7 ? 'proportional' : 'none',
  };
}
