/**
 * MESSY Organism - HD Graph Package
 * 
 * Graph structures, traversal, tensor support, and graph update projections.
 */

import { Gate, Channel, Edge } from '@messy/schemas';
import { Logger, LogLevel, generateId, now, computeResonance } from '@messy/utils';
import { ORGANISM_CONFIG } from '@messy/config';
import { ontology, CHANNEL_DEFINITIONS } from '@messy/ontology';

// ============================================================
// GRAPH TYPES
// ============================================================

export interface GraphNode {
  id: string;
  gateId: number;
  label: string;
  x: number;
  y: number;
  activation: number; // 0-1
  centerId?: number;
  metadata: Record<string, any>;
}

export interface GraphLink {
  id: string;
  source: string;
  target: string;
  channelId: string;
  weight: number;
  type: string;
  active: boolean;
}

export interface GraphState {
  nodes: GraphNode[];
  links: GraphLink[];
  timestamp: number;
  centerActivations: Map<number, number>;
}

// ============================================================
// TENSOR SUPPORT
// ============================================================

export class Tensor {
  private data: Float32Array;
  private shape: number[];

  constructor(shape: number[], data?: number[]) {
    this.shape = shape;
    const size = shape.reduce((a, b) => a * b, 1);
    this.data = new Float32Array(size);
    if (data) {
      for (let i = 0; i < Math.min(data.length, size); i++) {
        this.data[i] = data[i];
      }
    }
  }

  get(...indices: number[]): number {
    const idx = this.computeIndex(indices);
    return this.data[idx];
  }

  set(value: number, ...indices: number[]): void {
    const idx = this.computeIndex(indices);
    this.data[idx] = value;
  }

  private computeIndex(indices: number[]): number {
    let idx = 0;
    let stride = 1;
    for (let i = this.shape.length - 1; i >= 0; i--) {
      idx += (indices[i] || 0) * stride;
      stride *= this.shape[i];
    }
    return idx;
  }

  // Gate activation tensor: 64 gates x 6 lines x 6 colors x 6 tones x 5 bases
  static createGateTensor(): Tensor {
    return new Tensor([64, 6, 6, 6, 5]);
  }

  // Center activation tensor: 9 centers
  static createCenterTensor(): Tensor {
    return new Tensor([9]);
  }

  // Channel activation tensor: 36 channels
  static createChannelTensor(): Tensor {
    return new Tensor([36]);
  }

  // Apply activation at a specific gate address
  activateGate(gateId: number, line: number, color: number, tone: number, base: number, value: number): void {
    this.set(value, gateId - 1, line - 1, color - 1, tone - 1, base - 1);
  }

  // Get activation at a specific gate address
  getGateActivation(gateId: number, line: number, color: number, tone: number, base: number): number {
    return this.get(gateId - 1, line - 1, color - 1, tone - 1, base - 1);
  }

  // Sum along a dimension
  sum(dim: number): Tensor {
    const newShape = [...this.shape];
    newShape[dim] = 1;
    const result = new Tensor(newShape);

    // Simplified sum (full implementation would iterate properly)
    for (let i = 0; i < this.data.length; i++) {
      result.data[0] += this.data[i];
    }

    return result;
  }

  // Compute resonance with another tensor
  resonance(other: Tensor): number {
    if (this.data.length !== other.data.length) {
      throw new Error('Tensors must have same size for resonance');
    }

    const a = Array.from(this.data);
    const b = Array.from(other.data);
    return computeResonance(a, b);
  }

  toArray(): number[] {
    return Array.from(this.data);
  }

  getShape(): number[] {
    return [...this.shape];
  }
}

// ============================================================
// GRAPH ENGINE
// ============================================================

export class HDGraphEngine {
  private logger = new Logger('HDGraph', LogLevel.INFO);
  private nodes: Map<string, GraphNode> = new Map();
  private links: Map<string, GraphLink> = new Map();
  private gateTensor: Tensor;
  private centerTensor: Tensor;
  private channelTensor: Tensor;

  constructor() {
    this.gateTensor = Tensor.createGateTensor();
    this.centerTensor = Tensor.createCenterTensor();
    this.channelTensor = Tensor.createChannelTensor();
    this.initializeGraph();
  }

  private initializeGraph(): void {
    // Create nodes for all 64 gates
    for (let gateId = 1; gateId <= 64; gateId++) {
      const gate = ontology.getGate(gateId);
      if (!gate) continue;

      // Position in a circle
      const angle = (gateId - 1) * (2 * Math.PI / 64);
      const radius = 200;

      const node: GraphNode = {
        id: `gate_${gateId}`,
        gateId,
        label: gate.name,
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius,
        activation: 0,
        centerId: this.findCenterForGate(gateId),
        metadata: {},
      };

      this.nodes.set(node.id, node);
    }

    // Create links for all 36 channels
    for (const [channelId, def] of Object.entries(CHANNEL_DEFINITIONS)) {
      const sourceId = `gate_${def.gates[0]}`;
      const targetId = `gate_${def.gates[1]}`;

      const link: GraphLink = {
        id: `channel_${channelId}`,
        source: sourceId,
        target: targetId,
        channelId,
        weight: 0.1,
        type: def.type,
        active: false,
      };

      this.links.set(link.id, link);
    }

    this.logger.info(`Initialized graph: ${this.nodes.size} nodes, ${this.links.size} links`);
  }

  private findCenterForGate(gateId: number): number | undefined {
    const { CENTER_GATE_MAP } = require('@messy/ontology');
    for (const [centerId, gates] of Object.entries(CENTER_GATE_MAP)) {
      if ((gates as number[]).includes(gateId)) {
        return Number(centerId);
      }
    }
    return undefined;
  }

  // Activate a gate
  activateGate(gateId: number, level: number = 1.0): void {
    const node = this.nodes.get(`gate_${gateId}`);
    if (!node) return;

    node.activation = Math.min(1, node.activation + level);
    this.gateTensor.activateGate(gateId, 1, 1, 1, 1, level);

    // Propagate to connected channels
    for (const link of this.links.values()) {
      if (link.source === `gate_${gateId}` || link.target === `gate_${gateId}`) {
        link.weight = Math.min(1, link.weight + level * 0.1);
        link.active = link.weight > 0.3;

        // Activate the other end
        const otherId = link.source === `gate_${gateId}` ? link.target : link.source;
        const otherNode = this.nodes.get(otherId);
        if (otherNode) {
          otherNode.activation = Math.min(1, otherNode.activation + level * 0.3);
        }
      }
    }

    // Update center activation
    if (node.centerId) {
      const current = this.centerTensor.get(node.centerId - 1);
      this.centerTensor.set(Math.min(1, current + level * 0.2), node.centerId - 1);
    }
  }

  // Deactivate a gate
  deactivateGate(gateId: number): void {
    const node = this.nodes.get(`gate_${gateId}`);
    if (!node) return;

    node.activation = Math.max(0, node.activation - 0.1);
  }

  // Get active nodes
  getActiveNodes(threshold: number = 0.1): GraphNode[] {
    return Array.from(this.nodes.values())
      .filter(n => n.activation > threshold)
      .sort((a, b) => b.activation - a.activation);
  }

  // Get active links
  getActiveLinks(): GraphLink[] {
    return Array.from(this.links.values()).filter(l => l.active);
  }

  // Get graph state
  getGraphState(): GraphState {
    const centerActivations = new Map<number, number>();
    for (let i = 0; i < 9; i++) {
      centerActivations.set(i + 1, this.centerTensor.get(i));
    }

    return {
      nodes: Array.from(this.nodes.values()),
      links: Array.from(this.links.values()),
      timestamp: now(),
      centerActivations,
    };
  }

  // Find shortest path between two gates
  findPath(sourceGateId: number, targetGateId: number): GraphNode[] | null {
    const sourceId = `gate_${sourceGateId}`;
    const targetId = `gate_${targetGateId}`;

    // BFS
    const visited = new Set<string>();
    const queue: Array<{ id: string; path: string[] }> = [{ id: sourceId, path: [sourceId] }];

    while (queue.length > 0) {
      const current = queue.shift()!;

      if (current.id === targetId) {
        return current.path.map(id => this.nodes.get(id)!).filter(Boolean);
      }

      if (visited.has(current.id)) continue;
      visited.add(current.id);

      // Find neighbors
      for (const link of this.links.values()) {
        if (link.source === current.id && !visited.has(link.target)) {
          queue.push({ id: link.target, path: [...current.path, link.target] });
        }
        if (link.target === current.id && !visited.has(link.source)) {
          queue.push({ id: link.source, path: [...current.path, link.source] });
        }
      }
    }

    return null;
  }

  // Compute graph resonance between two subgraphs
  computeGraphResonance(gateIdsA: number[], gateIdsB: number[]): number {
    const tensorA = new Tensor([64]);
    const tensorB = new Tensor([64]);

    for (const id of gateIdsA) {
      tensorA.set(1, id - 1);
    }
    for (const id of gateIdsB) {
      tensorB.set(1, id - 1);
    }

    return tensorA.resonance(tensorB);
  }

  // Get tensor representations
  getGateTensor(): Tensor {
    return this.gateTensor;
  }

  getCenterTensor(): Tensor {
    return this.centerTensor;
  }

  getChannelTensor(): Tensor {
    return this.channelTensor;
  }

  // Stats
  getStats(): object {
    return {
      nodes: this.nodes.size,
      links: this.links.size,
      activeNodes: this.getActiveNodes().length,
      activeLinks: this.getActiveLinks().length,
      centerActivations: Array.from({ length: 9 }, (_, i) => this.centerTensor.get(i)),
    };
  }
}

// Singleton
export const hdGraph = new HDGraphEngine();
