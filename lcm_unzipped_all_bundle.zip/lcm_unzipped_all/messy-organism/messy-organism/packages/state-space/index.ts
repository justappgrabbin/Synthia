/**
 * MESSY Organism - State Space Package
 * 
 * Defines how states work internally inside the organism.
 * A state is a bounded region with internal coordinates, gradients, 
 * thresholds, and expressive tendencies.
 */

import { 
  MacroState, MicroState, InternalCoordinate,
  MacroStateSchema, MicroStateSchema, InternalCoordinateSchema
} from '@messy/schemas';
import { 
  computeStateDistance, interpolateState, deepClone, Logger, LogLevel 
} from '@messy/utils';
import { ORGANISM_CONFIG } from '@messy/config';
import { ontology } from '@messy/ontology';

// ============================================================
// STATE REGION MODEL
// ============================================================

export interface StateRegion {
  identity: string;
  macroState: MacroState;
  boundaries: {
    stableZones: Zone[];
    thresholdZones: Zone[];
    instabilityRidges: Zone[];
    neighborFacing: Map<string, number>; // neighbor -> facing strength
  };
  gradients: {
    strength: number;
    orientation: 'inward' | 'outward';
    posture: 'receptive' | 'projective';
    tendency: 'consolidating' | 'destabilizing';
    focus: 'narrow' | 'diffuse';
  };
  expressivePockets: ExpressivePocket[];
  latentSubregions: Subregion[];
}

export interface Zone {
  name: string;
  coordinates: InternalCoordinate;
  radius: number;
  stability: number; // 0-1
}

export interface ExpressivePocket {
  name: string;
  coordinates: InternalCoordinate;
  deliveryStyle: string;
  projectionBias: Record<string, number>;
}

export interface Subregion {
  name: string;
  coordinates: InternalCoordinate;
  activationThreshold: number;
}

// ============================================================
// STATE SPACE ENGINE
// ============================================================

export class StateSpaceEngine {
  private logger = new Logger('StateSpace', LogLevel.INFO);
  private activeRegions: Map<string, StateRegion> = new Map();
  private stateHistory: MacroState[] = [];
  private maxHistorySize = 10000;

  constructor() {
    this.initializeRegions();
  }

  private initializeRegions(): void {
    // Initialize all 64 gate regions
    for (let gateId = 1; gateId <= 64; gateId++) {
      const gate = ontology.getGate(gateId);
      if (!gate) continue;

      const region: StateRegion = {
        identity: `gate_${gateId}`,
        macroState: {
          identity: gate.name,
          gateId,
          stability: 'stable',
          coordinates: {},
        },
        boundaries: {
          stableZones: this.generateStableZones(gateId),
          thresholdZones: this.generateThresholdZones(gateId),
          instabilityRidges: [],
          neighborFacing: this.computeNeighborFacing(gateId),
        },
        gradients: {
          strength: 0.5,
          orientation: 'outward',
          posture: 'projective',
          tendency: 'consolidating',
          focus: 'narrow',
        },
        expressivePockets: this.generateExpressivePockets(gateId),
        latentSubregions: this.generateSubregions(gateId),
      };

      this.activeRegions.set(region.identity, region);
    }

    this.logger.info(`Initialized ${this.activeRegions.size} state regions`);
  }

  private generateStableZones(gateId: number): Zone[] {
    // Each gate has 6 lines, each line is a stable zone
    return Array.from({ length: 6 }, (_, i) => ({
      name: `line_${i + 1}`,
      coordinates: { line: i + 1 },
      radius: 0.3,
      stability: 0.8 + Math.random() * 0.2,
    }));
  }

  private generateThresholdZones(gateId: number): Zone[] {
    // Threshold zones between lines
    return Array.from({ length: 5 }, (_, i) => ({
      name: `threshold_${i + 1}_${i + 2}`,
      coordinates: { line: i + 1.5 },
      radius: 0.15,
      stability: 0.3 + Math.random() * 0.3,
    }));
  }

  private computeNeighborFacing(gateId: number): Map<string, number> {
    const neighbors = new Map<string, number>();
    // Adjacent gates in the I Ching sequence have facing tendencies
    const prev = gateId > 1 ? gateId - 1 : 64;
    const next = gateId < 64 ? gateId + 1 : 1;
    neighbors.set(`gate_${prev}`, 0.6);
    neighbors.set(`gate_${next}`, 0.6);

    // Complementary gates (opposite in binary)
    const complement = 65 - gateId;
    neighbors.set(`gate_${complement}`, 0.8);

    return neighbors;
  }

  private generateExpressivePockets(gateId: number): ExpressivePocket[] {
    return [
      {
        name: 'core_expression',
        coordinates: { line: 3, color: 3, tone: 3 },
        deliveryStyle: 'balanced',
        projectionBias: { language: 0.7, code: 0.5, image: 0.3 },
      },
      {
        name: 'extreme_expression',
        coordinates: { line: 1, color: 1, tone: 6 },
        deliveryStyle: 'intense',
        projectionBias: { language: 0.9, code: 0.2, image: 0.8 },
      },
    ];
  }

  private generateSubregions(gateId: number): Subregion[] {
    return Array.from({ length: 5 }, (_, i) => ({
      name: `sub_${i + 1}`,
      coordinates: { base: i + 1 },
      activationThreshold: 0.2 + i * 0.15,
    }));
  }

  // Get a state region by identity
  getRegion(identity: string): StateRegion | undefined {
    return this.activeRegions.get(identity);
  }

  // Find which region a coordinate set falls into
  locateRegion(coordinates: InternalCoordinate): StateRegion | undefined {
    if (!coordinates.gateId) return undefined;
    return this.activeRegions.get(`gate_${coordinates.gateId}`);
  }

  // Compute internal position within a region
  computeInternalPosition(
    region: StateRegion,
    coordinates: InternalCoordinate
  ): { zone: string; stability: number; gradientStrength: number } {
    // Find which zone the coordinate falls into
    let bestZone = region.boundaries.stableZones[0];
    let bestDist = Infinity;

    for (const zone of region.boundaries.stableZones) {
      const dist = computeStateDistance(
        { coordinates: zone.coordinates as any },
        { coordinates: coordinates as any }
      );
      if (dist < bestDist) {
        bestDist = dist;
        bestZone = zone;
      }
    }

    // Check threshold zones
    for (const zone of region.boundaries.thresholdZones) {
      const dist = computeStateDistance(
        { coordinates: zone.coordinates as any },
        { coordinates: coordinates as any }
      );
      if (dist < bestDist && dist < zone.radius) {
        bestDist = dist;
        bestZone = zone;
      }
    }

    return {
      zone: bestZone.name,
      stability: bestZone.stability,
      gradientStrength: 1 - bestDist,
    };
  }

  // Determine if a state is in changing regime
  isChanging(state: MacroState): boolean {
    return state.stability === 'changing' || state.stability === 'transitioning';
  }

  // Compute transition readiness
  computeTransitionReadiness(state: MacroState): number {
    if (!state.coordinates) return 0;

    const region = this.locateRegion(state.coordinates);
    if (!region) return 0;

    const position = this.computeInternalPosition(region, state.coordinates);

    // Higher gradient strength near boundaries = higher transition readiness
    if (position.zone.startsWith('threshold_')) {
      return 0.5 + position.gradientStrength * 0.5;
    }

    // Stable zones have low transition readiness
    return 0.1 + position.gradientStrength * 0.2;
  }

  // Compute neighboring tendencies
  getNeighboringTendencies(state: MacroState): Array<{ identity: string; strength: number }> {
    if (!state.coordinates?.gateId) return [];

    const region = this.activeRegions.get(`gate_${state.coordinates.gateId}`);
    if (!region) return [];

    return Array.from(region.boundaries.neighborFacing.entries())
      .map(([identity, strength]) => ({ identity, strength }))
      .sort((a, b) => b.strength - a.strength);
  }

  // Record state in history
  recordState(state: MacroState): void {
    this.stateHistory.push(deepClone(state));
    if (this.stateHistory.length > this.maxHistorySize) {
      this.stateHistory.shift();
    }
  }

  // Get state history
  getStateHistory(limit: number = 100): MacroState[] {
    return this.stateHistory.slice(-limit);
  }

  // Compute state trajectory
  computeTrajectory(steps: number = 10): MacroState[] {
    if (this.stateHistory.length < 2) return [];

    const recent = this.stateHistory.slice(-steps);
    // Simple linear extrapolation
    return recent;
  }

  // Find metastable states in history
  findMetastableStates(): MacroState[] {
    return this.stateHistory.filter(s => s.stability === 'metastable');
  }

  // Interpolate between two states
  interpolate(start: MacroState, end: MacroState, t: number): MacroState {
    return {
      ...start,
      coordinates: interpolateState(
        start.coordinates as any || {},
        end.coordinates as any || {},
        t
      ) as any,
    };
  }

  // Get projection bias for a state
  getProjectionBias(state: MacroState): Record<string, number> {
    if (!state.coordinates?.gateId) return {};

    const region = this.activeRegions.get(`gate_${state.coordinates.gateId}`);
    if (!region) return {};

    // Find nearest expressive pocket
    let bestPocket = region.expressivePockets[0];
    let bestDist = Infinity;

    for (const pocket of region.expressivePockets) {
      const dist = computeStateDistance(
        { coordinates: pocket.coordinates as any },
        { coordinates: state.coordinates as any }
      );
      if (dist < bestDist) {
        bestDist = dist;
        bestPocket = pocket;
      }
    }

    return bestPocket.projectionBias;
  }

  // Dump state space statistics
  getStats(): object {
    return {
      totalRegions: this.activeRegions.size,
      totalHistory: this.stateHistory.length,
      stableStates: this.stateHistory.filter(s => s.stability === 'stable').length,
      changingStates: this.stateHistory.filter(s => s.stability === 'changing').length,
      metastableStates: this.stateHistory.filter(s => s.stability === 'metastable').length,
    };
  }
}

// Singleton
export const stateSpace = new StateSpaceEngine();
