/**
 * MESSY Organism - Bus Package
 * 
 * Concrete event transport layer.
 * Local message delivery and adapters for runtime communication.
 */

import { MeshMessage, MessageQualification } from '@messy/schemas';
import { EventEmitter, Logger, LogLevel, generateId, now } from '@messy/utils';
import { mesh, MeshEvents } from '@messy/mesh';

// ============================================================
// BUS EVENTS
// ============================================================

export interface BusEvents {
  'bus:message': { message: BusMessage };
  'bus:request': { request: BusRequest; respond: (response: BusResponse) => void };
  'bus:response': { response: BusResponse };
  'bus:error': { error: Error; context: string };
  'bus:organ:register': { organ: string; capabilities: string[] };
  'bus:organ:unregister': { organ: string };
  'bus:heartbeat': { timestamp: number; organs: string[] };
}

export interface BusMessage {
  id: string;
  type: 'event' | 'request' | 'response' | 'command';
  topic: string;
  payload: unknown;
  source: string;
  target?: string;
  timestamp: number;
  correlationId?: string;
  meshQualification?: MessageQualification;
}

export interface BusRequest {
  id: string;
  method: string;
  params: Record<string, unknown>;
  source: string;
  timestamp: number;
}

export interface BusResponse {
  id: string;
  result?: unknown;
  error?: string;
  timestamp: number;
}

// ============================================================
// BUS ENGINE
// ============================================================

export class BusEngine {
  private logger = new Logger('Bus', LogLevel.INFO);
  private events = new EventEmitter<BusEvents>();
  private registeredOrgans: Map<string, { capabilities: string[]; lastSeen: number }> = new Map();
  private messageLog: BusMessage[] = [];
  private maxLogSize = 10000;
  private heartbeatInterval: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.connectToMesh();
    this.startHeartbeat();
  }

  private connectToMesh(): void {
    // Bridge mesh events to bus events
    mesh.on('messageEmitted', ({ message }) => {
      this.emit('bus:message', {
        message: this.meshToBusMessage(message),
      });
    });

    mesh.on('convergenceReached', ({ messages, level }) => {
      this.emit('bus:message', {
        message: {
          id: generateId(),
          type: 'event',
          topic: 'mesh:convergence',
          payload: { messages, level },
          source: 'mesh',
          timestamp: now(),
        },
      });
    });

    mesh.on('centerActivated', ({ centerId, level }) => {
      this.emit('bus:message', {
        message: {
          id: generateId(),
          type: 'event',
          topic: 'mesh:center:activated',
          payload: { centerId, level },
          source: 'mesh',
          timestamp: now(),
        },
      });
    });
  }

  private meshToBusMessage(meshMsg: MeshMessage): BusMessage {
    return {
      id: meshMsg.id,
      type: 'event',
      topic: `mesh:${meshMsg.convergenceState}`,
      payload: meshMsg.payload,
      source: meshMsg.qualification.sourceOrgan || 'mesh',
      timestamp: meshMsg.timestamp,
      meshQualification: meshMsg.qualification,
    };
  }

  // Start heartbeat
  private startHeartbeat(): void {
    this.heartbeatInterval = setInterval(() => {
      this.emit('bus:heartbeat', {
        timestamp: now(),
        organs: Array.from(this.registeredOrgans.keys()),
      });
    }, 5000);
  }

  // Event subscription
  on<K extends keyof BusEvents>(
    event: K,
    handler: (payload: BusEvents[K]) => void
  ): () => void {
    return this.events.on(event, handler);
  }

  // Emit bus event
  private emit<K extends keyof BusEvents>(event: K, payload: BusEvents[K]): void {
    this.events.emit(event, payload);
  }

  // Publish a message
  publish(message: Omit<BusMessage, 'id' | 'timestamp'>): BusMessage {
    const fullMessage: BusMessage = {
      ...message,
      id: generateId(),
      timestamp: now(),
    };

    this.logMessage(fullMessage);
    this.emit('bus:message', { message: fullMessage });

    // If message has mesh qualification, also emit into mesh
    if (fullMessage.meshQualification) {
      mesh.emitMessage(fullMessage.payload, fullMessage.meshQualification);
    }

    return fullMessage;
  }

  // Request-response pattern
  async request(
    target: string,
    method: string,
    params: Record<string, unknown>,
    timeoutMs: number = 5000
  ): Promise<BusResponse> {
    const requestId = generateId();

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error(`Request ${requestId} to ${target} timed out`));
      }, timeoutMs);

      const handler = this.on('bus:response', ({ response }) => {
        if (response.id === requestId) {
          clearTimeout(timeout);
          handler(); // unsubscribe
          if (response.error) {
            reject(new Error(response.error));
          } else {
            resolve(response);
          }
        }
      });

      const request: BusRequest = {
        id: requestId,
        method,
        params,
        source: 'bus',
        timestamp: now(),
      };

      this.emit('bus:request', {
        request,
        respond: (response) => {
          this.emit('bus:response', { response });
        },
      });
    });
  }

  // Register an organ
  registerOrgan(organ: string, capabilities: string[]): void {
    this.registeredOrgans.set(organ, {
      capabilities,
      lastSeen: now(),
    });
    this.emit('bus:organ:register', { organ, capabilities });
    this.logger.info(`Organ registered: ${organ} with ${capabilities.length} capabilities`);
  }

  // Unregister an organ
  unregisterOrgan(organ: string): void {
    this.registeredOrgans.delete(organ);
    this.emit('bus:organ:unregister', { organ });
    this.logger.info(`Organ unregistered: ${organ}`);
  }

  // Get registered organs
  getOrgans(): string[] {
    return Array.from(this.registeredOrgans.keys());
  }

  // Get organ capabilities
  getOrganCapabilities(organ: string): string[] {
    return this.registeredOrgans.get(organ)?.capabilities || [];
  }

  // Log message
  private logMessage(message: BusMessage): void {
    this.messageLog.push(message);
    if (this.messageLog.length > this.maxLogSize) {
      this.messageLog.shift();
    }
  }

  // Get message log
  getMessageLog(filter?: { topic?: string; source?: string; limit?: number }): BusMessage[] {
    let filtered = this.messageLog;

    if (filter?.topic) {
      filtered = filtered.filter(m => m.topic === filter.topic);
    }
    if (filter?.source) {
      filtered = filtered.filter(m => m.source === filter.source);
    }

    const limit = filter?.limit || 100;
    return filtered.slice(-limit);
  }

  // Subscribe to a topic
  subscribe(
    topic: string,
    handler: (message: BusMessage) => void
  ): () => void {
    return this.on('bus:message', ({ message }) => {
      if (message.topic === topic || message.topic.startsWith(topic + ':')) {
        handler(message);
      }
    });
  }

  // Command an organ
  command(organ: string, command: string, payload: unknown): BusMessage {
    return this.publish({
      type: 'command',
      topic: `organ:${organ}:${command}`,
      payload,
      source: 'bus',
      target: organ,
    });
  }

  // Dispose
  dispose(): void {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }
  }

  // Stats
  getStats(): object {
    return {
      registeredOrgans: this.registeredOrgans.size,
      totalMessages: this.messageLog.length,
      topics: [...new Set(this.messageLog.map(m => m.topic))],
    };
  }
}

// Singleton
export const bus = new BusEngine();
