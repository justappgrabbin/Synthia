/**
 * MESSY Organism - Mesh Package
 * 
 * The canonical communication and morphing substrate.
 * The mesh is not merely a transport layer — it is the generative 
 * relational field through which states are qualified, routed, 
 * morphed, converged, and expressed.
 */

import {
  MeshMessage, Channel, Edge, MessageQualification,
  MeshMessageSchema, ChannelSchema, EdgeSchema
} from '@messy/schemas';
import {
  EventEmitter, generateMeshMessageId, generateEdgeId,
  computeResonance, computeConvergence, Logger, LogLevel,
  deepClone, now
} from '@messy/utils';
import { ORGANISM_CONFIG } from '@messy/config';
import { stateSpace } from '@messy/state-space';
import { ontology } from '@messy/ontology';

// ============================================================
// MESH EVENTS
// ============================================================

export interface MeshEvents {
  messageEmitted: { message: MeshMessage };
  messageTraversing: { message: MeshMessage; channel: Channel };
  edgeFormed: { edge: Edge };
  edgeStrengthened: { edge: Edge; delta: number };
  morphOccurred: { message: MeshMessage; organ: string; before: any; after: any };
  convergenceReached: { messages: MeshMessage[]; level: number };
  centerActivated: { centerId: number; level: number };
  projectionTriggered: { domain: string; state: any };
}

// ============================================================
// MESH ENGINE
// ============================================================

export class MeshEngine {
  private logger = new Logger('Mesh', LogLevel.INFO);
  private events = new EventEmitter<MeshEvents>();
  private channels: Map<string, Channel> = new Map();
  private edges: Map<string, Edge> = new Map();
  private activeMessages: Map<string, MeshMessage> = new Map();
  private convergenceBuffer: MeshMessage[] = [];
  private convergenceThreshold = ORGANISM_CONFIG.runtime.convergenceThreshold;
  private maxRecursionDepth = ORGANISM_CONFIG.runtime.maxRecursionDepth;

  constructor() {
    this.initializeChannels();
  }

  private initializeChannels(): void {
    // Initialize all 36 Human Design channels
    const { CHANNEL_DEFINITIONS } = require('@messy/ontology');

    for (const [channelId, def] of Object.entries(CHANNEL_DEFINITIONS)) {
      const channel: Channel = {
        id: channelId,
        sourceGate: def.gates[0],
        targetGate: def.gates[1],
        name: def.description,
        edgeFunction: def.type,
        strength: 0.1,
        isActive: false,
        traversalCount: 0,
      };
      this.channels.set(channelId, channel);
    }

    this.logger.info(`Initialized ${this.channels.size} channels`);
  }

  // Event subscription
  on<K extends keyof MeshEvents>(
    event: K,
    handler: (payload: MeshEvents[K]) => void
  ): () => void {
    return this.events.on(event, handler);
  }

  // Emit a message into the mesh
  emitMessage(
    payload: unknown,
    qualification: MessageQualification
  ): MeshMessage {
    const message: MeshMessage = {
      id: generateMeshMessageId(),
      timestamp: now(),
      payload,
      qualification: deepClone(qualification),
      path: [],
      morphCount: 0,
      convergenceState: 'traversing',
    };

    this.activeMessages.set(message.id, message);
    this.events.emit('messageEmitted', { message: deepClone(message) });

    // Begin traversal
    this.traverseMessage(message);

    return message;
  }

  // Traverse a message through the mesh
  private async traverseMessage(message: MeshMessage): Promise<void> {
    if (message.qualification.recursionDepth > this.maxRecursionDepth) {
      this.logger.warn(`Message ${message.id} exceeded max recursion depth`);
      message.convergenceState = 'expressed';
      return;
    }

    // Find relevant channels based on active gates
    const relevantChannels = this.findRelevantChannels(message);

    for (const channel of relevantChannels) {
      // Traverse through channel
      message.path.push(channel.id);
      this.events.emit('messageTraversing', { message: deepClone(message), channel });

      // Strengthen or create edge
      this.processEdge(message, channel);

      // Apply morphing rules
      this.morphMessage(message, channel);

      // Check for convergence
      this.checkConvergence(message);

      // Recurse if needed
      if (message.morphCount > 0 && message.convergenceState === 'traversing') {
        const nextQualification = {
          ...message.qualification,
          recursionDepth: message.qualification.recursionDepth + 1,
        };
        this.emitMessage(message.payload, nextQualification);
      }
    }

    // If no channels traversed, message is expressed directly
    if (relevantChannels.length === 0) {
      message.convergenceState = 'expressed';
    }

    this.activeMessages.set(message.id, message);
  }

  // Find channels relevant to a message
  private findRelevantChannels(message: MeshMessage): Channel[] {
    const activeGates = message.qualification.activeGates || [];
    const relevant: Channel[] = [];

    for (const channel of this.channels.values()) {
      // Channel is relevant if it connects active gates
      if (
        activeGates.includes(channel.sourceGate) ||
        activeGates.includes(channel.targetGate)
      ) {
        relevant.push(channel);
      }

      // Also relevant if source/target center matches
      const sourceGate = ontology.getGate(channel.sourceGate);
      const targetGate = ontology.getGate(channel.targetGate);

      if (
        message.qualification.sourceCenter &&
        message.qualification.targetCenter
      ) {
        // Check center-to-center routing
        const sourceCenterGates = this.getCenterGates(message.qualification.sourceCenter);
        const targetCenterGates = this.getCenterGates(message.qualification.targetCenter);

        if (
          sourceCenterGates.includes(channel.sourceGate) &&
          targetCenterGates.includes(channel.targetGate)
        ) {
          relevant.push(channel);
        }
      }
    }

    // Sort by strength (strongest first)
    return relevant
      .sort((a, b) => b.strength - a.strength)
      .slice(0, 5); // Limit to top 5
  }

  private getCenterGates(centerId: number): number[] {
    const { CENTER_GATE_MAP } = require('@messy/ontology');
    return CENTER_GATE_MAP[centerId] || [];
  }

  // Process edge formation/strengthening
  private processEdge(message: MeshMessage, channel: Channel): void {
    const sourceNode = `gate_${channel.sourceGate}`;
    const targetNode = `gate_${channel.targetGate}`;
    const edgeId = generateEdgeId(sourceNode, targetNode);

    let edge = this.edges.get(edgeId);

    if (!edge) {
      edge = {
        id: edgeId,
        sourceNode,
        targetNode,
        channelId: channel.id,
        weight: 0.1,
        state: 'ephemeral',
        createdAt: now(),
        traversalHistory: [],
      };
      this.edges.set(edgeId, edge);
      this.events.emit('edgeFormed', { edge: deepClone(edge) });
    } else {
      // Strengthen existing edge
      const delta = 0.05 * (1 - edge.weight);
      edge.weight = Math.min(1, edge.weight + delta);
      edge.state = edge.weight > 0.5 ? 'persistent' : 'strengthening';
      edge.lastActivated = now();
      edge.traversalHistory.push(now());

      this.events.emit('edgeStrengthened', { edge: deepClone(edge), delta });
    }

    // Update channel
    channel.traversalCount++;
    channel.lastTraversal = now();
    channel.strength = Math.min(1, channel.strength + 0.02);
    if (channel.strength > 0.3) {
      channel.isActive = true;
    }
  }

  // Morph a message based on channel traversal
  private morphMessage(message: MeshMessage, channel: Channel): void {
    const before = deepClone(message.qualification);

    // Apply channel-specific morphing
    switch (channel.edgeFunction) {
      case 'inspiration':
        message.qualification.arcModulation = 
          (message.qualification.arcModulation || 0.5) * 1.2;
        break;
      case 'mutation':
        message.qualification.stratumContext = 
          ((message.qualification.stratumContext || 0) + 1) % 3;
        break;
      case 'logic':
        // Logic channels sharpen qualification
        message.qualification.userAlignmentContext = {
          ...message.qualification.userAlignmentContext,
          logicalMode: true,
        };
        break;
      case 'intimacy':
        // Intimacy channels deepen alignment
        message.qualification.userAlignmentContext = {
          ...message.qualification.userAlignmentContext,
          depth: (message.qualification.userAlignmentContext?.depth || 0) + 0.1,
        };
        break;
      case 'struggle':
        // Struggle channels create tension
        message.qualification.userAlignmentContext = {
          ...message.qualification.userAlignmentContext,
          tension: (message.qualification.userAlignmentContext?.tension || 0) + 0.2,
        };
        break;
      default:
        // Default: slight modulation
        message.qualification.arcModulation = 
          (message.qualification.arcModulation || 0.5) * (0.9 + Math.random() * 0.2);
    }

    message.morphCount++;
    message.qualification.activeChannels = [
      ...(message.qualification.activeChannels || []),
      channel.id,
    ];

    this.events.emit('morphOccurred', {
      message: deepClone(message),
      organ: message.qualification.sourceOrgan || 'unknown',
      before,
      after: deepClone(message.qualification),
    });
  }

  // Check for convergence
  private checkConvergence(message: MeshMessage): void {
    this.convergenceBuffer.push(deepClone(message));

    if (this.convergenceBuffer.length >= 3) {
      // Compute resonance among recent messages
      const activations = this.convergenceBuffer.map(m => 
        (m.qualification.activeGates?.length || 0) / 64
      );

      const convergence = computeConvergence(activations, this.convergenceThreshold);

      if (convergence.converged) {
        this.events.emit('convergenceReached', {
          messages: this.convergenceBuffer.slice(),
          level: convergence.level,
        });

        // Trigger center activation
        if (convergence.dominant !== null) {
          const centerId = convergence.dominant + 1;
          this.events.emit('centerActivated', {
            centerId,
            level: convergence.level,
          });
        }

        // Clear buffer after convergence
        this.convergenceBuffer = [];
        message.convergenceState = 'converging';
      }
    }

    // Keep buffer size bounded
    if (this.convergenceBuffer.length > 10) {
      this.convergenceBuffer.shift();
    }
  }

  // Get mesh statistics
  getStats(): object {
    return {
      activeMessages: this.activeMessages.size,
      totalChannels: this.channels.size,
      activeChannels: Array.from(this.channels.values()).filter(c => c.isActive).length,
      totalEdges: this.edges.size,
      persistentEdges: Array.from(this.edges.values()).filter(e => e.state === 'persistent').length,
      convergenceBufferSize: this.convergenceBuffer.length,
    };
  }

  // Get active channels
  getActiveChannels(): Channel[] {
    return Array.from(this.channels.values()).filter(c => c.isActive);
  }

  // Get edges for a node
  getEdgesForNode(nodeId: string): Edge[] {
    return Array.from(this.edges.values()).filter(
      e => e.sourceNode === nodeId || e.targetNode === nodeId
    );
  }

  // Get message by ID
  getMessage(id: string): MeshMessage | undefined {
    return this.activeMessages.get(id);
  }

  // Clean up old messages
  cleanup(maxAgeMs: number = 300000): void {
    const cutoff = now() - maxAgeMs;
    for (const [id, msg] of this.activeMessages) {
      if (msg.timestamp < cutoff) {
        this.activeMessages.delete(id);
      }
    }
  }
}

// Singleton
export const mesh = new MeshEngine();
