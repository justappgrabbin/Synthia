/**
 * MESSY Organism - Activation Package
 * 
 * Activation grammars and recursive activation logic.
 * Multiple input grammars may activate the same underlying ontological state.
 */

import { 
  MacroState, InternalCoordinate, MessageQualification 
} from '@messy/schemas';
import { 
  computeResonance, computeConvergence, Logger, LogLevel, now 
} from '@messy/utils';
import { ORGANISM_CONFIG } from '@messy/config';
import { ontology } from '@messy/ontology';
import { stateSpace } from '@messy/state-space';
import { mesh } from '@messy/mesh';

// ============================================================
// ACTIVATION GRAMMAR INTERFACE
// ============================================================

export interface ActivationGrammar {
  name: string;
  canActivate(input: unknown): boolean;
  activate(input: unknown): ActivationResult;
}

export interface ActivationResult {
  activated: boolean;
  states: MacroState[];
  confidence: number;
  grammar: string;
  qualification: MessageQualification;
}

// ============================================================
# HUMAN DESIGN ACTIVATION GRAMMAR
# ============================================================

export class HumanDesignGrammar implements ActivationGrammar {
  name = 'humanDesign';

  canActivate(input: unknown): boolean {
    if (typeof input !== 'object' || input === null) return false;
    const obj = input as Record<string, any>;
    return 'gates' in obj || 'channels' in obj || 'centers' in obj || 'birthDate' in obj;
  }

  activate(input: unknown): ActivationResult {
    const obj = input as Record<string, any>;
    const states: MacroState[] = [];

    // Activate from defined gates
    if (obj.gates && Array.isArray(obj.gates)) {
      for (const gateId of obj.gates) {
        const gate = ontology.getGate(gateId);
        if (gate) {
          states.push({
            identity: gate.name,
            gateId: gate.id,
            stability: 'stable',
            coordinates: { line: obj.lines?.[gateId] || 1 },
          });
        }
      }
    }

    // Activate from defined channels
    if (obj.channels && Array.isArray(obj.channels)) {
      for (const channelId of obj.channels) {
        const channel = mesh['channels'].get?.(channelId);
        if (channel) {
          states.push({
            identity: `channel_${channelId}`,
            stability: 'stable',
            coordinates: { gateId: channel.sourceGate },
          });
          states.push({
            identity: `channel_${channelId}`,
            stability: 'stable',
            coordinates: { gateId: channel.targetGate },
          });
        }
      }
    }

    return {
      activated: states.length > 0,
      states,
      confidence: Math.min(1, states.length / 10),
      grammar: this.name,
      qualification: {
        activeGates: states.map(s => s.gateId).filter(Boolean) as number[],
        sourceOrgan: 'HumanDesignGrammar',
      },
    };
  }
}

// ============================================================
// LANGUAGE PATTERN ACTIVATION GRAMMAR
// ============================================================

export class LanguagePatternGrammar implements ActivationGrammar {
  name = 'languagePattern';

  private patternMap: Map<RegExp, { gateId: number; confidence: number }> = new Map([
    [/(create|build|make|design)/i, { gateId: 1, confidence: 0.8 }],
    [/(receive|accept|allow|open)/i, { gateId: 2, confidence: 0.7 }],
    [/(difficult|challenge|struggle|begin)/i, { gateId: 3, confidence: 0.6 }],
    [/(answer|solution|resolve|fix)/i, { gateId: 4, confidence: 0.7 }],
    [/(wait|patience|time|period)/i, { gateId: 5, confidence: 0.8 }],
    [/(conflict|argue|dispute|fight)/i, { gateId: 6, confidence: 0.7 }],
    [/(lead|guide|direct|organize)/i, { gateId: 7, confidence: 0.8 }],
    [/(together|unite|join|bond)/i, { gateId: 8, confidence: 0.7 }],
    [/(small|detail|minor|subtle)/i, { gateId: 9, confidence: 0.6 }],
    [/(step|walk|tread|path)/i, { gateId: 10, confidence: 0.7 }],
    [/(peace|harmony|balance|calm)/i, { gateId: 11, confidence: 0.8 }],
    [/(stuck|block|stop|stand)/i, { gateId: 12, confidence: 0.7 }],
    [/(friend|group|community|fellow)/i, { gateId: 13, confidence: 0.8 }],
    [/(possess|have|own|wealth)/i, { gateId: 14, confidence: 0.7 }],
    [/(modest|humble|simple|plain)/i, { gateId: 15, confidence: 0.6 }],
    [/(enthusiasm|excitement|energy|passion)/i, { gateId: 16, confidence: 0.8 }],
    [/(follow|obey|adapt|conform)/i, { gateId: 17, confidence: 0.7 }],
    [/(decay|repair|fix|correct)/i, { gateId: 18, confidence: 0.6 }],
    [/(approach|near|come|advance)/i, { gateId: 19, confidence: 0.7 }],
    [/(contemplate|observe|view|watch)/i, { gateId: 20, confidence: 0.8 }],
    [/(bite|break|cut|penetrate)/i, { gateId: 21, confidence: 0.6 }],
    [/(grace|beauty|elegant|form)/i, { gateId: 22, confidence: 0.7 }],
    [/(split|separate|divide|part)/i, { gateId: 23, confidence: 0.6 }],
    [/(return|come back|restore|renew)/i, { gateId: 24, confidence: 0.7 }],
    [/(innocent|pure|simple|natural)/i, { gateId: 25, confidence: 0.8 }],
    [/(tame|control|discipline|restrain)/i, { gateId: 26, confidence: 0.7 }],
    [/(nourish|feed|sustain|support)/i, { gateId: 27, confidence: 0.8 }],
    [/(exceed|surpass|over|great)/i, { gateId: 28, confidence: 0.6 }],
    [/(persevere|persist|endure|continue)/i, { gateId: 29, confidence: 0.7 }],
    [/(light|bright|clarity|fire)/i, { gateId: 30, confidence: 0.8 }],
    [/(influence|affect|move|touch)/i, { gateId: 31, confidence: 0.7 }],
    [/(duration|last|remain|stay)/i, { gateId: 32, confidence: 0.6 }],
    [/(retreat|withdraw|escape|hide)/i, { gateId: 33, confidence: 0.7 }],
    [/(power|strength|force|might)/i, { gateId: 34, confidence: 0.8 }],
    [/(progress|advance|forward|go)/i, { gateId: 35, confidence: 0.7 }],
    [/(dark|shadow|dim|obscure)/i, { gateId: 36, confidence: 0.6 }],
    [/(family|home|house|kin)/i, { gateId: 37, confidence: 0.8 }],
    [/(opposition|different|other|oppose)/i, { gateId: 38, confidence: 0.7 }],
    [/(obstruct|block|hinder|impede)/i, { gateId: 39, confidence: 0.6 }],
    [/(deliver|free|release|liberate)/i, { gateId: 40, confidence: 0.7 }],
    [/(decrease|less|reduce|diminish)/i, { gateId: 41, confidence: 0.6 }],
    [/(increase|more|grow|expand)/i, { gateId: 42, confidence: 0.7 }],
    [/(breakthrough|break|pierce|burst)/i, { gateId: 43, confidence: 0.8 }],
    [/(meet|encounter|find|discover)/i, { gateId: 44, confidence: 0.7 }],
    [/(gather|collect|assemble|group)/i, { gateId: 45, confidence: 0.8 }],
    [/(push|rise|ascend|climb)/i, { gateId: 46, confidence: 0.7 }],
    [/(exhaust|drain|tired|weary)/i, { gateId: 47, confidence: 0.6 }],
    [/(well|source|spring|fountain)/i, { gateId: 48, confidence: 0.7 }],
    [/(revolution|change|reform|transform)/i, { gateId: 49, confidence: 0.8 }],
    [/(cauldron|vessel|pot|cook)/i, { gateId: 50, confidence: 0.6 }],
    [/(thunder|shock|shake|startle)/i, { gateId: 51, confidence: 0.7 }],
    [/(still|quiet|stop|mountain)/i, { gateId: 52, confidence: 0.8 }],
    [/(gradual|slow|step|progressive)/i, { gateId: 53, confidence: 0.7 }],
    [/(marry|wedding|maiden|young)/i, { gateId: 54, confidence: 0.6 }],
    [/(abundant|rich|full|plenty)/i, { gateId: 55, confidence: 0.7 }],
    [/(wander|travel|roam|nomad)/i, { gateId: 56, confidence: 0.8 }],
    [/(gentle|soft|wind|penetrate)/i, { gateId: 57, confidence: 0.7 }],
    [/(joy|happy|pleasure|delight)/i, { gateId: 58, confidence: 0.8 }],
    [/(disperse|scatter|dissolve|spread)/i, { gateId: 59, confidence: 0.6 }],
    [/(limit|restrict|bound|measure)/i, { gateId: 60, confidence: 0.7 }],
    [/(truth|inner|sincere|honest)/i, { gateId: 61, confidence: 0.8 }],
    [/(small|exceed|little|minor)/i, { gateId: 62, confidence: 0.6 }],
    [/(after|complete|finish|end)/i, { gateId: 63, confidence: 0.7 }],
    [/(before|incomplete|begin|start)/i, { gateId: 64, confidence: 0.8 }],
  ]);

  canActivate(input: unknown): boolean {
    return typeof input === 'string' && input.length > 0;
  }

  activate(input: unknown): ActivationResult {
    const text = String(input);
    const states: MacroState[] = [];
    const activatedGates: number[] = [];
    let totalConfidence = 0;
    let matchCount = 0;

    for (const [pattern, mapping] of this.patternMap) {
      if (pattern.test(text)) {
        const gate = ontology.getGate(mapping.gateId);
        if (gate) {
          states.push({
            identity: gate.name,
            gateId: gate.id,
            stability: 'stable',
            coordinates: {},
          });
          activatedGates.push(gate.id);
          totalConfidence += mapping.confidence;
          matchCount++;
        }
      }
    }

    return {
      activated: states.length > 0,
      states,
      confidence: matchCount > 0 ? totalConfidence / matchCount : 0,
      grammar: this.name,
      qualification: {
        activeGates: activatedGates,
        sourceOrgan: 'LanguagePatternGrammar',
      },
    };
  }
}

// ============================================================
// CODE PATTERN ACTIVATION GRAMMAR
// ============================================================

export class CodePatternGrammar implements ActivationGrammar {
  name = 'codePattern';

  private codePatterns: Map<RegExp, { gateId: number; confidence: number }> = new Map([
    [/(function|def|class|interface)/, { gateId: 1, confidence: 0.8 }],      // Creation
    [/(import|require|include|using)/, { gateId: 2, confidence: 0.7 }],     // Reception
    [/(try|catch|throw|error)/, { gateId: 3, confidence: 0.6 }],            // Difficulty
    [/(if|else|switch|case)/, { gateId: 4, confidence: 0.7 }],               // Answer
    [/(setTimeout|setInterval|await|sleep)/, { gateId: 5, confidence: 0.8 }], // Waiting
    [/(conflict|merge|rebase|diff)/, { gateId: 6, confidence: 0.7 }],        // Conflict
    [/(export|module|namespace|package)/, { gateId: 7, confidence: 0.8 }],   // Leadership
    [/(connect|link|bind|attach)/, { gateId: 8, confidence: 0.7 }],         // Union
    [/(const|let|var|static)/, { gateId: 9, confidence: 0.6 }],             // Small details
    [/(for|while|loop|iterate)/, { gateId: 10, confidence: 0.7 }],           // Treading
    [/(map|filter|reduce|sort)/, { gateId: 11, confidence: 0.8 }],            // Peace/harmony
    [/(break|continue|return|exit)/, { gateId: 12, confidence: 0.7 }],       // Standstill
    [/(comment|doc|README|note)/, { gateId: 13, confidence: 0.8 }],          // Fellowship
    [/(assets|resources|data|store)/, { gateId: 14, confidence: 0.7 }],       // Possession
    [/(clean|refactor|lint|format)/, { gateId: 15, confidence: 0.6 }],        // Modesty
    [/(animate|render|draw|paint)/, { gateId: 16, confidence: 0.8 }],        // Enthusiasm
    [/(extends|implements|inherit|mixin)/, { gateId: 17, confidence: 0.7 }],   // Following
    [/(deprecated|legacy|old|remove)/, { gateId: 18, confidence: 0.6 }],      // Decay
    [/(API|endpoint|route|handler)/, { gateId: 19, confidence: 0.7 }],        // Approach
    [/(console|log|debug|inspect)/, { gateId: 20, confidence: 0.8 }],        // Contemplation
    [/(test|spec|assert|verify)/, { gateId: 21, confidence: 0.6 }],         // Biting through
    [/(style|css|theme|color)/, { gateId: 22, confidence: 0.7 }],             // Grace
    [/(split|slice|chunk|partition)/, { gateId: 23, confidence: 0.6 }],      // Splitting
    [/(restore|reset|undo|revert)/, { gateId: 24, confidence: 0.7 }],        // Return
    [/(pure|immutable|const|frozen)/, { gateId: 25, confidence: 0.8 }],      // Innocence
    [/(control|manage|regulate|govern)/, { gateId: 26, confidence: 0.7 }],    // Taming
    [/(nourish|feed|supply|provide)/, { gateId: 27, confidence: 0.8 }],      // Nourishment
    [/(overflow|exceed|surpass|max)/, { gateId: 28, confidence: 0.6 }],      // Exceeding
    [/(promise|commit|resolve|then)/, { gateId: 29, confidence: 0.7 }],      // Perseverance
    [/(light|bright|highlight|focus)/, { gateId: 30, confidence: 0.8 }],    // Light
    [/(influence|affect|impact|change)/, { gateId: 31, confidence: 0.7 }],   // Influence
    [/(duration|last|persist|endure)/, { gateId: 32, confidence: 0.6 }],     // Duration
    [/(retreat|hide|private|protected)/, { gateId: 33, confidence: 0.7 }],    // Retreat
    [/(power|force|strength|capability)/, { gateId: 34, confidence: 0.8 }],   // Power
    [/(progress|advance|forward|next)/, { gateId: 35, confidence: 0.7 }],   // Progress
    [/(dark|shadow|hidden|obscure)/, { gateId: 36, confidence: 0.6 }],       // Darkening
    [/(family|group|team|cluster)/, { gateId: 37, confidence: 0.8 }],        // Family
    [/(opposite|negate|not|invert)/, { gateId: 38, confidence: 0.7 }],       // Opposition
    [/(block|prevent|stop|deny)/, { gateId: 39, confidence: 0.6 }],           // Obstruction
    [/(free|release|unlock|open)/, { gateId: 40, confidence: 0.7 }],          // Deliverance
    [/(decrease|less|reduce|shrink)/, { gateId: 41, confidence: 0.6 }],      // Decrease
    [/(increase|more|grow|expand)/, { gateId: 42, confidence: 0.7 }],        // Increase
    [/(break|cut|split|separate)/, { gateId: 43, confidence: 0.8 }],         // Breakthrough
    [/(meet|encounter|find|match)/, { gateId: 44, confidence: 0.7 }],        // Meeting
    [/(gather|collect|assemble|group)/, { gateId: 45, confidence: 0.8 }],   // Gathering
    [/(push|rise|ascend|climb)/, { gateId: 46, confidence: 0.7 }],           // Pushing up
    [/(exhaust|drain|tired|weary)/, { gateId: 47, confidence: 0.6 }],         // Exhaustion
    [/(source|origin|root|base)/, { gateId: 48, confidence: 0.7 }],          // Well
    [/(revolution|change|reform|transform)/, { gateId: 49, confidence: 0.8 }], // Revolution
    [/(vessel|container|hold|store)/, { gateId: 50, confidence: 0.6 }],      // Cauldron
    [/(shock|shake|startle|surprise)/, { gateId: 51, confidence: 0.7 }],      // Thunder
    [/(still|quiet|stop|halt)/, { gateId: 52, confidence: 0.8 }],             // Stillness
    [/(gradual|slow|step|progressive)/, { gateId: 53, confidence: 0.7 }],      // Gradual
    [/(marry|join|unite|combine)/, { gateId: 54, confidence: 0.6 }],           // Marrying
    [/(abundant|rich|full|plenty)/, { gateId: 55, confidence: 0.7 }],        // Abundance
    [/(wander|travel|roam|move)/, { gateId: 56, confidence: 0.8 }],         // Wanderer
    [/(gentle|soft|mild|subtle)/, { gateId: 57, confidence: 0.7 }],          // Gentle
    [/(joy|happy|pleasure|delight)/, { gateId: 58, confidence: 0.8 }],        // Joy
    [/(disperse|scatter|spread|distribute)/, { gateId: 59, confidence: 0.6 }], // Dispersion
    [/(limit|restrict|bound|confine)/, { gateId: 60, confidence: 0.7 }],     // Limitation
    [/(truth|inner|sincere|honest)/, { gateId: 61, confidence: 0.8 }],        // Inner truth
    [/(small|little|tiny|minor)/, { gateId: 62, confidence: 0.6 }],          // Small exceeding
    [/(after|complete|finish|end)/, { gateId: 63, confidence: 0.7 }],        // After completion
    [/(before|incomplete|begin|start)/, { gateId: 64, confidence: 0.8 }],     // Before completion
  ]);

  canActivate(input: unknown): boolean {
    return typeof input === 'string' && (input.includes('function') || input.includes('class') || input.includes('const'));
  }

  activate(input: unknown): ActivationResult {
    const code = String(input);
    const states: MacroState[] = [];
    const activatedGates: number[] = [];
    let totalConfidence = 0;
    let matchCount = 0;

    for (const [pattern, mapping] of this.codePatterns) {
      if (pattern.test(code)) {
        const gate = ontology.getGate(mapping.gateId);
        if (gate) {
          states.push({
            identity: gate.name,
            gateId: gate.id,
            stability: 'stable',
            coordinates: {},
          });
          activatedGates.push(gate.id);
          totalConfidence += mapping.confidence;
          matchCount++;
        }
      }
    }

    return {
      activated: states.length > 0,
      states,
      confidence: matchCount > 0 ? totalConfidence / matchCount : 0,
      grammar: this.name,
      qualification: {
        activeGates: activatedGates,
        sourceOrgan: 'CodePatternGrammar',
      },
    };
  }
}

// ============================================================
// ACTIVATION ENGINE
// ============================================================

export class ActivationEngine {
  private logger = new Logger('Activation', LogLevel.INFO);
  private grammars: ActivationGrammar[] = [];
  private activationHistory: ActivationResult[] = [];

  constructor() {
    this.registerDefaultGrammars();
  }

  private registerDefaultGrammars(): void {
    this.grammars.push(new HumanDesignGrammar());
    this.grammars.push(new LanguagePatternGrammar());
    this.grammars.push(new CodePatternGrammar());
    this.logger.info(`Registered ${this.grammars.length} activation grammars`);
  }

  // Register a custom grammar
  registerGrammar(grammar: ActivationGrammar): void {
    this.grammars.push(grammar);
    this.logger.info(`Registered grammar: ${grammar.name}`);
  }

  // Activate from any input
  activate(input: unknown): ActivationResult[] {
    const results: ActivationResult[] = [];

    for (const grammar of this.grammars) {
      try {
        if (grammar.canActivate(input)) {
          const result = grammar.activate(input);
          if (result.activated) {
            results.push(result);
            this.activationHistory.push(result);
          }
        }
      } catch (err) {
        this.logger.error(`Grammar ${grammar.name} failed:`, err);
      }
    }

    // Sort by confidence
    results.sort((a, b) => b.confidence - a.confidence);

    // Emit into mesh for each activated state
    for (const result of results) {
      for (const state of result.states) {
        mesh.emitMessage(state, result.qualification);
      }
    }

    return results;
  }

  // Activate with specific grammar
  activateWithGrammar(input: unknown, grammarName: string): ActivationResult | null {
    const grammar = this.grammars.find(g => g.name === grammarName);
    if (!grammar || !grammar.canActivate(input)) {
      return null;
    }

    return grammar.activate(input);
  }

  // Get activation history
  getHistory(limit: number = 100): ActivationResult[] {
    return this.activationHistory.slice(-limit);
  }

  // Get most active gates from history
  getMostActiveGates(limit: number = 10): Array<{ gateId: number; count: number }> {
    const counts = new Map<number, number>();

    for (const result of this.activationHistory) {
      for (const state of result.states) {
        if (state.gateId) {
          counts.set(state.gateId, (counts.get(state.gateId) || 0) + 1);
        }
      }
    }

    return Array.from(counts.entries())
      .map(([gateId, count]) => ({ gateId, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, limit);
  }

  // Get stats
  getStats(): object {
    return {
      registeredGrammars: this.grammars.map(g => g.name),
      totalActivations: this.activationHistory.length,
      mostActiveGates: this.getMostActiveGates(5),
    };
  }
}

// Singleton
export const activation = new ActivationEngine();
