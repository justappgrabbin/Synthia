/**
 * MESSY Organism - UI Package
 * 
 * Shared components, visual primitives, and organism state rendering.
 * Shell-independent UI pieces.
 */

// This is a React-based UI package
// In a real implementation, this would contain React components
// For now, we define the component interfaces

export interface OrganismViewProps {
  status: {
    state: string;
    mode: string;
    activeGates: number[];
    activeChannels: string[];
    convergenceLevel: number;
    semanticCoherence: number;
  };
  onGateClick?: (gateId: number) => void;
  onChannelClick?: (channelId: string) => void;
  onCenterClick?: (centerId: number) => void;
}

export interface GateViewProps {
  gateId: number;
  name: string;
  activation: number;
  isActive: boolean;
  onClick?: () => void;
}

export interface ChannelViewProps {
  channelId: string;
  sourceGate: number;
  targetGate: number;
  type: string;
  strength: number;
  isActive: boolean;
  onClick?: () => void;
}

export interface CenterViewProps {
  centerId: number;
  name: string;
  mode: string;
  activationLevel: number;
  isIdentity: boolean;
  activeGates: number[];
  onClick?: () => void;
}

export interface MeshViewProps {
  messages: Array<{
    id: string;
    source: string;
    target?: string;
    convergenceState: string;
    morphCount: number;
  }>;
  onMessageClick?: (messageId: string) => void;
}

export interface ProjectionViewProps {
  projections: Array<{
    id: string;
    domain: string;
    quality: number;
    rendered: unknown;
  }>;
  onProjectionClick?: (projectionId: string) => void;
}

export interface GrowthViewProps {
  events: Array<{
    id: string;
    type: string;
    source: string;
    impact: number;
    timestamp: number;
  }>;
  mutations: Array<{
    id: string;
    targetFile: string;
    mutationType: string;
    confidence: number;
    applied: boolean;
  }>;
}

// Theme definitions
export const ORGANISM_THEME = {
  colors: {
    background: '#0a0a0f',
    surface: '#12121a',
    surfaceElevated: '#1a1a25',
    primary: '#6366f1',
    secondary: '#8b5cf6',
    accent: '#06b6d4',
    success: '#22c55e',
    warning: '#f59e0b',
    error: '#ef4444',
    text: '#e2e8f0',
    textMuted: '#94a3b8',
    border: '#27272a',
  },
  fonts: {
    mono: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
    sans: 'ui-sans-serif, system-ui, -apple-system, sans-serif',
  },
  spacing: {
    xs: '0.25rem',
    sm: '0.5rem',
    md: '1rem',
    lg: '1.5rem',
    xl: '2rem',
  },
  borderRadius: {
    sm: '0.25rem',
    md: '0.5rem',
    lg: '0.75rem',
    xl: '1rem',
  },
} as const;

// Animation presets
export const ANIMATIONS = {
  pulse: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
  fadeIn: 'fadeIn 0.3s ease-out',
  slideUp: 'slideUp 0.3s ease-out',
  morph: 'morph 0.5s ease-in-out',
} as const;
