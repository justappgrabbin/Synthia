/**
 * MESSY Organism - Identity Center Package
 * 
 * The user-alignment hub. Where LLMs sit, MCP connections are bridged,
 * tool routing is aligned, and user-specific style and meaning are preserved.
 */

import { IdentityCenter, MessageQualification } from '@messy/schemas';
import { EventEmitter, Logger, LogLevel, deepClone, now } from '@messy/utils';
import { ORGANISM_CONFIG } from '@messy/config';
import { mesh } from '@messy/mesh';
import { bus } from '@messy/bus';

// ============================================================
// IDENTITY EVENTS
// ============================================================

export interface IdentityEvents {
  'identity:aligned': { userId: string; profile: Record<string, any> };
  'identity:bridge:connected': { type: 'llm' | 'mcp'; name: string };
  'identity:bridge:disconnected': { type: 'llm' | 'mcp'; name: string };
  'identity:preference:updated': { key: string; value: unknown };
  'identity:semantic:coherence': { score: number };
}

// ============================================================
// IDENTITY CENTER ENGINE
// ============================================================

export class IdentityCenterEngine {
  private logger = new Logger('IdentityCenter', LogLevel.INFO);
  private events = new EventEmitter<IdentityEvents>();
  private identity: IdentityCenter;
  private semanticHistory: Array<{ timestamp: number; context: Record<string, any> }> = [];
  private maxHistory = 1000;

  constructor(userId: string = 'default') {
    this.identity = {
      userId,
      alignmentProfile: {},
      llmBridges: [],
      mcpBridges: [],
      routingProfile: {
        preferredDimensions: [],
        preferredCenters: [],
        stylePreferences: {},
      },
      semanticCoherence: 0.5,
    };

    this.connectToMesh();
    this.registerWithBus();
  }

  private connectToMesh(): void {
    mesh.on('convergenceReached', ({ messages, level }) => {
      // Update semantic coherence based on convergence quality
      this.identity.semanticCoherence = 
        this.identity.semanticCoherence * 0.9 + level * 0.1;

      this.events.emit('identity:semantic:coherence', {
        score: this.identity.semanticCoherence,
      });
    });
  }

  private registerWithBus(): void {
    bus.registerOrgan('IdentityCenter', [
      'alignUser',
      'connectLLM',
      'connectMCP',
      'updatePreference',
      'getRoutingProfile',
      'computeSemanticCoherence',
    ]);
  }

  // Event subscription
  on<K extends keyof IdentityEvents>(
    event: K,
    handler: (payload: IdentityEvents[K]) => void
  ): () => void {
    return this.events.on(event, handler);
  }

  // Get current identity
  getIdentity(): IdentityCenter {
    return deepClone(this.identity);
  }

  // Update alignment profile
  updateAlignmentProfile(profile: Record<string, any>): void {
    this.identity.alignmentProfile = {
      ...this.identity.alignmentProfile,
      ...profile,
    };

    this.events.emit('identity:aligned', {
      userId: this.identity.userId,
      profile: this.identity.alignmentProfile,
    });
  }

  // Connect LLM bridge
  connectLLM(provider: string, model: string, config?: Record<string, any>): void {
    const bridge = { provider, model, config };
    this.identity.llmBridges.push(bridge);

    this.events.emit('identity:bridge:connected', {
      type: 'llm',
      name: `${provider}/${model}`,
    });

    this.logger.info(`LLM bridge connected: ${provider}/${model}`);
  }

  // Connect MCP bridge
  connectMCP(server: string, tools: string[], config?: Record<string, any>): void {
    const bridge = { server, tools, config };
    this.identity.mcpBridges.push(bridge);

    this.events.emit('identity:bridge:connected', {
      type: 'mcp',
      name: server,
    });

    this.logger.info(`MCP bridge connected: ${server} with ${tools.length} tools`);
  }

  // Disconnect bridge
  disconnectBridge(type: 'llm' | 'mcp', name: string): void {
    if (type === 'llm') {
      this.identity.llmBridges = this.identity.llmBridges.filter(
        b => `${b.provider}/${b.model}` !== name
      );
    } else {
      this.identity.mcpBridges = this.identity.mcpBridges.filter(
        b => b.server !== name
      );
    }

    this.events.emit('identity:bridge:disconnected', { type, name });
    this.logger.info(`${type.toUpperCase()} bridge disconnected: ${name}`);
  }

  // Update routing preference
  updateRoutingPreference(key: string, value: unknown): void {
    this.identity.routingProfile.stylePreferences[key] = value;

    this.events.emit('identity:preference:updated', { key, value });
  }

  // Set preferred dimensions
  setPreferredDimensions(dimensions: string[]): void {
    this.identity.routingProfile.preferredDimensions = dimensions;
  }

  // Set preferred centers
  setPreferredCenters(centers: number[]): void {
    this.identity.routingProfile.preferredCenters = centers;
  }

  // Compute semantic coherence score
  computeSemanticCoherence(context: Record<string, any>): number {
    this.semanticHistory.push({ timestamp: now(), context });
    if (this.semanticHistory.length > this.maxHistory) {
      this.semanticHistory.shift();
    }

    // Simple coherence: consistency of recent contexts
    if (this.semanticHistory.length < 2) {
      return this.identity.semanticCoherence;
    }

    const recent = this.semanticHistory.slice(-10);
    const keys = Object.keys(recent[0].context);
    let consistency = 0;

    for (let i = 1; i < recent.length; i++) {
      const prev = recent[i - 1].context;
      const curr = recent[i].context;
      let match = 0;
      let total = 0;

      for (const key of keys) {
        if (key in prev && key in curr) {
          total++;
          if (prev[key] === curr[key]) {
            match++;
          }
        }
      }

      if (total > 0) {
        consistency += match / total;
      }
    }

    const score = consistency / (recent.length - 1);
    this.identity.semanticCoherence = score;

    return score;
  }

  // Qualify a message with identity context
  qualifyMessage(qualification: MessageQualification): MessageQualification {
    return {
      ...qualification,
      userAlignmentContext: {
        ...qualification.userAlignmentContext,
        userId: this.identity.userId,
        preferredDimensions: this.identity.routingProfile.preferredDimensions,
        preferredCenters: this.identity.routingProfile.preferredCenters,
        stylePreferences: this.identity.routingProfile.stylePreferences,
        semanticCoherence: this.identity.semanticCoherence,
      },
    };
  }

  // Get routing decision for a request
  getRoutingDecision(request: { method: string; params: unknown }): {
    target: 'llm' | 'mcp' | 'local';
    bridge?: string;
    priority: number;
  } {
    // Simple routing logic
    if (request.method.startsWith('mcp:')) {
      return {
        target: 'mcp',
        bridge: this.identity.mcpBridges[0]?.server,
        priority: 1,
      };
    }

    if (request.method.startsWith('llm:')) {
      return {
        target: 'llm',
        bridge: `${this.identity.llmBridges[0]?.provider}/${this.identity.llmBridges[0]?.model}`,
        priority: 1,
      };
    }

    return { target: 'local', priority: 0.5 };
  }

  // Stats
  getStats(): object {
    return {
      userId: this.identity.userId,
      llmBridges: this.identity.llmBridges.length,
      mcpBridges: this.identity.mcpBridges.length,
      semanticCoherence: this.identity.semanticCoherence,
      preferredDimensions: this.identity.routingProfile.preferredDimensions,
      preferredCenters: this.identity.routingProfile.preferredCenters,
    };
  }
}

// Singleton (per-user instances would be managed by runtime)
export let identityCenter: IdentityCenterEngine;

export function initializeIdentityCenter(userId?: string): IdentityCenterEngine {
  identityCenter = new IdentityCenterEngine(userId);
  return identityCenter;
}
