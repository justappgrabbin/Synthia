/**
 * MESSY Organism - Persistence Package
 * 
 * Local-first storage for activation history, traversal history,
 * user alignment state, and state snapshots.
 */

import { MacroState, MeshMessage, Edge, Projection, GrowthEvent } from '@messy/schemas';
import { Logger, LogLevel, now, deepClone } from '@messy/utils';
import { ORGANISM_CONFIG } from '@messy/config';

// ============================================================
// PERSISTENCE INTERFACE
// ============================================================

export interface PersistenceAdapter {
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  saveState(state: MacroState): Promise<void>;
  loadStates(limit?: number): Promise<MacroState[]>;
  saveMessage(message: MeshMessage): Promise<void>;
  loadMessages(limit?: number): Promise<MeshMessage[]>;
  saveEdge(edge: Edge): Promise<void>;
  loadEdges(): Promise<Edge[]>;
  saveProjection(projection: Projection): Promise<void>;
  loadProjections(limit?: number): Promise<Projection[]>;
  saveGrowthEvent(event: GrowthEvent): Promise<void>;
  loadGrowthEvents(limit?: number): Promise<GrowthEvent[]>;
  snapshot(): Promise<Record<string, any>>;
  restore(snapshot: Record<string, any>): Promise<void>;
}

// ============================================================
// IN-MEMORY ADAPTER (Default)
# ============================================================

export class InMemoryAdapter implements PersistenceAdapter {
  private states: MacroState[] = [];
  private messages: MeshMessage[] = [];
  private edges: Edge[] = [];
  private projections: Projection[] = [];
  private growthEvents: GrowthEvent[] = [];
  private maxSize = 10000;

  async connect(): Promise<void> {
    // In-memory is always connected
  }

  async disconnect(): Promise<void> {
    this.states = [];
    this.messages = [];
    this.edges = [];
    this.projections = [];
    this.growthEvents = [];
  }

  async saveState(state: MacroState): Promise<void> {
    this.states.push(deepClone(state));
    if (this.states.length > this.maxSize) {
      this.states.shift();
    }
  }

  async loadStates(limit: number = 100): Promise<MacroState[]> {
    return this.states.slice(-limit);
  }

  async saveMessage(message: MeshMessage): Promise<void> {
    this.messages.push(deepClone(message));
    if (this.messages.length > this.maxSize) {
      this.messages.shift();
    }
  }

  async loadMessages(limit: number = 100): Promise<MeshMessage[]> {
    return this.messages.slice(-limit);
  }

  async saveEdge(edge: Edge): Promise<void> {
    const existing = this.edges.findIndex(e => e.id === edge.id);
    if (existing >= 0) {
      this.edges[existing] = deepClone(edge);
    } else {
      this.edges.push(deepClone(edge));
    }
  }

  async loadEdges(): Promise<Edge[]> {
    return [...this.edges];
  }

  async saveProjection(projection: Projection): Promise<void> {
    this.projections.push(deepClone(projection));
    if (this.projections.length > this.maxSize) {
      this.projections.shift();
    }
  }

  async loadProjections(limit: number = 100): Promise<Projection[]> {
    return this.projections.slice(-limit);
  }

  async saveGrowthEvent(event: GrowthEvent): Promise<void> {
    this.growthEvents.push(deepClone(event));
    if (this.growthEvents.length > this.maxSize) {
      this.growthEvents.shift();
    }
  }

  async loadGrowthEvents(limit: number = 100): Promise<GrowthEvent[]> {
    return this.growthEvents.slice(-limit);
  }

  async snapshot(): Promise<Record<string, any>> {
    return {
      states: this.states.length,
      messages: this.messages.length,
      edges: this.edges.length,
      projections: this.projections.length,
      growthEvents: this.growthEvents.length,
      timestamp: now(),
    };
  }

  async restore(snapshot: Record<string, any>): Promise<void> {
    // In-memory restore is a no-op for now
    console.log('Restoring from snapshot:', snapshot);
  }
}

// ============================================================
// SQLITE ADAPTER (Production)
# ============================================================

export class SQLiteAdapter implements PersistenceAdapter {
  private logger = new Logger('SQLiteAdapter', LogLevel.INFO);
  private dbPath: string;
  private db: any; // Would be better-sqlite3 Database

  constructor(dbPath: string = ORGANISM_CONFIG.persistence.path) {
    this.dbPath = dbPath;
  }

  async connect(): Promise<void> {
    // Lazy import to avoid dependency issues
    const Database = require('better-sqlite3');
    this.db = new Database(this.dbPath);
    this.initializeSchema();
    this.logger.info(`Connected to SQLite: ${this.dbPath}`);
  }

  private initializeSchema(): void {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS states (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        identity TEXT,
        gate_id INTEGER,
        center_id INTEGER,
        dimension TEXT,
        stability TEXT,
        coordinates TEXT,
        timestamp INTEGER
      );

      CREATE TABLE IF NOT EXISTS messages (
        id TEXT PRIMARY KEY,
        payload TEXT,
        qualification TEXT,
        path TEXT,
        morph_count INTEGER,
        convergence_state TEXT,
        timestamp INTEGER
      );

      CREATE TABLE IF NOT EXISTS edges (
        id TEXT PRIMARY KEY,
        source_node TEXT,
        target_node TEXT,
        channel_id TEXT,
        weight REAL,
        state TEXT,
        created_at INTEGER,
        last_activated INTEGER
      );

      CREATE TABLE IF NOT EXISTS projections (
        id TEXT PRIMARY KEY,
        domain TEXT,
        source_state TEXT,
        target_format TEXT,
        qualification TEXT,
        rendered TEXT,
        quality REAL,
        timestamp INTEGER
      );

      CREATE TABLE IF NOT EXISTS growth_events (
        id TEXT PRIMARY KEY,
        event_type TEXT,
        source TEXT,
        payload TEXT,
        impact REAL,
        timestamp INTEGER,
        processed INTEGER DEFAULT 0
      );
    `);
  }

  async disconnect(): Promise<void> {
    if (this.db) {
      this.db.close();
    }
  }

  async saveState(state: MacroState): Promise<void> {
    const stmt = this.db.prepare(`
      INSERT INTO states (identity, gate_id, center_id, dimension, stability, coordinates, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(
      state.identity,
      state.gateId || null,
      state.centerId || null,
      state.dimension || null,
      state.stability,
      JSON.stringify(state.coordinates),
      now()
    );
  }

  async loadStates(limit: number = 100): Promise<MacroState[]> {
    const stmt = this.db.prepare('SELECT * FROM states ORDER BY timestamp DESC LIMIT ?');
    const rows = stmt.all(limit);
    return rows.map((r: any) => ({
      identity: r.identity,
      gateId: r.gate_id,
      centerId: r.center_id,
      dimension: r.dimension,
      stability: r.stability,
      coordinates: r.coordinates ? JSON.parse(r.coordinates) : undefined,
    }));
  }

  async saveMessage(message: MeshMessage): Promise<void> {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO messages (id, payload, qualification, path, morph_count, convergence_state, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(
      message.id,
      JSON.stringify(message.payload),
      JSON.stringify(message.qualification),
      JSON.stringify(message.path),
      message.morphCount,
      message.convergenceState,
      message.timestamp
    );
  }

  async loadMessages(limit: number = 100): Promise<MeshMessage[]> {
    const stmt = this.db.prepare('SELECT * FROM messages ORDER BY timestamp DESC LIMIT ?');
    const rows = stmt.all(limit);
    return rows.map((r: any) => ({
      id: r.id,
      timestamp: r.timestamp,
      payload: JSON.parse(r.payload),
      qualification: JSON.parse(r.qualification),
      path: JSON.parse(r.path),
      morphCount: r.morph_count,
      convergenceState: r.convergence_state,
    }));
  }

  async saveEdge(edge: Edge): Promise<void> {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO edges (id, source_node, target_node, channel_id, weight, state, created_at, last_activated)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(
      edge.id,
      edge.sourceNode,
      edge.targetNode,
      edge.channelId,
      edge.weight,
      edge.state,
      edge.createdAt,
      edge.lastActivated || null
    );
  }

  async loadEdges(): Promise<Edge[]> {
    const stmt = this.db.prepare('SELECT * FROM edges');
    const rows = stmt.all();
    return rows.map((r: any) => ({
      id: r.id,
      sourceNode: r.source_node,
      targetNode: r.target_node,
      channelId: r.channel_id,
      weight: r.weight,
      state: r.state,
      createdAt: r.created_at,
      lastActivated: r.last_activated,
      traversalHistory: [],
    }));
  }

  async saveProjection(projection: Projection): Promise<void> {
    const stmt = this.db.prepare(`
      INSERT INTO projections (id, domain, source_state, target_format, qualification, rendered, quality, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(
      projection.id,
      projection.domain,
      JSON.stringify(projection.sourceState),
      projection.targetFormat,
      JSON.stringify(projection.qualification),
      JSON.stringify(projection.rendered),
      projection.quality,
      projection.timestamp
    );
  }

  async loadProjections(limit: number = 100): Promise<Projection[]> {
    const stmt = this.db.prepare('SELECT * FROM projections ORDER BY timestamp DESC LIMIT ?');
    const rows = stmt.all(limit);
    return rows.map((r: any) => ({
      id: r.id,
      domain: r.domain,
      sourceState: JSON.parse(r.source_state),
      targetFormat: r.target_format,
      qualification: JSON.parse(r.qualification),
      rendered: JSON.parse(r.rendered),
      quality: r.quality,
      timestamp: r.timestamp,
    }));
  }

  async saveGrowthEvent(event: GrowthEvent): Promise<void> {
    const stmt = this.db.prepare(`
      INSERT INTO growth_events (id, event_type, source, payload, impact, timestamp, processed)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(
      event.id,
      event.eventType,
      event.source,
      JSON.stringify(event.payload),
      event.impact,
      event.timestamp,
      event.processed ? 1 : 0
    );
  }

  async loadGrowthEvents(limit: number = 100): Promise<GrowthEvent[]> {
    const stmt = this.db.prepare('SELECT * FROM growth_events ORDER BY timestamp DESC LIMIT ?');
    const rows = stmt.all(limit);
    return rows.map((r: any) => ({
      id: r.id,
      eventType: r.event_type,
      source: r.source,
      payload: JSON.parse(r.payload),
      impact: r.impact,
      timestamp: r.timestamp,
      processed: r.processed === 1,
    }));
  }

  async snapshot(): Promise<Record<string, any>> {
    const counts = this.db.prepare(`
      SELECT 
        (SELECT COUNT(*) FROM states) as states,
        (SELECT COUNT(*) FROM messages) as messages,
        (SELECT COUNT(*) FROM edges) as edges,
        (SELECT COUNT(*) FROM projections) as projections,
        (SELECT COUNT(*) FROM growth_events) as growth_events
    `).get();

    return {
      ...counts,
      timestamp: now(),
    };
  }

  async restore(snapshot: Record<string, any>): Promise<void> {
    this.logger.info('Restoring from snapshot:', snapshot);
    // Full restore would require more complex logic
  }
}

// ============================================================
// PERSISTENCE ENGINE
// ============================================================

export class PersistenceEngine {
  private logger = new Logger('Persistence', LogLevel.INFO);
  private adapter: PersistenceAdapter;
  private snapshotInterval: ReturnType<typeof setInterval> | null = null;

  constructor(adapter?: PersistenceAdapter) {
    this.adapter = adapter || new InMemoryAdapter();
  }

  async initialize(): Promise<void> {
    await this.adapter.connect();
    this.startSnapshotting();
    this.logger.info('Persistence initialized');
  }

  private startSnapshotting(): void {
    const interval = ORGANISM_CONFIG.persistence.snapshotIntervalMs;
    this.snapshotInterval = setInterval(async () => {
      const snapshot = await this.adapter.snapshot();
      this.logger.debug('Snapshot:', snapshot);
    }, interval);
  }

  async saveState(state: MacroState): Promise<void> {
    await this.adapter.saveState(state);
  }

  async loadStates(limit?: number): Promise<MacroState[]> {
    return this.adapter.loadStates(limit);
  }

  async saveMessage(message: MeshMessage): Promise<void> {
    await this.adapter.saveMessage(message);
  }

  async loadMessages(limit?: number): Promise<MeshMessage[]> {
    return this.adapter.loadMessages(limit);
  }

  async saveEdge(edge: Edge): Promise<void> {
    await this.adapter.saveEdge(edge);
  }

  async loadEdges(): Promise<Edge[]> {
    return this.adapter.loadEdges();
  }

  async saveProjection(projection: Projection): Promise<void> {
    await this.adapter.saveProjection(projection);
  }

  async loadProjections(limit?: number): Promise<Projection[]> {
    return this.adapter.loadProjections(limit);
  }

  async saveGrowthEvent(event: GrowthEvent): Promise<void> {
    await this.adapter.saveGrowthEvent(event);
  }

  async loadGrowthEvents(limit?: number): Promise<GrowthEvent[]> {
    return this.adapter.loadGrowthEvents(limit);
  }

  async snapshot(): Promise<Record<string, any>> {
    return this.adapter.snapshot();
  }

  async dispose(): Promise<void> {
    if (this.snapshotInterval) {
      clearInterval(this.snapshotInterval);
    }
    await this.adapter.disconnect();
  }

  getStats(): object {
    return {
      adapter: this.adapter.constructor.name,
    };
  }
}

// Singleton
export let persistence: PersistenceEngine;

export function initializePersistence(adapter?: PersistenceAdapter): PersistenceEngine {
  persistence = new PersistenceEngine(adapter);
  return persistence;
}
