/**
 * MESSY Organism - Ingestion Package
 * 
 * File ingestion, source parsing, AST extraction.
 * The discerning ingestion system that learns and grows.
 */

import { GrowthEvent } from '@messy/schemas';
import { Logger, LogLevel, generateId, now, deepClone } from '@messy/utils';
import { ORGANISM_CONFIG } from '@messy/config';
import { bus } from '@messy/bus';
import { activation } from '@messy/activation';

// ============================================================
// INGESTION TYPES
// ============================================================

export interface IngestedArtifact {
  id: string;
  sourceType: 'file' | 'url' | 'api' | 'huggingface' | 'git' | 'text';
  sourcePath: string;
  content: string;
  parsed?: any;
  metadata: Record<string, any>;
  quality: number; // 0-1
  threatLevel: number; // 0-1
  timestamp: number;
  validated: boolean;
  ingested: boolean;
}

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  quality: number;
  threatLevel: number;
}

// ============================================================
// INGESTION ENGINE
// ============================================================

export class IngestionEngine {
  private logger = new Logger('Ingestion', LogLevel.INFO);
  private artifacts: Map<string, IngestedArtifact> = new Map();
  private learningMemory: Map<string, any> = new Map();
  private patternWeights: Map<string, number> = new Map();
  private qualityThreshold = 0.3;
  private threatThreshold = 0.7;

  constructor() {
    this.registerWithBus();
  }

  private registerWithBus(): void {
    bus.registerOrgan('Ingestion', [
      'ingestFile',
      'ingestText',
      'ingestURL',
      'validateArtifact',
      'getArtifact',
      'getLearningMemory',
    ]);
  }

  // Ingest a file
  async ingestFile(filePath: string, content: string): Promise<IngestedArtifact> {
    const artifact: IngestedArtifact = {
      id: generateId(),
      sourceType: 'file',
      sourcePath: filePath,
      content,
      metadata: {
        size: content.length,
        lines: content.split('
').length,
        extension: filePath.split('.').pop(),
      },
      quality: 0,
      threatLevel: 0,
      timestamp: now(),
      validated: false,
      ingested: false,
    };

    // Validate
    const validation = this.validateArtifact(artifact);
    artifact.quality = validation.quality;
    artifact.threatLevel = validation.threatLevel;
    artifact.validated = validation.valid;

    if (!validation.valid) {
      this.logger.warn(`Artifact ${artifact.id} failed validation:`, validation.errors);
      this.artifacts.set(artifact.id, artifact);
      return artifact;
    }

    // Check threat
    if (artifact.threatLevel > this.threatThreshold) {
      this.logger.warn(`Artifact ${artifact.id} rejected: threat level ${artifact.threatLevel}`);
      this.artifacts.set(artifact.id, artifact);
      return artifact;
    }

    // Parse based on type
    artifact.parsed = this.parseContent(artifact);

    // Ingest (activate)
    artifact.ingested = true;
    this.artifacts.set(artifact.id, artifact);

    // Learn from ingestion
    this.learnFromArtifact(artifact);

    // Emit growth event
    const event: GrowthEvent = {
      id: generateId(),
      eventType: 'ingestion',
      source: 'IngestionEngine',
      payload: artifact,
      impact: artifact.quality * 0.1,
      timestamp: now(),
      processed: false,
    };

    bus.publish({
      type: 'event',
      topic: 'organism:growth',
      payload: event,
      source: 'Ingestion',
    });

    this.logger.info(`Ingested artifact ${artifact.id} from ${filePath}`);
    return artifact;
  }

  // Ingest text directly
  async ingestText(text: string, metadata?: Record<string, any>): Promise<IngestedArtifact> {
    const artifact: IngestedArtifact = {
      id: generateId(),
      sourceType: 'text',
      sourcePath: 'inline',
      content: text,
      metadata: {
        ...metadata,
        size: text.length,
        lines: text.split('
').length,
      },
      quality: 0.5, // Text is generally acceptable
      threatLevel: 0,
      timestamp: now(),
      validated: true,
      ingested: false,
    };

    artifact.parsed = this.parseContent(artifact);
    artifact.ingested = true;
    this.artifacts.set(artifact.id, artifact);

    // Activate through language grammar
    activation.activate(text);

    this.learnFromArtifact(artifact);

    this.logger.info(`Ingested text artifact ${artifact.id}`);
    return artifact;
  }

  // Validate an artifact
  validateArtifact(artifact: IngestedArtifact): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Size check
    if (artifact.metadata.size > 10_000_000) {
      warnings.push('Large file (>10MB)');
    }

    // Content check
    if (!artifact.content || artifact.content.length === 0) {
      errors.push('Empty content');
    }

    // Threat detection (basic)
    let threatLevel = 0;
    const suspiciousPatterns = [
      /eval\s*\(/,
      /Function\s*\(/,
      /<script/i,
      /javascript:/i,
      /data:text\/html/i,
    ];

    for (const pattern of suspiciousPatterns) {
      if (pattern.test(artifact.content)) {
        threatLevel += 0.2;
        warnings.push(`Suspicious pattern: ${pattern.source}`);
      }
    }

    // Quality scoring
    let quality = 0.5;
    if (artifact.metadata.extension) {
      const knownExtensions = ['ts', 'tsx', 'js', 'jsx', 'json', 'md', 'py', 'rs', 'go'];
      if (knownExtensions.includes(artifact.metadata.extension)) {
        quality += 0.2;
      }
    }
    if (artifact.metadata.lines > 10) {
      quality += 0.1;
    }
    if (artifact.metadata.lines > 100) {
      quality += 0.1;
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
      quality: Math.min(1, quality),
      threatLevel: Math.min(1, threatLevel),
    };
  }

  // Parse content based on type
  private parseContent(artifact: IngestedArtifact): any {
    const ext = artifact.metadata.extension;

    switch (ext) {
      case 'json':
        try {
          return JSON.parse(artifact.content);
        } catch {
          return null;
        }
      case 'ts':
      case 'tsx':
      case 'js':
      case 'jsx':
        // Basic AST extraction (would use TypeScript compiler in full impl)
        return this.extractCodeStructure(artifact.content);
      case 'md':
        return this.extractMarkdownStructure(artifact.content);
      default:
        return {
          raw: artifact.content.slice(0, 1000),
          length: artifact.content.length,
        };
    }
  }

  // Extract code structure
  private extractCodeStructure(content: string): any {
    const functions: string[] = [];
    const classes: string[] = [];
    const imports: string[] = [];
    const exports: string[] = [];

    const functionRegex = /(?:function|const|let|var)\s+(\w+)\s*\(/g;
    const classRegex = /class\s+(\w+)/g;
    const importRegex = /import\s+.*?from\s+['"](.+?)['"]/g;
    const exportRegex = /export\s+(?:default\s+)?(?:class|function|const|let|var)?\s*(\w+)?/g;

    let match;
    while ((match = functionRegex.exec(content)) !== null) {
      functions.push(match[1]);
    }
    while ((match = classRegex.exec(content)) !== null) {
      classes.push(match[1]);
    }
    while ((match = importRegex.exec(content)) !== null) {
      imports.push(match[1]);
    }
    while ((match = exportRegex.exec(content)) !== null) {
      if (match[1]) exports.push(match[1]);
    }

    return {
      functions: [...new Set(functions)],
      classes: [...new Set(classes)],
      imports: [...new Set(imports)],
      exports: [...new Set(exports)],
      lineCount: content.split('
').length,
    };
  }

  // Extract markdown structure
  private extractMarkdownStructure(content: string): any {
    const headers: string[] = [];
    const codeBlocks: number = (content.match(/```/g) || []).length / 2;

    const headerRegex = /^(#{1,6})\s+(.+)$/gm;
    let match;
    while ((match = headerRegex.exec(content)) !== null) {
      headers.push(match[2]);
    }

    return {
      headers,
      codeBlocks,
      lineCount: content.split('
').length,
    };
  }

  // Learn from artifact
  private learnFromArtifact(artifact: IngestedArtifact): void {
    // Update pattern weights
    const ext = artifact.metadata.extension;
    if (ext) {
      const currentWeight = this.patternWeights.get(ext) || 0;
      this.patternWeights.set(ext, currentWeight + artifact.quality);
    }

    // Store in learning memory
    this.learningMemory.set(artifact.id, {
      quality: artifact.quality,
      type: artifact.sourceType,
      extension: ext,
      timestamp: artifact.timestamp,
    });

    // Evolve thresholds based on learning
    if (this.artifacts.size > 100) {
      const avgQuality = Array.from(this.artifacts.values())
        .reduce((sum, a) => sum + a.quality, 0) / this.artifacts.size;
      this.qualityThreshold = Math.max(0.1, avgQuality * 0.8);
    }
  }

  // Get artifact by ID
  getArtifact(id: string): IngestedArtifact | undefined {
    return this.artifacts.get(id);
  }

  // Get all artifacts
  getAllArtifacts(): IngestedArtifact[] {
    return Array.from(this.artifacts.values());
  }

  // Get learning memory
  getLearningMemory(): Record<string, any> {
    return Object.fromEntries(this.learningMemory);
  }

  // Get pattern weights
  getPatternWeights(): Record<string, number> {
    return Object.fromEntries(this.patternWeights);
  }

  // Stats
  getStats(): object {
    const artifacts = Array.from(this.artifacts.values());
    return {
      totalArtifacts: artifacts.length,
      ingested: artifacts.filter(a => a.ingested).length,
      rejected: artifacts.filter(a => !a.ingested && a.validated).length,
      avgQuality: artifacts.reduce((s, a) => s + a.quality, 0) / (artifacts.length || 1),
      avgThreat: artifacts.reduce((s, a) => s + a.threatLevel, 0) / (artifacts.length || 1),
      learningMemorySize: this.learningMemory.size,
      patternWeights: Object.fromEntries(this.patternWeights),
    };
  }
}

// Singleton
export const ingestion = new IngestionEngine();
