/**
 * MESSY Organism - Resonance Core Package
 * 
 * Extracted reusable resonance/domain logic from v9.1 and related prototypes.
 * Core resonance computation, pattern matching, and field analysis.
 */

import { Logger, LogLevel, computeResonance, now } from '@messy/utils';

// ============================================================
# RESONANCE PATTERNS
# ============================================================

export interface ResonancePattern {
  id: string;
  name: string;
  signature: number[];
  domain: string;
  strength: number;
  createdAt: number;
  lastMatched: number;
  matchCount: number;
}

export interface FieldState {
  timestamp: number;
  activations: Map<string, number>;
  dominantPattern: string | null;
  coherence: number;
  turbulence: number;
}

// ============================================================
# RESONANCE CORE ENGINE
# ============================================================

export class ResonanceCoreEngine {
  private logger = new Logger('ResonanceCore', LogLevel.INFO);
  private patterns: Map<string, ResonancePattern> = new Map();
  private fieldHistory: FieldState[] = [];
  private maxHistory = 1000;

  constructor() {
    this.initializeDefaultPatterns();
  }

  private initializeDefaultPatterns(): void {
    // Initialize with some basic resonance patterns
    const defaultPatterns: ResonancePattern[] = [
      {
        id: 'pattern_harmonic',
        name: 'Harmonic Resonance',
        signature: [1, 0.5, 0.25, 0.125, 0.0625, 0.03125],
        domain: 'sound',
        strength: 0.8,
        createdAt: now(),
        lastMatched: 0,
        matchCount: 0,
      },
      {
        id: 'pattern_fractal',
        name: 'Fractal Self-Similarity',
        signature: [1, 0.618, 0.382, 0.236, 0.146, 0.09],
        domain: 'structure',
        strength: 0.9,
        createdAt: now(),
        lastMatched: 0,
        matchCount: 0,
      },
      {
        id: 'pattern_oscillation',
        name: 'Oscillatory Pattern',
        signature: [1, -0.8, 0.6, -0.4, 0.2, -0.1],
        domain: 'behavior',
        strength: 0.7,
        createdAt: now(),
        lastMatched: 0,
        matchCount: 0,
      },
      {
        id: 'pattern_cascade',
        name: 'Activation Cascade',
        signature: [0.1, 0.3, 0.5, 0.7, 0.9, 1.0],
        domain: 'activation',
        strength: 0.85,
        createdAt: now(),
        lastMatched: 0,
        matchCount: 0,
      },
    ];

    for (const pattern of defaultPatterns) {
      this.patterns.set(pattern.id, pattern);
    }
  }

  // Register a new pattern
  registerPattern(pattern: Omit<ResonancePattern, 'createdAt' | 'lastMatched' | 'matchCount'>): ResonancePattern {
    const fullPattern: ResonancePattern = {
      ...pattern,
      createdAt: now(),
      lastMatched: 0,
      matchCount: 0,
    };

    this.patterns.set(fullPattern.id, fullPattern);
    this.logger.info(`Registered pattern: ${fullPattern.name}`);

    return fullPattern;
  }

  // Match a signal against all patterns
  matchPatterns(signal: number[]): Array<{ pattern: ResonancePattern; resonance: number }> {
    const matches: Array<{ pattern: ResonancePattern; resonance: number }> = [];

    for (const pattern of this.patterns.values()) {
      // Normalize signal to pattern length
      const normalizedSignal = this.normalizeSignal(signal, pattern.signature.length);

      const resonance = computeResonance(normalizedSignal, pattern.signature);

      if (resonance > 0.5) {
        pattern.lastMatched = now();
        pattern.matchCount++;
        matches.push({ pattern, resonance });
      }
    }

    // Sort by resonance strength
    matches.sort((a, b) => b.resonance - a.resonance);

    return matches;
  }

  // Normalize signal to target length
  private normalizeSignal(signal: number[], targetLength: number): number[] {
    if (signal.length === targetLength) return signal;

    const result: number[] = [];
    for (let i = 0; i < targetLength; i++) {
      const idx = Math.floor((i / targetLength) * signal.length);
      result.push(signal[Math.min(idx, signal.length - 1)]);
    }

    return result;
  }

  // Compute field state from current activations
  computeFieldState(activations: Map<string, number>): FieldState {
    const values = Array.from(activations.values());

    // Coherence: how aligned are the activations
    const avg = values.reduce((a, b) => a + b, 0) / (values.length || 1);
    const variance = values.reduce((sum, v) => sum + (v - avg) ** 2, 0) / (values.length || 1);
    const coherence = 1 - Math.sqrt(variance);

    // Turbulence: how rapidly things are changing
    let turbulence = 0;
    if (this.fieldHistory.length > 0) {
      const prev = this.fieldHistory[this.fieldHistory.length - 1];
      const prevValues = Array.from(prev.activations.values());
      if (prevValues.length === values.length) {
        for (let i = 0; i < values.length; i++) {
          turbulence += Math.abs(values[i] - prevValues[i]);
        }
        turbulence /= values.length;
      }
    }

    // Find dominant pattern
    const dominantPattern = this.findDominantPattern(activations);

    const state: FieldState = {
      timestamp: now(),
      activations: new Map(activations),
      dominantPattern,
      coherence,
      turbulence,
    };

    this.fieldHistory.push(state);
    if (this.fieldHistory.length > this.maxHistory) {
      this.fieldHistory.shift();
    }

    return state;
  }

  // Find dominant pattern in current activations
  private findDominantPattern(activations: Map<string, number>): string | null {
    const values = Array.from(activations.values());
    if (values.length === 0) return null;

    const matches = this.matchPatterns(values);
    if (matches.length === 0) return null;

    return matches[0].pattern.id;
  }

  // Get field history
  getFieldHistory(limit: number = 100): FieldState[] {
    return this.fieldHistory.slice(-limit);
  }

  // Detect anomalies in field history
  detectAnomalies(): Array<{ timestamp: number; deviation: number; description: string }> {
    if (this.fieldHistory.length < 3) return [];

    const anomalies: Array<{ timestamp: number; deviation: number; description: string }> = [];

    for (let i = 2; i < this.fieldHistory.length; i++) {
      const prev = this.fieldHistory[i - 1];
      const curr = this.fieldHistory[i];

      const coherenceDiff = Math.abs(curr.coherence - prev.coherence);
      const turbulenceDiff = Math.abs(curr.turbulence - prev.turbulence);

      if (coherenceDiff > 0.3) {
        anomalies.push({
          timestamp: curr.timestamp,
          deviation: coherenceDiff,
          description: `Coherence shift: ${prev.coherence.toFixed(2)} -> ${curr.coherence.toFixed(2)}`,
        });
      }

      if (turbulenceDiff > 0.3) {
        anomalies.push({
          timestamp: curr.timestamp,
          deviation: turbulenceDiff,
          description: `Turbulence spike: ${prev.turbulence.toFixed(2)} -> ${curr.turbulence.toFixed(2)}`,
        });
      }
    }

    return anomalies;
  }

  // Get stats
  getStats(): object {
    return {
      patterns: this.patterns.size,
      fieldHistory: this.fieldHistory.length,
      avgCoherence: this.fieldHistory.reduce((s, f) => s + f.coherence, 0) / (this.fieldHistory.length || 1),
      avgTurbulence: this.fieldHistory.reduce((s, f) => s + f.turbulence, 0) / (this.fieldHistory.length || 1),
    };
  }
}

// Singleton
export const resonanceCore = new ResonanceCoreEngine();
