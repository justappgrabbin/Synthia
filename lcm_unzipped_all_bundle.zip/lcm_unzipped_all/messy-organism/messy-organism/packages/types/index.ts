/**
 * MESSY Organism - Types Package
 * 
 * Shared TypeScript contracts, typed runtime messages, shared entity models.
 * This is the canonical type layer that all packages depend on.
 */

import { z } from 'zod';

// Re-export all schemas as types
export * from '@messy/schemas';

// ============================================================
// ADDITIONAL TYPE EXPORTS
// ============================================================

export type OrganismState = 
  | 'dormant'
  | 'initializing'
  | 'active'
  | 'processing'
  | 'converging'
  | 'expressing'
  | 'growing'
  | 'sleeping';

export type OrganismMode =
  | 'observation'
  | 'interaction'
  | 'creation'
  | 'reflection'
  | 'transformation';

export interface OrganismStatus {
  state: OrganismState;
  mode: OrganismMode;
  uptime: number;
  activeGates: number[];
  activeChannels: string[];
  activeCenters: number[];
  convergenceLevel: number;
  semanticCoherence: number;
  lastActivity: number;
}

export interface OrganismConfig {
  name: string;
  version: string;
  ontology: {
    planets: number;
    dimensions: number;
    centers: number;
    gates: number;
    linesPerGate: number;
    colorsPerLine: number;
    tonesPerColor: number;
    basesPerTone: number;
  };
  coordinates: {
    canonical: string[];
    discrete: string[];
    continuous: string[];
  };
  centerModes: string[];
  strata: Array<{ name: string; domain: string; index: number }>;
  dimensions: Array<{ name: string; macro: string; micro: string; keynote: string }>;
  meshLaw: string[];
  organs: string[];
  projectionDomains: string[];
  activationGrammars: string[];
  nodeCategories: string[];
  edgeFunctionTypes: string[];
  runtime: {
    meshTickMs: number;
    convergenceThreshold: number;
    maxRecursionDepth: number;
    defaultLogLevel: string;
  };
  persistence: {
    engine: string;
    path: string;
    snapshotIntervalMs: number;
  };
  selfGrowth: {
    enabled: boolean;
    autoEdit: boolean;
    learningRate: number;
    maxMutationPerCycle: number;
  };
}

export interface RuntimeContext {
  organism: OrganismStatus;
  mesh: {
    activeMessages: number;
    totalChannels: number;
    activeChannels: number;
    totalEdges: number;
  };
  activation: {
    grammars: string[];
    totalActivations: number;
    mostActiveGates: Array<{ gateId: number; count: number }>;
  };
  projection: {
    renderers: string[];
    totalProjections: number;
    byDomain: Record<string, number>;
  };
  identity: {
    userId: string;
    llmBridges: number;
    mcpBridges: number;
    semanticCoherence: number;
  };
  persistence: {
    adapter: string;
  };
  ingestion: {
    totalArtifacts: number;
    ingested: number;
    avgQuality: number;
  };
  selfSupervised: {
    learningRules: number;
    mutations: number;
    appliedMutations: number;
  };
  resonance: {
    patterns: number;
    fieldHistory: number;
    avgCoherence: number;
  };
  graph: {
    nodes: number;
    links: number;
    activeNodes: number;
    activeLinks: number;
  };
}

// API Response types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: number;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}
