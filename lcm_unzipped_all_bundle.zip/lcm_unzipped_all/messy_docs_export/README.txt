This zip is an export bundle of the doctrine docs drafted in canvas during this session.
It includes the latest manually-edited NODE_FUNCTIONS.md snapshot.
Some docs are concise exports for easier tracking in the UI.