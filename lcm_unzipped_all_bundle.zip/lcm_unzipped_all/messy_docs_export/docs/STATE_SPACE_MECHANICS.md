# STATE SPACE MECHANICS

## Purpose
Defines how states work internally inside the organism.

## Core Principle
A state is not a single point.
A state is a bounded region with internal coordinates, gradients, thresholds, and expressive tendencies.

## Macrostate and Microstate
### Macrostate
- hexagram
- center activation profile
- dimensionally qualified dominant state

### Microstate
- line
- color
- tone
- base
- degree
- minute
- second
- arc offset
- local modulation

## State Region Model
A state should be treated as a region, chamber, basin, or local manifold rather than a single dot.

Within a region there may be:
- stable interior zones
- threshold zones
- directional gradients
- neighbor-facing surfaces
- instability ridges
- expressive pockets
- latent subregions

## Hexagram as State Region
A hexagram is a bounded expressive region with internal structure.

## Internal Coordinates
- line
- color
- tone
- base
- arc position
- degree
- minute
- second

## Stability and Instability
A state region may contain:
- highly stable interior zones
- sensitive transition bands
- metastable pockets
- instability ridges
- high-tension boundary surfaces

## Final Rule
A state is a region with internal mechanics.
Without this, the organism collapses into symbolic labels.
