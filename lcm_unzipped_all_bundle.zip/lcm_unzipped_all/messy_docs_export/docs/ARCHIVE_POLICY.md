# ARCHIVE POLICY

## Purpose
Preserve superseded work without allowing it to continue acting as canonical source.

## Core Rule
Only one implementation per concern may remain canonical.

If two or more artifacts solve the same concern, one must win and the rest must be:
- extracted for unique logic
- wrapped as adapters
- or archived

## Archive Triggers
Archive when something is:
- duplicate
- superseded
- a parallel truth
- prototype drift
- platform out of scope
- dead-end integration

## Extraction Before Archive
1. identify unique logic
2. extract reusable part
3. move it into its canonical package
4. archive the remaining shell intact

## Import Rule
No archived file may be imported by live code.

## Root Cleanup Rule
Loose root-level duplicates must not remain in the live repo root after classification.

## Final Rule
Archived work remains visible.
Canonical work remains authoritative.
