# MIGRATION MAP

## Goal
Consolidate the uploaded prototypes and loose modules into one canonical monorepo without redesigning the product.

## Canonical Monorepo Target
- apps/runtime
- apps/browser-shell
- packages/ontology
- packages/state-space
- packages/mesh
- packages/bus
- packages/activation
- packages/projection
- packages/identity-center
- packages/types
- packages/persistence
- packages/ingestion
- packages/hd-graph
- packages/self-supervised
- packages/resonance-core
- packages/ui
- packages/organs-autoling
- packages/organs-diseminer
- packages/organs-novel-writer
- services/resonance-market-api
- services/oracle-py
- services/chart-oracle

## Intake Classification
- `synthia-kiosk-2(1).zip` -> keep as `apps/runtime`
- `synthia-browser(2).zip` -> keep as `apps/browser-shell`
- `synthia-v9.1(2).zip` -> extract unique logic to `packages/resonance-core`, archive remainder
- `synthia-ast-engine-2.zip` -> `packages/ingestion`
- `HDGraphEngine-1.ts` + `Tensor.ts` -> `packages/hd-graph`
- `synthia-self-supervised-engine (2).ts` -> `packages/self-supervised`
- `ResonanceMarketClient.ts` -> `services/resonance-market-api`
- `AutopoeticResonanceEngine_v7-1.zip` -> partial donor then archive
- `DebateCopilot(1).zip` -> archive for now

## Canonicality Rules
1. One runtime only
2. One browser shell only
3. One shared type system only
4. One message substrate only
5. One persistence layer only
6. One implementation per concern stays canonical
7. Everything else is extracted or archived

## Definition of Done
- one canonical monorepo shape
- `apps/runtime` is the only runtime entrypoint
- `apps/browser-shell` is the only browser shell
- package concerns are extracted cleanly
- services are optional and bounded
- no archived code is imported by live code
- README explains how to run the organism
