# FOUNDATION

## Purpose
MESSY is a local-first digital organism for alignment, activation, and expression.

## Core Thesis
All possible forms already exist in the state space as latent structure.
The organism does not primarily compute forms into existence. It addresses, activates, and expresses the relevant form.

## First Principles
- State space first
- Activation before computation
- Mesh before direct calls
- Morph through message passing
- Meaning is proportional
- Color is semantic state
- Identity is a center
- Local first

## What MESSY Is
MESSY is a recursive, message-morphic, state-latticed organism consisting of:
- a latent ontology
- activation grammars
- a message mesh
- gates, channels, and centers
- a user-centered identity hub
- projection layers for expression
- optional external cognition bridges

## Ontological Stack
Discrete layers:
- 13 planetary influences
- 5 dimensions
- 9 centers
- 64 hexagram nodes / gates
- 6 lines per gate
- 6 colors per line
- 6 tones per color
- 5 bases per tone

Continuous layers:
- arc-based modulation
- spectral variation
- sound variation
- color variation
- timing and position
- phase, intensity, and interpolation

## The Five Dimensions
1. Movement
2. Evolution
3. Being
4. Design
5. Space

## Identity Center
The Identity Center is the user-alignment hub where:
- the user’s LLMs sit
- MCP connections are bridged
- tool routing is aligned
- user-specific style and meaning are preserved

## Awareness Organs
- AUTOLING
- DISEMINER
- Automatic Novel Writer

## Strata
- Heart / Direction
- Mind / Structure / Code
- Action / Embodiment / Image

## Local-First Doctrine
Must remain local:
- ontology
- state space
- mesh
- gates, channels, centers
- identity center
- morph logic
- persistence
- browser shell and runtime spine

May be external:
- user LLMs
- MCP servers
- oracle services
- training pipelines
- market services
- heavy numerical or research modules

## Final Rule
The code is not the constitution.
The ontology is the constitution.
