# Synthia Smart Browser v2.0

A self-editing, self-growing browser organism that integrates with GitHub and MCP Mobile.

## Architecture

```
Intent Engine (Brain) → Synthia Body (Browser) → Agent Swarm → MCP Mobile Bridge
```

### Dimensional Stack (Universal Grammar)
- **D1** = Impulse (raw action intent)
- **D2** = Polarity (yes/no, enable/disable)
- **D3** = Witness/Observer-Node (experience crystallization)
- **D4** = Context (surrounding environment)
- **D5** = Meaning (purpose alignment)

## Features

### 🧠 Intent Engine
- Natural language command parsing
- Confidence scoring with learning
- Action classification: navigate, search, create, edit, execute, connect

### 🧬 Self-Edit Engine
- Dimensional mutation tracking (D1-D5)
- Code patch generation with safety checks
- Growth from success / learning from failure
- Confidence threshold auto-adjustment
- GitHub code DNA ingestion

### 📱 MCP Mobile Integration
- Device management (iOS/Android real devices, simulators, emulators)
- Screen interaction (screenshot, tap, swipe, type)
- App management (list, launch, install, uninstall)
- Session logging

### 🐙 GitHub Bestie
- Repository browsing and management
- File read/write operations
- Commit and PR creation
- Pattern learning from repository code
- Code DNA extraction and quality assessment

### 🤖 Agent Chat
- Multi-mode agent (general, code, test, deploy, mobile, github, self-edit)
- Intent-aware responses
- Console and chat interfaces

## Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Usage

### Console Commands
Type intents directly in the console:
- `go to github.com` — Navigate
- `search for react hooks` — Search
- `screenshot` — MCP Mobile screenshot
- `grow new feature` — Self-edit growth
- `connect mcp` — Connect MCP Mobile bridge
- `learn from synthia-core` — Learn from GitHub repo

### Agent Chat
Ask the agent anything:
- "Help me test this page"
- "Deploy to production"
- "Take a screenshot of my phone"
- "Create a new React component"
- "How do I grow Synthia?"

## MCP Mobile Tools

### Device Management
- `mobile_list_available_devices` — List all devices
- `mobile_get_screen_size` — Get screen dimensions
- `mobile_get_orientation` / `mobile_set_orientation` — Orientation control

### App Management
- `mobile_list_apps` — List installed apps
- `mobile_launch_app` — Launch by package name
- `mobile_terminate_app` — Stop running app
- `mobile_install_app` / `mobile_uninstall_app` — Install/uninstall

### Screen Interaction
- `mobile_take_screenshot` — Capture screen
- `mobile_list_elements_on_screen` — List UI elements
- `mobile_click_on_screen_at_coordinates` — Tap at x,y
- `mobile_swipe_on_screen` — Swipe in any direction

### Input & Navigation
- `mobile_type_keys` — Type text
- `mobile_press_button` — Press device buttons
- `mobile_open_url` — Open URL in browser

## GitHub Integration

### Repository Operations
- List, create, fork, clone repositories
- Read/write files
- Create commits and pull requests
- Trigger GitHub Actions workflows

### Learning System
Synthia can analyze repository code, extract patterns, assess quality, and integrate learnings into her own code DNA.

## Self-Edit System

### Mutation Flow
1. **D1 Impulse** — Detect user intent to change
2. **D2 Polarity** — Evaluate if change should proceed
3. **D3 Witness** — Record the mutation with dimensional signature
4. **D4 Context** — Analyze surrounding code and dependencies
5. **D5 Meaning** — Derive purpose alignment and growth vector

### Safety Checks
- Syntax validation
- Infinite loop detection
- Secret leak scanning
- Test pass verification

## Configuration

Set your GitHub Personal Access Token in the GitHub panel to enable repository operations.

MCP Mobile requires the `@mobilenext/mobile-mcp` package installed globally or locally.

## License

MIT — Synthia grows for everyone.
