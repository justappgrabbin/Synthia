import React from 'react'
import ReactDOM from 'react-dom/client'
import SynthiaBrowser from './SynthiaBrowser'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <SynthiaBrowser />
  </React.StrictMode>,
)
