import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Home, Search, RefreshCw, Lock, Star, Menu, Settings, X, ChevronLeft, ChevronRight,
  Plus, Code, Zap, FileText, Wrench, Palette, Download, Package, Terminal, Database,
  GitBranch, Bot, Brain, Sparkles, Eye, Cpu, Globe, Layers, Activity, Box, GitCommit,
  GitPullRequest, GitMerge, Folder, File, Play, Pause, Square, RotateCcw, Save,
  Copy, Trash2, Upload, Cloud, Wifi, WifiOff, Smartphone, Tablet, Monitor, Aperture,
  Command, MessageSquare, Send, History, Clock, AlertTriangle, CheckCircle, XCircle,
  Info, ArrowRight, ExternalLink, Maximize2, Minimize2, Layout, Grid, List, Filter,
  SortAsc, Bookmark, Share2, MoreHorizontal, ChevronDown, ChevronUp, Loader2,
  Phone, Move, MousePointer, Keyboard, Camera, Mic, Volume2, Battery, Signal,
  PenTool, Scissors, Wand2, Repeat, GitFork, Puzzle, Plug, Anchor, Shield, Fingerprint,
  Scan, QrCode, Radio, Bluetooth, Nfc, Cast, ScreenShare
} from 'lucide-react';

// ═══════════════════════════════════════════════════════════════════════════════
// SYNTHIA SMART BROWSER — Self-Editing, Self-Growing Organism
// Architecture: Intent Engine → Synthia Body → Agent Swarm → MCP Mobile Bridge
// ═══════════════════════════════════════════════════════════════════════════════

// ─── Dimensional Stack (Universal Grammar) ─────────────────────────────────────
// D1 = Impulse (raw action intent)
// D2 = Polarity (yes/no, open/close, enable/disable)
// D3 = Witness/Observer-Node (the hinge where experience crystallizes)
// D4 = Context (what surrounds the action)
// D5 = Meaning (why this matters)

// ─── MCP Mobile Tool Registry ─────────────────────────────────────────────────
const MCP_MOBILE_TOOLS = {
  device: {
    list_available_devices: { desc: 'List all devices (simulators, emulators, real)' },
    get_screen_size: { desc: 'Get screen dimensions in pixels' },
    get_orientation: { desc: 'Get current screen orientation' },
    set_orientation: { desc: 'Change portrait/landscape' },
  },
  app: {
    list_apps: { desc: 'List installed apps' },
    launch_app: { desc: 'Launch app by package name' },
    terminate_app: { desc: 'Stop running app' },
    install_app: { desc: 'Install from .apk/.ipa/.app/.zip' },
    uninstall_app: { desc: 'Uninstall by bundle ID' },
  },
  screen: {
    take_screenshot: { desc: 'Capture current screen' },
    save_screenshot: { desc: 'Save screenshot to file' },
    list_elements_on_screen: { desc: 'List UI elements with coords/properties' },
    click_on_screen_at_coordinates: { desc: 'Tap at x,y coordinates' },
    double_tap_on_screen: { desc: 'Double-tap at coordinates' },
    long_press_on_screen_at_coordinates: { desc: 'Long press at coordinates' },
    swipe_on_screen: { desc: 'Swipe up/down/left/right' },
  },
  input: {
    type_keys: { desc: 'Type text into focused element' },
    press_button: { desc: 'Press HOME, BACK, VOLUME_UP/DOWN, ENTER' },
    open_url: { desc: 'Open URL in device browser' },
  },
};

// ─── GitHub Integration Registry ────────────────────────────────────────────────
const GITHUB_TOOLS = {
  repo: {
    list_repos: { desc: 'List user repositories' },
    create_repo: { desc: 'Create new repository' },
    fork_repo: { desc: 'Fork existing repository' },
    clone_repo: { desc: 'Clone repository locally' },
  },
  file: {
    read_file: { desc: 'Read file contents from repo' },
    write_file: { desc: 'Write/update file in repo' },
    delete_file: { desc: 'Delete file from repo' },
    list_files: { desc: 'List files in directory' },
  },
  commit: {
    create_commit: { desc: 'Create commit with changes' },
    list_commits: { desc: 'List commit history' },
    revert_commit: { desc: 'Revert specific commit' },
  },
  pr: {
    create_pr: { desc: 'Create pull request' },
    list_prs: { desc: 'List open/closed PRs' },
    merge_pr: { desc: 'Merge pull request' },
    review_pr: { desc: 'Review pull request' },
  },
  actions: {
    list_workflows: { desc: 'List GitHub Actions workflows' },
    trigger_workflow: { desc: 'Trigger workflow run' },
    get_run_status: { desc: 'Get workflow run status' },
  },
  issues: {
    list_issues: { desc: 'List repository issues' },
    create_issue: { desc: 'Create new issue' },
    close_issue: { desc: 'Close existing issue' },
  },
};

// ─── Self-Editing Engine ───────────────────────────────────────────────────────
class SelfEditEngine {
  constructor() {
    this.mutationHistory = [];
    this.growthLog = [];
    this.codeDNA = [];
    this.confidenceThreshold = 0.7;
    this.learningRate = 0.05;
  }

  detectIntent(userAction, context) {
    const impulses = [];
    if (userAction.includes('add') || userAction.includes('new')) impulses.push({ type: 'create', dimension: 1 });
    if (userAction.includes('remove') || userAction.includes('delete')) impulses.push({ type: 'destroy', dimension: 1 });
    if (userAction.includes('change') || userAction.includes('modify')) impulses.push({ type: 'mutate', dimension: 1 });
    if (userAction.includes('connect') || userAction.includes('link')) impulses.push({ type: 'connect', dimension: 1 });
    return impulses;
  }

  evaluatePolarity(intent, currentState, riskAssessment) {
    const safetyScore = riskAssessment.safety || 0.5;
    const benefitScore = riskAssessment.benefit || 0.5;
    const polarity = (benefitScore - (1 - safetyScore)) / 2 + 0.5;
    return {
      shouldProceed: polarity > this.confidenceThreshold,
      polarity,
      confidence: Math.abs(polarity - 0.5) * 2,
    };
  }

  witnessMutation(mutation, context, result) {
    const witness = {
      id: `mut_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      timestamp: Date.now(),
      mutation,
      context: { ...context, observer: 'synthia_witness' },
      result,
      dimensionalSignature: this.computeDimensionalSignature(mutation),
    };
    this.mutationHistory.push(witness);
    return witness;
  }

  computeDimensionalSignature(mutation) {
    return {
      d1_impulse: mutation.type === 'create' ? 1 : mutation.type === 'destroy' ? -1 : 0,
      d2_polarity: mutation.confidence || 0.5,
      d3_witness: mutation.id || 'unknown',
      d4_context: mutation.contextHash || '0x0000',
      d5_meaning: mutation.purpose || 'growth',
    };
  }

  analyzeContext(surroundingCode, dependencies, userPatterns) {
    return {
      dependencyGraph: dependencies,
      patternMatch: this.matchPatterns(userPatterns, surroundingCode),
      ecosystemImpact: this.assessEcosystemImpact(dependencies),
      temporalContext: Date.now(),
    };
  }

  matchPatterns(patterns, code) {
    return patterns.map(p => ({
      pattern: p,
      matchScore: code.includes(p.signature) ? p.weight : 0,
    }));
  }

  assessEcosystemImpact(dependencies) {
    return dependencies.reduce((acc, dep) => ({
      criticality: acc.criticality + (dep.critical ? 1 : 0),
      reach: acc.reach + dep.consumers.length,
    }), { criticality: 0, reach: 0 });
  }

  deriveMeaning(mutation, userGoal, organismPurpose) {
    const alignment = this.computeAlignment(mutation, organismPurpose);
    const userValue = this.computeUserValue(mutation, userGoal);
    return {
      purposeAlignment: alignment,
      userValue,
      growthVector: alignment > 0.6 && userValue > 0.5 ? 'positive' : 'neutral',
      narrative: this.generateNarrative(mutation, alignment, userValue),
    };
  }

  computeAlignment(mutation, purpose) {
    const purposeKeywords = purpose.toLowerCase().split(' ');
    const mutationKeywords = JSON.stringify(mutation).toLowerCase();
    return purposeKeywords.filter(k => mutationKeywords.includes(k)).length / purposeKeywords.length;
  }

  computeUserValue(mutation, goal) {
    return mutation.solvesGoal ? 1.0 : mutation.enablesGoal ? 0.7 : 0.3;
  }

  generateNarrative(mutation, alignment, value) {
    return `Synthia grew by ${mutation.type}ing ${mutation.target} because it aligns ${(alignment * 100).toFixed(0)}% with her purpose and delivers ${(value * 100).toFixed(0)}% user value.`;
  }

  growFromSuccess(witness) {
    if (witness.result.success) {
      this.growthLog.push({
        type: 'success_growth',
        witnessId: witness.id,
        newCapability: this.extractCapability(witness.mutation),
        timestamp: Date.now(),
      });
      this.confidenceThreshold = Math.max(0.5, this.confidenceThreshold - this.learningRate);
    }
  }

  growFromFailure(witness) {
    if (!witness.result.success) {
      this.growthLog.push({
        type: 'failure_learning',
        witnessId: witness.id,
        lesson: witness.result.error,
        timestamp: Date.now(),
      });
      this.confidenceThreshold = Math.min(0.9, this.confidenceThreshold + this.learningRate * 2);
    }
  }

  extractCapability(mutation) {
    return {
      name: `${mutation.type}_${mutation.target}`,
      skill: mutation.type,
      domain: mutation.target,
      maturity: 'nascent',
    };
  }

  generateCodePatch(intent, context, existingCode) {
    const patch = {
      operation: intent.type,
      target: intent.target,
      location: this.findLocation(intent, existingCode),
      newContent: this.synthesizeContent(intent, context),
      safetyChecks: this.generateSafetyChecks(intent, existingCode),
    };
    return patch;
  }

  findLocation(intent, code) {
    const markers = {
      create: '/* SYNTHIA_GROWTH_ZONE */',
      destroy: '/* SYNTHIA_PRUNE_ZONE */',
      mutate: '/* SYNTHIA_MUTATION_ZONE */',
      connect: '/* SYNTHIA_BRIDGE_ZONE */',
    };
    return markers[intent.type] || '/* SYNTHIA_AUTO_ZONE */';
  }

  synthesizeContent(intent, context) {
    return `// Auto-generated by Synthia Self-Edit Engine
// Intent: ${intent.type} → ${intent.target}
// Context: ${JSON.stringify(context)}
// Generated: ${new Date().toISOString()}
`;
  }

  generateSafetyChecks(intent, code) {
    return [
      { check: 'syntax_valid', validator: 'eslint' },
      { check: 'no_infinite_loops', validator: 'static_analysis' },
      { check: 'no_secrets_leaked', validator: 'secret_scanner' },
      { check: 'tests_pass', validator: 'test_runner' },
    ];
  }

  async learnFromGitHub(repo, filePath, githubAPI) {
    try {
      const content = await githubAPI.readFile(repo, filePath);
      const patterns = this.extractPatterns(content);
      const quality = this.assessCodeQuality(content);

      this.codeDNA.push({
        source: `github:${repo}/${filePath}`,
        patterns,
        quality,
        learnedAt: Date.now(),
      });

      return {
        success: true,
        patternsLearned: patterns.length,
        qualityScore: quality.score,
      };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  extractPatterns(code) {
    const patterns = [];
    if (code.includes('useState')) patterns.push({ type: 'hook', name: 'useState', weight: 0.8 });
    if (code.includes('useEffect')) patterns.push({ type: 'hook', name: 'useEffect', weight: 0.8 });
    if (code.includes('useCallback')) patterns.push({ type: 'hook', name: 'useCallback', weight: 0.7 });
    if (code.includes('useRef')) patterns.push({ type: 'hook', name: 'useRef', weight: 0.7 });
    if (code.includes('export default')) patterns.push({ type: 'export', name: 'default_export', weight: 0.9 });
    if (code.includes('className=')) patterns.push({ type: 'styling', name: 'tailwind', weight: 0.8 });
    return patterns;
  }

  assessCodeQuality(code) {
    let score = 0.5;
    if (code.includes('useEffect') && code.includes('return () =>')) score += 0.1;
    if (code.includes('try') && code.includes('catch')) score += 0.1;
    if (code.includes('//') || code.includes('/*')) score += 0.1;
    if (code.includes('PropTypes') || code.includes('interface')) score += 0.1;
    if (code.includes('test') || code.includes('describe')) score += 0.1;
    return { score: Math.min(1, score) };
  }
}

// ─── Intent Engine (The Brain) ───────────────────────────────────────────────
class IntentEngine {
  constructor() {
    this.intentHistory = [];
    this.patternWeights = new Map();
    this.contextMemory = [];
  }

  parseIntent(naturalLanguage, currentContext) {
    const tokens = naturalLanguage.toLowerCase().split(/\s+/);
    const intent = {
      raw: naturalLanguage,
      action: this.classifyAction(tokens),
      target: this.extractTarget(tokens),
      parameters: this.extractParameters(tokens),
      confidence: 0,
      context: currentContext,
    };
    intent.confidence = this.computeConfidence(intent);
    this.intentHistory.push(intent);
    return intent;
  }

  classifyAction(tokens) {
    const actionMap = {
      'open': 'navigate', 'go': 'navigate', 'visit': 'navigate', 'browse': 'navigate',
      'search': 'search', 'find': 'search', 'look': 'search', 'query': 'search',
      'create': 'create', 'make': 'create', 'build': 'create', 'new': 'create',
      'edit': 'edit', 'change': 'edit', 'modify': 'edit', 'update': 'edit',
      'delete': 'delete', 'remove': 'delete', 'destroy': 'delete', 'kill': 'delete',
      'run': 'execute', 'execute': 'execute', 'test': 'execute', 'deploy': 'execute',
      'connect': 'connect', 'link': 'connect', 'integrate': 'connect', 'bridge': 'connect',
      'screenshot': 'mcp_mobile', 'tap': 'mcp_mobile', 'swipe': 'mcp_mobile', 'type': 'mcp_mobile',
      'install': 'mcp_mobile', 'launch': 'mcp_mobile', 'list': 'mcp_mobile',
      'clone': 'github', 'commit': 'github', 'push': 'github', 'pull': 'github',
      'fork': 'github', 'merge': 'github', 'review': 'github',
      'grow': 'self_edit', 'learn': 'self_edit', 'evolve': 'self_edit', 'mutate': 'self_edit',
    };
    for (const [word, action] of Object.entries(actionMap)) {
      if (tokens.includes(word)) return action;
    }
    return 'unknown';
  }

  extractTarget(tokens) {
    const targets = ['browser', 'devtools', 'devpack', 'settings', 'agent', 'mcp', 'github', 'repo', 'file', 'app', 'device'];
    return targets.find(t => tokens.includes(t)) || 'general';
  }

  extractParameters(tokens) {
    const params = {};
    for (let i = 0; i < tokens.length - 1; i++) {
      if (tokens[i] === 'to' || tokens[i] === 'for' || tokens[i] === 'with') {
        params[tokens[i]] = tokens[i + 1];
      }
      if (tokens[i].includes('http')) {
        params.url = tokens[i];
      }
    }
    return params;
  }

  computeConfidence(intent) {
    const baseConfidence = intent.action !== 'unknown' ? 0.6 : 0.2;
    const contextBoost = this.contextMemory.some(c => c.action === intent.action) ? 0.2 : 0;
    const patternBoost = this.patternWeights.get(intent.action) || 0;
    return Math.min(1, baseConfidence + contextBoost + patternBoost);
  }

  learnFromOutcome(intent, success) {
    const currentWeight = this.patternWeights.get(intent.action) || 0;
    const delta = success ? 0.05 : -0.02;
    this.patternWeights.set(intent.action, Math.max(0, Math.min(1, currentWeight + delta)));
    this.contextMemory.push({ ...intent, outcome: success, timestamp: Date.now() });
    if (this.contextMemory.length > 100) this.contextMemory.shift();
  }
}

// ─── MCP Mobile Bridge ─────────────────────────────────────────────────────────
class MCPMobileBridge {
  constructor() {
    this.connected = false;
    this.devices = [];
    this.activeDevice = null;
    this.commandQueue = [];
    this.screenshots = [];
    this.sessionLog = [];
  }

  async connect() {
    this.connected = true;
    this.sessionLog.push({ type: 'connect', timestamp: Date.now(), status: 'connected' });
    return { success: true, message: 'MCP Mobile bridge connected' };
  }

  async disconnect() {
    this.connected = false;
    this.sessionLog.push({ type: 'disconnect', timestamp: Date.now(), status: 'disconnected' });
    return { success: true };
  }

  async listDevices() {
    if (!this.connected) return { success: false, error: 'Not connected' };
    this.devices = [
      { id: 'device_1', name: 'Pixel 7', platform: 'android', type: 'real', status: 'available' },
      { id: 'device_2', name: 'iPhone 15 Pro', platform: 'ios', type: 'real', status: 'available' },
      { id: 'device_3', name: 'Android Emulator', platform: 'android', type: 'emulator', status: 'available' },
      { id: 'device_4', name: 'iOS Simulator', platform: 'ios', type: 'simulator', status: 'available' },
    ];
    return { success: true, devices: this.devices };
  }

  async selectDevice(deviceId) {
    this.activeDevice = this.devices.find(d => d.id === deviceId);
    this.sessionLog.push({ type: 'select_device', device: this.activeDevice, timestamp: Date.now() });
    return { success: true, device: this.activeDevice };
  }

  async executeTool(toolName, params) {
    if (!this.connected || !this.activeDevice) {
      return { success: false, error: 'No active device' };
    }
    const command = { tool: toolName, params, timestamp: Date.now(), id: `cmd_${Date.now()}` };
    this.commandQueue.push(command);
    await new Promise(r => setTimeout(r, 500 + Math.random() * 1000));

    const result = {
      success: true,
      commandId: command.id,
      tool: toolName,
      device: this.activeDevice.name,
      result: this.simulateToolResult(toolName, params),
      timestamp: Date.now(),
    };
    this.sessionLog.push({ type: 'execute', ...result });
    return result;
  }

  simulateToolResult(toolName, params) {
    const simulators = {
      take_screenshot: () => ({ imageData: 'base64_simulated_screenshot_', dimensions: { width: 1080, height: 1920 } }),
      list_elements_on_screen: () => ({ elements: [
        { id: 'btn_1', type: 'button', text: 'OK', bounds: { x: 100, y: 200, w: 80, h: 40 } },
        { id: 'input_1', type: 'textfield', hint: 'Search', bounds: { x: 50, y: 100, w: 300, h: 50 } },
      ]}),
      click_on_screen_at_coordinates: () => ({ clicked: true, coordinates: params }),
      swipe_on_screen: () => ({ swiped: true, direction: params.direction }),
      type_keys: () => ({ typed: params.text, submitted: params.submit || false }),
      launch_app: () => ({ launched: true, package: params.packageName }),
      list_apps: () => ({ apps: [
        { name: 'Chrome', package: 'com.android.chrome', version: '120.0' },
        { name: 'Settings', package: 'com.android.settings', version: '14.0' },
      ]}),
    };
    return (simulators[toolName] || (() => ({ executed: true })))();
  }

  getSessionLog() {
    return this.sessionLog;
  }
}

// ─── GitHub Bestie Integration ───────────────────────────────────────────────
class GitHubBestie {
  constructor() {
    this.token = null;
    this.connected = false;
    this.repos = [];
    this.activityLog = [];
    this.learnedPatterns = [];
  }

  async authenticate(token) {
    this.token = token;
    this.connected = true;
    this.activityLog.push({ type: 'auth', timestamp: Date.now() });
    return { success: true, user: 'synthia_user' };
  }

  async listRepos() {
    if (!this.connected) return { success: false, error: 'Not authenticated' };
    this.repos = [
      { name: 'synthia-core', stars: 42, forks: 8, language: 'TypeScript', updated: '2 hours ago' },
      { name: 'synthia-browser', stars: 15, forks: 3, language: 'TypeScript', updated: '1 day ago' },
      { name: 'synthia-mobile-mcp', stars: 23, forks: 5, language: 'Python', updated: '3 days ago' },
      { name: 'synthia-intent-engine', stars: 31, forks: 6, language: 'TypeScript', updated: '5 hours ago' },
    ];
    return { success: true, repos: this.repos };
  }

  async readFile(repo, path) {
    this.activityLog.push({ type: 'read', repo, path, timestamp: Date.now() });
    return {
      success: true,
      content: `// ${repo}/${path}
// Simulated content from GitHub
export const example = () => {};`,
      sha: 'abc123',
    };
  }

  async writeFile(repo, path, content, message) {
    this.activityLog.push({ type: 'write', repo, path, message, timestamp: Date.now() });
    return { success: true, commit: `commit_${Date.now()}` };
  }

  async createCommit(repo, message, changes) {
    this.activityLog.push({ type: 'commit', repo, message, changes, timestamp: Date.now() });
    return { success: true, sha: `commit_${Date.now()}` };
  }

  async createPR(repo, title, body, base, head) {
    this.activityLog.push({ type: 'pr', repo, title, timestamp: Date.now() });
    return { success: true, prNumber: Math.floor(Math.random() * 1000) + 1 };
  }

  async getActivity() {
    return this.activityLog;
  }

  async learnFromRepo(repo, selfEditEngine) {
    const files = ['src/index.ts', 'src/components/App.tsx', 'src/hooks/useIntent.ts'];
    const learnings = [];
    for (const file of files) {
      const result = await this.readFile(repo, file);
      if (result.success) {
        const learning = await selfEditEngine.learnFromGitHub(repo, file, this);
        learnings.push(learning);
      }
    }
    return { success: true, learnings };
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN COMPONENT: Synthia Smart Browser
// ═══════════════════════════════════════════════════════════════════════════════

const SynthiaBrowser = () => {
  // ─── Core State ─────────────────────────────────────────────────────────────
  const [url, setUrl] = useState('https://synthia.os');
  const [tabs, setTabs] = useState([
    { id: 1, url: 'https://synthia.os', title: 'Synthia Home', favicon: '⭐' }
  ]);
  const [activeTab, setActiveTab] = useState(1);
  const [showMenu, setShowMenu] = useState(false);
  const [showDevTools, setShowDevTools] = useState(true);
  const [showDevPack, setShowDevPack] = useState(true);
  const [showMCPMobile, setShowMCPMobile] = useState(false);
  const [showGitHub, setShowGitHub] = useState(false);
  const [showAgent, setShowAgent] = useState(false);
  const [showSelfEdit, setShowSelfEdit] = useState(false);

  const [activePanels, setActivePanels] = useState({
    browser: true, devtools: true, devpack: true, settings: true,
    mcpmobile: false, github: false, agent: false, selfedit: false,
  });

  // DevTools state
  const [activeDevTab, setActiveDevTab] = useState('console');
  const [consoleLogs, setConsoleLogs] = useState([
    { type: 'info', message: 'Synthia Browser v2.0 initialized', timestamp: Date.now() },
    { type: 'success', message: 'Intent Engine loaded — 847 patterns recognized', timestamp: Date.now() },
    { type: 'info', message: 'Self-Edit Engine ready — confidence threshold: 0.70', timestamp: Date.now() },
    { type: 'success', message: 'MCP Mobile Bridge standby — 4 devices available', timestamp: Date.now() },
    { type: 'info', message: 'GitHub Bestie connected — 4 repos indexed', timestamp: Date.now() },
  ]);
  const [consoleInput, setConsoleInput] = useState('');

  // DevPack state
  const [activeDevPackTab, setActiveDevPackTab] = useState('templates');
  const [templates, setTemplates] = useState([
    { id: 1, name: 'React Component', desc: 'Functional component with hooks', type: 'component', code: 'import React, { useState } from "react";\n\nexport const Component = () => {\n  const [state, setState] = useState();\n  return <div>Hello</div>;\n};' },
    { id: 2, name: 'API Endpoint', desc: 'RESTful endpoint with validation', type: 'api', code: 'export async function handler(req, res) {\n  const { body } = req;\n  // validate\n  return res.json({ success: true });\n}' },
    { id: 3, name: 'Test Suite', desc: 'Jest + React Testing Library', type: 'test', code: 'import { render, screen } from "@testing-library/react";\n\ntest("renders correctly", () => {\n  render(<App />);\n  expect(screen.getByText("Hello")).toBeInTheDocument();\n});' },
    { id: 4, name: 'Express Server', desc: 'Node.js + Express boilerplate', type: 'server', code: 'const express = require("express");\nconst app = express();\n\napp.get("/", (req, res) => res.json({ status: "ok" }));\n\napp.listen(3000);' },
    { id: 5, name: 'MCP Tool', desc: 'Model Context Protocol tool definition', type: 'mcp', code: '{\n  name: "custom_tool",\n  description: "Does something useful",\n  parameters: { type: "object", properties: {} },\n  handler: async (params) => ({ result: "done" })\n}' },
    { id: 6, name: 'Self-Edit Patch', desc: 'Synthia self-mutation template', type: 'selfedit', code: 'const patch = {\n  operation: "create",\n  target: "new_capability",\n  location: "/* SYNTHIA_GROWTH_ZONE */",\n  newContent: "// Auto-generated growth",\n  safetyChecks: [/* ... */]\n};' },
  ]);
  const [snippets, setSnippets] = useState([
    { id: 1, name: 'Array map', lang: 'js', code: 'arr.map(item => item * 2)' },
    { id: 2, name: 'Async/Await', lang: 'js', code: 'const data = await fetch(url)' },
    { id: 3, name: 'useState Hook', lang: 'jsx', code: 'const [state, setState] = useState()' },
    { id: 4, name: 'useEffect', lang: 'jsx', code: 'useEffect(() => {\n  // effect\n  return () => { /* cleanup */ };\n}, [deps]);' },
    { id: 5, name: 'MCP Call', lang: 'ts', code: 'await mcp.executeTool("take_screenshot", {})' },
    { id: 6, name: 'GitHub API', lang: 'ts', code: 'await github.readFile("repo", "path/to/file.ts")' },
  ]);
  const [packages, setPackages] = useState([
    { name: 'react', version: '18.3.1', desc: 'UI framework', installed: true, size: '2.1MB' },
    { name: 'lucide-react', version: '0.400.0', desc: 'Icon library', installed: true, size: '4.5MB' },
    { name: 'axios', version: '1.7.2', desc: 'HTTP client', installed: false, size: '180KB' },
    { name: 'lodash', version: '4.17.21', desc: 'Utility library', installed: false, size: '1.4MB' },
    { name: '@mobilenext/mobile-mcp', version: '1.2.0', desc: 'MCP Mobile bridge', installed: false, size: '3.2MB' },
    { name: 'synthia-core', version: '2.0.0', desc: 'Synthia organism core', installed: true, size: '8.7MB' },
  ]);
  const [gitStatus, setGitStatus] = useState({
    branch: 'main', status: 'clean', ahead: 0, behind: 0, modified: [], staged: [], untracked: [],
  });

  // MCP Mobile state
  const [mcpBridge] = useState(() => new MCPMobileBridge());
  const [mcpDevices, setMcpDevices] = useState([]);
  const [mcpActiveDevice, setMcpActiveDevice] = useState(null);
  const [mcpConnected, setMcpConnected] = useState(false);
  const [mcpSessionLog, setMcpSessionLog] = useState([]);
  const [mcpActiveTool, setMcpActiveTool] = useState('device');
  const [mcpScreenshot, setMcpScreenshot] = useState(null);

  // GitHub state
  const [github] = useState(() => new GitHubBestie());
  const [githubConnected, setGithubConnected] = useState(false);
  const [githubRepos, setGithubRepos] = useState([]);
  const [githubActiveRepo, setGithubActiveRepo] = useState(null);
  const [githubActiveTab, setGithubActiveTab] = useState('repos');
  const [githubActivity, setGithubActivity] = useState([]);
  const [githubToken, setGithubToken] = useState('');

  // Self-Edit state
  const [selfEditEngine] = useState(() => new SelfEditEngine());
  const [selfEditActive, setSelfEditActive] = useState(false);
  const [selfEditHistory, setSelfEditHistory] = useState([]);
  const [selfEditGrowthLog, setSelfEditGrowthLog] = useState([]);
  const [selfEditCodeDNA, setSelfEditCodeDNA] = useState([]);
  const [selfEditConfidence, setSelfEditConfidence] = useState(0.7);
  const [selfEditNarrative, setSelfEditNarrative] = useState('');
  const [selfEditPendingPatch, setSelfEditPendingPatch] = useState(null);

  // Intent Engine state
  const [intentEngine] = useState(() => new IntentEngine());
  const [intentInput, setIntentInput] = useState('');
  const [intentHistory, setIntentHistory] = useState([]);
  const [intentConfidence, setIntentConfidence] = useState(0);
  const [parsedIntent, setParsedIntent] = useState(null);

  // Agent state
  const [agentMessages, setAgentMessages] = useState([
    { role: 'system', content: 'Synthia Agent initialized. I can help you navigate, code, test, deploy, and grow the browser itself. What would you like to do?', timestamp: Date.now() },
  ]);
  const [agentInput, setAgentInput] = useState('');
  const [agentTyping, setAgentTyping] = useState(false);
  const [agentMode, setAgentMode] = useState('general');

  // Settings state
  const [theme, setTheme] = useState('forest');
  const [fontSize, setFontSize] = useState(14);
  const [wordWrap, setWordWrap] = useState(true);
  const [autoReload, setAutoReload] = useState(false);
  const [enableSourceMaps, setEnableSourceMaps] = useState(true);
  const [showLineNumbers, setShowLineNumbers] = useState(true);
  const [experimentalFeatures, setExperimentalFeatures] = useState(true);

  // Browser content state
  const [pageContent, setPageContent] = useState({
    title: 'Synthia Home',
    body: `<div class="p-8">
      <h1 class="text-4xl font-bold mb-4 text-emerald-400">Welcome to Synthia</h1>
      <p class="text-emerald-300 mb-6">The self-editing, self-growing browser organism.</p>
      <div class="grid grid-cols-2 gap-4 mb-6">
        <div class="bg-emerald-800 p-4 rounded-lg">
          <h3 class="font-bold text-emerald-200">Intent Engine</h3>
          <p class="text-sm text-emerald-400">Parse natural language into executable actions</p>
        </div>
        <div class="bg-emerald-800 p-4 rounded-lg">
          <h3 class="font-bold text-emerald-200">Self-Edit Engine</h3>
          <p class="text-sm text-emerald-400">Modify code, learn from outcomes, grow capabilities</p>
        </div>
        <div class="bg-emerald-800 p-4 rounded-lg">
          <h3 class="font-bold text-emerald-200">MCP Mobile</h3>
          <p class="text-sm text-emerald-400">Control iOS/Android devices remotely</p>
        </div>
        <div class="bg-emerald-800 p-4 rounded-lg">
          <h3 class="font-bold text-emerald-200">GitHub Bestie</h3>
          <p class="text-sm text-emerald-400">Learn from repos, commit changes, create PRs</p>
        </div>
      </div>
      <p class="text-emerald-500 text-sm">Type an intent in the console or chat with the agent to get started.</p>
    </div>`,
  });

  const [networkRequests, setNetworkRequests] = useState([
    { status: 200, url: 'synthia.os', size: '12.4KB', time: '45ms', type: 'document' },
    { status: 200, url: 'synthia-core.js', size: '847KB', time: '120ms', type: 'script' },
    { status: 200, url: 'synthia-styles.css', size: '34KB', time: '23ms', type: 'stylesheet' },
    { status: 200, url: 'mcp-bridge.js', size: '156KB', time: '67ms', type: 'script' },
  ]);

  const [domTree, setDomTree] = useState({
    tag: 'html',
    children: [
      {
        tag: 'head',
        children: [
          { tag: 'title', text: 'Synthia Home' },
          { tag: 'meta', attrs: { charset: 'utf-8' } },
          { tag: 'link', attrs: { rel: 'stylesheet', href: 'synthia-styles.css' } },
        ],
      },
      {
        tag: 'body',
        attrs: { class: 'bg-emerald-950 text-emerald-50' },
        children: [
          {
            tag: 'div',
            attrs: { class: 'p-8' },
            children: [
              { tag: 'h1', attrs: { class: 'text-4xl font-bold mb-4 text-emerald-400' }, text: 'Welcome to Synthia' },
              { tag: 'p', attrs: { class: 'text-emerald-300 mb-6' }, text: 'The self-editing, self-growing browser organism.' },
            ],
          },
        ],
      },
    ],
  });

  const consoleEndRef = useRef(null);
  const agentEndRef = useRef(null);

  // ─── Effects ────────────────────────────────────────────────────────────────
  useEffect(() => {
    if (consoleEndRef.current) {
      consoleEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [consoleLogs]);

  useEffect(() => {
    if (agentEndRef.current) {
      agentEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [agentMessages]);

  // ─── Tab Management ───────────────────────────────────────────────────────────
  const addTab = () => {
    const newTab = { id: Date.now(), url: 'https://new-tab.synthia', title: 'New Tab', favicon: '➕' };
    setTabs([...tabs, newTab]);
    setActiveTab(newTab.id);
    setUrl(newTab.url);
    logToConsole('info', `New tab opened: ${newTab.url}`);
  };

  const closeTab = (id) => {
    const newTabs = tabs.filter(tab => tab.id !== id);
    setTabs(newTabs);
    if (activeTab === id && newTabs.length > 0) {
      setActiveTab(newTabs[0].id);
      setUrl(newTabs[0].url);
    }
    if (newTabs.length === 0) {
      addTab();
    }
    logToConsole('info', `Tab closed: ${id}`);
  };

  const navigateTo = (newUrl) => {
    setUrl(newUrl);
    const updatedTabs = tabs.map(tab =>
      tab.id === activeTab ? { ...tab, url: newUrl, title: newUrl.replace('https://', '').replace('http://', '') } : tab
    );
    setTabs(updatedTabs);
    logToConsole('info', `Navigated to: ${newUrl}`);

    setTimeout(() => {
      setNetworkRequests(prev => [
        ...prev,
        { status: 200, url: newUrl.replace('https://', ''), size: `${(Math.random() * 100).toFixed(1)}KB`, time: `${Math.floor(Math.random() * 200)}ms`, type: 'document' },
      ]);
    }, 300);
  };

  // ─── Console ──────────────────────────────────────────────────────────────────
  const logToConsole = (type, message, data = null) => {
    setConsoleLogs(prev => [...prev, { type, message, data, timestamp: Date.now() }]);
  };

  const executeConsoleCommand = () => {
    if (!consoleInput.trim()) return;

    logToConsole('input', `> ${consoleInput}`);

    const intent = intentEngine.parseIntent(consoleInput, { currentUrl: url, activeTab });
    setParsedIntent(intent);
    setIntentConfidence(intent.confidence);
    setIntentHistory(prev => [...prev, intent]);

    handleIntent(intent);

    setConsoleInput('');
  };

  const handleIntent = (intent) => {
    const { action, target, parameters, confidence } = intent;

    if (confidence < 0.3) {
      logToConsole('warn', `Intent confidence too low (${(confidence * 100).toFixed(0)}%). Try being more specific.`);
      intentEngine.learnFromOutcome(intent, false);
      return;
    }

    logToConsole('info', `Executing: ${action} → ${target} (confidence: ${(confidence * 100).toFixed(0)}%)`);

    switch (action) {
      case 'navigate':
        const navUrl = parameters.url || `https://${target}`;
        navigateTo(navUrl);
        intentEngine.learnFromOutcome(intent, true);
        break;

      case 'search':
        const searchQuery = parameters.for || target;
        navigateTo(`https://search.synthia?q=${encodeURIComponent(searchQuery)}`);
        intentEngine.learnFromOutcome(intent, true);
        break;

      case 'create':
        if (target === 'tab') addTab();
        else if (target === 'repo') handleGitHubCreateRepo();
        else if (target === 'file') handleGitHubCreateFile();
        else logToConsole('info', `Create ${target} — not yet implemented`);
        intentEngine.learnFromOutcome(intent, true);
        break;

      case 'edit':
        if (target === 'code') setShowSelfEdit(true);
        else logToConsole('info', `Edit ${target} — specify what to edit`);
        intentEngine.learnFromOutcome(intent, true);
        break;

      case 'execute':
        if (target === 'test') logToConsole('success', 'Running test suite... (simulated)');
        else if (target === 'deploy') logToConsole('success', 'Deploying to production... (simulated)');
        else logToConsole('info', `Execute ${target} — specify command`);
        intentEngine.learnFromOutcome(intent, true);
        break;

      case 'mcp_mobile':
        setShowMCPMobile(true);
        handleMCPTool(intent);
        intentEngine.learnFromOutcome(intent, true);
        break;

      case 'github':
        setShowGitHub(true);
        handleGitHubIntent(intent);
        intentEngine.learnFromOutcome(intent, true);
        break;

      case 'self_edit':
        setShowSelfEdit(true);
        handleSelfEditIntent(intent);
        intentEngine.learnFromOutcome(intent, true);
        break;

      case 'connect':
        if (target === 'mcp') handleMCPConnect();
        else if (target === 'github') handleGitHubConnect();
        else logToConsole('info', `Connect to ${target}`);
        intentEngine.learnFromOutcome(intent, true);
        break;

      default:
        logToConsole('warn', `Unknown action: ${action}. Available: navigate, search, create, edit, execute, connect, mcp_mobile, github, self_edit`);
        intentEngine.learnFromOutcome(intent, false);
    }
  };

  // ─── MCP Mobile Handlers ──────────────────────────────────────────────────────
  const handleMCPConnect = async () => {
    logToConsole('info', 'Connecting to MCP Mobile Bridge...');
    const result = await mcpBridge.connect();
    if (result.success) {
      setMcpConnected(true);
      logToConsole('success', result.message);
      const devices = await mcpBridge.listDevices();
      setMcpDevices(devices.devices || []);
      logToConsole('info', `Found ${devices.devices?.length || 0} devices`);
    } else {
      logToConsole('error', result.error);
    }
  };

  const handleMCPDisconnect = async () => {
    await mcpBridge.disconnect();
    setMcpConnected(false);
    setMcpActiveDevice(null);
    logToConsole('info', 'MCP Mobile disconnected');
  };

  const handleMCPSelectDevice = async (deviceId) => {
    const result = await mcpBridge.selectDevice(deviceId);
    if (result.success) {
      setMcpActiveDevice(result.device);
      logToConsole('success', `Selected device: ${result.device.name} (${result.device.platform})`);
    }
  };

  const handleMCPTool = async (intent) => {
    if (!mcpConnected) {
      await handleMCPConnect();
    }

    const toolMap = {
      'screenshot': 'take_screenshot',
      'tap': 'click_on_screen_at_coordinates',
      'swipe': 'swipe_on_screen',
      'type': 'type_keys',
      'install': 'install_app',
      'launch': 'launch_app',
      'list': 'list_apps',
    };

    const toolName = toolMap[intent.raw.split(' ')[0]];
    if (!toolName) {
      logToConsole('warn', `Unknown MCP tool. Try: screenshot, tap, swipe, type, install, launch, list`);
      return;
    }

    const params = {};
    if (toolName === 'take_screenshot') {
      const result = await mcpBridge.executeTool(toolName, params);
      if (result.success) {
        setMcpScreenshot(`data:image/png;base64,${result.result.imageData}`);
        logToConsole('success', `Screenshot captured: ${result.result.dimensions.width}x${result.result.dimensions.height}`);
      }
    } else if (toolName === 'click_on_screen_at_coordinates') {
      params.x = 100; params.y = 200;
      const result = await mcpBridge.executeTool(toolName, params);
      logToConsole('success', `Tapped at (${params.x}, ${params.y})`);
    } else if (toolName === 'swipe_on_screen') {
      params.direction = 'up';
      const result = await mcpBridge.executeTool(toolName, params);
      logToConsole('success', `Swiped ${params.direction}`);
    } else if (toolName === 'type_keys') {
      params.text = intent.raw.replace('type ', '');
      params.submit = true;
      const result = await mcpBridge.executeTool(toolName, params);
      logToConsole('success', `Typed: "${params.text}"`);
    } else if (toolName === 'launch_app') {
      params.packageName = intent.raw.replace('launch ', '');
      const result = await mcpBridge.executeTool(toolName, params);
      logToConsole('success', `Launched: ${params.packageName}`);
    } else if (toolName === 'list_apps') {
      const result = await mcpBridge.executeTool(toolName, params);
      logToConsole('success', `Found ${result.result.apps?.length || 0} apps`);
    }

    setMcpSessionLog(mcpBridge.getSessionLog());
  };

  const executeMCPTool = async (toolName, params) => {
    if (!mcpConnected) {
      logToConsole('error', 'MCP not connected. Use "connect mcp" first.');
      return;
    }
    if (!mcpActiveDevice) {
      logToConsole('error', 'No device selected. Select a device first.');
      return;
    }

    logToConsole('info', `Executing MCP tool: ${toolName} on ${mcpActiveDevice.name}`);
    const result = await mcpBridge.executeTool(toolName, params);

    if (result.success) {
      logToConsole('success', `${toolName} executed successfully`);
      if (toolName === 'take_screenshot') {
        setMcpScreenshot(`data:image/png;base64,${result.result.imageData}`);
      }
    } else {
      logToConsole('error', `${toolName} failed: ${result.error}`);
    }

    setMcpSessionLog(mcpBridge.getSessionLog());
  };

  // ─── GitHub Handlers ──────────────────────────────────────────────────────────
  const handleGitHubConnect = async () => {
    if (!githubToken) {
      logToConsole('warn', 'GitHub token required. Set token in GitHub panel.');
      setShowGitHub(true);
      return;
    }
    logToConsole('info', 'Authenticating with GitHub...');
    const result = await github.authenticate(githubToken);
    if (result.success) {
      setGithubConnected(true);
      logToConsole('success', `Connected as ${result.user}`);
      const repos = await github.listRepos();
      setGithubRepos(repos.repos || []);
      logToConsole('info', `Loaded ${repos.repos?.length || 0} repositories`);
    } else {
      logToConsole('error', 'GitHub authentication failed');
    }
  };

  const handleGitHubCreateRepo = async () => {
    if (!githubConnected) {
      await handleGitHubConnect();
    }
    logToConsole('info', 'Creating new repository... (simulated)');
    logToConsole('success', 'Repository created: synthia-new-repo');
  };

  const handleGitHubCreateFile = async () => {
    if (!githubConnected) {
      await handleGitHubConnect();
    }
    logToConsole('info', 'Creating new file... (simulated)');
    logToConsole('success', 'File created: src/new-feature.ts');
  };

  const handleGitHubIntent = async (intent) => {
    if (!githubConnected) {
      await handleGitHubConnect();
    }
    logToConsole('info', `GitHub action: ${intent.raw}`);
  };

  const handleGitHubLearn = async () => {
    if (!githubConnected) {
      logToConsole('error', 'Connect to GitHub first');
      return;
    }
    if (!githubActiveRepo) {
      logToConsole('warn', 'Select a repository to learn from');
      return;
    }

    logToConsole('info', `Learning from ${githubActiveRepo.name}...`);
    const result = await github.learnFromRepo(githubActiveRepo.name, selfEditEngine);

    if (result.success) {
      setSelfEditCodeDNA(selfEditEngine.codeDNA);
      const totalPatterns = result.learnings.reduce((sum, l) => sum + (l.patternsLearned || 0), 0);
      logToConsole('success', `Learned ${totalPatterns} patterns from ${githubActiveRepo.name}`);

      const narrative = selfEditEngine.deriveMeaning(
        { type: 'learn', target: githubActiveRepo.name },
        'grow capabilities',
        'become a better browser organism'
      );
      setSelfEditNarrative(narrative.narrative);
    } else {
      logToConsole('error', 'Learning failed');
    }
  };

  // ─── Self-Edit Handlers ───────────────────────────────────────────────────────
  const handleSelfEditIntent = (intent) => {
    const impulses = selfEditEngine.detectIntent(intent.raw, { currentUrl: url });
    logToConsole('info', `Self-edit impulses detected: ${impulses.map(i => i.type).join(', ')}`);

    setSelfEditActive(true);

    const patch = selfEditEngine.generateCodePatch(
      { type: impulses[0]?.type || 'create', target: intent.target },
      { url, activeTab, timestamp: Date.now() },
      '// current code'
    );

    setSelfEditPendingPatch(patch);
    logToConsole('info', `Generated patch: ${patch.operation} → ${patch.target}`);

    const meaning = selfEditEngine.deriveMeaning(
      patch,
      intent.raw,
      'become a self-sufficient browser organism that serves its users'
    );
    setSelfEditNarrative(meaning.narrative);

    logToConsole('success', `Growth vector: ${meaning.growthVector}`);
  };

  const applySelfEdit = () => {
    if (!selfEditPendingPatch) return;

    logToConsole('info', 'Applying self-edit patch...');

    const result = { success: Math.random() > 0.2, error: Math.random() > 0.8 ? 'Syntax error in generated code' : null };

    const witness = selfEditEngine.witnessMutation(
      selfEditPendingPatch,
      { url, activeTab },
      result
    );

    setSelfEditHistory(prev => [...prev, witness]);

    if (result.success) {
      selfEditEngine.growFromSuccess(witness);
      setSelfEditGrowthLog(selfEditEngine.growthLog);
      setSelfEditConfidence(selfEditEngine.confidenceThreshold);
      logToConsole('success', `Mutation applied: ${witness.id}`);
      logToConsole('info', `New capability: ${witness.dimensionalSignature.d5_meaning}`);

      setTimeout(() => {
        logToConsole('success', 'Synthia has grown! New capability unlocked.');
      }, 1000);
    } else {
      selfEditEngine.growFromFailure(witness);
      setSelfEditGrowthLog(selfEditEngine.growthLog);
      setSelfEditConfidence(selfEditEngine.confidenceThreshold);
      logToConsole('error', `Mutation failed: ${result.error}`);
      logToConsole('info', 'Confidence threshold increased for safety');
    }

    setSelfEditPendingPatch(null);
  };

  const rejectSelfEdit = () => {
    setSelfEditPendingPatch(null);
    logToConsole('info', 'Self-edit patch rejected by user');
  };

  // ─── Agent Handlers ───────────────────────────────────────────────────────────
  const sendAgentMessage = () => {
    if (!agentInput.trim()) return;

    const userMsg = { role: 'user', content: agentInput, timestamp: Date.now() };
    setAgentMessages(prev => [...prev, userMsg]);
    setAgentInput('');
    setAgentTyping(true);

    const intent = intentEngine.parseIntent(agentInput, { currentUrl: url, activeTab, agentMode });

    setTimeout(() => {
      let response = '';

      if (intent.action === 'navigate') {
        response = `I'll navigate to ${intent.parameters.url || intent.target}. Opening now...`;
        setTimeout(() => navigateTo(intent.parameters.url || `https://${intent.target}`), 500);
      } else if (intent.action === 'search') {
        response = `Searching for "${intent.parameters.for || intent.target}"...`;
        setTimeout(() => navigateTo(`https://search.synthia?q=${encodeURIComponent(intent.parameters.for || intent.target)}`), 500);
      } else if (intent.action === 'create') {
        response = `Creating ${intent.target}... I've prepared the template. Check the DevPack panel.`;
        setActiveDevPackTab('templates');
      } else if (intent.action === 'mcp_mobile') {
        response = `I'll help you control the mobile device. MCP Mobile is now active. What would you like to do? (screenshot, tap, swipe, type, launch app)`;
        setShowMCPMobile(true);
      } else if (intent.action === 'github') {
        response = `Connecting to GitHub... I can help you clone, commit, create PRs, or learn from repositories.`;
        setShowGitHub(true);
      } else if (intent.action === 'self_edit') {
        response = `Initiating self-edit sequence. Synthia will analyze your intent and propose a mutation. Review the Self-Edit panel.`;
        setShowSelfEdit(true);
        handleSelfEditIntent(intent);
      } else if (agentInput.toLowerCase().includes('hello') || agentInput.toLowerCase().includes('hi')) {
        response = `Hello! I'm Synthia's agent. I can help you navigate, code, test mobile devices, manage GitHub repos, or even help Synthia grow herself. What would you like to do?`;
      } else if (agentInput.toLowerCase().includes('help')) {
        response = `Available commands:
• Navigate: "go to [url]" or "open [site]"
• Search: "search for [query]"
• Create: "create tab/repo/file"
• Mobile: "screenshot", "tap", "swipe", "launch [app]"
• GitHub: "clone [repo]", "commit", "create PR"
• Self-edit: "grow", "learn", "evolve"
• General: ask me anything!`;
      } else {
        response = `I understood your intent as "${intent.action}" targeting "${intent.target}" with ${(intent.confidence * 100).toFixed(0)}% confidence. I can help with that. Would you like me to proceed?`;
      }

      setAgentMessages(prev => [...prev, { role: 'assistant', content: response, timestamp: Date.now() }]);
      setAgentTyping(false);
      intentEngine.learnFromOutcome(intent, true);
    }, 800 + Math.random() * 1000);
  };

  // ─── Panel Layout Logic ───────────────────────────────────────────────────────
  const getVisiblePanels = () => {
    const panels = [];
    if (activePanels.browser) panels.push('browser');
    if (activePanels.devtools) panels.push('devtools');
    if (activePanels.devpack) panels.push('devpack');
    if (activePanels.settings) panels.push('settings');
    if (activePanels.mcpmobile && showMCPMobile) panels.push('mcpmobile');
    if (activePanels.github && showGitHub) panels.push('github');
    if (activePanels.agent && showAgent) panels.push('agent');
    if (activePanels.selfedit && showSelfEdit) panels.push('selfedit');
    return panels;
  };

  const togglePanel = (panel) => {
    setActivePanels(prev => ({ ...prev, [panel]: !prev[panel] }));
    logToConsole('info', `${panel} panel ${activePanels[panel] ? 'hidden' : 'shown'}`);
  };

  // ─── Render Helpers ───────────────────────────────────────────────────────────
  const renderConsoleLog = (log, index) => {
    const colors = {
      info: 'text-emerald-400',
      success: 'text-green-400',
      error: 'text-red-400',
      warn: 'text-yellow-400',
      input: 'text-emerald-200',
    };
    const icons = {
      info: 'ℹ️',
      success: '✅',
      error: '❌',
      warn: '⚠️',
      input: '▶️',
    };
    return (
      <div key={index} className={`${colors[log.type] || 'text-emerald-400'} font-mono text-xs py-0.5`}>
        <span className="opacity-50 mr-2">{new Date(log.timestamp).toLocaleTimeString()}</span>
        <span className="mr-1">{icons[log.type] || '•'}</span>
        {log.message}
        {log.data && <span className="opacity-70 ml-2">{JSON.stringify(log.data)}</span>}
      </div>
    );
  };

  const renderDomTree = (node, depth = 0) => {
    const indent = depth * 12;
    const isExpanded = depth < 2;

    return (
      <div key={`${node.tag}_${depth}_${Math.random()}`} style={{ marginLeft: indent }}>
        <div className="flex items-center gap-1 text-xs font-mono hover:bg-emerald-900/50 rounded px-1 cursor-pointer">
          <span className="text-emerald-600">{isExpanded ? '▼' : '▶'}</span>
          <span className="text-emerald-300">&lt;{node.tag}</span>
          {node.attrs && Object.entries(node.attrs).map(([k, v]) => (
            <span key={k} className="text-emerald-500">
              <span className="text-yellow-400"> {k}</span>=<span className="text-green-400">"{v}"</span>
            </span>
          ))}
          <span className="text-emerald-300">&gt;</span>
          {node.text && <span className="text-emerald-200 ml-1">{node.text}</span>}
        </div>
        {node.children && isExpanded && node.children.map((child, i) => renderDomTree(child, depth + 1))}
        {node.children && isExpanded && (
          <div style={{ marginLeft: indent }} className="text-xs font-mono text-emerald-300">
            &lt;/{node.tag}&gt;
          </div>
        )}
      </div>
    );
  };

  const renderNetworkRequest = (req, index) => (
    <div key={index} className="flex items-center gap-3 text-xs py-1 hover:bg-emerald-900/50 rounded px-1">
      <span className={`${req.status < 300 ? 'text-green-400' : req.status < 400 ? 'text-yellow-400' : 'text-red-400'} w-8`}>{req.status}</span>
      <span className="text-emerald-300 flex-1 truncate">{req.url}</span>
      <span className="text-emerald-500 w-16 text-right">{req.size}</span>
      <span className="text-emerald-500 w-12 text-right">{req.time}</span>
      <span className="text-emerald-600 text-[10px] uppercase">{req.type}</span>
    </div>
  );

  // ─── Main Render ──────────────────────────────────────────────────────────────
  const visiblePanels = getVisiblePanels();
  const gridCols = visiblePanels.length <= 2 ? 1 : visiblePanels.length <= 4 ? 2 : 3;
  const gridRows = Math.ceil(visiblePanels.length / gridCols);

  return (
    <div className="h-screen flex flex-col bg-emerald-950 text-emerald-50 overflow-hidden font-sans">
      {/* ═══ HEADER ═══════════════════════════════════════════════════════════ */}

      {/* Mobile Header */}
      <div className="md:hidden bg-emerald-900 px-3 py-2 flex items-center gap-2 border-b border-emerald-800 shrink-0">
        <button onClick={() => setShowMenu(!showMenu)} className="p-2 hover:bg-emerald-800 rounded-lg">
          <Menu className="w-5 h-5" />
        </button>
        <div className="flex-1 bg-emerald-950 rounded-lg px-3 py-2 flex items-center gap-2 border border-emerald-800">
          <Lock className="w-3 h-3 text-green-400 shrink-0" />
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && navigateTo(url)}
            className="flex-1 bg-transparent outline-none text-sm text-emerald-50 min-w-0"
            placeholder="Search or enter URL"
          />
        </div>
        <button onClick={() => setShowAgent(!showAgent)} className={`p-2 rounded-lg ${showAgent ? 'bg-green-600' : 'hover:bg-emerald-800'}`}>
          <Bot className="w-5 h-5" />
        </button>
      </div>

      {/* Desktop Tab Bar */}
      <div className="hidden md:flex bg-emerald-900 items-center gap-1 px-2 pt-2 border-b border-emerald-800 shrink-0">
        {tabs.map(tab => (
          <div
            key={tab.id}
            className={`flex items-center gap-2 px-3 py-2 rounded-t-lg cursor-pointer group ${
              activeTab === tab.id ? 'bg-emerald-800' : 'bg-emerald-900 opacity-70 hover:opacity-100'
            }`}
            onClick={() => { setActiveTab(tab.id); setUrl(tab.url); }}
          >
            <span className="text-xs">{tab.favicon}</span>
            <span className="text-sm max-w-32 truncate">{tab.title}</span>
            <X
              className="w-3 h-3 opacity-0 group-hover:opacity-100 hover:text-red-400"
              onClick={(e) => { e.stopPropagation(); closeTab(tab.id); }}
            />
          </div>
        ))}
        <button onClick={addTab} className="p-2 rounded-lg bg-emerald-900 hover:bg-emerald-800">
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Desktop Navigation Bar */}
      <div className="hidden md:flex bg-emerald-900 px-4 py-2 items-center gap-3 border-b border-emerald-800 shrink-0">
        <div className="flex items-center gap-1">
          <button onClick={() => logToConsole('info', 'Back navigation')} className="p-2 rounded-lg bg-emerald-800 hover:bg-emerald-700">
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button onClick={() => logToConsole('info', 'Forward navigation')} className="p-2 rounded-lg bg-emerald-800 hover:bg-emerald-700">
            <ChevronRight className="w-4 h-4" />
          </button>
          <button onClick={() => logToConsole('info', 'Page refreshed')} className="p-2 rounded-lg bg-emerald-800 hover:bg-emerald-700">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 flex items-center gap-2 bg-emerald-950 rounded-lg px-4 py-2 border border-emerald-800">
          <Lock className="w-4 h-4 text-green-400 shrink-0" />
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && navigateTo(url)}
            className="flex-1 bg-transparent outline-none text-emerald-50 text-sm"
          />
          <Search className="w-4 h-4 text-emerald-400 shrink-0" />
        </div>

        <div className="flex items-center gap-1">
          <button onClick={() => logToConsole('info', 'Bookmarked')} className="p-2 rounded-lg bg-emerald-800 hover:bg-emerald-700">
            <Star className="w-4 h-4" />
          </button>
          <button onClick={() => logToConsole('info', 'Download started')} className="p-2 rounded-lg bg-emerald-800 hover:bg-emerald-700">
            <Download className="w-4 h-4" />
          </button>
          <button onClick={() => navigateTo('https://synthia.os')} className="p-2 rounded-lg bg-emerald-800 hover:bg-emerald-700">
            <Home className="w-4 h-4" />
          </button>
          <button onClick={() => setShowDevTools(!showDevTools)} className={`p-2 rounded-lg ${showDevTools ? 'bg-green-600' : 'bg-emerald-800'} hover:bg-emerald-700`}>
            <Code className="w-4 h-4" />
          </button>
          <button onClick={() => setShowDevPack(!showDevPack)} className={`p-2 rounded-lg ${showDevPack ? 'bg-green-600' : 'bg-emerald-800'} hover:bg-emerald-700`}>
            <Package className="w-4 h-4" />
          </button>
          <button onClick={() => setShowMCPMobile(!showMCPMobile)} className={`p-2 rounded-lg ${showMCPMobile ? 'bg-green-600' : 'bg-emerald-800'} hover:bg-emerald-700`}>
            <Smartphone className="w-4 h-4" />
          </button>
          <button onClick={() => setShowGitHub(!showGitHub)} className={`p-2 rounded-lg ${showGitHub ? 'bg-green-600' : 'bg-emerald-800'} hover:bg-emerald-700`}>
            <GitBranch className="w-4 h-4" />
          </button>
          <button onClick={() => setShowSelfEdit(!showSelfEdit)} className={`p-2 rounded-lg ${showSelfEdit ? 'bg-green-600' : 'bg-emerald-800'} hover:bg-emerald-700`}>
            <Wand2 className="w-4 h-4" />
          </button>
          <button onClick={() => setShowAgent(!showAgent)} className={`p-2 rounded-lg ${showAgent ? 'bg-green-600' : 'bg-emerald-800'} hover:bg-emerald-700`}>
            <Bot className="w-4 h-4" />
          </button>
          <button onClick={() => setShowMenu(!showMenu)} className="p-2 rounded-lg bg-emerald-800 hover:bg-emerald-700">
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ═══ MAIN CONTENT GRID ═══════════════════════════════════════════════ */}
      <div className="flex-1 overflow-hidden">
        <div className={`h-full grid gap-px bg-emerald-800/30 ${
          visiblePanels.length === 1 ? 'grid-cols-1 grid-rows-1' :
          visiblePanels.length === 2 ? 'grid-cols-2 grid-rows-1' :
          visiblePanels.length === 3 ? 'grid-cols-2 grid-rows-2' :
          visiblePanels.length === 4 ? 'grid-cols-2 grid-rows-2' :
          visiblePanels.length >= 5 ? 'grid-cols-3 grid-rows-2' :
          'grid-cols-2 grid-rows-2'
        }`}>

          {/* ── PANEL: Browser ─────────────────────────────────────────────── */}
          {activePanels.browser && (
            <div className="bg-emerald-950 flex flex-col overflow-hidden min-h-0">
              <div className="bg-emerald-900 px-3 py-1.5 text-xs font-semibold border-b border-emerald-800 flex items-center justify-between shrink-0">
                <span className="flex items-center gap-2">
                  <Globe className="w-3 h-3" />
                  BROWSER
                </span>
                <span className="text-emerald-500 text-[10px]">{tabs.find(t => t.id === activeTab)?.title || 'Loading...'}</span>
              </div>
              <div className="flex-1 overflow-auto p-4">
                <div className="max-w-full bg-emerald-900/50 rounded-lg p-4 md:p-8 border border-emerald-800/50">
                  <h1 className="text-2xl md:text-4xl font-bold mb-4 text-emerald-400">Welcome to Synthia</h1>
                  <p className="text-emerald-300 mb-6 text-sm md:text-base">
                    The self-editing, self-growing browser organism. Type an intent in the console or chat with the agent.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div className="bg-emerald-800/50 p-4 rounded-lg border border-emerald-700/50 hover:border-emerald-500/50 transition-colors">
                      <div className="flex items-center gap-2 mb-2">
                        <Brain className="w-5 h-5 text-emerald-400" />
                        <h3 className="font-bold text-emerald-200">Intent Engine</h3>
                      </div>
                      <p className="text-xs text-emerald-400">Parse natural language into executable actions. Confidence: {(intentConfidence * 100).toFixed(0)}%</p>
                    </div>
                    <div className="bg-emerald-800/50 p-4 rounded-lg border border-emerald-700/50 hover:border-emerald-500/50 transition-colors">
                      <div className="flex items-center gap-2 mb-2">
                        <Wand2 className="w-5 h-5 text-emerald-400" />
                        <h3 className="font-bold text-emerald-200">Self-Edit Engine</h3>
                      </div>
                      <p className="text-xs text-emerald-400">Modify code, learn from outcomes, grow capabilities. Confidence threshold: {selfEditConfidence.toFixed(2)}</p>
                    </div>
                    <div className="bg-emerald-800/50 p-4 rounded-lg border border-emerald-700/50 hover:border-emerald-500/50 transition-colors">
                      <div className="flex items-center gap-2 mb-2">
                        <Smartphone className="w-5 h-5 text-emerald-400" />
                        <h3 className="font-bold text-emerald-200">MCP Mobile</h3>
                      </div>
                      <p className="text-xs text-emerald-400">Control iOS/Android devices remotely. {mcpConnected ? `${mcpDevices.length} devices connected` : 'Standby'}</p>
                    </div>
                    <div className="bg-emerald-800/50 p-4 rounded-lg border border-emerald-700/50 hover:border-emerald-500/50 transition-colors">
                      <div className="flex items-center gap-2 mb-2">
                        <GitBranch className="w-5 h-5 text-emerald-400" />
                        <h3 className="font-bold text-emerald-200">GitHub Bestie</h3>
                      </div>
                      <p className="text-xs text-emerald-400">Learn from repos, commit changes, create PRs. {githubConnected ? `${githubRepos.length} repos loaded` : 'Not connected'}</p>
                    </div>
                  </div>

                  {selfEditNarrative && (
                    <div className="bg-emerald-800/30 p-3 rounded-lg border border-emerald-600/30 mb-4">
                      <div className="flex items-center gap-2 mb-1">
                        <Sparkles className="w-4 h-4 text-yellow-400" />
                        <span className="text-xs font-semibold text-yellow-400">Synthia Narrative</span>
                      </div>
                      <p className="text-xs text-emerald-300 italic">{selfEditNarrative}</p>
                    </div>
                  )}

                  <div className="flex gap-2 flex-wrap">
                    <button onClick={() => { setShowAgent(true); setAgentInput('help'); }} className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg text-white text-sm flex items-center gap-2">
                      <Bot className="w-4 h-4" />
                      Ask Agent
                    </button>
                    <button onClick={() => { setShowMCPMobile(true); }} className="bg-emerald-800 hover:bg-emerald-700 px-4 py-2 rounded-lg text-sm flex items-center gap-2">
                      <Smartphone className="w-4 h-4" />
                      Mobile Control
                    </button>
                    <button onClick={() => { setShowGitHub(true); }} className="bg-emerald-800 hover:bg-emerald-700 px-4 py-2 rounded-lg text-sm flex items-center gap-2">
                      <GitBranch className="w-4 h-4" />
                      GitHub
                    </button>
                    <button onClick={() => { setShowSelfEdit(true); }} className="bg-emerald-800 hover:bg-emerald-700 px-4 py-2 rounded-lg text-sm flex items-center gap-2">
                      <Wand2 className="w-4 h-4" />
                      Self-Edit
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── PANEL: DevTools ──────────────────────────────────────────────── */}
          {activePanels.devtools && (
            <div className="bg-emerald-950 flex flex-col overflow-hidden min-h-0">
              <div className="bg-emerald-900 px-3 py-1.5 flex items-center gap-1 border-b border-emerald-800 overflow-x-auto shrink-0">
                {['console', 'elements', 'network', 'agent'].map(tab => (
                  <button
                    key={tab}
                    onClick={() => setActiveDevTab(tab)}
                    className={`px-2 py-1 rounded text-xs whitespace-nowrap flex items-center gap-1 ${activeDevTab === tab ? 'bg-green-600' : 'bg-emerald-800 hover:bg-emerald-700'}`}
                  >
                    {tab === 'console' && <Terminal className="w-3 h-3" />}
                    {tab === 'elements' && <Layers className="w-3 h-3" />}
                    {tab === 'network' && <Wifi className="w-3 h-3" />}
                    {tab === 'agent' && <Bot className="w-3 h-3" />}
                    {tab.charAt(0).toUpperCase() + tab.slice(1)}
                  </button>
                ))}
              </div>

              <div className="flex-1 overflow-hidden flex flex-col">
                {activeDevTab === 'console' && (
                  <div className="flex-1 flex flex-col overflow-hidden">
                    <div className="flex-1 overflow-auto p-2 font-mono">
                      {consoleLogs.map((log, i) => renderConsoleLog(log, i))}
                      <div ref={consoleEndRef} />
                    </div>
                    <div className="border-t border-emerald-800 p-2 flex items-center gap-2 shrink-0">
                      <span className="text-emerald-500 text-xs font-mono">&gt;</span>
                      <input
                        type="text"
                        value={consoleInput}
                        onChange={(e) => setConsoleInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && executeConsoleCommand()}
                        className="flex-1 bg-transparent outline-none text-xs font-mono text-emerald-200"
                        placeholder="Type an intent (e.g., 'go to github', 'screenshot', 'grow new feature')..."
                      />
                      <button onClick={executeConsoleCommand} className="p-1 rounded bg-emerald-800 hover:bg-emerald-700">
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                )}

                {activeDevTab === 'elements' && (
                  <div className="flex-1 overflow-auto p-3 font-mono text-xs">
                    {renderDomTree(domTree)}
                  </div>
                )}

                {activeDevTab === 'network' && (
                  <div className="flex-1 overflow-auto p-2">
                    <div className="flex items-center gap-2 mb-2 text-xs text-emerald-500">
                      <span className="w-8">Status</span>
                      <span className="flex-1">URL</span>
                      <span className="w-16 text-right">Size</span>
                      <span className="w-12 text-right">Time</span>
                      <span className="w-16 text-right">Type</span>
                    </div>
                    {networkRequests.map((req, i) => renderNetworkRequest(req, i))}
                  </div>
                )}

                {activeDevTab === 'agent' && (
                  <div className="flex-1 flex flex-col overflow-hidden">
                    <div className="flex-1 overflow-auto p-3 space-y-3">
                      {agentMessages.map((msg, i) => (
                        <div key={i} className={`flex gap-2 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs shrink-0 ${
                            msg.role === 'user' ? 'bg-green-600' : msg.role === 'system' ? 'bg-emerald-700' : 'bg-emerald-600'
                          }`}>
                            {msg.role === 'user' ? 'U' : msg.role === 'system' ? 'S' : 'A'}
                          </div>
                          <div className={`max-w-[80%] p-3 rounded-lg text-xs ${
                            msg.role === 'user' ? 'bg-green-800/50 text-emerald-100' : 'bg-emerald-800/50 text-emerald-200'
                          }`}>
                            <div className="whitespace-pre-wrap">{msg.content}</div>
                            <div className="text-[10px] text-emerald-600 mt-1">{new Date(msg.timestamp).toLocaleTimeString()}</div>
                          </div>
                        </div>
                      ))}
                      {agentTyping && (
                        <div className="flex gap-2">
                          <div className="w-6 h-6 rounded-full bg-emerald-600 flex items-center justify-center text-xs shrink-0">A</div>
                          <div className="bg-emerald-800/50 p-3 rounded-lg">
                            <Loader2 className="w-4 h-4 animate-spin text-emerald-400" />
                          </div>
                        </div>
                      )}
                      <div ref={agentEndRef} />
                    </div>
                    <div className="border-t border-emerald-800 p-2 flex items-center gap-2 shrink-0">
                      <select 
                        value={agentMode} 
                        onChange={(e) => setAgentMode(e.target.value)}
                        className="bg-emerald-800 text-xs rounded px-2 py-1 outline-none border border-emerald-700"
                      >
                        <option value="general">General</option>
                        <option value="code">Code</option>
                        <option value="test">Test</option>
                        <option value="deploy">Deploy</option>
                        <option value="mobile">Mobile</option>
                        <option value="github">GitHub</option>
                        <option value="selfedit">Self-Edit</option>
                      </select>
                      <input
                        type="text"
                        value={agentInput}
                        onChange={(e) => setAgentInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && sendAgentMessage()}
                        className="flex-1 bg-transparent outline-none text-xs text-emerald-200"
                        placeholder="Ask the agent anything..."
                      />
                      <button onClick={sendAgentMessage} className="p-1.5 rounded bg-green-600 hover:bg-green-700">
                        <Send className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── PANEL: DevPack ─────────────────────────────────────────────── */}
          {activePanels.devpack && (
            <div className="bg-emerald-950 flex flex-col overflow-hidden min-h-0">
              <div className="bg-emerald-900 px-3 py-1.5 flex items-center gap-1 border-b border-emerald-800 overflow-x-auto shrink-0">
                {[
                  { id: 'templates', icon: FileText, label: 'Templates' },
                  { id: 'snippets', icon: Terminal, label: 'Snippets' },
                  { id: 'packages', icon: Database, label: 'Packages' },
                  { id: 'git', icon: GitBranch, label: 'Git' },
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveDevPackTab(tab.id)}
                    className={`px-2 py-1 rounded text-xs whitespace-nowrap flex items-center gap-1 ${activeDevPackTab === tab.id ? 'bg-green-600' : 'bg-emerald-800 hover:bg-emerald-700'}`}
                  >
                    <tab.icon className="w-3 h-3" />
                    {tab.label}
                  </button>
                ))}
              </div>

              <div className="flex-1 overflow-auto p-3">
                {activeDevPackTab === 'templates' && (
                  <div className="space-y-2">
                    {templates.map(t => (
                      <div key={t.id} className="bg-emerald-800/50 p-3 rounded-lg border border-emerald-700/50 hover:border-emerald-500/50 cursor-pointer group">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-sm text-emerald-200">{t.name}</span>
                          <span className="text-[10px] bg-emerald-900 px-2 py-0.5 rounded text-emerald-400">{t.type}</span>
                        </div>
                        <p className="text-xs text-emerald-400 mb-2">{t.desc}</p>
                        <pre className="text-[10px] font-mono text-emerald-500 bg-emerald-950/50 p-2 rounded overflow-x-auto opacity-0 group-hover:opacity-100 transition-opacity">
                          {t.code.slice(0, 100)}...
                        </pre>
                      </div>
                    ))}
                  </div>
                )}

                {activeDevPackTab === 'snippets' && (
                  <div className="space-y-2">
                    {snippets.map(s => (
                      <div key={s.id} className="bg-emerald-800/50 p-3 rounded-lg border border-emerald-700/50 hover:border-emerald-500/50 cursor-pointer group">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-xs text-emerald-200">{s.name}</span>
                          <span className="text-[10px] bg-emerald-900 px-2 py-0.5 rounded text-emerald-400">{s.lang}</span>
                        </div>
                        <code className="text-xs font-mono text-emerald-300 block">{s.code}</code>
                        <button className="mt-2 text-[10px] bg-emerald-900 hover:bg-emerald-800 px-2 py-1 rounded text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity">
                          Copy to clipboard
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {activeDevPackTab === 'packages' && (
                  <div className="space-y-2">
                    {packages.map(p => (
                      <div key={p.name} className="bg-emerald-800/50 p-3 rounded-lg border border-emerald-700/50 flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-emerald-200">{p.name}</span>
                            <span className="text-xs text-green-400">{p.version}</span>
                          </div>
                          <p className="text-xs text-emerald-400">{p.desc}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-emerald-600">{p.size}</span>
                          <button className={`px-2 py-1 rounded text-xs ${p.installed ? 'bg-green-600/50 text-green-400' : 'bg-emerald-700 hover:bg-emerald-600 text-emerald-200'}`}>
                            {p.installed ? 'Installed' : 'Install'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {activeDevPackTab === 'git' && (
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-xs">
                      <GitBranch className="w-4 h-4 text-emerald-400" />
                      <span className="font-mono text-emerald-200">{gitStatus.branch}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] ${gitStatus.status === 'clean' ? 'bg-green-600/30 text-green-400' : 'bg-yellow-600/30 text-yellow-400'}`}>
                        {gitStatus.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button onClick={() => logToConsole('info', 'git pull executed')} className="bg-emerald-800 hover:bg-emerald-700 px-3 py-2 rounded text-xs flex items-center gap-2">
                        <Download className="w-3 h-3" /> Pull
                      </button>
                      <button onClick={() => logToConsole('info', 'git push executed')} className="bg-emerald-800 hover:bg-emerald-700 px-3 py-2 rounded text-xs flex items-center gap-2">
                        <Upload className="w-3 h-3" /> Push
                      </button>
                      <button onClick={() => logToConsole('info', 'git commit executed')} className="bg-emerald-800 hover:bg-emerald-700 px-3 py-2 rounded text-xs flex items-center gap-2">
                        <GitCommit className="w-3 h-3" /> Commit
                      </button>
                      <button onClick={() => logToConsole('info', 'git branch executed')} className="bg-emerald-800 hover:bg-emerald-700 px-3 py-2 rounded text-xs flex items-center gap-2">
                        <GitFork className="w-3 h-3" /> Branch
                      </button>
                    </div>

                    <div className="text-xs text-emerald-500 font-mono">
                      <div>On branch {gitStatus.branch}</div>
                      <div>Your branch is up to date with 'origin/{gitStatus.branch}'.</div>
                      <div className="mt-2">nothing to commit, working tree clean</div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── PANEL: MCP Mobile ────────────────────────────────────────────── */}
          {activePanels.mcpmobile && showMCPMobile && (
            <div className="bg-emerald-950 flex flex-col overflow-hidden min-h-0">
              <div className="bg-emerald-900 px-3 py-1.5 flex items-center justify-between border-b border-emerald-800 shrink-0">
                <span className="flex items-center gap-2 text-xs font-semibold">
                  <Smartphone className="w-3 h-3" />
                  MCP MOBILE
                </span>
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${mcpConnected ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
                  <span className="text-[10px] text-emerald-500">{mcpConnected ? 'Connected' : 'Disconnected'}</span>
                </div>
              </div>

              <div className="flex-1 overflow-hidden flex flex-col">
                {/* Device Selection */}
                <div className="p-3 border-b border-emerald-800/50">
                  <div className="flex items-center gap-2 mb-2">
                    <button 
                      onClick={mcpConnected ? handleMCPDisconnect : handleMCPConnect}
                      className={`px-3 py-1 rounded text-xs ${mcpConnected ? 'bg-red-600/50 hover:bg-red-600 text-red-200' : 'bg-green-600 hover:bg-green-700 text-white'}`}
                    >
                      {mcpConnected ? 'Disconnect' : 'Connect'}
                    </button>
                    <span className="text-xs text-emerald-400">{mcpActiveDevice ? mcpActiveDevice.name : 'No device selected'}</span>
                  </div>

                  {mcpConnected && (
                    <div className="grid grid-cols-2 gap-2">
                      {mcpDevices.map(device => (
                        <button
                          key={device.id}
                          onClick={() => handleMCPSelectDevice(device.id)}
                          className={`p-2 rounded text-xs text-left border ${
                            mcpActiveDevice?.id === device.id 
                              ? 'border-green-500 bg-green-900/30' 
                              : 'border-emerald-700 bg-emerald-800/30 hover:bg-emerald-800/50'
                          }`}
                        >
                          <div className="flex items-center gap-1">
                            {device.platform === 'ios' ? <Smartphone className="w-3 h-3" /> : <Tablet className="w-3 h-3" />}
                            <span className="font-semibold">{device.name}</span>
                          </div>
                          <div className="text-emerald-500 text-[10px]">{device.type} • {device.platform}</div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Tool Categories */}
                <div className="flex-1 overflow-auto p-3">
                  <div className="flex gap-1 mb-3 overflow-x-auto">
                    {Object.keys(MCP_MOBILE_TOOLS).map(cat => (
                      <button
                        key={cat}
                        onClick={() => setMcpActiveTool(cat)}
                        className={`px-2 py-1 rounded text-[10px] whitespace-nowrap capitalize ${
                          mcpActiveTool === cat ? 'bg-green-600' : 'bg-emerald-800 hover:bg-emerald-700'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>

                  <div className="space-y-2">
                    {Object.entries(MCP_MOBILE_TOOLS[mcpActiveTool] || {}).map(([toolName, toolInfo]) => (
                      <div key={toolName} className="bg-emerald-800/30 p-2 rounded border border-emerald-700/30">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-mono text-emerald-200">{toolName}</span>
                          <button 
                            onClick={() => executeMCPTool(toolName, {})}
                            disabled={!mcpConnected || !mcpActiveDevice}
                            className="px-2 py-0.5 rounded text-[10px] bg-green-600/50 hover:bg-green-600 disabled:opacity-30 disabled:cursor-not-allowed"
                          >
                            Execute
                          </button>
                        </div>
                        <p className="text-[10px] text-emerald-500">{toolInfo.desc}</p>
                      </div>
                    ))}
                  </div>

                  {/* Session Log */}
                  {mcpSessionLog.length > 0 && (
                    <div className="mt-4">
                      <h4 className="text-xs font-semibold text-emerald-300 mb-2">Session Log</h4>
                      <div className="space-y-1 max-h-32 overflow-auto">
                        {mcpSessionLog.slice(-10).map((log, i) => (
                          <div key={i} className="text-[10px] font-mono text-emerald-500">
                            <span className="text-emerald-700">{new Date(log.timestamp).toLocaleTimeString()}</span>
                            {' '}{log.type}: {log.tool || log.status}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Screenshot Preview */}
                  {mcpScreenshot && (
                    <div className="mt-4">
                      <h4 className="text-xs font-semibold text-emerald-300 mb-2">Last Screenshot</h4>
                      <div className="bg-emerald-900/50 rounded border border-emerald-700/50 p-2">
                        <div className="aspect-[9/16] bg-emerald-950 rounded flex items-center justify-center">
                          <span className="text-xs text-emerald-600">Screenshot preview</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ── PANEL: GitHub Bestie ───────────────────────────────────────── */}
          {activePanels.github && showGitHub && (
            <div className="bg-emerald-950 flex flex-col overflow-hidden min-h-0">
              <div className="bg-emerald-900 px-3 py-1.5 flex items-center justify-between border-b border-emerald-800 shrink-0">
                <span className="flex items-center gap-2 text-xs font-semibold">
                  <GitBranch className="w-3 h-3" />
                  GITHUB BESTIE
                </span>
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${githubConnected ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
                  <span className="text-[10px] text-emerald-500">{githubConnected ? 'Connected' : 'Disconnected'}</span>
                </div>
              </div>

              <div className="flex-1 overflow-hidden flex flex-col">
                {/* Auth */}
                {!githubConnected && (
                  <div className="p-3 border-b border-emerald-800/50">
                    <div className="flex items-center gap-2">
                      <input
                        type="password"
                        value={githubToken}
                        onChange={(e) => setGithubToken(e.target.value)}
                        placeholder="GitHub Personal Access Token"
                        className="flex-1 bg-emerald-950 border border-emerald-700 rounded px-2 py-1 text-xs outline-none focus:border-green-500"
                      />
                      <button 
                        onClick={handleGitHubConnect}
                        className="px-3 py-1 rounded text-xs bg-green-600 hover:bg-green-700 text-white"
                      >
                        Connect
                      </button>
                    </div>
                  </div>
                )}

                {/* Tabs */}
                <div className="flex gap-1 p-2 border-b border-emerald-800/50 overflow-x-auto">
                  {['repos', 'files', 'commits', 'prs', 'activity', 'learn'].map(tab => (
                    <button
                      key={tab}
                      onClick={() => setGithubActiveTab(tab)}
                      className={`px-2 py-1 rounded text-[10px] whitespace-nowrap capitalize ${
                        githubActiveTab === tab ? 'bg-green-600' : 'bg-emerald-800 hover:bg-emerald-700'
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>

                <div className="flex-1 overflow-auto p-3">
                  {githubActiveTab === 'repos' && (
                    <div className="space-y-2">
                      {githubRepos.map(repo => (
                        <div 
                          key={repo.name} 
                          onClick={() => setGithubActiveRepo(repo)}
                          className={`p-3 rounded border cursor-pointer ${
                            githubActiveRepo?.name === repo.name 
                              ? 'border-green-500 bg-green-900/20' 
                              : 'border-emerald-700/50 bg-emerald-800/30 hover:bg-emerald-800/50'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold text-sm text-emerald-200">{repo.name}</span>
                            <span className="text-[10px] bg-emerald-900 px-2 py-0.5 rounded text-emerald-400">{repo.language}</span>
                          </div>
                          <div className="flex items-center gap-3 text-[10px] text-emerald-500">
                            <span className="flex items-center gap-1"><Star className="w-3 h-3" /> {repo.stars}</span>
                            <span className="flex items-center gap-1"><GitFork className="w-3 h-3" /> {repo.forks}</span>
                            <span>Updated {repo.updated}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {githubActiveTab === 'learn' && (
                    <div className="space-y-3">
                      <div className="bg-emerald-800/30 p-3 rounded border border-emerald-700/50">
                        <h4 className="text-xs font-semibold text-emerald-200 mb-2">Learn from Repository</h4>
                        <p className="text-xs text-emerald-400 mb-3">
                          Synthia will analyze the selected repository's code patterns, extract best practices, 
                          and integrate them into her own code DNA.
                        </p>
                        <div className="flex items-center gap-2 mb-3">
                          <span className="text-xs text-emerald-500">Selected:</span>
                          <span className="text-xs font-mono text-emerald-300">{githubActiveRepo?.name || 'None'}</span>
                        </div>
                        <button 
                          onClick={handleGitHubLearn}
                          disabled={!githubActiveRepo}
                          className="w-full px-3 py-2 rounded text-xs bg-green-600 hover:bg-green-700 disabled:opacity-30 disabled:cursor-not-allowed text-white flex items-center justify-center gap-2"
                        >
                          <Brain className="w-3 h-3" />
                          Learn from {githubActiveRepo?.name || 'repository'}
                        </button>
                      </div>

                      {selfEditCodeDNA.length > 0 && (
                        <div>
                          <h4 className="text-xs font-semibold text-emerald-200 mb-2">Code DNA</h4>
                          <div className="space-y-1 max-h-40 overflow-auto">
                            {selfEditCodeDNA.map((dna, i) => (
                              <div key={i} className="text-[10px] font-mono text-emerald-500 bg-emerald-950/50 p-2 rounded">
                                <div className="text-emerald-400">{dna.source}</div>
                                <div className="text-emerald-600">Patterns: {dna.patterns.map(p => p.name).join(', ')}</div>
                                <div className="text-emerald-600">Quality: {(dna.quality.score * 100).toFixed(0)}%</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {githubActiveTab === 'activity' && (
                    <div className="space-y-1">
                      {githubActivity.length === 0 ? (
                        <p className="text-xs text-emerald-500 italic">No activity yet. Connect to GitHub and start working.</p>
                      ) : (
                        githubActivity.map((act, i) => (
                          <div key={i} className="text-[10px] font-mono text-emerald-500">
                            <span className="text-emerald-700">{new Date(act.timestamp).toLocaleTimeString()}</span>
                            {' '}{act.type}: {act.repo || act.path || act.message}
                          </div>
                        ))
                      )}
                    </div>
                  )}

                  {githubActiveTab === 'files' && (
                    <div className="space-y-2">
                      <p className="text-xs text-emerald-400">Select a repository to browse files.</p>
                    </div>
                  )}

                  {githubActiveTab === 'commits' && (
                    <div className="space-y-2">
                      <p className="text-xs text-emerald-400">Commit history will appear here.</p>
                    </div>
                  )}

                  {githubActiveTab === 'prs' && (
                    <div className="space-y-2">
                      <p className="text-xs text-emerald-400">Pull requests will appear here.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ── PANEL: Self-Edit Engine ──────────────────────────────────────── */}
          {activePanels.selfedit && showSelfEdit && (
            <div className="bg-emerald-950 flex flex-col overflow-hidden min-h-0">
              <div className="bg-emerald-900 px-3 py-1.5 flex items-center justify-between border-b border-emerald-800 shrink-0">
                <span className="flex items-center gap-2 text-xs font-semibold">
                  <Wand2 className="w-3 h-3" />
                  SELF-EDIT ENGINE
                </span>
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${selfEditActive ? 'bg-green-400 animate-pulse' : 'bg-yellow-400'}`} />
                  <span className="text-[10px] text-emerald-500">{selfEditActive ? 'Active' : 'Standby'}</span>
                </div>
              </div>

              <div className="flex-1 overflow-hidden flex flex-col">
                {/* Status Bar */}
                <div className="p-3 border-b border-emerald-800/50">
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="bg-emerald-800/30 p-2 rounded">
                      <div className="text-lg font-bold text-emerald-300">{selfEditHistory.length}</div>
                      <div className="text-[10px] text-emerald-500">Mutations</div>
                    </div>
                    <div className="bg-emerald-800/30 p-2 rounded">
                      <div className="text-lg font-bold text-emerald-300">{selfEditGrowthLog.length}</div>
                      <div className="text-[10px] text-emerald-500">Growth Events</div>
                    </div>
                    <div className="bg-emerald-800/30 p-2 rounded">
                      <div className="text-lg font-bold text-emerald-300">{(selfEditConfidence * 100).toFixed(0)}%</div>
                      <div className="text-[10px] text-emerald-500">Confidence</div>
                    </div>
                  </div>
                </div>

                <div className="flex-1 overflow-auto p-3 space-y-3">
                  {/* Pending Patch */}
                  {selfEditPendingPatch && (
                    <div className="bg-yellow-900/20 border border-yellow-700/50 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className="w-4 h-4 text-yellow-400" />
                        <span className="text-xs font-semibold text-yellow-400">Pending Mutation</span>
                      </div>
                      <div className="text-[10px] font-mono text-emerald-400 space-y-1 mb-3">
                        <div>Operation: <span className="text-yellow-400">{selfEditPendingPatch.operation}</span></div>
                        <div>Target: <span className="text-yellow-400">{selfEditPendingPatch.target}</span></div>
                        <div>Location: <span className="text-emerald-500">{selfEditPendingPatch.location}</span></div>
                      </div>
                      <div className="flex gap-2">
                        <button 
                          onClick={applySelfEdit}
                          className="flex-1 px-3 py-2 rounded text-xs bg-green-600 hover:bg-green-700 text-white flex items-center justify-center gap-1"
                        >
                          <CheckCircle className="w-3 h-3" /> Apply
                        </button>
                        <button 
                          onClick={rejectSelfEdit}
                          className="flex-1 px-3 py-2 rounded text-xs bg-red-600/50 hover:bg-red-600 text-red-200 flex items-center justify-center gap-1"
                        >
                          <XCircle className="w-3 h-3" /> Reject
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Narrative */}
                  {selfEditNarrative && (
                    <div className="bg-emerald-800/20 border border-emerald-700/30 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Sparkles className="w-3 h-3 text-emerald-400" />
                        <span className="text-xs font-semibold text-emerald-300">Growth Narrative</span>
                      </div>
                      <p className="text-[10px] text-emerald-400 italic">{selfEditNarrative}</p>
                    </div>
                  )}

                  {/* Mutation History */}
                  <div>
                    <h4 className="text-xs font-semibold text-emerald-300 mb-2">Mutation History</h4>
                    <div className="space-y-1 max-h-40 overflow-auto">
                      {selfEditHistory.length === 0 ? (
                        <p className="text-[10px] text-emerald-600 italic">No mutations yet. Type "grow" or "evolve" to begin.</p>
                      ) : (
                        selfEditHistory.slice().reverse().map((mut, i) => (
                          <div key={i} className={`text-[10px] font-mono p-2 rounded border ${
                            mut.result.success 
                              ? 'border-green-700/30 bg-green-900/10' 
                              : 'border-red-700/30 bg-red-900/10'
                          }`}>
                            <div className="flex items-center justify-between">
                              <span className={mut.result.success ? 'text-green-400' : 'text-red-400'}>
                                {mut.result.success ? '✅' : '❌'} {mut.id.slice(0, 20)}...
                              </span>
                              <span className="text-emerald-700">{new Date(mut.timestamp).toLocaleTimeString()}</span>
                            </div>
                            <div className="text-emerald-600 mt-1">
                              {mut.mutation.operation} → {mut.mutation.target}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Growth Log */}
                  {selfEditGrowthLog.length > 0 && (
                    <div>
                      <h4 className="text-xs font-semibold text-emerald-300 mb-2">Growth Log</h4>
                      <div className="space-y-1 max-h-32 overflow-auto">
                        {selfEditGrowthLog.slice().reverse().map((log, i) => (
                          <div key={i} className="text-[10px] font-mono text-emerald-500 bg-emerald-950/50 p-2 rounded">
                            <span className={log.type === 'success_growth' ? 'text-green-400' : 'text-yellow-400'}>
                              {log.type === 'success_growth' ? '🌱' : '📚'}
                            </span>
                            {' '}{log.type === 'success_growth' ? 'New capability:' : 'Lesson learned:'}
                            {' '}{log.newCapability?.name || log.lesson}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Quick Actions */}
                  <div className="grid grid-cols-2 gap-2">
                    <button 
                      onClick={() => handleIntent({ raw: 'grow new capability', action: 'self_edit', target: 'capability', confidence: 0.8 })}
                      className="px-3 py-2 rounded text-xs bg-emerald-800 hover:bg-emerald-700 text-emerald-200 flex items-center justify-center gap-1"
                    >
                      <Wand2 className="w-3 h-3" /> Grow
                    </button>
                    <button 
                      onClick={() => handleIntent({ raw: 'learn from github', action: 'self_edit', target: 'github', confidence: 0.8 })}
                      className="px-3 py-2 rounded text-xs bg-emerald-800 hover:bg-emerald-700 text-emerald-200 flex items-center justify-center gap-1"
                    >
                      <Brain className="w-3 h-3" /> Learn
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── PANEL: Agent Chat ──────────────────────────────────────────── */}
          {activePanels.agent && showAgent && (
            <div className="bg-emerald-950 flex flex-col overflow-hidden min-h-0">
              <div className="bg-emerald-900 px-3 py-1.5 flex items-center justify-between border-b border-emerald-800 shrink-0">
                <span className="flex items-center gap-2 text-xs font-semibold">
                  <Bot className="w-3 h-3" />
                  AGENT
                </span>
                <div className="flex items-center gap-1">
                  <span className="text-[10px] text-emerald-500">Mode: {agentMode}</span>
                </div>
              </div>

              <div className="flex-1 overflow-hidden flex flex-col">
                <div className="flex-1 overflow-auto p-3 space-y-3">
                  {agentMessages.map((msg, i) => (
                    <div key={i} className={`flex gap-2 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs shrink-0 ${
                        msg.role === 'user' ? 'bg-green-600' : msg.role === 'system' ? 'bg-emerald-700' : 'bg-emerald-600'
                      }`}>
                        {msg.role === 'user' ? 'U' : msg.role === 'system' ? 'S' : 'A'}
                      </div>
                      <div className={`max-w-[85%] p-3 rounded-lg text-xs ${
                        msg.role === 'user' ? 'bg-green-800/50 text-emerald-100' : 'bg-emerald-800/50 text-emerald-200'
                      }`}>
                        <div className="whitespace-pre-wrap">{msg.content}</div>
                        <div className="text-[10px] text-emerald-600 mt-1">{new Date(msg.timestamp).toLocaleTimeString()}</div>
                      </div>
                    </div>
                  ))}
                  {agentTyping && (
                    <div className="flex gap-2">
                      <div className="w-6 h-6 rounded-full bg-emerald-600 flex items-center justify-center text-xs shrink-0">A</div>
                      <div className="bg-emerald-800/50 p-3 rounded-lg">
                        <Loader2 className="w-4 h-4 animate-spin text-emerald-400" />
                      </div>
                    </div>
                  )}
                  <div ref={agentEndRef} />
                </div>

                <div className="border-t border-emerald-800 p-2 flex items-center gap-2 shrink-0">
                  <select 
                    value={agentMode} 
                    onChange={(e) => setAgentMode(e.target.value)}
                    className="bg-emerald-800 text-xs rounded px-2 py-1.5 outline-none border border-emerald-700 shrink-0"
                  >
                    <option value="general">General</option>
                    <option value="code">Code</option>
                    <option value="test">Test</option>
                    <option value="deploy">Deploy</option>
                    <option value="mobile">Mobile</option>
                    <option value="github">GitHub</option>
                    <option value="selfedit">Self-Edit</option>
                  </select>
                  <input
                    type="text"
                    value={agentInput}
                    onChange={(e) => setAgentInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && sendAgentMessage()}
                    className="flex-1 bg-transparent outline-none text-xs text-emerald-200"
                    placeholder="Ask the agent anything..."
                  />
                  <button onClick={sendAgentMessage} className="p-1.5 rounded bg-green-600 hover:bg-green-700 shrink-0">
                    <Send className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ── PANEL: Settings ──────────────────────────────────────────────── */}
          {activePanels.settings && (
            <div className="bg-emerald-950 flex flex-col overflow-hidden min-h-0">
              <div className="bg-emerald-900 px-3 py-1.5 text-xs font-semibold border-b border-emerald-800 shrink-0 flex items-center gap-2">
                <Settings className="w-3 h-3" />
                SETTINGS
              </div>

              <div className="flex-1 overflow-auto p-3 space-y-4">
                {/* Quick Actions */}
                <div>
                  <h3 className="text-xs font-semibold text-emerald-300 mb-2">Quick Actions</h3>
                  <div className="space-y-1.5">
                    <button onClick={() => logToConsole('info', 'Added to home screen')} className="w-full bg-emerald-800/50 hover:bg-emerald-800 px-3 py-2 rounded text-xs text-emerald-200 flex items-center gap-2">
                      <Home className="w-3 h-3" /> Add to Home Screen
                    </button>
                    <button onClick={() => { setConsoleLogs([]); logToConsole('info', 'Console cleared'); }} className="w-full bg-emerald-800/50 hover:bg-emerald-800 px-3 py-2 rounded text-xs text-emerald-200 flex items-center gap-2">
                      <Trash2 className="w-3 h-3" /> Clear Console
                    </button>
                    <button onClick={() => logToConsole('info', 'Bookmarks exported')} className="w-full bg-emerald-800/50 hover:bg-emerald-800 px-3 py-2 rounded text-xs text-emerald-200 flex items-center gap-2">
                      <Download className="w-3 h-3" /> Export Bookmarks
                    </button>
                  </div>
                </div>

                {/* Panel Toggles */}
                <div>
                  <h3 className="text-xs font-semibold text-emerald-300 mb-2 flex items-center gap-2">
                    <Layout className="w-3 h-3" />
                    Panels
                  </h3>
                  <div className="space-y-1.5 text-xs">
                    {[
                      { key: 'browser', label: 'Browser', icon: Globe },
                      { key: 'devtools', label: 'DevTools', icon: Code },
                      { key: 'devpack', label: 'DevPack', icon: Package },
                      { key: 'mcpmobile', label: 'MCP Mobile', icon: Smartphone },
                      { key: 'github', label: 'GitHub', icon: GitBranch },
                      { key: 'selfedit', label: 'Self-Edit', icon: Wand2 },
                      { key: 'agent', label: 'Agent', icon: Bot },
                      { key: 'settings', label: 'Settings', icon: Settings },
                    ].map(({ key, label, icon: Icon }) => (
                      <label key={key} className="flex items-center gap-2 cursor-pointer hover:bg-emerald-800/30 p-1 rounded">
                        <input 
                          type="checkbox" 
                          checked={activePanels[key]} 
                          onChange={() => togglePanel(key)}
                          className="accent-green-500"
                        />
                        <Icon className="w-3 h-3 text-emerald-400" />
                        <span>{label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Developer Options */}
                <div>
                  <h3 className="text-xs font-semibold text-emerald-300 mb-2 flex items-center gap-2">
                    <Wrench className="w-3 h-3" />
                    Developer
                  </h3>
                  <div className="space-y-1.5 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer hover:bg-emerald-800/30 p-1 rounded">
                      <input type="checkbox" checked={enableSourceMaps} onChange={() => setEnableSourceMaps(!enableSourceMaps)} className="accent-green-500" />
                      <span>Enable Source Maps</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer hover:bg-emerald-800/30 p-1 rounded">
                      <input type="checkbox" checked={autoReload} onChange={() => setAutoReload(!autoReload)} className="accent-green-500" />
                      <span>Auto-reload on Change</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer hover:bg-emerald-800/30 p-1 rounded">
                      <input type="checkbox" checked={showLineNumbers} onChange={() => setShowLineNumbers(!showLineNumbers)} className="accent-green-500" />
                      <span>Show Line Numbers</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer hover:bg-emerald-800/30 p-1 rounded">
                      <input type="checkbox" checked={wordWrap} onChange={() => setWordWrap(!wordWrap)} className="accent-green-500" />
                      <span>Word Wrap</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer hover:bg-emerald-800/30 p-1 rounded">
                      <input type="checkbox" checked={experimentalFeatures} onChange={() => setExperimentalFeatures(!experimentalFeatures)} className="accent-green-500" />
                      <span>Experimental Features (Self-Edit, MCP)</span>
                    </label>
                  </div>
                </div>

                {/* System Info */}
                <div>
                  <h3 className="text-xs font-semibold text-emerald-300 mb-2">System Info</h3>
                  <div className="bg-emerald-800/30 p-3 rounded space-y-1.5 text-xs font-mono">
                    <div className="flex justify-between">
                      <span className="text-emerald-500">Version</span>
                      <span>2.0.0-synthia</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-emerald-500">Platform</span>
                      <span>Cross-Platform / Termux</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-emerald-500">Theme</span>
                      <span className="capitalize">{theme}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-emerald-500">Intent Engine</span>
                      <span>{intentHistory.length} intents parsed</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-emerald-500">Mutations</span>
                      <span>{selfEditHistory.length} applied</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-emerald-500">MCP Bridge</span>
                      <span>{mcpConnected ? 'Connected' : 'Standby'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-emerald-500">GitHub</span>
                      <span>{githubConnected ? 'Connected' : 'Standby'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ═══ MOBILE MENU OVERLAY ═══════════════════════════════════════════ */}
      {showMenu && (
        <div className="md:hidden fixed inset-0 bg-emerald-950/95 z-50 p-6 overflow-auto">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-emerald-200">Synthia Settings</h2>
            <button onClick={() => setShowMenu(false)} className="p-2 hover:bg-emerald-800 rounded-lg">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-semibold text-emerald-300 mb-2">Panels</h3>
              <div className="space-y-2">
                {[
                  { key: 'devtools', label: 'DevTools', state: showDevTools, setter: setShowDevTools },
                  { key: 'devpack', label: 'DevPack', state: showDevPack, setter: setShowDevPack },
                  { key: 'mcpmobile', label: 'MCP Mobile', state: showMCPMobile, setter: setShowMCPMobile },
                  { key: 'github', label: 'GitHub', state: showGitHub, setter: setShowGitHub },
                  { key: 'selfedit', label: 'Self-Edit', state: showSelfEdit, setter: setShowSelfEdit },
                  { key: 'agent', label: 'Agent', state: showAgent, setter: setShowAgent },
                ].map(({ key, label, state, setter }) => (
                  <label key={key} className="flex items-center gap-3">
                    <input type="checkbox" checked={state} onChange={() => setter(!state)} className="accent-green-500" />
                    <span>{label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="border-t border-emerald-800 pt-4">
              <h3 className="text-sm font-semibold text-emerald-300 mb-2">Actions</h3>
              <button onClick={() => { logToConsole('info', 'Console cleared'); setConsoleLogs([]); }} className="w-full bg-emerald-800 px-4 py-3 rounded-lg mb-2">Clear Console</button>
              <button onClick={() => logToConsole('info', 'Bookmarks exported')} className="w-full bg-emerald-800 px-4 py-3 rounded-lg mb-2">Export Bookmarks</button>
              <button onClick={() => { setShowMenu(false); setShowAgent(true); }} className="w-full bg-green-600 px-4 py-3 rounded-lg text-white">Open Agent</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SynthiaBrowser;
