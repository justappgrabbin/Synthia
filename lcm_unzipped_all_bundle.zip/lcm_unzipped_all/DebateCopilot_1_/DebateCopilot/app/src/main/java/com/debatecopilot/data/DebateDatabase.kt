package com.debatecopilot.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.OnConflictStrategy
import androidx.room.Entity
import androidx.room.PrimaryKey

@Database(entities = [CachedResearch::class], version = 1)
abstract class DebateDatabase : RoomDatabase() {
    abstract fun researchDao(): ResearchDao

    companion object {
        @Volatile private var INSTANCE: DebateDatabase? = null

        fun getDatabase(context: Context): DebateDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    DebateDatabase::class.java,
                    "debate_copilot_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}

@Dao
interface ResearchDao {
    @Query("SELECT * FROM cached_research WHERE topic = :topic LIMIT 1")
    suspend fun getByTopic(topic: String): CachedResearch?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(research: CachedResearch)

    @Query("DELETE FROM cached_research WHERE timestamp < :cutoff")
    suspend fun clearOld(cutoff: Long)
}

@Entity(tableName = "cached_research")
data class CachedResearch(
    @PrimaryKey val topic: String,
    val resultJson: String,
    val timestamp: Long = System.currentTimeMillis()
)
