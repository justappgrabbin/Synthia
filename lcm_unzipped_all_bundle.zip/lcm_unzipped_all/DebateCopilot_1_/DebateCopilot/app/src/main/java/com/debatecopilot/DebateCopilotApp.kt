package com.debatecopilot

import android.app.Application
import android.content.Context
import com.debatecopilot.data.DebateDatabase
import com.debatecopilot.data.PositionProfile
import com.debatecopilot.research.ResearchCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class DebateCopilotApp : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var database: DebateDatabase
        private set

    lateinit var positionProfile: PositionProfile
        private set

    lateinit var researchCache: ResearchCache
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = DebateDatabase.getDatabase(this)
        positionProfile = PositionProfile(this)
        researchCache = ResearchCache(this)
    }

    companion object {
        lateinit var instance: DebateCopilotApp
            private set

        fun getContext(): Context = instance.applicationContext
    }
}
