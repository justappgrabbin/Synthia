package com.debatecopilot.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*

/**
 * TikTokReaderService — reads the TikTok UI tree in real-time using Accessibility API.
 * This captures comments, captions, live chat, and any text visible on screen.
 * No screenshots needed — Android hands us the text directly.
 */
class TikTokReaderService : AccessibilityService() {

    companion object {
        const val TAG = "TikTokReader"
        var lastCapturedText = ""
            private set
        var onTextCaptured: ((String) -> Unit)? = null
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var lastDebounceTime = 0L
    private val DEBOUNCE_MS = 800L

    override fun onServiceConnected() {
        super.onServiceConnected()

        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                        AccessibilityEvent.TYPE_VIEW_CLICKED or
                        AccessibilityEvent.TYPE_VIEW_FOCUSED or
                        AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED or
                        AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                    AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 100
        }
        serviceInfo = info

        Log.d(TAG, "TikTok Reader Service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val packageName = event.packageName?.toString() ?: return

        // We only care about TikTok (and a few other social apps)
        if (!isTargetApp(packageName)) return

        val rootNode = rootInActiveWindow ?: return

        try {
            val text = extractAllText(rootNode)
            if (text.isNotBlank() && text != lastCapturedText) {
                val now = System.currentTimeMillis()
                if (now - lastDebounceTime > DEBOUNCE_MS) {
                    lastDebounceTime = now
                    lastCapturedText = text

                    Log.d(TAG, "Captured text (${text.length} chars) from $packageName")

                    serviceScope.launch {
                        onTextCaptured?.invoke(text)
                        // Also broadcast to overlay service
                        sendBroadcast(Intent("com.debatecopilot.NEW_TEXT").apply {
                            putExtra("text", text)
                            putExtra("source", packageName)
                        })
                    }
                }
            }
        } finally {
            rootNode.recycle()
        }
    }

    override fun onInterrupt() {
        Log.d(TAG, "Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    private fun isTargetApp(packageName: String): Boolean {
        return packageName.contains("tiktok") ||
               packageName.contains("com.zhiliaoapp.musically") ||
               packageName.contains("instagram") ||
               packageName.contains("x") ||
               packageName.contains("twitter") ||
               packageName.contains("youtube") ||
               packageName.contains("facebook")
    }

    /**
     * Recursively extract all text from the accessibility node tree.
     * This is the magic — we get every visible text element.
     */
    private fun extractAllText(node: AccessibilityNodeInfo): String {
        val builder = StringBuilder()

        fun traverse(n: AccessibilityNodeInfo) {
            // Get text from this node
            n.text?.let { builder.append(it).append(" ") }
            n.contentDescription?.let { builder.append(it).append(" ") }

            // Recurse into children
            for (i in 0 until n.childCount) {
                n.getChild(i)?.let { child ->
                    try {
                        traverse(child)
                    } finally {
                        child.recycle()
                    }
                }
            }
        }

        traverse(node)
        return builder.toString().trim().replace(Regex("\s+"), " ")
    }
}
