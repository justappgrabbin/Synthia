package com.debatecopilot.research

import android.content.Context
import android.util.LruCache
import org.json.JSONObject

class ResearchCache(context: Context) {
    private val memoryCache = LruCache<String, ResearchResult>(20)
    private val prefs = context.getSharedPreferences("research_cache", Context.MODE_PRIVATE)

    fun get(topic: String): ResearchResult? {
        return memoryCache.get(topic) ?: run {
            val jsonStr = prefs.getString(topic, null) ?: return null
            try {
                deserialize(jsonStr)
            } catch (e: Exception) {
                null
            }
        }
    }

    fun put(topic: String, result: ResearchResult) {
        memoryCache.put(topic, result)
        prefs.edit().putString(topic, serialize(result)).apply()
    }

    private fun serialize(result: ResearchResult): String {
        val json = JSONObject().apply {
            put("topic", result.topic)
            put("searchTimeMs", result.searchTimeMs)
            put("stance", result.stance.name)
            put("tone", result.tone.name)
            put("sources", org.json.JSONArray().apply {
                result.sources.forEach { s ->
                    put(JSONObject().apply {
                        put("title", s.title)
                        put("url", s.url)
                        put("snippet", s.snippet)
                        put("source", s.source)
                        put("peerReviewedScore", s.peerReviewedScore)
                        put("engine", s.engine)
                    })
                }
            })
            put("talkingPoints", org.json.JSONArray().apply {
                result.talkingPoints.forEach { tp ->
                    put(JSONObject().apply {
                        put("text", tp.text)
                        put("source", tp.source)
                        put("url", tp.url)
                        put("type", tp.type.name)
                    })
                }
            })
        }
        return json.toString()
    }

    private fun deserialize(jsonStr: String): ResearchResult? {
        return try {
            val json = JSONObject(jsonStr)
            ResearchResult(
                topic = json.getString("topic"),
                sources = emptyList(),
                facts = emptyList(),
                talkingPoints = emptyList(),
                stance = Stance.valueOf(json.getString("stance")),
                tone = Tone.valueOf(json.getString("tone")),
                searchTimeMs = json.getLong("searchTimeMs")
            )
        } catch (e: Exception) {
            null
        }
    }
}
