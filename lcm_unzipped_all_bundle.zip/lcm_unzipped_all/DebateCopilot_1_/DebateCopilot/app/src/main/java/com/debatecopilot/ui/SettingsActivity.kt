package com.debatecopilot.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Switch
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.debatecopilot.R

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val stanceSpinner = findViewById<Spinner>(R.id.stanceSpinner)
        val toneSpinner = findViewById<Spinner>(R.id.toneSpinner)
        val audioSwitch = findViewById<Switch>(R.id.audioSwitch)
        val saveBtn = findViewById<Button>(R.id.saveBtn)

        stanceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item,
            listOf("AUTO", "PRO", "CON", "NEUTRAL")).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        toneSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item,
            listOf("FACT_BASED", "AGGRESSIVE", "CALM")).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        val prefs = getSharedPreferences("debate_settings", MODE_PRIVATE)
        stanceSpinner.setSelection(
            listOf("AUTO", "PRO", "CON", "NEUTRAL").indexOf(prefs.getString("stance", "AUTO"))
        )
        toneSpinner.setSelection(
            listOf("FACT_BASED", "AGGRESSIVE", "CALM").indexOf(prefs.getString("tone", "FACT_BASED"))
        )
        audioSwitch.isChecked = prefs.getBoolean("audio_capture", false)

        saveBtn.setOnClickListener {
            prefs.edit().apply {
                putString("stance", stanceSpinner.selectedItem.toString())
                putString("tone", toneSpinner.selectedItem.toString())
                putBoolean("audio_capture", audioSwitch.isChecked)
                apply()
            }
            finish()
        }
    }
}
