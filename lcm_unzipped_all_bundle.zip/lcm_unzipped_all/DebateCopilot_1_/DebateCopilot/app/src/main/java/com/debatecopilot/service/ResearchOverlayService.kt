package com.debatecopilot.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.debatecopilot.DebateCopilotApp
import com.debatecopilot.R
import com.debatecopilot.research.ResearchEngine
import com.debatecopilot.research.ResearchResult
import com.debatecopilot.research.Stance
import com.debatecopilot.research.Tone
import com.debatecopilot.research.TalkingPoint
import kotlinx.coroutines.*

/**
 * ResearchOverlayService — draws a floating window on top of TikTok.
 * Shows real-time research results, talking points, and sources.
 * Draggable, minimizable, always on top.
 */
class ResearchOverlayService : Service() {

    companion object {
        const val TAG = "ResearchOverlay"
        const val CHANNEL_ID = "debate_copilot_overlay"
        const val NOTIFICATION_ID = 1337
    }

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View
    private lateinit var params: WindowManager.LayoutParams

    private var isMinimized = false
    private var minimizedView: View? = null

    private val researchEngine = ResearchEngine()
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var currentTopic = ""
    private var currentStance = Stance.AUTO
    private var currentTone = Tone.FACT_BASED

    // UI elements
    private lateinit var titleText: TextView
    private lateinit var contentScroll: ScrollView
    private lateinit var contentContainer: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var minimizeBtn: ImageButton
    private lateinit var closeBtn: ImageButton
    private lateinit var stanceBtn: Button
    private lateinit var toneBtn: Button
    private lateinit var refreshBtn: Button
    private lateinit var copyBtn: Button

    private var lastResearchJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        setupOverlay()
        registerTextReceiver()

        Log.d(TAG, "Overlay service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        try {
            windowManager.removeView(overlayView)
            minimizedView?.let { windowManager.removeView(it) }
        } catch (e: Exception) {
            Log.w(TAG, "Error removing overlay: ${e.message}")
        }
        serviceScope.cancel()
        unregisterReceiver(textReceiver)
    }

    private fun setupOverlay() {
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        overlayView = inflater.inflate(R.layout.overlay_research, null)

        // Window parameters for overlay on top of everything
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 100
            width = (resources.displayMetrics.widthPixels * 0.92).toInt()
        }

        windowManager.addView(overlayView, params)

        // Bind UI elements
        titleText = overlayView.findViewById(R.id.overlayTitle)
        contentScroll = overlayView.findViewById(R.id.contentScroll)
        contentContainer = overlayView.findViewById(R.id.contentContainer)
        statusText = overlayView.findViewById(R.id.statusText)
        minimizeBtn = overlayView.findViewById(R.id.minimizeBtn)
        closeBtn = overlayView.findViewById(R.id.closeBtn)
        stanceBtn = overlayView.findViewById(R.id.stanceBtn)
        toneBtn = overlayView.findViewById(R.id.toneBtn)
        refreshBtn = overlayView.findViewById(R.id.refreshBtn)
        copyBtn = overlayView.findViewById(R.id.copyBtn)

        // Drag functionality
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f

        overlayView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchX).toInt()
                    params.y = initialY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(overlayView, params)
                    true
                }
                else -> false
            }
        }

        // Button handlers
        minimizeBtn.setOnClickListener { toggleMinimize() }
        closeBtn.setOnClickListener { stopSelf() }

        stanceBtn.setOnClickListener {
            currentStance = when (currentStance) {
                Stance.PRO -> Stance.CON
                Stance.CON -> Stance.NEUTRAL
                Stance.NEUTRAL -> Stance.AUTO
                Stance.AUTO -> Stance.PRO
            }
            stanceBtn.text = "Stance: ${currentStance.name}"
            Toast.makeText(this, "Stance: ${currentStance.name}", Toast.LENGTH_SHORT).show()
        }

        toneBtn.setOnClickListener {
            currentTone = when (currentTone) {
                Tone.FACT_BASED -> Tone.AGGRESSIVE
                Tone.AGGRESSIVE -> Tone.CALM
                Tone.CALM -> Tone.FACT_BASED
            }
            toneBtn.text = "Tone: ${currentTone.name}"
            Toast.makeText(this, "Tone: ${currentTone.name}", Toast.LENGTH_SHORT).show()
        }

        refreshBtn.setOnClickListener {
            if (currentTopic.isNotBlank()) {
                triggerResearch(currentTopic)
            }
        }

        copyBtn.setOnClickListener {
            copyAllToClipboard()
        }

        // Initial state
        showWaitingState()
    }

    private fun showWaitingState() {
        contentContainer.removeAllViews()
        val waitingView = TextView(this).apply {
            text = "🎯 Open TikTok and start arguing...\n\nI'll research in real-time and feed you the good stuff."
            setTextColor(getColor(android.R.color.white))
            textSize = 14f
            setPadding(20, 20, 20, 20)
        }
        contentContainer.addView(waitingView)
        statusText.text = "Waiting for TikTok content..."
    }

    private fun toggleMinimize() {
        if (isMinimized) {
            // Restore
            minimizedView?.let { 
                try { windowManager.removeView(it) } catch (_: Exception) {} 
            }
            minimizedView = null
            overlayView.visibility = View.VISIBLE
            isMinimized = false
        } else {
            // Minimize to a small floating dot
            overlayView.visibility = View.GONE

            val dotView = View(this).apply {
                setBackgroundResource(R.drawable.floating_dot)
            }

            val dotParams = WindowManager.LayoutParams(
                80, 80,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) 
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY 
                else 
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = params.x
                y = params.y
            }

            dotView.setOnClickListener {
                toggleMinimize()
            }

            windowManager.addView(dotView, dotParams)
            minimizedView = dotView
            isMinimized = true
        }
    }

    private fun registerTextReceiver() {
        registerReceiver(textReceiver, IntentFilter("com.debatecopilot.NEW_TEXT"))
    }

    private val textReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra("text") ?: return
            val source = intent.getStringExtra("source") ?: "unknown"

            Log.d(TAG, "Received text from $source: ${text.take(100)}...")

            // Extract topic from text
            val topic = extractTopic(text)
            if (topic.isNotBlank() && topic != currentTopic) {
                currentTopic = topic
                titleText.text = "📌 $topic"
                statusText.text = "🔍 Researching..."
                triggerResearch(topic)
            }
        }
    }

    /**
     * Extract the debate topic from captured text.
     * Uses keyword extraction and topic modeling.
     */
    private fun extractTopic(text: String): String {
        // Simple extraction — look for debate keywords and take the surrounding context
        val debateKeywords = listOf(
            "believe", "think", "wrong", "right", "prove", "evidence",
            "study", "research", "fact", "opinion", "argument", "debate",
            "climate", "vaccine", "economy", "politics", "science",
            "gender", "race", "religion", "health", "technology",
            "AI", "crypto", "bitcoin", "nft", "metaverse"
        )

        val sentences = text.split(Regex("[.!?]")).filter { it.length > 10 }

        for (sentence in sentences) {
            val lower = sentence.lowercase()
            for (keyword in debateKeywords) {
                if (lower.contains(keyword.lowercase())) {
                    // Clean up the sentence for a search query
                    return sentence.trim()
                        .replace(Regex("@[\w_]+"), "") // Remove @mentions
                        .replace(Regex("#\w+"), "") // Remove hashtags
                        .replace(Regex("https?://\S+"), "") // Remove URLs
                        .replace(Regex("[^\w\s]"), " ") // Remove special chars
                        .replace(Regex("\s+"), " ")
                        .trim()
                        .take(120)
                }
            }
        }

        // Fallback: just take the longest sentence
        return sentences.maxByOrNull { it.length }?.trim()?.take(120) ?: ""
    }

    private fun triggerResearch(topic: String) {
        lastResearchJob?.cancel()

        lastResearchJob = serviceScope.launch {
            try {
                statusText.text = "🔍 Researching: $topic"

                val result = researchEngine.researchTopic(
                    topic = topic,
                    yourStance = currentStance,
                    tone = currentTone
                )

                displayResults(result)

            } catch (e: Exception) {
                Log.e(TAG, "Research failed: ${e.message}")
                statusText.text = "❌ Research failed. Tap refresh to retry."
            }
        }
    }

    private fun displayResults(result: ResearchResult) {
        contentContainer.removeAllViews()

        // Header
        val headerView = TextView(this).apply {
            text = "⏱️ ${result.searchTimeMs}ms | ${result.sources.size} sources | ${result.facts.size} facts"
            setTextColor(getColor(android.R.color.holo_green_light))
            textSize = 12f
            setPadding(10, 5, 10, 5)
        }
        contentContainer.addView(headerView)

        // Divider
        contentContainer.addView(createDivider())

        // Talking Points — the main event
        val tpHeader = TextView(this).apply {
            text = "💬 YOUR TALKING POINTS"
            setTextColor(getColor(android.R.color.holo_orange_light))
            textSize = 16f
            setPadding(10, 10, 10, 5)
        }
        contentContainer.addView(tpHeader)

        result.talkingPoints.forEach { point ->
            val pointView = createTalkingPointView(point)
            contentContainer.addView(pointView)
        }

        // Divider
        contentContainer.addView(createDivider())

        // Sources
        val srcHeader = TextView(this).apply {
            text = "📚 SOURCES (${result.sources.size})"
            setTextColor(getColor(android.R.color.holo_blue_light))
            textSize = 14f
            setPadding(10, 10, 10, 5)
        }
        contentContainer.addView(srcHeader)

        result.sources.take(5).forEach { source ->
            val sourceView = TextView(this).apply {
                val badge = if (source.peerReviewedScore >= 5) "✅" else "⚡"
                text = "$badge ${source.title}\n   ↳ ${source.source} (${source.engine})"
                setTextColor(getColor(android.R.color.white))
                textSize = 11f
                setPadding(15, 5, 10, 10)
                setOnClickListener {
                    // Open URL in browser
                    val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(source.url))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                }
                isClickable = true
                isFocusable = true
            }
            contentContainer.addView(sourceView)
        }

        statusText.text = "✅ Ready — ${result.talkingPoints.size} talking points loaded"
    }

    private fun createTalkingPointView(point: TalkingPoint): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(15, 8, 15, 8)
            setBackgroundResource(R.drawable.talking_point_bg)
        }

        val pointText = TextView(this).apply {
            text = point.text
            setTextColor(getColor(android.R.color.white))
            textSize = 13f
        }
        container.addView(pointText)

        if (point.source.isNotBlank()) {
            val sourceText = TextView(this).apply {
                text = "— ${point.source}"
                setTextColor(getColor(android.R.color.darker_gray))
                textSize = 10f
                setPadding(0, 2, 0, 0)
            }
            container.addView(sourceText)
        }

        // Copy button for this point
        val copyPointBtn = Button(this).apply {
            text = "📋 Copy"
            textSize = 10f
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = android.content.ClipData.newPlainText("Talking Point", point.text)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(this@ResearchOverlayService, "Copied!", Toast.LENGTH_SHORT).show()
            }
        }
        container.addView(copyPointBtn)

        return container
    }

    private fun createDivider(): View {
        return View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 2
            ).apply { setMargins(10, 5, 10, 5) }
            setBackgroundColor(getColor(android.R.color.darker_gray))
        }
    }

    private fun copyAllToClipboard() {
        val allText = StringBuilder()
        for (i in 0 until contentContainer.childCount) {
            val child = contentContainer.getChildAt(i)
            if (child is TextView) {
                allText.appendLine(child.text)
            }
        }

        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val clip = android.content.ClipData.newPlainText("Debate Research", allText.toString())
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, "All content copied!", Toast.LENGTH_SHORT).show()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Debate Copilot Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the research overlay running"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, 
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Debate Copilot")
            .setContentText("Research overlay is active")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }
}
