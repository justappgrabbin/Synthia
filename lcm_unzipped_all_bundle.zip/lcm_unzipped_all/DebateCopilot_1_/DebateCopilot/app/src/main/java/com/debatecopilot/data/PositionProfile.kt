package com.debatecopilot.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject

/**
 * PositionProfile — learns your positions from files, browser history, and bookmarks.
 * Builds a profile of topics you care about, your likely stance, and knowledge depth.
 * This is used by the research engine to tailor arguments to YOUR views.
 */
class PositionProfile(context: Context) {

    companion object {
        const val TAG = "PositionProfile"
        const val PREFS_NAME = "position_profile"
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // Topic → inferred stance and confidence
    private val topicPositions = mutableMapOf<String, TopicPosition>()

    // Keywords you frequently encounter
    private val keywordFrequency = mutableMapOf<String, Int>()

    // Domains you trust (from bookmarks and frequent visits)
    private val trustedDomains = mutableMapOf<String, Int>()

    init {
        loadProfile()
    }

    /**
     * Add insight from a document. Extracts topics and infers positions.
     */
    fun addDocumentInsight(filename: String, content: String) {
        // Extract keywords
        val words = content.split(Regex("[^\w]+"))
            .filter { it.length > 3 }
            .map { it.lowercase() }

        words.forEach { word ->
            keywordFrequency[word] = keywordFrequency.getOrDefault(word, 0) + 1
        }

        // Look for stance indicators
        val stanceIndicators = mapOf(
            "pro" to listOf("support", "believe in", "advocate", "defend", "promote", "benefits", "advantages"),
            "con" to listOf("oppose", "against", "harmful", "dangerous", "risks", "problems", "issues"),
            "neutral" to listOf("analyze", "examine", "study", "research", "investigate", "compare")
        )

        val lowerContent = content.lowercase()

        // Try to infer topic from filename and content
        val topic = inferTopic(filename, content)
        if (topic.isNotBlank()) {
            var proScore = 0
            var conScore = 0

            stanceIndicators["pro"]?.forEach { indicator ->
                if (lowerContent.contains(indicator)) proScore++
            }
            stanceIndicators["con"]?.forEach { indicator ->
                if (lowerContent.contains(indicator)) conScore++
            }

            val stance = when {
                proScore > conScore * 2 -> "pro"
                conScore > proScore * 2 -> "con"
                else -> "neutral"
            }

            val confidence = (proScore + conScore).coerceIn(1, 10)

            topicPositions[topic] = TopicPosition(
                topic = topic,
                stance = stance,
                confidence = confidence,
                sources = (topicPositions[topic]?.sources ?: 0) + 1
            )

            Log.d(TAG, "Document insight: $topic → $stance (confidence: $confidence)")
        }
    }

    /**
     * Add browser history entry.
     */
    fun addBrowserHistory(url: String, title: String, visits: Int) {
        val domain = extractDomain(url)
        trustedDomains[domain] = trustedDomains.getOrDefault(domain, 0) + visits

        // Infer topic from URL and title
        val topic = inferTopicFromUrl(url, title)
        if (topic.isNotBlank()) {
            topicPositions[topic] = TopicPosition(
                topic = topic,
                stance = "unknown",
                confidence = visits.coerceIn(1, 10),
                sources = (topicPositions[topic]?.sources ?: 0) + 1
            )
        }
    }

    /**
     * Add bookmark.
     */
    fun addBookmark(url: String, title: String) {
        val domain = extractDomain(url)
        trustedDomains[domain] = trustedDomains.getOrDefault(domain, 0) + 5 // Bookmarks count more

        val topic = inferTopicFromUrl(url, title)
        if (topic.isNotBlank()) {
            topicPositions[topic] = TopicPosition(
                topic = topic,
                stance = "unknown",
                confidence = 5,
                sources = (topicPositions[topic]?.sources ?: 0) + 1
            )
        }
    }

    /**
     * Get your likely stance on a topic.
     */
    fun getStance(topic: String): String {
        // Fuzzy match topic
        val normalized = topic.lowercase()

        topicPositions.forEach { (key, position) ->
            if (normalized.contains(key.lowercase()) || key.lowercase().contains(normalized)) {
                return position.stance
            }
        }

        return "unknown"
    }

    /**
     * Get your trusted domains for source prioritization.
     */
    fun getTrustedDomains(): List<String> {
        return trustedDomains.entries
            .sortedByDescending { it.value }
            .map { it.key }
            .take(20)
    }

    /**
     * Get topics you care about.
     */
    fun getKnownTopics(): List<String> {
        return topicPositions.keys.toList()
    }

    fun saveProfile() {
        val json = JSONObject().apply {
            put("topics", JSONArray().apply {
                topicPositions.values.forEach { put(it.toJson()) }
            })
            put("keywords", JSONObject().apply {
                keywordFrequency.forEach { put(it.key, it.value) }
            })
            put("domains", JSONObject().apply {
                trustedDomains.forEach { put(it.key, it.value) }
            })
        }

        prefs.edit().putString("profile", json.toString()).apply()
        Log.d(TAG, "Profile saved: ${topicPositions.size} topics, ${trustedDomains.size} domains")
    }

    private fun loadProfile() {
        val jsonStr = prefs.getString("profile", null) ?: return
        try {
            val json = JSONObject(jsonStr)

            val topicsArray = json.getJSONArray("topics")
            for (i in 0 until topicsArray.length()) {
                val obj = topicsArray.getJSONObject(i)
                val topic = obj.getString("topic")
                topicPositions[topic] = TopicPosition.fromJson(obj)
            }

            val keywordsObj = json.getJSONObject("keywords")
            keywordsObj.keys().forEach { key ->
                keywordFrequency[key] = keywordsObj.getInt(key)
            }

            val domainsObj = json.getJSONObject("domains")
            domainsObj.keys().forEach { key ->
                trustedDomains[key] = domainsObj.getInt(key)
            }

            Log.d(TAG, "Profile loaded: ${topicPositions.size} topics")
        } catch (e: Exception) {
            Log.w(TAG, "Failed to load profile: ${e.message}")
        }
    }

    private fun inferTopic(filename: String, content: String): String {
        // Extract from filename first
        val nameTopic = filename
            .replace(Regex("\.(pdf|doc|docx|txt|md)$"), "")
            .replace(Regex("[_-]"), " ")
            .trim()

        if (nameTopic.length > 3 && nameTopic.length < 50) return nameTopic

        // Extract from content — look for capitalized phrases
        val capitalized = content.split(Regex("[^\w\s]"))
            .filter { it.length > 5 }
            .filter { it.split(" ").all { word -> word.firstOrNull()?.isUpperCase() == true } }

        return capitalized.firstOrNull() ?: ""
    }

    private fun inferTopicFromUrl(url: String, title: String): String {
        // Use title if available
        if (title.length > 5 && title.length < 60) {
            return title.replace(Regex("[-|]"), " ").trim()
        }

        // Extract from URL path
        val path = url.substringAfter("//").substringAfter("/")
        val segments = path.split("/").filter { it.length > 3 }

        return segments.firstOrNull()?.replace("-", " ")?.replace("_", " ") ?: ""
    }

    private fun extractDomain(url: String): String {
        return try {
            val host = java.net.URL(url).host
            host.removePrefix("www.")
        } catch (e: Exception) {
            url
        }
    }

    data class TopicPosition(
        val topic: String,
        val stance: String,
        val confidence: Int,
        val sources: Int
    ) {
        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("topic", topic)
                put("stance", stance)
                put("confidence", confidence)
                put("sources", sources)
            }
        }

        companion object {
            fun fromJson(json: JSONObject): TopicPosition {
                return TopicPosition(
                    topic = json.getString("topic"),
                    stance = json.getString("stance"),
                    confidence = json.getInt("confidence"),
                    sources = json.getInt("sources")
                )
            }
        }
    }
}
