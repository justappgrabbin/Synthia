package com.debatecopilot.research

import android.util.Log
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * ResearchEngine — scrapes Google and DuckDuckGo for real-time research.
 * NO API KEYS needed. Uses web scraping with peer-review filtering.
 * 
 * Strategy:
 * 1. Query DuckDuckGo HTML (lighter, less bot protection)
 * 2. Query Google as fallback
 * 3. Filter results for peer-reviewed indicators
 * 4. Extract key facts, stats, and counter-arguments
 * 5. Format as "your side" talking points
 */
class ResearchEngine {

    companion object {
        const val TAG = "ResearchEngine"

        // Peer-reviewed domain indicators
        val PEER_REVIEWED_DOMAINS = setOf(
            "ncbi.nlm.nih.gov", "pubmed", "nature.com", "science.org",
            "cell.com", "thelancet.com", "nejm.org", "jamanetwork.com",
            "bmj.com", "pnas.org", "arxiv.org", "biorxiv.org",
            "springer.com", "wiley.com", "sciencedirect.com", "elsevier.com",
            "academia.edu", "researchgate.net", "doi.org", "ieee.org",
            "acm.org", "aps.org", "iopscience.iop.org", "tandfonline.com",
            "oxfordjournals.org", "cambridge.org", "sagepub.com",
            "cdc.gov", "who.int", "fda.gov", "epa.gov", "europa.eu",
            "gov.uk", "nih.gov", "nsf.gov", "noaa.gov", "nasa.gov",
            "harvard.edu", "mit.edu", "stanford.edu", "berkeley.edu",
            "cornell.edu", "princeton.edu", "yale.edu", "columbia.edu",
            "uchicago.edu", "caltech.edu", "ox.ac.uk", "cam.ac.uk",
            "reuters.com", "apnews.com", "bloomberg.com", "economist.com",
            "ft.com", "wsj.com", "nytimes.com", "washingtonpost.com",
            "theguardian.com", "bbc.com", "npr.org", "pbs.org"
        )

        // Academic / research file extensions
        val RESEARCH_EXTENSIONS = setOf("pdf", "doc", "docx")
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    /**
     * Main research function. Takes the topic from TikTok, researches it,
     * and returns formatted talking points for "your side" of the argument.
     */
    suspend fun researchTopic(
        topic: String,
        yourStance: Stance = Stance.AUTO,
        tone: Tone = Tone.FACT_BASED
    ): ResearchResult = withContext(Dispatchers.IO) {

        Log.d(TAG, "Researching: $topic | Stance: $yourStance | Tone: $tone")

        val startTime = System.currentTimeMillis()

        // Parallel search on both engines
        val ddgDeferred = async { searchDuckDuckGo(topic) }
        val googleDeferred = async { searchGoogle(topic) }

        val ddgResults = ddgDeferred.await()
        val googleResults = googleDeferred.await()

        // Merge and deduplicate
        val allResults = (ddgResults + googleResults)
            .distinctBy { it.url }
            .sortedByDescending { it.peerReviewedScore }

        // Filter for peer-reviewed / high-quality sources
        val qualityResults = allResults.filter { it.peerReviewedScore >= 3 }

        // If no quality results, use what we have
        val finalResults = if (qualityResults.isNotEmpty()) qualityResults else allResults

        // Extract key facts from top results
        val facts = extractKeyFacts(finalResults.take(5), topic)

        // Generate counter-arguments based on stance
        val talkingPoints = generateTalkingPoints(topic, facts, yourStance, tone)

        val elapsed = System.currentTimeMillis() - startTime
        Log.d(TAG, "Research completed in ${elapsed}ms | ${finalResults.size} sources | ${talkingPoints.size} talking points")

        ResearchResult(
            topic = topic,
            sources = finalResults.take(8),
            facts = facts,
            talkingPoints = talkingPoints,
            stance = yourStance,
            tone = tone,
            searchTimeMs = elapsed
        )
    }

    /**
     * Search DuckDuckGo HTML — no API key, just scrape the results page.
     */
    private suspend fun searchDuckDuckGo(query: String): List<SearchResult> = withContext(Dispatchers.IO) {
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://html.duckduckgo.com/html/?q=$encoded"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext emptyList()

            val doc = Jsoup.parse(body)
            val results = mutableListOf<SearchResult>()

            doc.select(".result")?.forEach { result ->
                val title = result.select(".result__a")?.first()?.text() ?: ""
                val url = result.select(".result__a")?.first()?.attr("href") ?: ""
                val snippet = result.select(".result__snippet")?.first()?.text() ?: ""

                if (title.isNotBlank() && url.isNotBlank()) {
                    results.add(SearchResult(
                        title = title,
                        url = url,
                        snippet = snippet,
                        source = extractDomain(url),
                        peerReviewedScore = calculatePeerReviewScore(url, title, snippet),
                        engine = "DuckDuckGo"
                    ))
                }
            }

            results
        } catch (e: Exception) {
            Log.e(TAG, "DuckDuckGo search failed: ${e.message}")
            emptyList()
        }
    }

    /**
     * Search Google HTML — fallback when DDG fails.
     */
    private suspend fun searchGoogle(query: String): List<SearchResult> = withContext(Dispatchers.IO) {
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://www.google.com/search?q=$encoded&num=10"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .header("Accept-Language", "en-US,en;q=0.9")
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext emptyList()

            val doc = Jsoup.parse(body)
            val results = mutableListOf<SearchResult>()

            // Google result selectors
            doc.select("div.g, div[data-hveid], .g")?.forEach { result ->
                val titleElem = result.select("h3").first()
                val linkElem = result.select("a[href]").first()
                val snippetElem = result.select(".VwiC3b, .s, span[data-st]").first()

                val title = titleElem?.text() ?: ""
                val href = linkElem?.attr("href") ?: ""
                val url = if (href.startsWith("/url?q=")) {
                    href.substringAfter("/url?q=").substringBefore("&")
                } else href
                val snippet = snippetElem?.text() ?: ""

                if (title.isNotBlank() && url.isNotBlank() && !url.startsWith("/")) {
                    results.add(SearchResult(
                        title = title,
                        url = url,
                        snippet = snippet,
                        source = extractDomain(url),
                        peerReviewedScore = calculatePeerReviewScore(url, title, snippet),
                        engine = "Google"
                    ))
                }
            }

            results
        } catch (e: Exception) {
            Log.e(TAG, "Google search failed: ${e.message}")
            emptyList()
        }
    }

    /**
     * Extract key facts from search result pages.
     */
    private suspend fun extractKeyFacts(results: List<SearchResult>, topic: String): List<Fact> = withContext(Dispatchers.IO) {
        val facts = mutableListOf<Fact>()

        results.take(3).forEach { result ->
            try {
                val request = Request.Builder()
                    .url(result.url)
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                    .build()

                val response = client.newCall(request).execute()
                val body = response.body?.string() ?: return@forEach

                val doc = Jsoup.parse(body)

                // Extract paragraphs that contain numbers, percentages, or key terms
                doc.select("p").forEach { p ->
                    val text = p.text()
                    if (text.length in 50..400 && 
                        (text.contains(Regex("\d+%|\d+ percent|study|research|found|showed|data|evidence|according to|reported")) ||
                         text.contains(topic, ignoreCase = true))) {

                        facts.add(Fact(
                            text = text,
                            source = result.source,
                            url = result.url,
                            confidence = result.peerReviewedScore
                        ))
                    }
                }

                // Look for data tables, lists, blockquotes
                doc.select("li, td, blockquote, .fact, .stat").forEach { elem ->
                    val text = elem.text()
                    if (text.length in 30..300 && text.contains(Regex("\d"))) {
                        facts.add(Fact(
                            text = text,
                            source = result.source,
                            url = result.url,
                            confidence = result.peerReviewedScore
                        ))
                    }
                }

            } catch (e: Exception) {
                Log.w(TAG, "Failed to extract from ${result.url}: ${e.message}")
            }
        }

        facts.distinctBy { it.text }.take(15)
    }

    /**
     * Generate talking points formatted for "your side" of the argument.
     */
    private fun generateTalkingPoints(
        topic: String,
        facts: List<Fact>,
        stance: Stance,
        tone: Tone
    ): List<TalkingPoint> {
        val points = mutableListOf<TalkingPoint>()

        // Categorize facts by type
        val stats = facts.filter { it.text.contains(Regex("\d+%|\d+ percent|\d+ million|\d+ billion|study of|sample of|n=")) }
        val studies = facts.filter { it.text.contains(Regex("study|research|paper|journal|published|peer-reviewed|meta-analysis|randomized|clinical trial")) }
        val experts = facts.filter { it.text.contains(Regex("according to|expert|professor|doctor|researcher|scientist|found that|concluded that")) }
        val historical = facts.filter { it.text.contains(Regex("history|historically|since|decade|century|tradition|evolution")) }

        // Build talking points based on tone
        when (tone) {
            Tone.FACT_BASED -> {
                stats.take(3).forEach { 
                    points.add(TalkingPoint("📊 Stat: ${it.text}", it.source, it.url, PointType.STAT))
                }
                studies.take(3).forEach {
                    points.add(TalkingPoint("📄 Study: ${it.text}", it.source, it.url, PointType.STUDY))
                }
                experts.take(2).forEach {
                    points.add(TalkingPoint("🎓 Expert: ${it.text}", it.source, it.url, PointType.EXPERT))
                }
            }
            Tone.AGGRESSIVE -> {
                points.add(TalkingPoint("💥 The data doesn't lie. ${stats.firstOrNull()?.text ?: "Research consistently shows..."}", 
                    stats.firstOrNull()?.source ?: "", stats.firstOrNull()?.url ?: "", PointType.STAT))
                studies.take(2).forEach {
                    points.add(TalkingPoint("🔥 ${it.text}", it.source, it.url, PointType.STUDY))
                }
            }
            Tone.CALM -> {
                points.add(TalkingPoint("🌿 Let's look at what the research actually says...", "", "", PointType.OPENING))
                studies.take(3).forEach {
                    points.add(TalkingPoint("• ${it.text}", it.source, it.url, PointType.STUDY))
                }
                stats.take(2).forEach {
                    points.add(TalkingPoint("• ${it.text}", it.source, it.url, PointType.STAT))
                }
            }
        }

        // Add counter-argument prep
        points.add(TalkingPoint(
            "🛡️ Counter-prep: If they say "what about [opposite view]", respond with: ${studies.firstOrNull()?.text ?: "the peer-reviewed consensus"}",
            studies.firstOrNull()?.source ?: "",
            studies.firstOrNull()?.url ?: "",
            PointType.COUNTER
        ))

        return points
    }

    private fun extractDomain(url: String): String {
        return try {
            val host = java.net.URL(url).host
            host.removePrefix("www.")
        } catch (e: Exception) {
            url
        }
    }

    private fun calculatePeerReviewScore(url: String, title: String, snippet: String): Int {
        var score = 0
        val lowerUrl = url.lowercase()
        val lowerTitle = title.lowercase()
        val lowerSnippet = snippet.lowercase()

        // Domain check
        PEER_REVIEWED_DOMAINS.forEach { domain ->
            if (lowerUrl.contains(domain)) score += 2
        }

        // Academic indicators in title/snippet
        val academicWords = listOf("study", "research", "peer-reviewed", "meta-analysis", 
            "clinical trial", "journal", "published", "doi", "evidence", "data",
            "university", "institute", "department", "professor", "phd", "md")
        academicWords.forEach { word ->
            if (lowerTitle.contains(word) || lowerSnippet.contains(word)) score += 1
        }

        // Numbers = data
        if (title.contains(Regex("\d+%|\d+ percent"))) score += 1
        if (snippet.contains(Regex("\d+%|\d+ percent|\d+ million|\d+ billion"))) score += 1

        // PDF links often academic
        if (lowerUrl.endsWith(".pdf")) score += 2

        // News sites get lower base score
        if (lowerUrl.contains("news") || lowerUrl.contains("blog")) score -= 1

        score.coerceIn(0, 10)
    }
}

// Data classes
enum class Stance { PRO, CON, NEUTRAL, AUTO }
enum class Tone { FACT_BASED, AGGRESSIVE, CALM }
enum class PointType { STAT, STUDY, EXPERT, HISTORICAL, COUNTER, OPENING }

data class SearchResult(
    val title: String,
    val url: String,
    val snippet: String,
    val source: String,
    val peerReviewedScore: Int,
    val engine: String
)

data class Fact(
    val text: String,
    val source: String,
    val url: String,
    val confidence: Int
)

data class TalkingPoint(
    val text: String,
    val source: String,
    val url: String,
    val type: PointType
)

data class ResearchResult(
    val topic: String,
    val sources: List<SearchResult>,
    val facts: List<Fact>,
    val talkingPoints: List<TalkingPoint>,
    val stance: Stance,
    val tone: Tone,
    val searchTimeMs: Long
)
