package com.debatecopilot.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.debatecopilot.MainActivity
import com.debatecopilot.R
import kotlinx.coroutines.*

/**
 * AudioCaptureService — captures audio from TikTok and other apps using MediaProjection.
 * On Android 10+, this requires user approval via screen capture dialog.
 * The audio is transcribed (placeholder for now) and fed to the research engine.
 * 
 * NOTE: Full speech-to-text requires a transcription engine. This service captures
 * the audio stream. You can integrate Whisper, Google Speech, or on-device STT.
 */
class AudioCaptureService : Service() {

    companion object {
        const val TAG = "AudioCapture"
        const val CHANNEL_ID = "debate_copilot_audio"
        const val NOTIFICATION_ID = 1338
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
    }

    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var isRecording = false

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)

        if (resultCode != -1 && data != null) {
            startAudioCapture(resultCode, data)
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        stopAudioCapture()
        serviceScope.cancel()
    }

    private fun startAudioCapture(resultCode: Int, data: Intent) {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val config = AudioPlaybackCaptureConfiguration.Builder(mediaProjection!!)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .build()

            val audioFormat = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(16000)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()

            val bufferSize = AudioRecord.getMinBufferSize(
                16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            ) * 2

            audioRecord = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(config)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(bufferSize)
                .build()

            audioRecord?.startRecording()
            isRecording = true

            Log.d(TAG, "Audio capture started")

            // Capture loop — reads audio and sends for transcription
            serviceScope.launch {
                val buffer = ShortArray(bufferSize)
                while (isRecording && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        // TODO: Feed to speech-to-text engine
                        // For now, we log that audio is being captured
                        // You can integrate Whisper, Google Cloud Speech, or on-device STT here
                        processAudioChunk(buffer, read)
                    }
                }
            }
        } else {
            Log.w(TAG, "Audio capture requires Android 10+")
        }
    }

    private fun processAudioChunk(buffer: ShortArray, size: Int) {
        // Placeholder for audio processing
        // In production, this would:
        // 1. Buffer audio chunks
        // 2. Feed to STT engine (Whisper, etc.)
        // 3. Get transcribed text
        // 4. Broadcast to ResearchOverlayService for research

        // For now, we just verify audio is flowing
        val sum = buffer.take(size).sumOf { it.toLong() * it.toLong() }
        val rms = kotlin.math.sqrt(sum.toDouble() / size)

        if (rms > 100) {
            Log.d(TAG, "Audio detected (RMS: ${rms.toInt()})")
        }
    }

    private fun stopAudioCapture() {
        isRecording = false
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping audio: ${e.message}")
        }
        audioRecord = null
        mediaProjection?.stop()
        mediaProjection = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Audio Capture",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Captures audio from TikTok for transcription"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Audio Capture")
            .setContentText("Listening to TikTok audio...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }
}
