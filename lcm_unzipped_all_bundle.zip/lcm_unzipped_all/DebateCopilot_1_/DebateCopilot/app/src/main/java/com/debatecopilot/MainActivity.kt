package com.debatecopilot

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.debatecopilot.service.FileIngestionService
import com.debatecopilot.service.ResearchOverlayService
import com.debatecopilot.ui.SettingsActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var overlayBtn: Button
    private lateinit var accessibilityBtn: Button
    private lateinit var fileAccessBtn: Button
    private lateinit var launchBtn: Button
    private lateinit var settingsBtn: Button

    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        if (allGranted) {
            Toast.makeText(this, "Permissions granted", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Some permissions denied — app may not work fully", Toast.LENGTH_LONG).show()
        }
        updateStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        overlayBtn = findViewById(R.id.overlayBtn)
        accessibilityBtn = findViewById(R.id.accessibilityBtn)
        fileAccessBtn = findViewById(R.id.fileAccessBtn)
        launchBtn = findViewById(R.id.launchBtn)
        settingsBtn = findViewById(R.id.settingsBtn)

        overlayBtn.setOnClickListener { requestOverlayPermission() }
        accessibilityBtn.setOnClickListener { openAccessibilitySettings() }
        fileAccessBtn.setOnClickListener { requestFilePermissions() }
        launchBtn.setOnClickListener { launchOverlay() }
        settingsBtn.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }

        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val accessibilityOk = isAccessibilityServiceEnabled()
        val filesOk = hasFileAccess()

        val status = buildString {
            appendLine("Overlay: ${if (overlayOk) "✅" else "❌"}")
            appendLine("Accessibility: ${if (accessibilityOk) "✅" else "❌"}")
            appendLine("File Access: ${if (filesOk) "✅" else "❌"}")
            if (overlayOk && accessibilityOk) {
                appendLine()
                appendLine("Ready to launch! 🚀")
            } else {
                appendLine()
                appendLine("Enable all permissions to use Debate Copilot")
            }
        }
        statusText.text = status

        launchBtn.isEnabled = overlayOk && accessibilityOk
        launchBtn.alpha = if (launchBtn.isEnabled) 1.0f else 0.5f
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
        Toast.makeText(this, "Find "Debate Copilot" and enable it", Toast.LENGTH_LONG).show()
    }

    private fun requestFilePermissions() {
        val permissions = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
            permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!android.os.Environment.isExternalStorageManager()) {
                val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                startActivity(intent)
            }
        }

        if (permissions.isNotEmpty()) {
            requestPermissionsLauncher.launch(permissions.toTypedArray())
        }

        // Start file ingestion to learn your positions
        startService(Intent(this, FileIngestionService::class.java))
    }

    private fun hasFileAccess(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            android.os.Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return enabledServices.any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    private fun launchOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        startService(Intent(this, ResearchOverlayService::class.java))
        Toast.makeText(this, "Debate Copilot overlay launched!", Toast.LENGTH_SHORT).show()
        finish()
    }
}
