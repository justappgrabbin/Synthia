package com.debatecopilot.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.Browser
import android.provider.MediaStore
import android.util.Log
import androidx.core.app.NotificationCompat
import com.debatecopilot.MainActivity
import com.debatecopilot.R
import com.debatecopilot.data.PositionProfile
import kotlinx.coroutines.*
import java.io.File

/**
 * FileIngestionService — scans your local files, documents, browser history,
 * and bookmarks to learn your positions, interests, and knowledge areas.
 * This builds a "position profile" that the research engine uses to tailor
 * arguments to YOUR actual views.
 * 
 * What it scans:
 * - Documents folder (PDFs, DOCX, TXT) — extracts topics and positions
 * - Browser history — what you search for, what sites you visit
 * - Bookmarks — saved articles, research
 * - Download folder — papers, reports
 * - Notes apps (if files are accessible)
 */
class FileIngestionService : Service() {

    companion object {
        const val TAG = "FileIngestion"
        const val CHANNEL_ID = "debate_copilot_ingestion"
        const val NOTIFICATION_ID = 1339
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var positionProfile: PositionProfile

    override fun onCreate() {
        super.onCreate()
        positionProfile = PositionProfile(this)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        serviceScope.launch {
            ingestAll()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    private suspend fun ingestAll() = withContext(Dispatchers.IO) {
        Log.d(TAG, "Starting file ingestion...")

        val jobs = listOf(
            async { ingestDocuments() },
            async { ingestBrowserHistory() },
            async { ingestDownloads() },
            async { ingestBookmarks() }
        )

        jobs.awaitAll()

        Log.d(TAG, "Ingestion complete. Profile updated.")
        positionProfile.saveProfile()
    }

    /**
     * Scan Documents, Downloads, and common storage for text files.
     * Extract topics, keywords, and inferred positions.
     */
    private suspend fun ingestDocuments() = withContext(Dispatchers.IO) {
        try {
            val scanDirs = listOf(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                File(Environment.getExternalStorageDirectory(), "Notes"),
                File(Environment.getExternalStorageDirectory(), "MyFiles"),
            )

            val extensions = setOf("txt", "pdf", "doc", "docx", "md", "rtf")

            for (dir in scanDirs) {
                if (!dir.exists() || !dir.canRead()) continue

                dir.walkTopDown().filter { it.isFile && it.extension.lowercase() in extensions }
                    .take(100) // Limit to avoid overwhelming
                    .forEach { file ->
                        try {
                            val content = extractTextFromFile(file)
                            if (content.length > 50) {
                                positionProfile.addDocumentInsight(file.name, content)
                            }
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed to read ${file.name}: ${e.message}")
                        }
                    }
            }

            Log.d(TAG, "Documents ingested")
        } catch (e: Exception) {
            Log.e(TAG, "Document ingestion failed: ${e.message}")
        }
    }

    /**
     * Read browser history to understand what topics you research.
     * Requires READ_HISTORY_BOOKMARKS permission.
     */
    private suspend fun ingestBrowserHistory() = withContext(Dispatchers.IO) {
        try {
            val cursor = contentResolver.query(
                Browser.BOOKMARKS_URI,
                arrayOf(
                    Browser.BookmarkColumns.URL,
                    Browser.BookmarkColumns.TITLE,
                    Browser.BookmarkColumns.DATE,
                    Browser.BookmarkColumns.VISITS
                ),
                null, null,
                "${Browser.BookmarkColumns.DATE} DESC"
            )

            cursor?.use {
                val urlIndex = it.getColumnIndex(Browser.BookmarkColumns.URL)
                val titleIndex = it.getColumnIndex(Browser.BookmarkColumns.TITLE)
                val visitsIndex = it.getColumnIndex(Browser.BookmarkColumns.VISITS)

                var count = 0
                while (it.moveToNext() && count < 200) {
                    val url = it.getString(urlIndex) ?: continue
                    val title = it.getString(titleIndex) ?: ""
                    val visits = it.getInt(visitsIndex)

                    positionProfile.addBrowserHistory(url, title, visits)
                    count++
                }
            }

            Log.d(TAG, "Browser history ingested: $count entries")
        } catch (e: SecurityException) {
            Log.w(TAG, "No permission to read browser history")
        } catch (e: Exception) {
            Log.e(TAG, "Browser history ingestion failed: ${e.message}")
        }
    }

    /**
     * Scan Downloads folder for research papers, reports, etc.
     */
    private suspend fun ingestDownloads() = withContext(Dispatchers.IO) {
        try {
            val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadDir.exists() || !downloadDir.canRead()) return@withContext

            val researchPatterns = listOf("paper", "report", "study", "research", "analysis", "review")

            downloadDir.listFiles()?.filter { it.isFile }
                ?.filter { file ->
                    researchPatterns.any { pattern ->
                        file.name.lowercase().contains(pattern)
                    }
                }
                ?.take(50)
                ?.forEach { file ->
                    try {
                        val content = extractTextFromFile(file)
                        positionProfile.addDocumentInsight(file.name, content)
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to read download ${file.name}")
                    }
                }

            Log.d(TAG, "Downloads ingested")
        } catch (e: Exception) {
            Log.e(TAG, "Download ingestion failed: ${e.message}")
        }
    }

    /**
     * Read browser bookmarks for saved research and articles.
     */
    private suspend fun ingestBookmarks() = withContext(Dispatchers.IO) {
        try {
            val cursor = contentResolver.query(
                Browser.BOOKMARKS_URI,
                arrayOf(
                    Browser.BookmarkColumns.URL,
                    Browser.BookmarkColumns.TITLE
                ),
                "${Browser.BookmarkColumns.BOOKMARK} = 1",
                null, null
            )

            cursor?.use {
                val urlIndex = it.getColumnIndex(Browser.BookmarkColumns.URL)
                val titleIndex = it.getColumnIndex(Browser.BookmarkColumns.TITLE)

                var count = 0
                while (it.moveToNext() && count < 100) {
                    val url = it.getString(urlIndex) ?: continue
                    val title = it.getString(titleIndex) ?: ""
                    positionProfile.addBookmark(url, title)
                    count++
                }
            }

            Log.d(TAG, "Bookmarks ingested")
        } catch (e: SecurityException) {
            Log.w(TAG, "No permission to read bookmarks")
        } catch (e: Exception) {
            Log.e(TAG, "Bookmark ingestion failed: ${e.message}")
        }
    }

    private fun extractTextFromFile(file: File): String {
        return when (file.extension.lowercase()) {
            "txt", "md", "rtf" -> file.readText(Charsets.UTF_8).take(10000)
            "pdf" -> {
                // Basic PDF text extraction — for production, use PdfBox or similar
                // For now, we read raw bytes and extract ASCII text
                val bytes = file.readBytes()
                val text = bytes.filter { it in 32..126 }.map { it.toChar() }.joinToString("")
                text.take(10000)
            }
            "doc", "docx" -> {
                // DOCX is a ZIP — extract text from word/document.xml
                try {
                    val zip = java.util.zip.ZipFile(file)
                    val entry = zip.getEntry("word/document.xml")
                    if (entry != null) {
                        val xml = zip.getInputStream(entry).readBytes().toString(Charsets.UTF_8)
                        // Strip XML tags
                        xml.replace(Regex("<[^>]+>"), " ")
                            .replace(Regex("\s+"), " ")
                            .take(10000)
                    } else {
                        ""
                    }
                } catch (e: Exception) {
                    ""
                }
            }
            else -> ""
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "File Ingestion",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Scans your files to learn your positions"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Debate Copilot")
            .setContentText("Learning your positions from files...")
            .setSmallIcon(android.R.drawable.ic_menu_save)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }
}
