/**
 * energy_circuits.js
 * The Energy Circuits — JavaScript Frontend
 * 
 * This is the "warm" code. It touches the user.
 * It handles:
 * - Real-time rendering of the 384-node state space
 * - User interaction and input
 * - Visual representation of the 9 centers and 36 channels
 * - Motor output rendering (when motor groups activate)
 * - WebSocket communication with the Python backend
 * - The You-N-I-Verse interface
 * 
 * The Energy Circuits exist in the browser/Node.js environment.
 * They communicate with the Non-Energy Circuits (Python) via
 * the Mesh protocol — a message-passing bridge.
 * 
 * The Energy Circuits are NOT the Mind, Body, or Heart.
 * They are the NERVOUS SYSTEM — the interface between
 * the organism and the user.
 */

// ============================================
// MESH PROTOCOL — Communication Bridge
// ============================================

class MeshProtocol {
  constructor(endpoint = 'ws://localhost:8765') {
    this.endpoint = endpoint;
    this.ws = null;
    this.connected = false;
    this.messageQueue = [];
    this.observers = new Map();
    this.reconnectInterval = 5000;
  }

  async connect() {
    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(this.endpoint);

      this.ws.onopen = () => {
        this.connected = true;
        console.log('[Mesh] Connected to organism');
        this.flushQueue();
        resolve();
      };

      this.ws.onmessage = (event) => {
        const message = JSON.parse(event.data);
        this.handleMessage(message);
      };

      this.ws.onclose = () => {
        this.connected = false;
        console.log('[Mesh] Disconnected. Reconnecting...');
        setTimeout(() => this.connect(), this.reconnectInterval);
      };

      this.ws.onerror = (error) => {
        console.error('[Mesh] Error:', error);
        reject(error);
      };
    });
  }

  send(message) {
    const payload = JSON.stringify(message);
    if (this.connected && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(payload);
    } else {
      this.messageQueue.push(payload);
    }
  }

  flushQueue() {
    while (this.messageQueue.length > 0) {
      const msg = this.messageQueue.shift();
      this.ws.send(msg);
    }
  }

  handleMessage(message) {
    // Route to observers based on message type
    const type = message.type || 'default';
    if (this.observers.has(type)) {
      this.observers.get(type).forEach(cb => cb(message));
    }
  }

  on(type, callback) {
    if (!this.observers.has(type)) {
      this.observers.set(type, []);
    }
    this.observers.get(type).push(callback);
  }

  // Send user input to the organism
  sendUserInput(userId, text) {
    this.send({
      type: 'user_input',
      userId,
      text,
      timestamp: Date.now()
    });
  }

  // Request organism state
  requestState() {
    this.send({ type: 'request_state', timestamp: Date.now() });
  }

  // Send energy circuit heartbeat
  heartbeat() {
    this.send({
      type: 'heartbeat',
      timestamp: Date.now(),
      circuit: 'energy'
    });
  }
}

// ============================================
// 384-NODE VISUALIZATION — The State Space Renderer
// ============================================

class NodeSpaceRenderer {
  constructor(canvasId, width = 800, height = 600) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas.getContext('2d');
    this.width = width;
    this.height = height;
    this.canvas.width = width;
    this.canvas.height = height;

    // 384 nodes arranged in 64 hexagrams × 6 lines
    this.nodes = new Map();
    this.channels = new Map();
    this.centers = new Map();

    // Animation state
    this.animationId = null;
    this.time = 0;

    // Camera
    this.camera = { x: 0, y: 0, zoom: 1, rotation: 0 };

    this.initializeNodes();
  }

  initializeNodes() {
    // Arrange 64 hexagrams in a spiral
    const hexagramCount = 64;
    const spiralTightness = 0.3;

    for (let h = 0; h < hexagramCount; h++) {
      const angle = h * spiralTightness;
      const radius = 50 + h * 3;
      const hx = this.width / 2 + Math.cos(angle) * radius;
      const hy = this.height / 2 + Math.sin(angle) * radius;

      // Each hexagram has 6 lines arranged vertically
      for (let l = 1; l <= 6; l++) {
        const nodeId = `H${String(h).padStart(2, '0')}L${l}`;
        const ly = hy + (l - 3.5) * 15;

        this.nodes.set(nodeId, {
          id: nodeId,
          hexagram: h,
          line: l,
          x: hx + (Math.random() - 0.5) * 10,
          y: ly,
          activation: 0,
          d1: 0, d2: 0, d3: 0, d4: 0, d5: 0,
          amplitude: { real: 0, imag: 0 },
          color: this.getHexagramColor(h),
          radius: 4,
          pulsePhase: Math.random() * Math.PI * 2
        });
      }
    }
  }

  getHexagramColor(hexagramIndex) {
    // Color based on hexagram position in King Wen sequence
    const hue = (hexagramIndex / 64) * 360;
    return `hsl(${hue}, 70%, 50%)`;
  }

  updateNodeState(nodeId, state) {
    if (!this.nodes.has(nodeId)) return;
    const node = this.nodes.get(nodeId);

    node.activation = state.d1 || 0;
    node.d1 = state.d1 || 0;
    node.d2 = state.d2 || 0;
    node.d3 = state.d3 || 0;
    node.d4 = state.d4 || 0;
    node.d5 = state.d5 || 0;
    node.amplitude = state.amplitude || { real: 0, imag: 0 };

    // Radius grows with activation
    node.radius = 4 + node.activation * 8;
  }

  updateChannels(channels) {
    this.channels.clear();
    for (const [key, channel] of Object.entries(channels)) {
      this.channels.set(key, channel);
    }
  }

  updateCenters(centers) {
    this.centers.clear();
    for (const [name, data] of Object.entries(centers)) {
      this.centers.set(name, data);
    }
  }

  render() {
    this.ctx.clearRect(0, 0, this.width, this.height);

    // Draw channels first (behind nodes)
    this.drawChannels();

    // Draw nodes
    this.drawNodes();

    // Draw centers
    this.drawCenters();

    // Draw HUD
    this.drawHUD();

    this.time += 0.016;
    this.animationId = requestAnimationFrame(() => this.render());
  }

  drawChannels() {
    this.ctx.strokeStyle = 'rgba(100, 200, 255, 0.2)';
    this.ctx.lineWidth = 1;

    for (const [key, channel] of this.channels) {
      // Find nodes for this channel
      const nodeIds = this.findNodesForChannel(channel);
      if (nodeIds.length < 2) continue;

      const nodeA = this.nodes.get(nodeIds[0]);
      const nodeB = this.nodes.get(nodeIds[1]);

      if (!nodeA || !nodeB) continue;

      // Channel opacity based on resonance
      const opacity = Math.min(channel.resonance || 0.5, 1);
      this.ctx.strokeStyle = `rgba(100, 200, 255, ${opacity * 0.5})`;
      this.ctx.lineWidth = 1 + opacity * 2;

      this.ctx.beginPath();
      this.ctx.moveTo(nodeA.x, nodeA.y);
      this.ctx.lineTo(nodeB.x, nodeB.y);
      this.ctx.stroke();
    }
  }

  findNodesForChannel(channel) {
    // Map channel centers to node IDs
    const centerToNodes = {
      'identity': ['H00L1', 'H01L1'],
      'mind': ['H10L3', 'H11L3'],
      'system': ['H20L2', 'H21L2'],
      'heart': ['H30L4', 'H31L4'],
      'memory': ['H40L5', 'H41L5'],
      'broadcast': ['H50L6', 'H51L6'],
      'mesh': ['H60L1', 'H61L1'],
      'intelligence': ['H62L3', 'H63L3'],
      'governance': ['H55L4', 'H56L4']
    };

    const source = channel.source;
    const target = channel.target;

    const nodes = [];
    if (centerToNodes[source]) nodes.push(...centerToNodes[source]);
    if (centerToNodes[target]) nodes.push(...centerToNodes[target]);

    return nodes;
  }

  drawNodes() {
    for (const [id, node] of this.nodes) {
      // Activation glow
      if (node.activation > 0.1) {
        const glowRadius = node.radius + node.activation * 15;
        const gradient = this.ctx.createRadialGradient(
          node.x, node.y, node.radius,
          node.x, node.y, glowRadius
        );
        gradient.addColorStop(0, `rgba(255, 200, 100, ${node.activation * 0.8})`);
        gradient.addColorStop(1, 'rgba(255, 200, 100, 0)');

        this.ctx.fillStyle = gradient;
        this.ctx.beginPath();
        this.ctx.arc(node.x, node.y, glowRadius, 0, Math.PI * 2);
        this.ctx.fill();
      }

      // Node body
      this.ctx.fillStyle = node.color;
      this.ctx.beginPath();
      this.ctx.arc(node.x, node.y, node.radius, 0, Math.PI * 2);
      this.ctx.fill();

      // Pulse effect
      if (node.activation > 0.5) {
        const pulse = Math.sin(this.time * 3 + node.pulsePhase) * 0.5 + 0.5;
        this.ctx.strokeStyle = `rgba(255, 255, 255, ${pulse * node.activation})`;
        this.ctx.lineWidth = 2;
        this.ctx.beginPath();
        this.ctx.arc(node.x, node.y, node.radius + pulse * 5, 0, Math.PI * 2);
        this.ctx.stroke();
      }
    }
  }

  drawCenters() {
    const centerPositions = {
      'identity': { x: 100, y: 100 },
      'mind': { x: 700, y: 100 },
      'system': { x: 100, y: 500 },
      'heart': { x: 700, y: 500 },
      'memory': { x: 400, y: 50 },
      'broadcast': { x: 400, y: 550 },
      'mesh': { x: 50, y: 300 },
      'intelligence': { x: 750, y: 300 },
      'governance': { x: 400, y: 300 }
    };

    for (const [name, data] of this.centers) {
      const pos = centerPositions[name];
      if (!pos) continue;

      const activation = data.activation || 0;
      const size = 20 + activation * 30;

      // Center glow
      this.ctx.fillStyle = `rgba(200, 100, 255, ${activation * 0.5})`;
      this.ctx.beginPath();
      this.ctx.arc(pos.x, pos.y, size, 0, Math.PI * 2);
      this.ctx.fill();

      // Center label
      this.ctx.fillStyle = 'white';
      this.ctx.font = '12px monospace';
      this.ctx.textAlign = 'center';
      this.ctx.fillText(name.toUpperCase(), pos.x, pos.y + 4);

      // Node count
      this.ctx.font = '10px monospace';
      this.ctx.fillStyle = `rgba(255, 255, 255, ${0.5 + activation * 0.5})`;
      this.ctx.fillText(`${data.node_count || 0} nodes`, pos.x, pos.y + 18);
    }
  }

  drawHUD() {
    this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    this.ctx.fillRect(10, 10, 200, 120);

    this.ctx.fillStyle = 'white';
    this.ctx.font = '12px monospace';
    this.ctx.textAlign = 'left';

    this.ctx.fillText('SYNTHIA ORGANISM', 20, 30);
    this.ctx.fillText(`Nodes: ${this.nodes.size}`, 20, 50);
    this.ctx.fillText(`Channels: ${this.channels.size}`, 20, 65);
    this.ctx.fillText(`Active: ${this.getActiveNodeCount()}`, 20, 80);
    this.ctx.fillText(`Time: ${this.time.toFixed(1)}s`, 20, 95);
    this.ctx.fillText(`Motor: ${this.motorActive ? 'ON' : 'OFF'}`, 20, 110);
  }

  getActiveNodeCount() {
    let count = 0;
    for (const node of this.nodes.values()) {
      if (node.activation > 0.1) count++;
    }
    return count;
  }

  get motorActive() {
    for (const [name, data] of this.centers) {
      if (['heart', 'broadcast', 'system'].includes(name) && data.activation > 0.5) {
        return true;
      }
    }
    return false;
  }

  start() {
    this.render();
  }

  stop() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
  }
}

// ============================================
// YOU-N-I-VERSE INTERFACE — User Connection
// ============================================

class YouNIVerseInterface {
  constructor(mesh, renderer) {
    this.mesh = mesh;
    this.renderer = renderer;
    this.userId = null;
    this.userState = {
      hexagram: 0,
      line: 1,
      connected: false
    };

    this.conversationHistory = [];
    this.currentMode = 'text';
  }

  async connect(userId, profile = {}) {
    this.userId = userId;

    // Send connection request to organism
    this.mesh.send({
      type: 'connect_user',
      userId,
      profile,
      timestamp: Date.now()
    });

    // Wait for response
    return new Promise((resolve) => {
      this.mesh.on('user_connected', (msg) => {
        if (msg.userId === userId) {
          this.userState.connected = true;
          this.userState.hexagram = msg.hexagram;
          this.userState.line = msg.line;
          resolve(msg);
        }
      });
    });
  }

  async sendMessage(text) {
    if (!this.userState.connected) {
      throw new Error('Not connected to organism');
    }

    // Add to conversation history
    this.conversationHistory.push({
      role: 'user',
      text,
      timestamp: Date.now()
    });

    // Send to organism
    this.mesh.sendUserInput(this.userId, text);

    // Wait for response
    return new Promise((resolve) => {
      const handler = (msg) => {
        if (msg.userId === this.userId && msg.type === 'response') {
          this.mesh.observers.get('response')?.delete(handler);

          this.conversationHistory.push({
            role: 'organism',
            text: msg.response,
            timestamp: Date.now()
          });

          resolve(msg);
        }
      };

      this.mesh.on('response', handler);
    });
  }

  switchMode(mode) {
    this.currentMode = mode;
    this.mesh.send({
      type: 'switch_mode',
      userId: this.userId,
      mode,
      timestamp: Date.now()
    });
  }

  getUserPosition() {
    return {
      hexagram: this.userState.hexagram,
      line: this.userState.line,
      hexagramName: this.getHexagramName(this.userState.hexagram)
    };
  }

  getHexagramName(index) {
    const names = [
      'The Creative', 'The Receptive', 'Difficulty at the Beginning',
      'Youthful Folly', 'Waiting', 'Conflict', 'The Army',
      'Holding Together', 'Small Taming', 'Treading', 'Peace',
      'Standstill', 'Fellowship', 'Possession', 'Modesty',
      'Enthusiasm', 'Following', 'Work on the Decayed', 'Approach',
      'Contemplation', 'Biting Through', 'Grace', 'Splitting Apart',
      'Return', 'Innocence', 'The Taming Power of the Great',
      'The Corners of the Mouth', 'Preponderance of the Great',
      'The Abysmal Water', 'The Clinging Fire', 'Influence',
      'Duration', 'Retreat', 'The Power of the Great', 'Progress',
      'Darkening of the Light', 'The Family', 'Opposition',
      'Obstruction', 'Deliverance', 'Decrease', 'Increase',
      'Breakthrough', 'Coming to Meet', 'Gathering Together',
      'Pushing Upward', 'Oppression', 'The Well', 'Revolution',
      'The Cauldron', 'The Arousing Thunder', 'Keeping Still',
      'Development', 'The Marrying Maiden', 'Abundance',
      'The Wanderer', 'The Gentle', 'The Joyous', 'Dispersion',
      'Limitation', 'Inner Truth', 'Preponderance of the Small',
      'After Completion', 'Before Completion'
    ];
    return names[index] || 'Unknown';
  }
}

// ============================================
// MOTOR OUTPUT RENDERER — Non-Text Generation
// ============================================

class MotorOutputRenderer {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.activeOutputs = new Set();
  }

  render(outputType, data) {
    switch (outputType) {
      case 'video':
        return this.renderVideo(data);
      case 'game':
        return this.renderGame(data);
      case 'music':
        return this.renderMusic(data);
      case 'photo':
        return this.renderPhoto(data);
      case 'app':
        return this.renderApp(data);
      default:
        return this.renderText(data);
    }
  }

  renderVideo(data) {
    const video = document.createElement('div');
    video.className = 'motor-output video-output';
    video.innerHTML = `
      <div class="video-frame">
        <canvas id="video-canvas-${Date.now()}" width="640" height="360"></canvas>
        <div class="video-overlay">
          <span class="video-label">◉ GENERATED SCENE</span>
          <span class="video-source">From hexagram ${data.hexagram || '?'}</span>
        </div>
      </div>
    `;
    this.container.appendChild(video);
    this.activeOutputs.add('video');
    return video;
  }

  renderGame(data) {
    const game = document.createElement('div');
    game.className = 'motor-output game-output';
    game.innerHTML = `
      <div class="game-frame">
        <div class="game-world">
          <div class="game-entity" style="left: ${Math.random() * 80}%; top: ${Math.random() * 80}%">◉</div>
          <div class="game-entity" style="left: ${Math.random() * 80}%; top: ${Math.random() * 80}%">◉</div>
        </div>
        <div class="game-ui">
          <span>Interactive Scenario</span>
          <span>Phase: ${data.phase || '?'}</span>
        </div>
      </div>
    `;
    this.container.appendChild(game);
    this.activeOutputs.add('game');
    return game;
  }

  renderMusic(data) {
    const music = document.createElement('div');
    music.className = 'motor-output music-output';
    music.innerHTML = `
      <div class="music-visualizer">
        <canvas id="music-canvas-${Date.now()}" width="400" height="100"></canvas>
        <div class="music-info">
          <span>♪ Harmonic Pattern</span>
          <span>Hexagram ${data.hexagram || '?'} — Line ${data.line || '?'}</span>
        </div>
      </div>
    `;
    this.container.appendChild(music);
    this.activeOutputs.add('music');
    return music;
  }

  renderPhoto(data) {
    const photo = document.createElement('div');
    photo.className = 'motor-output photo-output';
    photo.innerHTML = `
      <div class="photo-frame">
        <div class="photo-composition" style="background: hsl(${data.hexagram * 5.625 || 0}, 60%, 40%)">
          <div class="photo-element">◉</div>
        </div>
        <div class="photo-caption">
          Composition from ${data.hexagramName || 'Unknown'}
        </div>
      </div>
    `;
    this.container.appendChild(photo);
    this.activeOutputs.add('photo');
    return photo;
  }

  renderApp(data) {
    const app = document.createElement('div');
    app.className = 'motor-output app-output';
    app.innerHTML = `
      <div class="app-frame">
        <div class="app-header">
          <span>◉ Tool</span>
          <span>${data.phase || '?'}</span>
        </div>
        <div class="app-body">
          <div class="app-control">Input</div>
          <div class="app-display">Output</div>
        </div>
      </div>
    `;
    this.container.appendChild(app);
    this.activeOutputs.add('app');
    return app;
  }

  renderText(data) {
    const text = document.createElement('div');
    text.className = 'motor-output text-output';
    text.innerHTML = `<p>${data.response || data.text || '...'}</p>`;
    this.container.appendChild(text);
    return text;
  }

  clear() {
    this.container.innerHTML = '';
    this.activeOutputs.clear();
  }
}

// ============================================
// MAIN APPLICATION — Synthia Organism UI
// ============================================

class SynthiaOrganismApp {
  constructor() {
    this.mesh = new MeshProtocol();
    this.renderer = null;
    this.interface = null;
    this.motorRenderer = null;
    this.state = 'disconnected';
  }

  async init() {
    // Initialize UI elements
    this.renderer = new NodeSpaceRenderer('node-canvas');
    this.motorRenderer = new MotorOutputRenderer('output-container');

    // Connect to organism
    await this.mesh.connect();

    // Set up message handlers
    this.mesh.on('state_update', (msg) => this.handleStateUpdate(msg));
    this.mesh.on('channel_formed', (msg) => this.handleChannelFormed(msg));
    this.mesh.on('motor_activation', (msg) => this.handleMotorActivation(msg));
    this.mesh.on('response', (msg) => this.handleResponse(msg));

    // Start rendering
    this.renderer.start();

    // Start heartbeat
    setInterval(() => this.mesh.heartbeat(), 5000);

    this.state = 'connected';
    console.log('[App] Synthia Organism initialized');
  }

  async connectUser(userId) {
    this.interface = new YouNIVerseInterface(this.mesh, this.renderer);
    const result = await this.interface.connect(userId);

    console.log('[App] User connected:', result);
    return result;
  }

  async sendMessage(text) {
    if (!this.interface) {
      throw new Error('No user connected');
    }

    const response = await this.interface.sendMessage(text);

    // Render response
    if (response.motor_active) {
      this.motorRenderer.render(response.output_type || 'text', response);
    } else {
      this.motorRenderer.render('text', response);
    }

    return response;
  }

  handleStateUpdate(msg) {
    // Update node states
    if (msg.nodes) {
      for (const [nodeId, state] of Object.entries(msg.nodes)) {
        this.renderer.updateNodeState(nodeId, state);
      }
    }

    // Update channels
    if (msg.channels) {
      this.renderer.updateChannels(msg.channels);
    }

    // Update centers
    if (msg.centers) {
      this.renderer.updateCenters(msg.centers);
    }
  }

  handleChannelFormed(msg) {
    console.log('[Channel] Formed:', msg.channel);
    // Visual feedback
  }

  handleMotorActivation(msg) {
    console.log('[Motor] Activated:', msg.outputs);
    // Enable motor output buttons
  }

  handleResponse(msg) {
    console.log('[Response]:', msg.response);
  }
}

// ============================================
// EXPORT
// ============================================

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    MeshProtocol,
    NodeSpaceRenderer,
    YouNIVerseInterface,
    MotorOutputRenderer,
    SynthiaOrganismApp
  };
} else {
  window.SynthiaOrganism = {
    MeshProtocol,
    NodeSpaceRenderer,
    YouNIVerseInterface,
    MotorOutputRenderer,
    SynthiaOrganismApp
  };
}
