"""
messy_vessel.py
The Vessel — MESSY Reimagined (Non-Energy Circuit / Python)

MESSY is the container, the world, the semantic simulation space.
It is NOT the mind, body, or heart — it is the VESSEL they traverse.

The Vessel contains:
- The semantic network (directed graph with labeled edges)
- The simulation clock (temporal dimension)
- The behavioral rules (stochastic, probabilistic)
- The 384-node state space (the I Ching-ordered possibility field)
- The 9 centers (emergent from graph topology)
- The 36 channels (emerge through message passing)

The Vessel is passive in itself — it is ACTIVATED by the traversing
entities (Autonovel, DISEMINER, AUTOLING). Without them, it is
an empty possibility field. With them, it becomes a living world.

The Vessel uses the I Ching as its ordering principle:
- Time flows through the 64 hexagrams
- Each moment is a line position within a hexagram
- The changing lines (yao) represent state transitions
- The temporal dimension is cyclic, not linear
"""

from typing import Dict, List, Tuple, Optional, Set, Callable, Any
from dataclasses import dataclass, field
from enum import Enum, auto
import json
import hashlib
from collections import defaultdict
import numpy as np
from i_ching_384_nodes import StateSpace384, NodeState, Dimension


class VesselPhase(Enum):
    """The Vessel cycles through phases like the I Ching"""
    CREATION = auto()      # Qian — pure yang, potential
    RECEPTION = auto()     # Kun — pure yin, manifestation
    DIFFICULTY = auto()    # Zhun — chaos at birth
    GROWTH = auto()        # Tai — peace, expansion
    STANDSTILL = auto()    # Pi — stagnation, consolidation
    TRANSFORMATION = auto() # Ge — revolution, change
    RETURN = auto()        # Fu — return to source
    COMPLETION = auto()    # Ji Ji — after completion
    BEFORE_COMPLETION = auto() # Wei Ji — before completion


@dataclass
class SemanticTriple:
    """
    The fundamental unit of the Vessel's semantic network.
    α — R — β, where α and β are objects/relations, R is a relation.

    In Klein's original MESSY, this was the atomic unit.
    Here, it is enhanced with 5D state and temporal awareness.
    """
    alpha: str              # Object or relation (node ID)
    relation: str           # The relation type
    beta: str               # Object or relation (node ID)

    # Temporal properties
    creation_time: float = 0.0
    deletion_time: Optional[float] = None

    # 5D state (inherited from the nodes it connects)
    d1_impulse: float = 0.0
    d2_polarity: float = 0.0
    d3_witness: float = 0.0
    d4_context: float = 0.0
    d5_meaning: float = 0.0

    # Possibility amplitude (quantum-like superposition)
    amplitude: complex = complex(1, 0)

    # Lexical expression list (links to natural language)
    lexical_variants: List[str] = field(default_factory=list)

    # Self-referential: can point to other triples
    subnetwork_pointers: List[str] = field(default_factory=list)

    @property
    def is_active(self) -> bool:
        """A triple is active if it hasn't been deleted"""
        return self.deletion_time is None

    @property
    def triple_id(self) -> str:
        """Unique identifier for this triple"""
        return hashlib.sha256(
            f"{self.alpha}:{self.relation}:{self.beta}:{self.creation_time}".encode()
        ).hexdigest()[:16]

    def to_5d_tensor(self) -> np.ndarray:
        """Return the triple's 5D state as a tensor"""
        return np.array([
            self.d1_impulse, self.d2_polarity, self.d3_witness,
            self.d4_context, self.d5_meaning
        ])

    def resonate_with(self, other: 'SemanticTriple') -> float:
        """Compute resonance with another triple"""
        self_t = self.to_5d_tensor()
        other_t = other.to_5d_tensor()

        dot = np.dot(self_t, other_t)
        mag = np.linalg.norm(self_t) * np.linalg.norm(other_t)

        if mag == 0:
            return 0.0

        return dot / mag


@dataclass
class VesselEntity:
    """
    An entity traversing the Vessel.
    This could be a user, a character, a thought, a memory —
    anything that exists within the simulation space.

    Entities have:
    - A semantic network (their "universe of discourse")
    - A position in the 384-node state space
    - Behavioral rules (stochastic, modifiable)
    - A history of interactions
    """
    entity_id: str
    entity_type: str  # 'user', 'character', 'thought', 'memory', 'archetype'

    # Position in 384-node space (which hexagram/line they occupy)
    hexagram_position: int = 0
    line_position: int = 1

    # The entity's semantic network (private universe)
    semantic_network: Dict[str, SemanticTriple] = field(default_factory=dict)

    # Behavioral rules (stochastic, written in simulation language)
    behavioral_rules: List[Dict] = field(default_factory=list)

    # Grammar (for language generation/parsing)
    grammar_rules: List[Dict] = field(default_factory=list)

    # State across 5 dimensions
    d1_impulse: float = 0.0
    d2_polarity: float = 0.0
    d3_witness: float = 0.0
    d4_context: float = 0.0
    d5_meaning: float = 0.0

    # Interaction history
    interaction_log: List[Dict] = field(default_factory=list)

    # The entity's "possibility field" — all states it could be
    possibility_field: np.ndarray = field(default_factory=lambda: np.zeros(384))

    def move_to(self, hexagram: int, line: int):
        """Move the entity to a new position in the state space"""
        self.hexagram_position = hexagram
        self.line_position = line

    def add_triple(self, alpha: str, relation: str, beta: str, time: float = 0.0):
        """Add a semantic triple to the entity's network"""
        triple = SemanticTriple(alpha, relation, beta, creation_time=time)
        self.semantic_network[triple.triple_id] = triple
        return triple.triple_id

    def to_5d_tensor(self) -> np.ndarray:
        return np.array([
            self.d1_impulse, self.d2_polarity, self.d3_witness,
            self.d4_context, self.d5_meaning
        ])


class Vessel:
    """
    The Vessel — MESSY Reimagined.

    The Vessel is the container. It holds:
    - The 384-node state space (possibility field)
    - The semantic network (all triples in the simulation)
    - All entities (users, characters, thoughts, memories)
    - The simulation clock
    - The behavioral rules (stochastic)
    - The 9 centers (emergent)
    - The 36 channels (emergent)

    The Vessel is activated by the traversing entities:
    - Autonovel (Mind) — generates narrative from vessel state
    - DISEMINER (Body) — learns distributional patterns from vessel
    - AUTOLING (Heart) — evolves grammar rules from vessel interactions

    Without these entities, the Vessel is a sleeping possibility field.
    With them, it becomes a living world.
    """

    def __init__(self):
        # The 384-node state space
        self.state_space = StateSpace384()

        # The global semantic network (all triples)
        self.global_network: Dict[str, SemanticTriple] = {}

        # All entities in the vessel
        self.entities: Dict[str, VesselEntity] = {}

        # The simulation clock
        self.time: float = 0.0
        self.phase: VesselPhase = VesselPhase.CREATION

        # Current hexagram (temporal position)
        self.current_hexagram: int = 0
        self.current_line: int = 1

        # Changing lines (yao) — which lines are in transition
        self.changing_lines: Set[int] = set()

        # Behavioral rules (stochastic)
        self.behavioral_rules: List[Dict] = []

        # Event queue
        self.events: List[Dict] = []

        # Observers (for real-time feedback to energy circuits)
        self.observers: List[Callable] = []

        # The You-N-I-Verse node — the bridge between user and system
        self.youniverse_node: Optional[str] = None

        # Motor group activation state
        self.motor_active: bool = False
        self.motor_outputs: List[str] = []

    def create_entity(self, entity_id: str, entity_type: str = 'character') -> VesselEntity:
        """Create a new entity in the vessel"""
        entity = VesselEntity(entity_id=entity_id, entity_type=entity_type)
        self.entities[entity_id] = entity

        # Place entity in state space
        hexagram = hash(entity_id) % 64
        line = (hash(entity_id) >> 8) % 6 + 1
        entity.move_to(hexagram, line)

        # Activate the corresponding node
        self.state_space.activate_node(hexagram, line, 0.5)

        return entity

    def add_user(self, user_id: str) -> VesselEntity:
        """
        Add a user to the You-N-I-Verse.
        The user IS represented by the entity as a whole.
        The system learns about them and communicates with them.
        """
        user = self.create_entity(user_id, entity_type='user')

        # The user entity becomes the You-N-I-Verse node
        self.youniverse_node = user_id

        # Initialize the user's semantic network with self-knowledge
        user.add_triple(user_id, 'is', 'human', self.time)
        user.add_triple(user_id, 'exists_in', 'vessel', self.time)
        user.add_triple(user_id, 'observes', 'vessel', self.time)

        # Notify observers
        for observer in self.observers:
            observer('user_entered', {
                'user_id': user_id,
                'hexagram': user.hexagram_position,
                'line': user.line_position,
                'time': self.time
            })

        return user

    def add_triple(self, alpha: str, relation: str, beta: str, 
                   entity_id: Optional[str] = None) -> str:
        """
        Add a semantic triple to the vessel.
        If entity_id is provided, add to that entity's private network.
        Otherwise, add to the global network.
        """
        triple = SemanticTriple(alpha, relation, beta, creation_time=self.time)

        if entity_id and entity_id in self.entities:
            self.entities[entity_id].semantic_network[triple.triple_id] = triple
        else:
            self.global_network[triple.triple_id] = triple

        # Activate corresponding nodes in state space
        self._activate_triple_nodes(triple)

        return triple.triple_id

    def _activate_triple_nodes(self, triple: SemanticTriple):
        """Activate nodes in the 384-space corresponding to a triple"""
        # Hash the triple components to hexagram/line positions
        alpha_hash = hash(triple.alpha) % 64
        alpha_line = (hash(triple.alpha) >> 8) % 6 + 1

        beta_hash = hash(triple.beta) % 64
        beta_line = (hash(triple.beta) >> 8) % 6 + 1

        self.state_space.activate_node(alpha_hash, alpha_line, 0.3)
        self.state_space.activate_node(beta_hash, beta_line, 0.3)

    def simulate_event(self, event_type: str, participants: List[str], 
                       context: Dict = None):
        """
        Simulate an event in the vessel.
        Events alter the semantic network and trigger state changes.
        """
        event = {
            'type': event_type,
            'participants': participants,
            'context': context or {},
            'time': self.time,
            'hexagram': self.current_hexagram,
            'line': self.current_line
        }

        self.events.append(event)

        # Apply behavioral rules
        self._apply_behavioral_rules(event)

        # Update entity states
        for participant_id in participants:
            if participant_id in self.entities:
                entity = self.entities[participant_id]
                entity.interaction_log.append(event)

                # Update entity's 5D state based on event
                self._update_entity_state(entity, event)

        # Advance time
        self._advance_time()

        # Notify observers
        for observer in self.observers:
            observer('event', event)

    def _apply_behavioral_rules(self, event: Dict):
        """Apply stochastic behavioral rules to the event"""
        for rule in self.behavioral_rules:
            # Check if rule applies to this event type
            if rule.get('event_type') == event['type']:
                # Compute probability of rule firing
                probability = rule.get('probability', 0.5)

                # Check conditions
                conditions_met = self._check_conditions(rule.get('conditions', []), event)

                if conditions_met and np.random.random() < probability:
                    # Apply rule effects
                    self._apply_effects(rule.get('effects', []), event)

    def _check_conditions(self, conditions: List[Dict], event: Dict) -> bool:
        """Check if all conditions are met for a rule"""
        for condition in conditions:
            # Example: {'type': 'entity_has_property', 'entity': 'participant_0', 'property': 'greedy'}
            pass  # Simplified for now
        return True

    def _apply_effects(self, effects: List[Dict], event: Dict):
        """Apply the effects of a rule"""
        for effect in effects:
            # Example: {'type': 'add_triple', 'alpha': 'A', 'relation': 'loves', 'beta': 'B'}
            if effect.get('type') == 'add_triple':
                self.add_triple(
                    effect['alpha'], effect['relation'], effect['beta']
                )

    def _update_entity_state(self, entity: VesselEntity, event: Dict):
        """Update an entity's 5D state based on an event"""
        # Increase D1 (impulse) from event activation
        entity.d1_impulse += 0.1

        # Update D4 (context) with temporal embedding
        entity.d4_context += 0.05

        # Update D3 (witness) if the entity is observing
        if event.get('type') in ['observation', 'conversation', 'perception']:
            entity.d3_witness += 0.1

        # Update D5 (meaning) if the entity is expressing
        if event.get('type') in ['speech', 'creation', 'expression']:
            entity.d5_meaning += 0.1

    def _advance_time(self):
        """Advance the simulation clock through the I Ching sequence"""
        self.time += 1.0

        # Advance line position
        self.current_line += 1
        if self.current_line > 6:
            self.current_line = 1
            self.current_hexagram = (self.current_hexagram + 1) % 64

            # Change phase based on hexagram
            self._update_phase()

        # Tick the state space
        self.state_space.tick(dt=1.0)

        # Check for changing lines (yao)
        self._check_changing_lines()

    def _update_phase(self):
        """Update the vessel phase based on current hexagram"""
        phase_map = {
            0: VesselPhase.CREATION,      # Qian
            1: VesselPhase.RECEPTION,      # Kun
            2: VesselPhase.DIFFICULTY,     # Zhun
            10: VesselPhase.GROWTH,        # Tai
            11: VesselPhase.STANDSTILL,    # Pi
            48: VesselPhase.TRANSFORMATION, # Ge
            23: VesselPhase.RETURN,        # Fu
            62: VesselPhase.COMPLETION,    # Ji Ji
            63: VesselPhase.BEFORE_COMPLETION, # Wei Ji
        }

        self.phase = phase_map.get(self.current_hexagram, VesselPhase.CREATION)

    def _check_changing_lines(self):
        """Check which lines are in transition (changing yao)"""
        # A line is changing if its activation is high but unstable
        self.changing_lines.clear()

        for line in range(1, 7):
            node = self.state_space.get_node(self.current_hexagram, line)
            if node and node.d1_impulse > 0.7 and node.d2_polarity > 0.5:
                self.changing_lines.add(line)

    def get_vessel_state(self) -> Dict:
        """Get the complete state of the vessel"""
        return {
            'time': self.time,
            'phase': self.phase.name,
            'hexagram': self.current_hexagram,
            'hexagram_name': self.state_space.get_node(self.current_hexagram, 1).hexagram_name if self.state_space.get_node(self.current_hexagram, 1) else "Unknown",
            'line': self.current_line,
            'changing_lines': list(self.changing_lines),
            'entity_count': len(self.entities),
            'triple_count': len(self.global_network),
            'event_count': len(self.events),
            'state_space': self.state_space.get_state_snapshot(),
            'motor_active': self.motor_active,
            'motor_outputs': self.motor_outputs
        }

    def to_json(self) -> str:
        """Serialize vessel state to JSON"""
        return json.dumps(self.get_vessel_state(), indent=2, default=str)


if __name__ == '__main__':
    # Test the vessel
    vessel = Vessel()

    # Add a user
    user = vessel.add_user('user_001')

    # Create a character
    character = vessel.create_entity('char_001', 'character')

    # Add some triples
    vessel.add_triple('user_001', 'sees', 'char_001')
    vessel.add_triple('char_001', 'feels', 'curious')

    # Simulate an event
    vessel.simulate_event('conversation', ['user_001', 'char_001'], {
        'topic': 'greeting',
        'emotional_tone': 'neutral'
    })

    # Print state
    print(vessel.to_json())
