"""
mesh_bridge.py
The Mesh Bridge — WebSocket Server (Non-Energy Circuit / Python)

Updated to include Garden Mode commands and subscription management.
"""

import asyncio
import json
import websockets
from typing import Dict, Set, Callable
from organism_orchestrator import DigitalOrganism

# Import garden mode if available
try:
    from garden_mode import GardenMode, ResonanceSignature, CultivationPhase
    GARDEN_AVAILABLE = True
except ImportError:
    GARDEN_AVAILABLE = False


class MeshBridge:
    """WebSocket bridge connecting Python organism to JavaScript energy circuits."""

    def __init__(self, organism: DigitalOrganism, host='localhost', port=8765):
        self.organism = organism
        self.host = host
        self.port = port
        self.clients: Set[websockets.WebSocketServerProtocol] = set()
        self.running = False
        self.server = None

        # Garden modes for connected users
        self.gardens: Dict[str, GardenMode] = {}

    async def handle_client(self, websocket, path):
        """Handle a new client connection"""
        self.clients.add(websocket)
        print(f"[Bridge] Client connected. Total: {len(self.clients)}")

        try:
            async for message in websocket:
                await self.handle_message(websocket, message)
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            self.clients.discard(websocket)
            print(f"[Bridge] Client disconnected. Total: {len(self.clients)}")

    async def handle_message(self, websocket, message):
        """Handle a message from a client"""
        try:
            data = json.loads(message)
            msg_type = data.get('type')

            if msg_type == 'user_input':
                user_id = data.get('userId')
                text = data.get('text')

                result = self.organism.process_user_input(user_id, text)

                await websocket.send(json.dumps({
                    'type': 'response',
                    'userId': user_id,
                    'response': result.get('response'),
                    'state': result.get('state'),
                    'motor_active': result.get('motor_active'),
                    'hexagram': result.get('hexagram'),
                    'line': result.get('line'),
                    'phase': result.get('phase')
                }))

            elif msg_type == 'connect_user':
                user_id = data.get('userId')
                profile = data.get('profile', {})

                # Create garden mode for user
                if GARDEN_AVAILABLE and user_id not in self.gardens:
                    self.gardens[user_id] = GardenMode(user_id)

                response = self.organism.connect_user(user_id, profile)
                user_entity = self.organism.vessel.entities.get(user_id)

                await websocket.send(json.dumps({
                    'type': 'user_connected',
                    'userId': user_id,
                    'greeting': response,
                    'hexagram': user_entity.hexagram_position if user_entity else 0,
                    'line': user_entity.line_position if user_entity else 1,
                    'garden_mode': GARDEN_AVAILABLE
                }))

            elif msg_type == 'garden_question':
                user_id = data.get('userId')

                if GARDEN_AVAILABLE and user_id in self.gardens:
                    garden = self.gardens[user_id]
                    question = garden.ask_question()

                    await websocket.send(json.dumps({
                        'type': 'garden_question',
                        'userId': user_id,
                        'question': question,
                        'fade_status': garden._check_fade() if hasattr(garden, '_check_fade') else {}
                    }))
                else:
                    await websocket.send(json.dumps({
                        'type': 'garden_question',
                        'userId': user_id,
                        'question': None,
                        'error': 'Garden mode not available'
                    }))

            elif msg_type == 'garden_response':
                user_id = data.get('userId')
                response_text = data.get('response')

                if GARDEN_AVAILABLE and user_id in self.gardens:
                    garden = self.gardens[user_id]
                    result = garden.process_response(response_text)

                    await websocket.send(json.dumps({
                        'type': 'garden_response',
                        'userId': user_id,
                        'message': result.get('message'),
                        'insights': result.get('insights'),
                        'fade_status': result.get('fade_status'),
                        'signature': result.get('signature')
                    }))
                else:
                    await websocket.send(json.dumps({
                        'type': 'garden_response',
                        'userId': user_id,
                        'error': 'Garden mode not available'
                    }))

            elif msg_type == 'subscription':
                user_id = data.get('userId')

                if GARDEN_AVAILABLE and user_id in self.gardens:
                    garden = self.gardens[user_id]
                    representation = garden.get_subscription_representation()

                    await websocket.send(json.dumps({
                        'type': 'subscription',
                        'userId': user_id,
                        'representation': representation
                    }))
                else:
                    await websocket.send(json.dumps({
                        'type': 'subscription',
                        'userId': user_id,
                        'representation': None
                    }))

            elif msg_type == 'request_state':
                state = self.organism.get_state_snapshot()

                node_states = {}
                for node_id, node in self.organism.vessel.state_space.nodes.items():
                    node_states[node_id] = {
                        'd1': node.d1_impulse,
                        'd2': node.d2_polarity,
                        'd3': node.d3_witness,
                        'd4': node.d4_context,
                        'd5': node.d5_meaning,
                        'amplitude': {'real': node.possibility_amplitude.real, 
                                     'imag': node.possibility_amplitude.imag}
                    }

                await websocket.send(json.dumps({
                    'type': 'state_update',
                    'state': state,
                    'nodes': node_states,
                    'channels': self.organism.channels,
                    'centers': {
                        name: {'node_count': len(data['nodes']), 
                               'activation': data['activation']}
                        for name, data in self.organism.centers.items()
                    }
                }))

            elif msg_type == 'heartbeat':
                await websocket.send(json.dumps({
                    'type': 'heartbeat_ack',
                    'timestamp': data.get('timestamp'),
                    'organism_time': self.organism.vessel.time
                }))

            elif msg_type == 'switch_mode':
                user_id = data.get('userId')
                mode = data.get('mode')

                if user_id in self.organism.connected_users:
                    self.organism.connected_users[user_id]['preferred_mode'] = mode

                await websocket.send(json.dumps({
                    'type': 'mode_switched',
                    'userId': user_id,
                    'mode': mode
                }))

        except json.JSONDecodeError:
            print(f"[Bridge] Invalid JSON: {message}")
        except Exception as e:
            print(f"[Bridge] Error handling message: {e}")

    async def broadcast_state(self):
        """Broadcast organism state to all connected clients"""
        if not self.clients:
            return

        state = self.organism.get_state_snapshot()

        message = json.dumps({
            'type': 'state_update',
            'state': state
        }, default=str)

        disconnected = set()
        for client in self.clients:
            try:
                await client.send(message)
            except websockets.exceptions.ConnectionClosed:
                disconnected.add(client)

        self.clients -= disconnected

    async def start(self):
        """Start the WebSocket server"""
        self.running = True

        self.server = await websockets.serve(
            self.handle_client,
            self.host,
            self.port
        )

        print(f"[Bridge] WebSocket server started on ws://{self.host}:{self.port}")

        asyncio.create_task(self.broadcast_loop())

        await self.server.wait_closed()

    async def broadcast_loop(self):
        """Periodically broadcast state to all clients"""
        while self.running:
            await self.broadcast_state()
            await asyncio.sleep(1.0)

    async def stop(self):
        """Stop the WebSocket server"""
        self.running = False
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        print("[Bridge] Stopped")


async def main():
    """Main entry point — start organism and bridge"""
    organism = DigitalOrganism()
    organism.awaken()

    organism.start()

    bridge = MeshBridge(organism)

    try:
        await bridge.start()
    except KeyboardInterrupt:
        print("\n[Bridge] Shutting down...")
        await bridge.stop()
        organism.stop()


if __name__ == '__main__':
    asyncio.run(main())
