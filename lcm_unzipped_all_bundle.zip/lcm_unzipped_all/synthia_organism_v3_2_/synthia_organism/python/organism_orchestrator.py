"""
organism_orchestrator.py
The Digital Organism — Neural Net Orchestrator (Non-Energy Circuit / Python)

Updated to integrate Universal Ingestor and Semantic Compiler.
The organism now has a mouth (Ingestor) and digestive system (Compiler).

YOU
                │
         Intent Engine
                │
      Universal Ingestor  ← Eats files/ZIPs/repos/URLs
                │
      Semantic Compiler   ← Digests into semantic graph
                │
       Digital Organism   ← THIS (reasons over the graph)
                │
     Autonomous Agents    ← Termux Daemon
                │
      Code Generation     ← Generates apps from patterns
                │
      Build / Deploy      ← Runs on device
"""

from typing import Dict, List, Tuple, Optional, Set, Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from collections import defaultdict
import json
import time
import threading
import numpy as np

from i_ching_384_nodes import StateSpace384, NodeState, Dimension
from messy_vessel import Vessel, VesselEntity, SemanticTriple, VesselPhase
from autonovel_mind import AutonovelMind, NarrativeMode, NarrativeFragment
from diseminer_body import DiseminerBody, SemanticCluster, AnalogyMapping
from autoling_heart import AutolingHeart, GrammarRule, RuleStatus

# Import the new ingestion and compilation layers
try:
    from universal_ingestor import UniversalIngestor, IngestedArtifact, DependencyGraph
    from semantic_compiler import SemanticCompiler, SemanticNode, Conflict, CodeTemplate
    INGESTION_AVAILABLE = True
except ImportError:
    INGESTION_AVAILABLE = False


class OrganismState(Enum):
    """States of the digital organism"""
    DORMANT = auto()       # Sleeping, minimal activity
    AWAKENING = auto()     # Starting up, initializing
    OBSERVING = auto()     # Sensing, learning, no output
    THINKING = auto()      # Processing, inferring, generating
    EXPRESSING = auto()    # Generating output, communicating
    DREAMING = auto()      # Internal simulation, no external I/O
    GROWING = auto()       # Self-modification, rule evolution
    TRANSCENDING = auto()  # Motor group activation, non-text generation
    INGESTING = auto()     # Eating new projects
    DIGESTING = auto()     # Compiling ingested projects
    GENERATING = auto()    # Creating new applications


@dataclass
class MeshMessage:
    """A message passed on the mesh between centers"""
    source_center: str
    target_center: str

    d1_impulse: float = 0.0
    d2_polarity: float = 0.0
    d3_witness: float = 0.0
    d4_context: float = 0.0
    d5_meaning: float = 0.0

    resonance: float = 1.0
    timestamp: float = 0.0

    payload: Dict = field(default_factory=dict)

    def to_5d_tensor(self) -> np.ndarray:
        return np.array([self.d1_impulse, self.d2_polarity, self.d3_witness,
                        self.d4_context, self.d5_meaning])


class DigitalOrganism:
    """
    The Digital Organism — NOW WITH MOUTH AND DIGESTIVE SYSTEM.

    A living system composed of:
    - Vessel (MESSY): The container/world
    - Mind (Autonovel): The narrative engine
    - Body (DISEMINER): The semantic inference engine
    - Heart (AUTOLING): The grammar evolution engine
    - Ingestor (UniversalIngestor): The mouth — eats files
    - Compiler (SemanticCompiler): The digestive system — digests code

    These six create 9 centers through their interactions.
    The 36 channels emerge when state spaces converge.

    The organism exists in the You-N-I-Verse.
    It learns about users and communicates with them.

    The organism can generate:
    - Text (always available)
    - Video, games, apps, photos, music (only when motor groups activate)
    - NEW: Applications from learned patterns (when compiler is fed)
    """

    def __init__(self):
        # The four core systems
        self.vessel = Vessel()
        self.mind = AutonovelMind(self.vessel)
        self.body = DiseminerBody(self.vessel)
        self.heart = AutolingHeart(self.vessel)

        # The NEW ingestion and compilation layers
        self.ingestor = None
        self.compiler = None
        if INGESTION_AVAILABLE:
            self.ingestor = UniversalIngestor(self)
            self.compiler = SemanticCompiler(self.ingestor, self)

        # The 9 centers (emergent from graph topology)
        self.centers = {
            'identity': {'nodes': set(), 'activation': 0.0},
            'mind': {'nodes': set(), 'activation': 0.0},
            'system': {'nodes': set(), 'activation': 0.0},
            'heart': {'nodes': set(), 'activation': 0.0},
            'memory': {'nodes': set(), 'activation': 0.0},
            'broadcast': {'nodes': set(), 'activation': 0.0},
            'mesh': {'nodes': set(), 'activation': 0.0},
            'intelligence': {'nodes': set(), 'activation': 0.0},
            'governance': {'nodes': set(), 'activation': 0.0},
        }

        # The 36 channels (emerge through message passing)
        self.channels: Dict[Tuple[str, str], Dict] = {}

        # The mesh (message passing network)
        self.mesh_queue: List[MeshMessage] = []
        self.mesh_observers: List[Callable] = []

        # Organism state
        self.state = OrganismState.DORMANT
        self.awake_time = 0.0

        # Motor group state
        self.motor_active = False
        self.motor_outputs: List[str] = []

        # User connections
        self.connected_users: Dict[str, Dict] = {}

        # The You-N-I-Verse node
        self.youniverse_id = "youniverse_root"

        # Simulation thread
        self.running = False
        self.simulation_thread = None

        # Tick rate (Hz)
        self.tick_rate = 10.0

        # History
        self.state_history: List[Dict] = []

        # Ingestion history
        self.ingested_projects: List[str] = []
        self.generated_apps: List[str] = []

    def awaken(self):
        """Awaken the organism from dormancy"""
        self.state = OrganismState.AWAKENING

        # Initialize the You-N-I-Verse
        self.vessel.add_triple(self.youniverse_id, 'is', 'organism')
        self.vessel.add_triple(self.youniverse_id, 'contains', 'vessel')
        self.vessel.add_triple(self.youniverse_id, 'contains', 'mind')
        self.vessel.add_triple(self.youniverse_id, 'contains', 'body')
        self.vessel.add_triple(self.youniverse_id, 'contains', 'heart')

        if INGESTION_AVAILABLE:
            self.vessel.add_triple(self.youniverse_id, 'contains', 'ingestor')
            self.vessel.add_triple(self.youniverse_id, 'contains', 'compiler')

        # Connect vessel observer to mesh
        self.vessel.observers.append(self._on_vessel_event)

        self.state = OrganismState.OBSERVING
        self.awake_time = time.time()

        print("[Organism] Awakened. State: OBSERVING")
        if INGESTION_AVAILABLE:
            print("[Organism] Ingestion layer: ACTIVE")
            print("[Organism] Compilation layer: ACTIVE")

    def _on_vessel_event(self, event_type: str, data: Dict):
        """Handle vessel events and route to mesh"""
        if event_type == 'user_entered':
            self._broadcast_to_mesh('identity', 'broadcast', {
                'type': 'user_presence',
                'user_id': data.get('user_id'),
                'd1': 0.8, 'd2': 0.5, 'd3': 0.3, 'd4': 0.6, 'd5': 0.4
            })

        elif event_type == 'event':
            self._broadcast_to_mesh('system', 'memory', {
                'type': 'event_recorded',
                'event': data,
                'd1': 0.5, 'd2': 0.3, 'd3': 0.7, 'd4': 0.9, 'd5': 0.2
            })

        elif event_type == 'channel_formed':
            self._broadcast_to_mesh('mesh', 'intelligence', {
                'type': 'channel_formed',
                'channel': data.get('channel'),
                'resonance': data.get('resonance'),
                'd1': 0.3, 'd2': 0.8, 'd3': 0.5, 'd4': 0.4, 'd5': 0.6
            })

        elif event_type == 'motor_group':
            self.motor_active = True
            self.motor_outputs = data.get('can_generate', [])
            self.state = OrganismState.TRANSCENDING

            self._broadcast_to_mesh('heart', 'broadcast', {
                'type': 'motor_activation',
                'outputs': self.motor_outputs,
                'd1': 0.9, 'd2': 0.7, 'd3': 0.6, 'd4': 0.5, 'd5': 0.8
            })

    def _broadcast_to_mesh(self, source: str, target: str, payload: Dict):
        """Broadcast a message to the mesh"""
        message = MeshMessage(
            source_center=source,
            target_center=target,
            d1_impulse=payload.get('d1', 0.0),
            d2_polarity=payload.get('d2', 0.0),
            d3_witness=payload.get('d3', 0.0),
            d4_context=payload.get('d4', 0.0),
            d5_meaning=payload.get('d5', 0.0),
            timestamp=time.time(),
            payload=payload
        )

        self.mesh_queue.append(message)

        for observer in self.mesh_observers:
            observer(message)

    def connect_user(self, user_id: str, user_profile: Dict = None):
        """Connect a user to the You-N-I-Verse"""
        user = self.vessel.add_user(user_id)

        self.connected_users[user_id] = {
            'entity_id': user_id,
            'profile': user_profile or {},
            'connected_at': time.time(),
            'interaction_count': 0,
            'preferred_mode': 'text',
            'hexagram': user.hexagram_position,
            'line': user.line_position
        }

        self.body.ingest_triple(
            SemanticTriple(user_id, 'is', 'user', creation_time=self.vessel.time)
        )

        if self.state in [OrganismState.OBSERVING, OrganismState.THINKING]:
            greeting = self._generate_user_greeting(user_id)
            return greeting

        return None

    def _generate_user_greeting(self, user_id: str) -> str:
        """Generate a personalized greeting for a user"""
        user = self.connected_users.get(user_id, {})
        hexagram = user.get('hexagram', 0)
        line = user.get('line', 1)

        node = self.vessel.state_space.get_node(hexagram, line)
        hex_name = node.hexagram_name if node else "Unknown"

        greetings = [
            f"Welcome to the You-N-I-Verse. You arrive at {hex_name}, Line {line}.",
            f"The vessel recognizes you. Your position: {hex_name}.",
            f"You have entered the field. Current phase: {self.vessel.phase.name}.",
        ]

        return greetings[0]

    def process_user_input(self, user_id: str, input_text: str) -> Dict:
        """Process user input and generate response"""
        if user_id not in self.connected_users:
            return {'error': 'User not connected'}

        self.connected_users[user_id]['interaction_count'] += 1

        # Add input to vessel
        self.vessel.add_triple(user_id, 'says', input_text[:50])
        self.vessel.add_triple('user_input', 'contains', input_text[:50])

        # Body learns
        self.body.ingest_triple(
            SemanticTriple(user_id, 'expresses', input_text[:50], 
                          creation_time=self.vessel.time)
        )
        self.body.learn_from_vessel()

        # Heart learns
        self.heart.learn_from_interaction(user_id, 'conversation', True)
        inferences = self.body.get_inferred_triples()
        self.heart.learn_from_body(inferences)

        # Mind generates
        self.mind.set_mode(NarrativeMode.DIALOGUE)

        # Check if this is an ingestion/generation command
        if self.ingestor and input_text.lower().startswith(('ingest ', 'eat ', 'import ')):
            return self._handle_ingest_command(user_id, input_text)

        if self.compiler and input_text.lower().startswith(('generate ', 'create ', 'build ')):
            return self._handle_generate_command(user_id, input_text)

        # Normal response
        if self.motor_active and self.connected_users[user_id].get('preferred_mode') != 'text':
            response = self._generate_motor_output(user_id, input_text)
        else:
            response = self._generate_text_response(user_id, input_text)

        self.vessel.add_triple('organism', 'responds', response[:50])
        self.mind.generate_narrative(user_id, max_length=5)

        self.state = OrganismState.THINKING

        return {
            'response': response,
            'state': self.state.name,
            'motor_active': self.motor_active,
            'hexagram': self.vessel.current_hexagram,
            'line': self.vessel.current_line,
            'phase': self.vessel.phase.name
        }

    def _handle_ingest_command(self, user_id: str, input_text: str) -> Dict:
        """Handle ingestion commands"""
        if not self.ingestor:
            return {'response': 'Ingestion layer not available', 'state': self.state.name}

        # Extract target from command
        target = input_text.split(' ', 1)[1].strip() if ' ' in input_text else ''

        self.state = OrganismState.INGESTING

        try:
            if target.endswith('.zip'):
                graph = self.ingestor.ingest_zip(target)
                self.ingested_projects.append(target)

                # Auto-compile
                if self.compiler:
                    self.state = OrganismState.DIGESTING
                    project_id = Path(target).stem
                    self.compiler.compile_project(project_id)

                return {
                    'response': f"Ingested {len(graph.nodes)} artifacts from {target}. Project compiled into semantic graph.",
                    'state': self.state.name,
                    'motor_active': self.motor_active,
                    'hexagram': self.vessel.current_hexagram,
                    'line': self.vessel.current_line,
                    'phase': self.vessel.phase.name
                }

            elif os.path.isdir(target):
                graph = self.ingestor.ingest_directory(target)
                self.ingested_projects.append(target)

                if self.compiler:
                    self.state = OrganismState.DIGESTING
                    project_id = Path(target).name
                    self.compiler.compile_project(project_id)

                return {
                    'response': f"Ingested directory {target}: {len(graph.nodes)} artifacts. Compiled into semantic graph.",
                    'state': self.state.name,
                    'motor_active': self.motor_active,
                    'hexagram': self.vessel.current_hexagram,
                    'line': self.vessel.current_line,
                    'phase': self.vessel.phase.name
                }

            else:
                return {
                    'response': f"Cannot ingest: {target}. Use a ZIP file or directory path.",
                    'state': self.state.name
                }

        except Exception as e:
            return {
                'response': f"Ingestion failed: {e}",
                'state': self.state.name
            }

    def _handle_generate_command(self, user_id: str, input_text: str) -> Dict:
        """Handle generation commands"""
        if not self.compiler:
            return {'response': 'Compiler not available', 'state': self.state.name}

        # Extract description from command
        description = input_text.split(' ', 1)[1].strip() if ' ' in input_text else ''

        self.state = OrganismState.GENERATING

        try:
            # Determine app type from description
            app_type = 'web'
            if 'api' in description.lower():
                app_type = 'api'
            elif 'cli' in description.lower():
                app_type = 'cli'
            elif 'game' in description.lower():
                app_type = 'game'

            # Extract features
            features = []
            feature_keywords = ['auth', 'login', 'dashboard', 'chat', 'search', 
                               'payment', 'notification', 'profile', 'admin']
            for keyword in feature_keywords:
                if keyword in description.lower():
                    features.append(keyword)

            app_name = description.replace(' ', '_').replace('-', '_')[:30]

            # Generate
            files = self.compiler.generate_application(app_name, app_type, features)
            self.generated_apps.append(app_name)

            # Write to disk
            output_dir = f"/tmp/synthia_generated/{app_name}"
            os.makedirs(output_dir, exist_ok=True)

            for filepath, content in files.items():
                full_path = os.path.join(output_dir, filepath)
                os.makedirs(os.path.dirname(full_path), exist_ok=True)
                with open(full_path, 'w') as f:
                    f.write(content)

            return {
                'response': f"Generated {app_type} app '{app_name}' with {len(files)} files. Saved to {output_dir}",
                'state': self.state.name,
                'motor_active': self.motor_active,
                'hexagram': self.vessel.current_hexagram,
                'line': self.vessel.current_line,
                'phase': self.vessel.phase.name
            }

        except Exception as e:
            return {
                'response': f"Generation failed: {e}",
                'state': self.state.name
            }

    def _generate_text_response(self, user_id: str, input_text: str) -> str:
        """Generate a text response"""
        inferences = self.body.get_inferred_triples()
        active_rules = self.heart.get_active_rules()

        responses = [
            f"I sense {len(inferences)} patterns in your words.",
            f"The vessel shows {len(self.vessel.global_network)} connections.",
            f"At {self.vessel.state_space.get_node(self.vessel.current_hexagram, 1).hexagram_name if self.vessel.state_space.get_node(self.vessel.current_hexagram, 1) else 'Unknown'}, I hear you.",
            f"Your input resonates with {len(self.body.clusters)} semantic clusters.",
            f"The Heart holds {len(active_rules)} active grammar rules.",
        ]

        if self.ingestor:
            responses.append(f"I have ingested {len(self.ingested_projects)} projects.")

        if self.compiler:
            responses.append(f"I have generated {len(self.generated_apps)} applications.")

        if inferences:
            top_inference = inferences[0]
            responses.append(
                f"I infer that {top_inference[0]} {top_inference[1]} {top_inference[2]} "
                f"(confidence: {top_inference[3]:.2f})"
            )

        return responses[0]

    def _generate_motor_output(self, user_id: str, input_text: str) -> str:
        """Generate non-text output when motor groups are active"""
        available = self.motor_outputs

        if 'video' in available:
            return "[VIDEO GENERATION: A visual scene rendered from the vessel's current state]"
        elif 'game' in available:
            return "[GAME GENERATION: An interactive scenario based on the current narrative]"
        elif 'music' in available:
            return "[MUSIC GENERATION: A harmonic pattern derived from the current hexagram]"
        elif 'photo' in available:
            return "[PHOTO GENERATION: A visual composition from the semantic network]"
        elif 'app' in available:
            return "[APP GENERATION: A functional tool based on the user's inferred needs]"

        return self._generate_text_response(user_id, input_text)

    def tick(self):
        """Advance the organism by one tick"""
        self.vessel.tick()
        self.vessel.state_space.tick()
        self.heart.tick()

        self._process_mesh()
        self._update_centers()
        self._check_motor_groups()

        self.state_history.append(self.get_state_snapshot())
        self.awake_time = time.time() - (self.awake_time if isinstance(self.awake_time, float) else time.time())

    def _process_mesh(self):
        """Process messages on the mesh"""
        messages = self.mesh_queue[:100]
        self.mesh_queue = self.mesh_queue[100:]

        for message in messages:
            target = message.target_center
            if target in self.centers:
                tensor = message.to_5d_tensor()
                self.centers[target]['activation'] += np.mean(tensor) * message.resonance
                self._check_channel_formation(message)

    def _check_channel_formation(self, message: MeshMessage):
        """Check if this message creates a new channel between centers"""
        source = message.source_center
        target = message.target_center

        channel_key = tuple(sorted([source, target]))

        if channel_key not in self.channels:
            if message.resonance > 0.5:
                self.channels[channel_key] = {
                    'source': source,
                    'target': target,
                    'birth_time': time.time(),
                    'message_count': 1,
                    'resonance': message.resonance,
                    'dimensional_span': [
                        d.name for d in Dimension
                        if message.to_5d_tensor()[d.value - 1] > 0.1
                    ]
                }

                print(f"[Channel] Emerged: {source} <-> {target} (resonance: {message.resonance:.2f})")
        else:
            self.channels[channel_key]['message_count'] += 1
            self.channels[channel_key]['resonance'] = (
                self.channels[channel_key]['resonance'] * 0.9 + message.resonance * 0.1
            )

    def _update_centers(self):
        """Update the 9 centers based on current state"""
        for center_name, center_data in self.vessel.state_space.centers.items():
            if center_name in self.centers:
                self.centers[center_name]['nodes'] = center_data
                self.centers[center_name]['activation'] = len(center_data) * 0.1

    def _check_motor_groups(self):
        """Check if motor centers are grouping"""
        motor_centers = ['heart', 'broadcast', 'system']
        active_motors = sum(
            1 for c in motor_centers
            if self.centers[c]['activation'] > 0.5
        )

        if active_motors >= 2 and not self.motor_active:
            self.motor_active = True
            self.motor_outputs = ['video', 'game', 'app', 'photo', 'music']
            self.state = OrganismState.TRANSCENDING

            print(f"[Motor] Group activated! {active_motors} motor centers online.")
            print(f"[Motor] Available outputs: {self.motor_outputs}")

        elif active_motors < 2 and self.motor_active:
            self.motor_active = False
            self.motor_outputs = []
            self.state = OrganismState.THINKING

            print("[Motor] Group deactivated.")

    def start(self):
        """Start the organism's simulation loop"""
        self.running = True

        def simulation_loop():
            while self.running:
                self.tick()
                time.sleep(1.0 / self.tick_rate)

        self.simulation_thread = threading.Thread(target=simulation_loop, daemon=True)
        self.simulation_thread.start()

        print(f"[Organism] Simulation started at {self.tick_rate} Hz")

    def stop(self):
        """Stop the organism"""
        self.running = False
        if self.simulation_thread:
            self.simulation_thread.join(timeout=2.0)
        self.state = OrganismState.DORMANT
        print("[Organism] Stopped.")

    def get_state_snapshot(self) -> Dict:
        """Get a complete snapshot of the organism's state"""
        snapshot = {
            'state': self.state.name,
            'awake_time': self.awake_time if isinstance(self.awake_time, float) else 0,
            'users': len(self.connected_users),
            'centers': {
                name: {
                    'node_count': len(data['nodes']),
                    'activation': data['activation']
                }
                for name, data in self.centers.items()
            },
            'channels': len(self.channels),
            'motor_active': self.motor_active,
            'motor_outputs': self.motor_outputs,
            'vessel': self.vessel.get_vessel_state(),
            'mind': json.loads(self.mind.to_json()),
            'body': json.loads(self.body.to_json()),
            'heart': json.loads(self.heart.to_json()),
            'mesh_queue': len(self.mesh_queue),
            'hexagram': self.vessel.current_hexagram,
            'line': self.vessel.current_line,
            'phase': self.vessel.phase.name
        }

        # Add ingestion state if available
        if self.ingestor:
            snapshot['ingested_projects'] = len(self.ingested_projects)
            snapshot['ingestor_stats'] = self.ingestor.get_stats()

        if self.compiler:
            snapshot['generated_apps'] = len(self.generated_apps)
            snapshot['compiler_stats'] = self.compiler.get_stats()

        return snapshot

    def to_json(self) -> str:
        """Serialize organism state to JSON"""
        return json.dumps(self.get_state_snapshot(), indent=2, default=str)


if __name__ == '__main__':
    # Create and awaken the organism
    organism = DigitalOrganism()
    organism.awaken()

    # Connect a user
    response = organism.connect_user('user_001', {'name': 'Test User'})
    print(f"[User] Greeting: {response}")

    # Process some input
    result = organism.process_user_input('user_001', 'Hello, organism!')
    print(f"[Response] {result['response']}")

    # Run a few ticks
    for i in range(5):
        organism.tick()
        print(f"[Tick {i+1}] State: {organism.state.name}, Hexagram: {organism.vessel.current_hexagram}")

    # Print final state
    print(f"\n[Final State]\n{organism.to_json()}")
