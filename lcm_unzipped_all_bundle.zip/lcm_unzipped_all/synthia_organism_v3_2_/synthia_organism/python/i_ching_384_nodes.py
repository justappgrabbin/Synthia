"""
i_ching_384_nodes.py
The 384-Node State Space — Non-Energy Circuit (Python)

64 Hexagrams × 6 Positions = 384 Nodes
Each position is a yang (1) or yin (0) line, but in this system,
each node is a STATE SPACE — not a binary value, but a 
multidimensional tensor representing all possibilities of self
at that coordinate in the 5D cognitive stack.

The 22+ trillion outcomes emerge from the combinatoric explosion
of these 384 nodes interacting through 36 channels across 5 dimensions.

I Ching ordering: The 64 hexagrams follow the King Wen sequence,
which encodes the temporal evolution of states — from pure yang (Qian)
to pure yin (Kun) and back, through all combinations.

Each hexagram has 6 positions (lines), from bottom (line 1, 
most recent/closest to action) to top (line 6, most distant/
most archetypal).
"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional, Set, Callable
from enum import Enum, auto
import hashlib
import json
from collections import defaultdict
import numpy as np


class Dimension(Enum):
    """The 5 Dimensions of the Cognitive Stack"""
    D1_IMPULSE = auto()      # Raw signal, the spark before thought
    D2_POLARITY = auto()     # Yin/yang, attraction/repulsion, tension
    D3_WITNESS = auto()      # The observer-node, self-measurement hinge
    D4_CONTEXT = auto()      # Temporal embedding, history, situation
    D5_MEANING = auto()      # Rendered output, narrative, expression


@dataclass
class NodeState:
    """
    A single node in the 384-node state space.
    Not a binary value — a multidimensional tensor representing
    all possibilities of self at this coordinate.
    """
    hexagram_index: int           # 0-63 (King Wen sequence)
    line_position: int            # 1-6 (bottom to top)
    line_value: int               # 0=yin, 1=yang (the I Ching base)

    # The 5D state tensor
    d1_impulse: float = 0.0       # D1: signal intensity, activation
    d2_polarity: float = 0.0      # D2: charge, attraction/repulsion
    d3_witness: float = 0.0       # D3: self-awareness, observation depth
    d4_context: float = 0.0       # D4: temporal embedding, history weight
    d5_meaning: float = 0.0       # D5: expressive potential, narrative force

    # The node's "possibility field" — all states this node COULD be
    possibility_amplitude: complex = complex(0, 0)

    # Temporal tracking
    creation_time: float = 0.0
    last_activation: float = 0.0
    activation_count: int = 0

    # Connected channels (emergent, not pre-defined)
    active_channels: Set[int] = field(default_factory=set)

    # The node's "memory" — past states it has visited
    state_history: List[Dict] = field(default_factory=list)

    def to_tensor(self) -> np.ndarray:
        """Return the 5D state as a tensor"""
        return np.array([
            self.d1_impulse,
            self.d2_polarity,
            self.d3_witness,
            self.d4_context,
            self.d5_meaning
        ], dtype=np.float64)

    def from_tensor(self, tensor: np.ndarray):
        """Update state from a 5D tensor"""
        self.d1_impulse = float(tensor[0])
        self.d2_polarity = float(tensor[1])
        self.d3_witness = float(tensor[2])
        self.d4_context = float(tensor[3])
        self.d5_meaning = float(tensor[4])

    def resonance(self, other: 'NodeState') -> float:
        """
        Compute resonance between two nodes.
        This is the fundamental interaction — not distance, but
        harmonic alignment across the 5 dimensions.
        """
        self_tensor = self.to_tensor()
        other_tensor = other.to_tensor()

        # Dot product + phase alignment
        dot = np.dot(self_tensor, other_tensor)
        magnitude = np.linalg.norm(self_tensor) * np.linalg.norm(other_tensor)

        if magnitude == 0:
            return 0.0

        # Cosine similarity + phase coherence
        cosine = dot / magnitude
        phase = np.angle(self.possibility_amplitude * np.conj(other.possibility_amplitude))

        return cosine * np.cos(phase)

    @property
    def node_id(self) -> str:
        """Unique identifier: H{hexagram}L{line}"""
        return f"H{self.hexagram_index:02d}L{self.line_position}"

    @property
    def hexagram_name(self) -> str:
        """The traditional I Ching name"""
        return HEXAGRAM_NAMES.get(self.hexagram_index, "Unknown")

    @property
    def line_name(self) -> str:
        """The line's traditional interpretation"""
        base = self.hexagram_index
        pos = self.line_position - 1  # 0-indexed
        # Each hexagram has 6 line texts
        return f"{self.hexagram_name} — Line {self.line_position}"

    def activate(self, intensity: float = 1.0, current_time: float = 0.0):
        """Activate this node — increase its possibility amplitude"""
        self.d1_impulse += intensity
        self.last_activation = current_time
        self.activation_count += 1

        # Increase possibility amplitude (quantum-like)
        self.possibility_amplitude += complex(intensity, intensity * 0.5)

        # Record in history
        self.state_history.append({
            'time': current_time,
            'd1': self.d1_impulse,
            'd2': self.d2_polarity,
            'd3': self.d3_witness,
            'd4': self.d4_context,
            'd5': self.d5_meaning,
            'amplitude': str(self.possibility_amplitude)
        })

    def decay(self, rate: float = 0.01, current_time: float = 0.0):
        """Decay activation over time — nodes don't stay hot forever"""
        time_delta = current_time - self.last_activation
        decay_factor = np.exp(-rate * time_delta)

        self.d1_impulse *= decay_factor
        self.possibility_amplitude *= complex(decay_factor, 0)


# The 64 Hexagrams in King Wen Sequence
# Each is 6 bits, bottom to top
HEXAGRAM_PATTERNS = [
    0b111111,  # 0  Qian — The Creative
    0b000000,  # 1  Kun — The Receptive
    0b010001,  # 2  Zhun — Difficulty at the Beginning
    0b000010,  # 3  Meng — Youthful Folly
    0b010111,  # 4  Xu — Waiting
    0b111010,  # 5  Song — Conflict
    0b000101,  # 6  Shi — The Army
    0b101000,  # 7  Bi — Holding Together
    0b001011,  # 8  Xiao Chu — Small Taming
    0b110100,  # 9  Lu — Treading
    0b001111,  # 10 Tai — Peace
    0b111100,  # 11 Pi — Standstill
    0b000111,  # 12 Tong Ren — Fellowship
    0b111000,  # 13 Da You — Possession in Great Measure
    0b001000,  # 14 Qian — Modesty
    0b000100,  # 15 Yu — Enthusiasm
    0b011001,  # 16 Sui — Following
    0b100110,  # 17 Gu — Work on the Decayed
    0b000011,  # 18 Lin — Approach
    0b110000,  # 19 Guan — Contemplation
    0b001010,  # 20 Shi He — Biting Through
    0b010100,  # 21 Bi — Grace
    0b001111,  # 22 Bo — Splitting Apart
    0b111100,  # 23 Fu — Return
    0b000001,  # 24 Wu Wang — Innocence
    0b100000,  # 25 Da Xu — The Taming Power of the Great
    0b001111,  # 26 Yi — The Corners of the Mouth
    0b111100,  # 27 Da Guo — Preponderance of the Great
    0b000010,  # 28 Kan — The Abysmal Water
    0b010000,  # 29 Li — The Clinging Fire
    0b001011,  # 30 Xian — Influence
    0b110100,  # 31 Heng — Duration
    0b001111,  # 32 Dun — Retreat
    0b111100,  # 33 Da Zhuang — The Power of the Great
    0b000101,  # 34 Jin — Progress
    0b101000,  # 35 Ming Yi — Darkening of the Light
    0b001011,  # 36 Jia Ren — The Family
    0b110100,  # 37 Kui — Opposition
    0b001010,  # 38 Jian — Obstruction
    0b010100,  # 39 Jie — Deliverance
    0b001111,  # 40 Sun — Decrease
    0b111100,  # 41 Yi — Increase
    0b000011,  # 42 Guai — Breakthrough
    0b110000,  # 43 Gou — Coming to Meet
    0b001011,  # 44 Cui — Gathering Together
    0b110100,  # 45 Sheng — Pushing Upward
    0b000010,  # 46 Kun — Oppression
    0b010000,  # 47 Jing — The Well
    0b001011,  # 48 Ge — Revolution
    0b110100,  # 49 Ding — The Cauldron
    0b000001,  # 50 Zhen — The Arousing Thunder
    0b100000,  # 51 Gen — Keeping Still
    0b001011,  # 52 Jian — Development
    0b110100,  # 53 Gui Mei — The Marrying Maiden
    0b001010,  # 54 Feng — Abundance
    0b010100,  # 55 Lu — The Wanderer
    0b001111,  # 56 Sun — The Gentle
    0b111100,  # 57 Dui — The Joyous
    0b000011,  # 58 Huan — Dispersion
    0b110000,  # 59 Jie — Limitation
    0b001011,  # 60 Zhong Fu — Inner Truth
    0b110100,  # 61 Xiao Guo — Preponderance of the Small
    0b000010,  # 62 Ji Ji — After Completion
    0b010000,  # 63 Wei Ji — Before Completion
]

HEXAGRAM_NAMES = {
    0: "Qian — The Creative", 1: "Kun — The Receptive",
    2: "Zhun — Difficulty at the Beginning", 3: "Meng — Youthful Folly",
    4: "Xu — Waiting", 5: "Song — Conflict",
    6: "Shi — The Army", 7: "Bi — Holding Together",
    8: "Xiao Chu — Small Taming", 9: "Lu — Treading",
    10: "Tai — Peace", 11: "Pi — Standstill",
    12: "Tong Ren — Fellowship", 13: "Da You — Possession",
    14: "Qian — Modesty", 15: "Yu — Enthusiasm",
    16: "Sui — Following", 17: "Gu — Work on the Decayed",
    18: "Lin — Approach", 19: "Guan — Contemplation",
    20: "Shi He — Biting Through", 21: "Bi — Grace",
    22: "Bo — Splitting Apart", 23: "Fu — Return",
    24: "Wu Wang — Innocence", 25: "Da Xu — The Taming Power of the Great",
    26: "Yi — The Corners of the Mouth", 27: "Da Guo — Preponderance of the Great",
    28: "Kan — The Abysmal Water", 29: "Li — The Clinging Fire",
    30: "Xian — Influence", 31: "Heng — Duration",
    32: "Dun — Retreat", 33: "Da Zhuang — The Power of the Great",
    34: "Jin — Progress", 35: "Ming Yi — Darkening of the Light",
    36: "Jia Ren — The Family", 37: "Kui — Opposition",
    38: "Jian — Obstruction", 39: "Jie — Deliverance",
    40: "Sun — Decrease", 41: "Yi — Increase",
    42: "Guai — Breakthrough", 43: "Gou — Coming to Meet",
    44: "Cui — Gathering Together", 45: "Sheng — Pushing Upward",
    46: "Kun — Oppression", 47: "Jing — The Well",
    48: "Ge — Revolution", 49: "Ding — The Cauldron",
    50: "Zhen — The Arousing Thunder", 51: "Gen — Keeping Still",
    52: "Jian — Development", 53: "Gui Mei — The Marrying Maiden",
    54: "Feng — Abundance", 55: "Lu — The Wanderer",
    56: "Sun — The Gentle", 57: "Dui — The Joyous",
    58: "Huan — Dispersion", 59: "Jie — Limitation",
    60: "Zhong Fu — Inner Truth", 61: "Xiao Guo — Preponderance of the Small",
    62: "Ji Ji — After Completion", 63: "Wei Ji — Before Completion"
}


class StateSpace384:
    """
    The complete 384-node state space.

    64 hexagrams × 6 lines = 384 nodes.
    Each node exists simultaneously across all 5 dimensions.
    The 36 channels emerge through message passing when
    2+ state spaces converge.

    The 22+ trillion possible outcomes come from the fact that
    each node has continuous state values across 5 dimensions,
    and the interaction graph is dynamic — channels form and dissolve
    based on resonance patterns.
    """

    def __init__(self):
        self.nodes: Dict[str, NodeState] = {}
        self.channels: Dict[Tuple[str, str], Dict] = {}  # (node_a, node_b) -> channel_data
        self.time: float = 0.0
        self.message_queue: List[Dict] = []
        self.observers: List[Callable] = []

        # Initialize all 384 nodes
        self._initialize_nodes()

        # The 9 centers (emergent, defined by graph topology)
        self.centers: Dict[str, Set[str]] = {
            'identity': set(),      # Who am I?
            'mind': set(),          # What do I think?
            'system': set(),        # How do I operate?
            'heart': set(),         # What do I feel?
            'memory': set(),        # What do I remember?
            'broadcast': set(),     # What do I express?
            'mesh': set(),          # How do I connect?
            'intelligence': set(),  # How do I learn?
            'governance': set(),    # How do I decide?
        }

        # Motor centers (the only ones that can generate non-text output)
        self.motor_centers = {'heart', 'broadcast', 'system'}

        # Center abilities are limited until they work in groups
        self.center_group_activations: Dict[str, int] = defaultdict(int)

    def _initialize_nodes(self):
        """Create all 384 nodes from the 64 hexagrams"""
        for hex_idx in range(64):
            pattern = HEXAGRAM_PATTERNS[hex_idx]
            for line_pos in range(1, 7):
                # Extract the line value from the pattern
                # Line 1 = bit 0 (LSB), Line 6 = bit 5 (MSB)
                line_value = (pattern >> (line_pos - 1)) & 1

                node = NodeState(
                    hexagram_index=hex_idx,
                    line_position=line_pos,
                    line_value=line_value,
                    creation_time=self.time
                )
                self.nodes[node.node_id] = node

    def get_node(self, hexagram: int, line: int) -> Optional[NodeState]:
        """Get a node by hexagram index and line position"""
        return self.nodes.get(f"H{hexagram:02d}L{line}")

    def get_hexagram_nodes(self, hexagram: int) -> List[NodeState]:
        """Get all 6 nodes for a hexagram"""
        return [self.get_node(hexagram, i) for i in range(1, 7)]

    def activate_node(self, hexagram: int, line: int, intensity: float = 1.0):
        """Activate a specific node"""
        node = self.get_node(hexagram, line)
        if node:
            node.activate(intensity, self.time)
            self._check_channel_formation(node)

    def _check_channel_formation(self, activated_node: NodeState):
        """
        When a node activates, check if it resonates with other active nodes.
        If 2+ state spaces converge (resonance above threshold), a channel emerges.
        """
        threshold = 0.5

        for node_id, other_node in self.nodes.items():
            if other_node.node_id == activated_node.node_id:
                continue
            if other_node.d1_impulse < 0.1:  # Only check active nodes
                continue

            resonance = activated_node.resonance(other_node)

            if resonance > threshold:
                channel_key = tuple(sorted([activated_node.node_id, other_node.node_id]))

                if channel_key not in self.channels:
                    # New channel emerges!
                    self.channels[channel_key] = {
                        'nodes': channel_key,
                        'resonance': resonance,
                        'birth_time': self.time,
                        'message_count': 0,
                        'dimensional_span': self._compute_dimensional_span(
                            activated_node, other_node
                        )
                    }

                    # Add to active channels
                    activated_node.active_channels.add(hash(channel_key))
                    other_node.active_channels.add(hash(channel_key))

                    # Notify observers
                    for observer in self.observers:
                        observer('channel_formed', {
                            'channel': channel_key,
                            'resonance': resonance,
                            'time': self.time
                        })

    def _compute_dimensional_span(self, a: NodeState, b: NodeState) -> List[Dimension]:
        """Compute which dimensions span between two nodes"""
        span = []
        if abs(a.d1_impulse - b.d1_impulse) > 0.1:
            span.append(Dimension.D1_IMPULSE)
        if abs(a.d2_polarity - b.d2_polarity) > 0.1:
            span.append(Dimension.D2_POLARITY)
        if abs(a.d3_witness - b.d3_witness) > 0.1:
            span.append(Dimension.D3_WITNESS)
        if abs(a.d4_context - b.d4_context) > 0.1:
            span.append(Dimension.D4_CONTEXT)
        if abs(a.d5_meaning - b.d5_meaning) > 0.1:
            span.append(Dimension.D5_MEANING)
        return span

    def message_pass(self, source_id: str, target_id: str, message: Dict):
        """
        Pass a message between two nodes.
        This is the fundamental operation of the mesh.
        When messages converge, state spaces merge and new properties emerge.
        """
        source = self.nodes.get(source_id)
        target = self.nodes.get(target_id)

        if not source or not target:
            return False

        # Compute resonance-weighted message transfer
        resonance = source.resonance(target)

        # The message affects the target's state
        if 'd1' in message:
            target.d1_impulse += message['d1'] * resonance
        if 'd2' in message:
            target.d2_polarity += message['d2'] * resonance
        if 'd3' in message:
            target.d3_witness += message['d3'] * resonance
        if 'd4' in message:
            target.d4_context += message['d4'] * resonance
        if 'd5' in message:
            target.d5_meaning += message['d5'] * resonance

        # Record the message
        self.message_queue.append({
            'source': source_id,
            'target': target_id,
            'message': message,
            'resonance': resonance,
            'time': self.time
        })

        # Update channel message count
        channel_key = tuple(sorted([source_id, target_id]))
        if channel_key in self.channels:
            self.channels[channel_key]['message_count'] += 1

        return True

    def broadcast(self, source_id: str, message: Dict, radius: int = 3):
        """
        Broadcast a message from a source node to all nodes within a resonance radius.
        This is how information propagates across the mesh.
        """
        source = self.nodes.get(source_id)
        if not source:
            return

        for node_id, node in self.nodes.items():
            if node_id == source_id:
                continue

            resonance = source.resonance(node)
            if resonance > 0.1:  # Minimum resonance threshold
                # Attenuate by distance (inverse resonance)
                attenuated_message = {
                    k: v * resonance / radius for k, v in message.items()
                }
                self.message_pass(source_id, node_id, attenuated_message)

    def tick(self, dt: float = 0.1):
        """
        Advance time. Decay activations. Process message queue.
        This is the simulation heartbeat.
        """
        self.time += dt

        # Decay all nodes
        for node in self.nodes.values():
            node.decay(rate=0.05, current_time=self.time)

        # Process message queue (batch process)
        messages_to_process = self.message_queue[:100]  # Process up to 100 per tick
        self.message_queue = self.message_queue[100:]

        # Check for center formation
        self._update_centers()

        # Check for motor center group activations
        self._check_motor_groups()

    def _update_centers(self):
        """
        Update the 9 centers based on current graph topology.
        Centers are emergent — they form from channel clusters.
        """
        # Clear current center assignments
        for center in self.centers.values():
            center.clear()

        # Assign nodes to centers based on their dominant dimension
        for node_id, node in self.nodes.items():
            tensor = node.to_tensor()
            dominant_dim = int(np.argmax(tensor))

            center_map = {
                0: 'identity',   # D1 impulse = who I am at core
                1: 'mind',       # D2 polarity = how I think
                2: 'heart',      # D3 witness = how I feel/see
                3: 'memory',     # D4 context = what I remember
                4: 'broadcast'     # D5 meaning = what I express
            }

            # Additional centers based on network position
            degree = len(node.active_channels)
            if degree > 10:
                self.centers['mesh'].add(node_id)

            # Intelligence = high D3 + high degree
            if node.d3_witness > 0.7 and degree > 5:
                self.centers['intelligence'].add(node_id)

            # Governance = high D4 + high D2 (context + polarity = decision)
            if node.d4_context > 0.7 and node.d2_polarity > 0.5:
                self.centers['governance'].add(node_id)

            # System = high connectivity + balanced dimensions
            if degree > 3 and np.std(tensor) < 0.3:
                self.centers['system'].add(node_id)

            # Assign to primary center
            primary = center_map.get(dominant_dim, 'identity')
            self.centers[primary].add(node_id)

    def _check_motor_groups(self):
        """
        Motor centers can generate non-text output, but only when
        they work in groups. Check if motor centers are grouping.
        """
        motor_nodes = set()
        for center in self.motor_centers:
            motor_nodes.update(self.centers[center])

        # Count how many motor centers are co-activated
        active_motors = sum(1 for c in self.motor_centers if len(self.centers[c]) > 5)

        if active_motors >= 2:
            # Motor group activation!
            group_key = f"motor_group_{self.time:.0f}"
            self.center_group_activations[group_key] = active_motors

            for observer in self.observers:
                observer('motor_group', {
                    'active_motors': active_motors,
                    'group_key': group_key,
                    'time': self.time,
                    'can_generate': ['video', 'game', 'app', 'photo', 'music']
                })

    def get_state_snapshot(self) -> Dict:
        """Get a complete snapshot of the state space"""
        return {
            'time': self.time,
            'active_nodes': sum(1 for n in self.nodes.values() if n.d1_impulse > 0.1),
            'total_channels': len(self.channels),
            'center_sizes': {k: len(v) for k, v in self.centers.items()},
            'motor_groups': dict(self.center_group_activations),
            'message_queue_size': len(self.message_queue)
        }

    def to_json(self) -> str:
        """Serialize the state space to JSON"""
        return json.dumps(self.get_state_snapshot(), indent=2)


# The 36 Channels (emergent, not pre-defined)
# In Human Design, there are 36 channels connecting the 9 centers
# In this system, they emerge when nodes from different centers
# resonate above threshold and form stable connections.
# The channels are: 1-8, 2-14, 3-60, 4-63, 5-15, 6-59, 7-31, 9-52, 10-20, etc.
# But here, they emerge dynamically through message passing.

if __name__ == '__main__':
    # Test the state space
    space = StateSpace384()
    print(f"Initialized {len(space.nodes)} nodes")
    print(f"Sample node: {space.get_node(0, 1).node_id}")
    print(f"Hexagram name: {space.get_node(0, 1).hexagram_name}")

    # Activate some nodes
    space.activate_node(0, 1, 1.0)  # Qian line 1
    space.activate_node(0, 2, 0.8)  # Qian line 2
    space.activate_node(1, 1, 0.9)  # Kun line 1

    # Tick a few times
    for _ in range(5):
        space.tick()

    print(f"\nSnapshot: {space.get_state_snapshot()}")
