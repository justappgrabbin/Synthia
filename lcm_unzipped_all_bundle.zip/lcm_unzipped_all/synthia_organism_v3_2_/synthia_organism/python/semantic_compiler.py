"""
semantic_compiler.py
The Semantic Compiler — The Digestive System (Non-Energy Circuit / Python)

This is the second missing piece. After the Ingestor eats, the Compiler digests.

It takes the raw ingested artifacts and:
1. Builds a unified semantic graph (all projects merged)
2. Resolves dependencies (what needs what)
3. Detects conflicts (version mismatches, duplicate definitions)
4. Repairs broken code (syntax errors, missing imports)
5. Generates new code (from patterns, templates, user intent)
6. Rewrites itself (modifies its own code based on learned patterns)
7. Creates applications (from arbitrary repositories)

The Compiler is the bridge between ingestion and generation.
Without it, the organism eats but doesn't grow.
With it, the organism becomes self-modifying.
"""

import os
import re
import ast
import json
import hashlib
from typing import Dict, List, Tuple, Optional, Set, Any
from dataclasses import dataclass, field
from collections import defaultdict
from pathlib import Path

from universal_ingestor import UniversalIngestor, IngestedArtifact, DependencyGraph


@dataclass
class SemanticNode:
    """A node in the unified semantic graph"""
    id: str
    type: str  # 'file', 'class', 'function', 'variable', 'module', 'concept'
    name: str
    source: str  # Which project/file this came from
    properties: Dict[str, Any] = field(default_factory=dict)
    relations: List[Tuple[str, str, float]] = field(default_factory=list)  # (relation, target_id, weight)
    content: str = ''
    ast_hash: str = ''


@dataclass
class Conflict:
    """A detected conflict between artifacts"""
    type: str  # 'duplicate', 'version_mismatch', 'circular_dependency', 'missing_import'
    source: str
    target: str
    description: str
    severity: float  # 0-1
    resolution: Optional[str] = None


@dataclass
class CodeTemplate:
    """A learned code pattern that can be instantiated"""
    id: str
    pattern_type: str  # 'class', 'function', 'component', 'api', 'test'
    language: str
    template: str
    variables: List[str] = field(default_factory=list)
    examples: List[str] = field(default_factory=list)
    usage_count: int = 0


class SemanticCompiler:
    """
    The Semantic Compiler.

    Takes ingested artifacts and compiles them into a unified semantic graph.
    Then operates on that graph to:
    - Merge projects
    - Repair code
    - Generate new code
    - Rewrite itself
    - Build applications

    This is the digestive system. Raw food (files) goes in.
    Nutrients (semantic triples) come out. The organism grows.
    """

    def __init__(self, ingestor: UniversalIngestor = None, organism=None):
        self.ingestor = ingestor
        self.organism = organism

        # The unified semantic graph
        self.semantic_graph: Dict[str, SemanticNode] = {}

        # Conflicts detected
        self.conflicts: List[Conflict] = []

        # Learned code templates
        self.templates: Dict[str, CodeTemplate] = {}

        # Pattern library (learned from ingestion)
        self.patterns: Dict[str, List[str]] = defaultdict(list)

        # Self-modification log
        self.self_modifications: List[Dict] = []

    def compile_project(self, project_id: str) -> Dict[str, SemanticNode]:
        """
        Compile a project into the unified semantic graph.

        This is the main digestion step. Takes raw artifacts and
        produces a structured graph that the organism can reason about.
        """
        if not self.ingestor or project_id not in self.ingestor.ingested_projects:
            return {}

        graph = self.ingestor.ingested_projects[project_id]
        compiled_nodes = {}

        for path, artifact in graph.nodes.items():
            # Create semantic nodes for the artifact itself
            file_node = SemanticNode(
                id=f"file:{path}",
                type='file',
                name=Path(path).name,
                source=project_id,
                properties={
                    'language': artifact.language,
                    'size': artifact.size,
                    'hash': artifact.hash
                },
                content=artifact.content[:1000]  # Truncated
            )
            self.semantic_graph[file_node.id] = file_node
            compiled_nodes[file_node.id] = file_node

            # Create nodes for classes
            if artifact.ast and 'classes' in artifact.ast:
                for cls in artifact.ast['classes']:
                    class_node = SemanticNode(
                        id=f"class:{project_id}:{cls['name']}",
                        type='class',
                        name=cls['name'],
                        source=path,
                        properties={
                            'line': cls.get('line', 0),
                            'bases': cls.get('bases', [])
                        }
                    )
                    # Add inheritance relations
                    for base in cls.get('bases', []):
                        if base and base != 'None':
                            class_node.relations.append(('inherits_from', f"class:{project_id}:{base}", 1.0))

                    self.semantic_graph[class_node.id] = class_node
                    compiled_nodes[class_node.id] = class_node

                    # Link file to class
                    file_node.relations.append(('contains', class_node.id, 1.0))

            # Create nodes for functions
            if artifact.ast and 'functions' in artifact.ast:
                for func in artifact.ast['functions']:
                    func_node = SemanticNode(
                        id=f"func:{project_id}:{func['name']}",
                        type='function',
                        name=func['name'],
                        source=path,
                        properties={
                            'line': func.get('line', 0),
                            'args': func.get('args', [])
                        }
                    )
                    self.semantic_graph[func_node.id] = func_node
                    compiled_nodes[func_node.id] = func_node

                    # Link file to function
                    file_node.relations.append(('contains', func_node.id, 1.0))

            # Add triple-based relations
            for triple in artifact.semantic_triples:
                subject, relation, obj = triple

                # Create or get subject node
                subj_id = f"concept:{project_id}:{subject}"
                if subj_id not in self.semantic_graph:
                    self.semantic_graph[subj_id] = SemanticNode(
                        id=subj_id,
                        type='concept',
                        name=subject,
                        source=project_id
                    )

                # Create or get object node
                obj_id = f"concept:{project_id}:{obj}"
                if obj_id not in self.semantic_graph:
                    self.semantic_graph[obj_id] = SemanticNode(
                        id=obj_id,
                        type='concept',
                        name=obj,
                        source=project_id
                    )

                # Add relation
                self.semantic_graph[subj_id].relations.append((relation, obj_id, 0.8))

        # Detect conflicts
        self._detect_conflicts(project_id)

        # Learn templates from this project
        self._learn_templates(project_id)

        return compiled_nodes

    def _detect_conflicts(self, project_id: str):
        """Detect conflicts within a project"""
        # Find duplicate definitions
        names = defaultdict(list)
        for node_id, node in self.semantic_graph.items():
            if node.source == project_id or node.source.startswith(project_id):
                names[node.name].append(node_id)

        for name, node_ids in names.items():
            if len(node_ids) > 1:
                # Check if they're actually duplicates or just same-named
                contents = [self.semantic_graph[nid].content for nid in node_ids]
                if len(set(contents)) > 1:
                    self.conflicts.append(Conflict(
                        type='duplicate',
                        source=node_ids[0],
                        target=node_ids[1],
                        description=f"Duplicate definition of '{name}' with different implementations",
                        severity=0.7
                    ))

        # Find circular dependencies
        # (Simplified: just check for files that import each other)
        if self.ingestor and project_id in self.ingestor.ingested_projects:
            graph = self.ingestor.ingested_projects[project_id]
            for edge in graph.edges:
                if edge[2] == 'imports':
                    # Check reverse
                    for reverse_edge in graph.edges:
                        if reverse_edge[0] == edge[1] and reverse_edge[1] == edge[0]:
                            self.conflicts.append(Conflict(
                                type='circular_dependency',
                                source=edge[0],
                                target=edge[1],
                                description=f"Circular dependency between {Path(edge[0]).name} and {Path(edge[1]).name}",
                                severity=0.5
                            ))

    def _learn_templates(self, project_id: str):
        """Learn code templates from a project"""
        if not self.ingestor or project_id not in self.ingestor.ingested_projects:
            return

        graph = self.ingestor.ingested_projects[project_id]

        for path, artifact in graph.nodes.items():
            if artifact.language != 'python':
                continue

            # Learn class templates
            if artifact.ast and 'classes' in artifact.ast:
                for cls in artifact.ast['classes']:
                    template_id = f"template:class:{cls['name']}"

                    # Extract class body as template
                    lines = artifact.content.split('\n')
                    class_lines = []
                    in_class = False
                    indent = None

                    for i, line in enumerate(lines):
                        if f"class {cls['name']}" in line:
                            in_class = True
                            indent = len(line) - len(line.lstrip())
                            class_lines.append(line)
                        elif in_class:
                            if line.strip() and not line.startswith(' ' * (indent + 4)) and not line.startswith('\t'):
                                break
                            class_lines.append(line)

                    if class_lines:
                        template = CodeTemplate(
                            id=template_id,
                            pattern_type='class',
                            language='python',
                            template='\n'.join(class_lines),
                            variables=['CLASS_NAME', 'BASE_CLASSES', 'METHODS']
                        )
                        self.templates[template_id] = template

            # Learn function templates
            if artifact.ast and 'functions' in artifact.ast:
                for func in artifact.ast['functions']:
                    template_id = f"template:func:{func['name']}"

                    # Extract function body
                    lines = artifact.content.split('\n')
                    func_lines = []
                    in_func = False
                    indent = None

                    for i, line in enumerate(lines):
                        if f"def {func['name']}(" in line:
                            in_func = True
                            indent = len(line) - len(line.lstrip())
                            func_lines.append(line)
                        elif in_func:
                            if line.strip() and not line.startswith(' ' * (indent + 4)) and not line.startswith('\t'):
                                break
                            func_lines.append(line)

                    if func_lines:
                        template = CodeTemplate(
                            id=template_id,
                            pattern_type='function',
                            language='python',
                            template='\n'.join(func_lines),
                            variables=['FUNC_NAME', 'ARGS', 'BODY']
                        )
                        self.templates[template_id] = template

    def merge_graphs(self, project_ids: List[str]) -> Dict[str, SemanticNode]:
        """Merge multiple projects into a single unified graph"""
        merged = {}

        for pid in project_ids:
            if pid not in self.ingestor.ingested_projects:
                continue

            # Compile if not already compiled
            compiled = self.compile_project(pid)
            merged.update(compiled)

        # Detect cross-project conflicts
        self._detect_cross_project_conflicts(project_ids)

        return merged

    def _detect_cross_project_conflicts(self, project_ids: List[str]):
        """Detect conflicts between projects"""
        # Find same-named symbols in different projects
        all_names = defaultdict(lambda: defaultdict(list))

        for node_id, node in self.semantic_graph.items():
            for pid in project_ids:
                if node.source == pid or node.source.startswith(pid):
                    all_names[node.name][pid].append(node_id)

        for name, project_nodes in all_names.items():
            if len(project_nodes) > 1:
                # Same name in multiple projects
                pids = list(project_nodes.keys())
                self.conflicts.append(Conflict(
                    type='cross_project_duplicate',
                    source=pids[0],
                    target=pids[1],
                    description=f"'{name}' defined in multiple projects: {', '.join(pids)}",
                    severity=0.6
                ))

    def repair_code(self, artifact: IngestedArtifact) -> str:
        """
        Attempt to repair broken code in an artifact.

        Fixes:
        - Missing imports (add based on usage)
        - Syntax errors (basic fixes)
        - Undefined variables (infer from context)
        - Broken references (redirect to available symbols)
        """
        content = artifact.content
        repairs = []

        # Fix missing imports
        if artifact.language == 'python':
            # Detect used but undefined names
            try:
                tree = ast.parse(content)
                defined = set()
                used = set()

                for node in ast.walk(tree):
                    if isinstance(node, ast.Name):
                        if isinstance(node.ctx, ast.Store):
                            defined.add(node.id)
                        elif isinstance(node.ctx, ast.Load):
                            used.add(node.id)
                    elif isinstance(node, ast.FunctionDef):
                        defined.add(node.name)
                    elif isinstance(node, ast.ClassDef):
                        defined.add(node.name)

                # Find undefined but used names
                undefined = used - defined - set(dir(__builtins__))

                # Add imports for common undefined names
                import_lines = []
                for name in undefined:
                    if name in ['np', 'pd', 'plt', 'tf', 'torch']:
                        import_lines.append(f"import {self._map_alias(name)}")
                    elif name in ['json', 'os', 'sys', 're', 'math']:
                        import_lines.append(f"import {name}")

                if import_lines:
                    content = '\n'.join(import_lines) + '\n\n' + content
                    repairs.append(f"Added {len(import_lines)} missing imports")

            except SyntaxError:
                repairs.append("Could not parse for repair (syntax error)")

        return content

    def _map_alias(self, alias: str) -> str:
        """Map common aliases to their module names"""
        mapping = {
            'np': 'numpy',
            'pd': 'pandas',
            'plt': 'matplotlib.pyplot',
            'tf': 'tensorflow',
            'torch': 'torch'
        }
        return mapping.get(alias, alias)

    def generate_from_template(self, template_id: str, variables: Dict[str, str]) -> str:
        """Generate code from a learned template"""
        if template_id not in self.templates:
            return f"# Template {template_id} not found"

        template = self.templates[template_id]
        code = template.template

        # Replace variables
        for var, value in variables.items():
            code = code.replace(f"{{{var}}}", value)

        template.usage_count += 1

        return code

    def generate_application(self, name: str, type: str = 'web', 
                            features: List[str] = None) -> Dict[str, str]:
        """
        Generate a complete application from learned patterns.

        Uses templates learned from ingested projects to generate
        a new application with the specified features.
        """
        features = features or []
        files = {}

        # Generate based on type
        if type == 'web':
            files = self._generate_web_app(name, features)
        elif type == 'api':
            files = self._generate_api(name, features)
        elif type == 'cli':
            files = self._generate_cli(name, features)
        elif type == 'game':
            files = self._generate_game(name, features)

        return files

    def _generate_web_app(self, name: str, features: List[str]) -> Dict[str, str]:
        """Generate a web application"""
        files = {}

        # HTML
        files[f'{name}/index.html'] = f"""<!DOCTYPE html>
<html>
<head>
  <title>{name}</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div id="app"></div>
  <script src="app.js"></script>
</body>
</html>"""

        # CSS
        files[f'{name}/style.css'] = """* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: sans-serif; background: #f0f0f0; }
#app { max-width: 800px; margin: 0 auto; padding: 20px; }"""

        # JS
        files[f'{name}/app.js'] = f"""// {name} - Generated by Synthia
console.log("{name} initialized");

// Features: {', '.join(features)}

document.addEventListener('DOMContentLoaded', () => {{
  const app = document.getElementById('app');
  app.innerHTML = '<h1>Welcome to {name}</h1>';
}});"""

        return files

    def _generate_api(self, name: str, features: List[str]) -> Dict[str, str]:
        """Generate an API service"""
        files = {}

        files[f'{name}/api.py'] = f"""from fastapi import FastAPI

app = FastAPI(title="{name}")

@app.get("/")
def root():
    return {{"message": "Welcome to {name}"}}

# Features: {', '.join(features)}
"""

        return files

    def _generate_cli(self, name: str, features: List[str]) -> Dict[str, str]:
        """Generate a CLI tool"""
        files = {}

        files[f'{name}/cli.py'] = f"""import argparse

def main():
    parser = argparse.ArgumentParser(description="{name}")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    print(f"{name} running...")

    # Features: {', '.join(features)}

if __name__ == "__main__":
    main()
"""

        return files

    def _generate_game(self, name: str, features: List[str]) -> Dict[str, str]:
        """Generate a simple game"""
        files = {}

        files[f'{name}/game.py'] = f"""import pygame

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("{name}")
        self.running = True

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False

            self.screen.fill((0, 0, 0))
            pygame.display.flip()

        pygame.quit()

if __name__ == "__main__":
    game = Game()
    game.run()
"""

        return files

    def rewrite_self(self, modification: Dict) -> bool:
        """
        Modify the compiler's own code based on learned patterns.

        This is the self-modification capability. The compiler can:
        - Add new template types
        - Update repair strategies
        - Extend language support
        - Improve conflict detection

        WARNING: This is dangerous. Use with caution.
        """
        mod_type = modification.get('type')

        if mod_type == 'add_template':
            template = modification.get('template')
            if template:
                self.templates[template.id] = template
                self.self_modifications.append({
                    'type': 'add_template',
                    'template_id': template.id,
                    'timestamp': __import__('time').time()
                })
                return True

        elif mod_type == 'add_pattern':
            pattern_name = modification.get('name')
            pattern_regex = modification.get('regex')
            if pattern_name and pattern_regex:
                self.patterns[pattern_name].append(pattern_regex)
                self.self_modifications.append({
                    'type': 'add_pattern',
                    'pattern': pattern_name,
                    'timestamp': __import__('time').time()
                })
                return True

        elif mod_type == 'update_repair':
            strategy = modification.get('strategy')
            if strategy:
                # Add new repair strategy
                self.self_modifications.append({
                    'type': 'update_repair',
                    'strategy': strategy,
                    'timestamp': __import__('time').time()
                })
                return True

        return False

    def query_graph(self, query: str) -> List[SemanticNode]:
        """
        Query the semantic graph using natural language-like queries.

        Examples:
        - "find all classes that inherit from X"
        - "show me functions that use Y"
        - "what depends on Z?"
        """
        results = []

        # Simple pattern matching for now
        query_lower = query.lower()

        if 'class' in query_lower:
            for node in self.semantic_graph.values():
                if node.type == 'class':
                    results.append(node)

        elif 'function' in query_lower or 'def ' in query_lower:
            for node in self.semantic_graph.values():
                if node.type == 'function':
                    results.append(node)

        elif 'inherit' in query_lower:
            for node in self.semantic_graph.values():
                for rel, target, _ in node.relations:
                    if rel == 'inherits_from':
                        results.append(node)

        elif 'depend' in query_lower:
            for node in self.semantic_graph.values():
                for rel, target, _ in node.relations:
                    if rel == 'depends_on':
                        results.append(node)

        return results

    def get_stats(self) -> Dict:
        """Get compiler statistics"""
        return {
            'nodes': len(self.semantic_graph),
            'conflicts': len(self.conflicts),
            'templates': len(self.templates),
            'self_modifications': len(self.self_modifications),
            'patterns': len(self.patterns)
        }

    def to_json(self) -> str:
        """Serialize compiler state to JSON"""
        return json.dumps({
            'stats': self.get_stats(),
            'conflicts': [
                {'type': c.type, 'source': c.source, 'target': c.target, 
                 'description': c.description, 'severity': c.severity}
                for c in self.conflicts
            ],
            'templates': [
                {'id': t.id, 'type': t.pattern_type, 'language': t.language, 
                 'usage': t.usage_count}
                for t in self.templates.values()
            ]
        }, indent=2, default=str)


if __name__ == '__main__':
    # Test the compiler
    from universal_ingestor import UniversalIngestor

    ingestor = UniversalIngestor()
    ingestor.ingest_directory('/mnt/agents/output/synthia_organism', 'synthia')

    compiler = SemanticCompiler(ingestor)
    compiler.compile_project('synthia')

    print(f"Compiled {len(compiler.semantic_graph)} semantic nodes")
    print(f"Detected {len(compiler.conflicts)} conflicts")
    print(f"Learned {len(compiler.templates)} templates")

    # Generate an app
    app_files = compiler.generate_application('test_app', 'web', ['auth', 'dashboard'])
    print(f"\nGenerated {len(app_files)} files for test_app")
    for path, content in list(app_files.items())[:3]:
        print(f"  {path}: {len(content)} bytes")
