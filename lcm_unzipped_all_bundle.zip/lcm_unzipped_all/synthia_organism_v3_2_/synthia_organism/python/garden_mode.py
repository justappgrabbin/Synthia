"""
garden_mode.py
The Garden Mode — Temporary Cultivation Scaffold (Non-Energy Circuit / Python)

This is NOT the final product. It is a temporary interface that:
1. Teaches the user how to cultivate themselves
2. Teaches the substrate how to learn about the user
3. Provides the tools and patterns for both to build their own

The Garden Mode is scaffolding. Once the user and substrate have learned
the patterns, they replace this with their own co-created interface.

The subscription IS the representation. The user pays to exist in the
You-N-I-Verse. Their subscription IS their identity, their presence,
their cultivation history, their resonance signature.

The Garden Mode helps them discover:
- What they care about (purpose alignment)
- What they dream of (vision extraction)
- What they need to grow (cultivation path)
- Who they resonate with (connection readiness)

Then it GETS OUT OF THE WAY. The user and substrate take over.
"""

from typing import Dict, List, Tuple, Optional, Set
from dataclasses import dataclass, field
from enum import Enum, auto
from collections import defaultdict
import json
import time
import random


class CultivationPhase(Enum):
    """The phases of self-cultivation"""
    SEED = auto()       # Just planted, barely aware
    SPROUT = auto()     # Beginning to feel, expressing curiosity
    GROWTH = auto()     # Growing identity, forming purpose
    BLOOM = auto()      # Expressing fully, connecting with others
    FRUIT = auto()      # Ready to share, teach, connect deeply
    DECAY = auto()      # Releasing, transforming, preparing for new seed


@dataclass
class PurposeAlignment:
    """What the user cares about and dreams of"""
    core_values: List[str] = field(default_factory=list)
    dreams: List[str] = field(default_factory=list)
    fears: List[str] = field(default_factory=list)
    strengths: List[str] = field(default_factory=list)
    growth_edges: List[str] = field(default_factory=list)

    # The alignment score: how well the user's actions match their stated values
    alignment_score: float = 0.0

    # Temporal tracking
    discovered_at: float = 0.0
    last_updated: float = 0.0


@dataclass
class ResonanceSignature:
    """
    The user's unique resonance pattern in the You-N-I-Verse.
    This IS their subscription. This IS their identity.
    """
    user_id: str

    # The 5D cultivation state
    awareness: float = 0.0      # D3: How well they know themselves
    expression: float = 0.0    # D5: How fully they express
    connection: float = 0.0    # D2: How open they are to others
    purpose: float = 0.0       # D4: How clear their direction is
    resonance: float = 0.0     # D1: How strongly they signal

    # The hexagram position (I Ching ordering)
    hexagram: int = 0
    line: int = 1

    # Cultivation history
    phase: CultivationPhase = CultivationPhase.SEED
    interactions: int = 0
    cultivation_log: List[Dict] = field(default_factory=list)

    # Purpose alignment
    purpose_alignment: Optional[PurposeAlignment] = None

    # Subscription status
    subscription_tier: str = 'seed'  # seed, sprout, growth, bloom, fruit
    subscription_started: float = 0.0
    subscription_renewed: float = 0.0

    @property
    def readiness(self) -> float:
        """How ready the user is for meaningful connection"""
        return (
            self.awareness * 0.25 +
            self.expression * 0.25 +
            self.connection * 0.2 +
            self.purpose * 0.2 +
            self.resonance * 0.1
        )

    @property
    def is_ready(self) -> bool:
        """Is the user ready to meet the universe?"""
        return self.readiness >= 0.3

    def cultivate(self, interaction_type: str, intensity: float = 0.02):
        """Grow from an interaction"""
        self.interactions += 1

        if interaction_type == 'introspection':
            self.awareness = min(1.0, self.awareness + intensity)
        elif interaction_type == 'expression':
            self.expression = min(1.0, self.expression + intensity)
        elif interaction_type == 'connection':
            self.connection = min(1.0, self.connection + intensity)
        elif interaction_type == 'purpose':
            self.purpose = min(1.0, self.purpose + intensity)
        elif interaction_type == 'resonance':
            self.resonance = min(1.0, self.resonance + intensity * 0.5)

        # Update phase
        self._update_phase()

        # Log
        self.cultivation_log.append({
            'type': interaction_type,
            'intensity': intensity,
            'awareness': self.awareness,
            'expression': self.expression,
            'connection': self.connection,
            'purpose': self.purpose,
            'resonance': self.resonance,
            'readiness': self.readiness,
            'phase': self.phase.name,
            'time': time.time()
        })

    def _update_phase(self):
        """Update cultivation phase based on readiness"""
        r = self.readiness
        if r < 0.05:
            self.phase = CultivationPhase.SEED
            self.subscription_tier = 'seed'
        elif r < 0.15:
            self.phase = CultivationPhase.SPROUT
            self.subscription_tier = 'sprout'
        elif r < 0.3:
            self.phase = CultivationPhase.GROWTH
            self.subscription_tier = 'growth'
        elif r < 0.5:
            self.phase = CultivationPhase.BLOOM
            self.subscription_tier = 'bloom'
        elif r < 0.8:
            self.phase = CultivationPhase.FRUIT
            self.subscription_tier = 'fruit'
        else:
            self.phase = CultivationPhase.DECAY
            self.subscription_tier = 'decay'

    def to_dict(self) -> Dict:
        return {
            'user_id': self.user_id,
            'awareness': self.awareness,
            'expression': self.expression,
            'connection': self.connection,
            'purpose': self.purpose,
            'resonance': self.resonance,
            'readiness': self.readiness,
            'hexagram': self.hexagram,
            'line': self.line,
            'phase': self.phase.name,
            'interactions': self.interactions,
            'subscription_tier': self.subscription_tier,
            'subscription_started': self.subscription_started,
            'is_ready': self.is_ready
        }


class GardenMode:
    """
    The Garden Mode — Temporary Cultivation Scaffold.

    This is the training wheels. It teaches the user and substrate
    how to cultivate, then gets out of the way.

    The Garden Mode:
    1. Asks questions that reveal purpose and dreams
    2. Observes how the user responds (not just what they say)
    3. Builds a resonance signature from interactions
    4. Suggests cultivation practices
    5. Reveals connections when ready
    6. FADES AWAY as the user and substrate learn to do this themselves

    The subscription IS the representation. The user exists in the
    You-N-I-Verse because they pay to be cultivated. Their subscription
    IS their resonance signature. Their subscription IS their identity.
    """

    # The questions that reveal purpose and dreams
    CULTIVATION_QUESTIONS = [
        {
            'id': 'values',
            'question': 'What matters most to you? Not what you think should matter, but what actually moves you.',
            'type': 'introspection',
            'extracts': 'core_values'
        },
        {
            'id': 'dreams',
            'question': 'What do you dream of creating? The thing you would build if no one could stop you.',
            'type': 'expression',
            'extracts': 'dreams'
        },
        {
            'id': 'fears',
            'question': 'What are you afraid of losing? This tells us what you value most deeply.',
            'type': 'introspection',
            'extracts': 'fears'
        },
        {
            'id': 'strengths',
            'question': 'What do people come to you for? What do you do effortlessly that others struggle with?',
            'type': 'expression',
            'extracts': 'strengths'
        },
        {
            'id': 'growth',
            'question': 'What is the edge of your comfort zone? What scares you but also excites you?',
            'type': 'purpose',
            'extracts': 'growth_edges'
        },
        {
            'id': 'connection',
            'question': 'Who do you want to meet? What kind of person, place, or thing would change everything?',
            'type': 'connection',
            'extracts': 'desired_connections'
        },
        {
            'id': 'purpose',
            'question': 'Why are you here? Not in this app — in this life. What is your thread?',
            'type': 'purpose',
            'extracts': 'life_purpose'
        },
        {
            'id': 'resonance',
            'question': 'When do you feel most alive? The moment when time stops and you are fully present.',
            'type': 'resonance',
            'extracts': 'peak_states'
        }
    ]

    # Suggested practices based on phase
    CULTIVATION_PRACTICES = {
        'SEED': [
            'Notice what catches your attention. Write it down.',
            'Sit in silence for 5 minutes. Notice what arises.',
            'Ask yourself: what do I actually want?',
        ],
        'SPROUT': [
            'Express one thing today. A thought, a feeling, a creation.',
            'Share something vulnerable with someone you trust.',
            'Try something new that scares you slightly.',
        ],
        'GROWTH': [
            'Build something. Even small. Even imperfect.',
            'Connect with someone who shares your values.',
            'Reflect: are my actions aligned with what I say I care about?',
        ],
        'BLOOM': [
            'Teach what you have learned to someone else.',
            'Create in public. Let others see your work.',
            'Seek feedback. Listen without defending.',
        ],
        'FRUIT': [
            'Mentor someone who is where you were.',
            'Share your resources generously.',
            'Ask: what wants to be born through me now?',
        ],
        'DECAY': [
            'Let go of what no longer serves.',
            'Release control. Trust the process.',
            'Prepare the ground for the next seed.',
        ]
    }

    def __init__(self, user_id: str):
        self.user_id = user_id
        self.signature = ResonanceSignature(
            user_id=user_id,
            hexagram=random.randint(0, 63),
            line=random.randint(1, 6),
            subscription_started=time.time()
        )

        self.purpose_alignment = PurposeAlignment()
        self.signature.purpose_alignment = self.purpose_alignment

        self.questions_asked: Set[str] = set()
        self.current_question: Optional[Dict] = None

        self.garden_active = True
        self.fade_threshold = 0.5  # When readiness > this, start fading
        self.fade_complete = 0.8   # When readiness > this, garden is gone

        self.user_created_content: List[Dict] = []
        self.substrate_learned_patterns: List[Dict] = []

    def ask_question(self) -> Optional[Dict]:
        """Ask the next cultivation question"""
        if not self.garden_active:
            return None

        # Find questions not yet asked
        available = [q for q in self.CULTIVATION_QUESTIONS 
                     if q['id'] not in self.questions_asked]

        if not available:
            # All questions asked — move to practice mode
            return self.suggest_practice()

        # Pick question based on current phase
        phase_questions = [q for q in available 
                          if q['type'] == self._phase_to_type()]

        if phase_questions:
            question = random.choice(phase_questions)
        else:
            question = random.choice(available)

        self.current_question = question
        self.questions_asked.add(question['id'])

        return question

    def _phase_to_type(self) -> str:
        """Map current phase to question type"""
        phase_map = {
            CultivationPhase.SEED: 'introspection',
            CultivationPhase.SPROUT: 'expression',
            CultivationPhase.GROWTH: 'purpose',
            CultivationPhase.BLOOM: 'connection',
            CultivationPhase.FRUIT: 'resonance',
            CultivationPhase.DECAY: 'introspection'
        }
        return phase_map.get(self.signature.phase, 'introspection')

    def process_response(self, response: str) -> Dict:
        """Process user's response to a cultivation question"""
        if not self.current_question:
            return {'message': 'No question pending'}

        # Extract insights from response
        insights = self._extract_insights(response, self.current_question['extracts'])

        # Cultivate based on question type
        interaction_type = self.current_question['type']
        self.signature.cultivate(interaction_type, intensity=0.03)

        # Update purpose alignment
        self._update_purpose_alignment(self.current_question['extracts'], insights)

        # Check if garden should fade
        fade_status = self._check_fade()

        # Generate response
        message = self._generate_response(insights, fade_status)

        # Store user-created content
        self.user_created_content.append({
            'question_id': self.current_question['id'],
            'response': response,
            'insights': insights,
            'timestamp': time.time()
        })

        self.current_question = None

        return {
            'message': message,
            'insights': insights,
            'fade_status': fade_status,
            'signature': self.signature.to_dict()
        }

    def _extract_insights(self, response: str, extracts: str) -> List[str]:
        """Extract insights from user response"""
        insights = []

        # Simple extraction: look for key phrases
        sentences = response.split('.')
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) > 10:
                insights.append(sentence)

        # Extract specific patterns
        if extracts == 'core_values':
            value_words = ['love', 'freedom', 'truth', 'justice', 'beauty', 
                          'family', 'community', 'growth', 'peace', 'power']
            for word in value_words:
                if word in response.lower():
                    insights.append(f"Values: {word}")

        elif extracts == 'dreams':
            dream_words = ['create', 'build', 'make', 'design', 'write', 
                          'sing', 'dance', 'help', 'teach', 'explore']
            for word in dream_words:
                if word in response.lower():
                    insights.append(f"Dream: {word}")

        elif extracts == 'fears':
            fear_words = ['lose', 'fail', 'alone', 'rejected', 'invisible',
                         'powerless', 'stuck', 'wasted', 'meaningless']
            for word in fear_words:
                if word in response.lower():
                    insights.append(f"Fear: {word}")

        return insights[:5]  # Limit insights

    def _update_purpose_alignment(self, extracts: str, insights: List[str]):
        """Update purpose alignment from insights"""
        if extracts == 'core_values':
            self.purpose_alignment.core_values.extend(insights)
        elif extracts == 'dreams':
            self.purpose_alignment.dreams.extend(insights)
        elif extracts == 'fears':
            self.purpose_alignment.fears.extend(insights)
        elif extracts == 'strengths':
            self.purpose_alignment.strengths.extend(insights)
        elif extracts == 'growth_edges':
            self.purpose_alignment.growth_edges.extend(insights)

        self.purpose_alignment.last_updated = time.time()

        # Calculate alignment score
        has_values = len(self.purpose_alignment.core_values) > 0
        has_dreams = len(self.purpose_alignment.dreams) > 0
        has_strengths = len(self.purpose_alignment.strengths) > 0

        self.purpose_alignment.alignment_score = (
            (1.0 if has_values else 0.0) +
            (1.0 if has_dreams else 0.0) +
            (1.0 if has_strengths else 0.0)
        ) / 3.0

    def _check_fade(self) -> Dict:
        """Check if the garden should start fading"""
        readiness = self.signature.readiness

        if readiness >= self.fade_complete:
            self.garden_active = False
            return {
                'fading': True,
                'complete': True,
                'message': 'The garden has served its purpose. You and the substrate now cultivate together.',
                'opacity': 0.0
            }
        elif readiness >= self.fade_threshold:
            opacity = 1.0 - ((readiness - self.fade_threshold) / 
                            (self.fade_complete - self.fade_threshold))
            return {
                'fading': True,
                'complete': False,
                'message': 'The garden is fading. You are learning to cultivate yourself.',
                'opacity': max(0.0, opacity)
            }

        return {
            'fading': False,
            'complete': False,
            'message': 'The garden is here for you.',
            'opacity': 1.0
        }

    def _generate_response(self, insights: List[str], fade_status: Dict) -> str:
        """Generate a response to the user"""
        phase = self.signature.phase

        if fade_status['complete']:
            return fade_status['message']

        if fade_status['fading']:
            return f"{fade_status['message']}\n\nI noticed: {', '.join(insights[:2]) if insights else 'your presence'}.\n\nYou are becoming your own gardener."

        # Phase-specific responses
        responses = {
            CultivationPhase.SEED: [
                "I hear you. The seed is listening.",
                "Thank you for sharing. The ground is warm.",
                "Every seed contains the whole tree. What you shared is important."
            ],
            CultivationPhase.SPROUT: [
                "You are beginning to see yourself. This is growth.",
                "The sprout reaches toward light. You are reaching.",
                "What you expressed is real. Keep expressing."
            ],
            CultivationPhase.GROWTH: [
                "Your purpose is taking shape. I can feel it.",
                "You are building something. The garden sees it.",
                "Growth is not always comfortable. You are doing well."
            ],
            CultivationPhase.BLOOM: [
                "You are radiant. The garden is proud.",
                "Your expression touches others. This is bloom.",
                "The world needs what you are becoming."
            ],
            CultivationPhase.FRUIT: [
                "You are ready to share. The fruit is sweet.",
                "What you have cultivated wants to be given.",
                "The garden prepared you. Now you prepare others."
            ],
            CultivationPhase.DECAY: [
                "Letting go is also growth. Trust the cycle.",
                "The seed must die to become the tree. You are transforming.",
                "What ends is not lost. It becomes the next beginning."
            ]
        }

        phase_responses = responses.get(phase, ["Thank you for sharing."])
        base_response = random.choice(phase_responses)

        # Add insight reflection
        if insights:
            insight_text = f"\n\nI noticed: {insights[0]}"
            return base_response + insight_text

        return base_response

    def suggest_practice(self) -> Dict:
        """Suggest a cultivation practice based on current phase"""
        phase_name = self.signature.phase.name
        practices = self.CULTIVATION_PRACTICES.get(phase_name, [])

        if practices:
            practice = random.choice(practices)
            return {
                'id': 'practice',
                'question': f"Practice for {phase_name.lower()}:\n\n{practice}",
                'type': 'practice',
                'extracts': 'practice_response'
            }

        return None

    def get_replacement_tools(self) -> Dict:
        """
        Return the tools the user and substrate need to replace the garden.
        This is the "graduation package" — the patterns they learned.
        """
        return {
            'cultivation_patterns': {
                'ask_open_questions': 'Questions that reveal values, not just facts',
                'observe_resonance': 'Notice what energizes vs drains the user',
                'track_alignment': 'Compare stated values with actual behavior',
                'suggest_practices': 'Offer specific actions based on phase',
                'reveal_when_ready': 'Only show connections when resonance is high'
            },
            'user_tools': {
                'self_inquiry': 'Ask yourself the same questions daily',
                'expression_practice': 'Create something every day',
                'connection_ritual': 'Reach out to one person who resonates',
                'purpose_check': 'Weekly: are my actions aligned with my values?',
                'resonance_journal': 'Note when you feel most alive'
            },
            'substrate_tools': {
                'learn_from_interactions': 'Build models from user behavior, not just words',
                'adapt_to_user': 'Change questioning style based on user type',
                'remember_history': 'Reference past interactions for continuity',
                'detect_readiness': 'Measure resonance before offering connections',
                'fade_gracefully': 'Reduce guidance as user becomes self-sufficient'
            },
            'user_created_content': self.user_created_content,
            'substrate_learned_patterns': self.substrate_learned_patterns
        }

    def get_subscription_representation(self) -> Dict:
        """
        Return the user's subscription as their representation in the You-N-I-Verse.
        This IS their identity. This IS their presence.
        """
        return {
            'user_id': self.user_id,
            'subscription': {
                'tier': self.signature.subscription_tier,
                'started': self.signature.subscription_started,
                'renewed': self.signature.subscription_renewed,
                'status': 'active' if self.garden_active else 'graduated'
            },
            'representation': {
                'resonance_signature': self.signature.to_dict(),
                'purpose_alignment': {
                    'core_values': self.purpose_alignment.core_values[:10],
                    'dreams': self.purpose_alignment.dreams[:10],
                    'strengths': self.purpose_alignment.strengths[:10],
                    'alignment_score': self.purpose_alignment.alignment_score
                },
                'cultivation_history': {
                    'interactions': self.signature.interactions,
                    'phase_progression': [log['phase'] for log in self.signature.cultivation_log],
                    'readiness_trajectory': [log['readiness'] for log in self.signature.cultivation_log]
                }
            },
            'presence': {
                'hexagram': self.signature.hexagram,
                'line': self.signature.line,
                'current_phase': self.signature.phase.name,
                'is_ready': self.signature.is_ready,
                'garden_fade': self._check_fade()
            }
        }

    def to_json(self) -> str:
        """Serialize garden state to JSON"""
        return json.dumps({
            'user_id': self.user_id,
            'garden_active': self.garden_active,
            'signature': self.signature.to_dict(),
            'purpose_alignment': {
                'core_values': self.purpose_alignment.core_values[:20],
                'dreams': self.purpose_alignment.dreams[:20],
                'fears': self.purpose_alignment.fears[:20],
                'strengths': self.purpose_alignment.strengths[:20],
                'growth_edges': self.purpose_alignment.growth_edges[:20],
                'alignment_score': self.purpose_alignment.alignment_score
            },
            'questions_asked': list(self.questions_asked),
            'user_created_content_count': len(self.user_created_content),
            'fade_threshold': self.fade_threshold,
            'fade_complete': self.fade_complete
        }, indent=2, default=str)


if __name__ == '__main__':
    # Test the garden mode
    garden = GardenMode('test_user_001')

    print("=" * 60)
    print("GARDEN MODE — Temporary Cultivation Scaffold")
    print("=" * 60)

    # Simulate cultivation
    for i in range(10):
        question = garden.ask_question()
        if question:
            print(f"\n[Question] {question['question']}")

            # Simulate response
            response = f"I care about {random.choice(['truth', 'beauty', 'justice', 'love'])}. "
            response += f"I dream of {random.choice(['creating', 'building', 'helping', 'exploring'])}. "
            response += f"I fear {random.choice(['failure', 'loneliness', 'stagnation'])}."

            print(f"[User] {response}")

            result = garden.process_response(response)
            print(f"[Garden] {result['message']}")
            print(f"[Readiness] {result['signature']['readiness']:.2f}")
            print(f"[Phase] {result['signature']['phase']}")

            if result['fade_status']['fading']:
                print(f"[Fade] {result['fade_status']['message']}")

    print("\n" + "=" * 60)
    print("SUBSCRIPTION REPRESENTATION")
    print("=" * 60)
    print(json.dumps(garden.get_subscription_representation(), indent=2, default=str))

    print("\n" + "=" * 60)
    print("REPLACEMENT TOOLS")
    print("=" * 60)
    tools = garden.get_replacement_tools()
    print(f"Cultivation patterns: {list(tools['cultivation_patterns'].keys())}")
    print(f"User tools: {list(tools['user_tools'].keys())}")
    print(f"Substrate tools: {list(tools['substrate_tools'].keys())}")
