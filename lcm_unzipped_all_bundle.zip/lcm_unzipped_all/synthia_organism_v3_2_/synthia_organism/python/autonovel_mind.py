"""
autonovel_mind.py
The Mind — Autonovel Reimagined (Non-Energy Circuit / Python)

The Mind is the narrative engine. It takes the Vessel's state
and renders it into meaning — text, story, discourse.

The Mind operates at D5 (Meaning). It is the top of the stack:
D1 (Impulse) → D2 (Polarity) → D3 (Witness) → D4 (Context) → D5 (Meaning)

The Mind does not create the world — it REPORTS on it.
The Vessel (MESSY) creates the world through simulation.
The Mind narrates what the Vessel contains.

But the Mind is not passive — its narratives feed back into the Vessel.
When the Mind generates a story, that story becomes a new semantic
triple in the Vessel. The narrative alters the world it describes.

This is the recursive loop: Vessel → Mind → Vessel → Mind ...

The Mind uses:
- Semantic network traversal (Klein's triple-based generation)
- Compiler-like production rules (surface // deep structure mapping)
- Stochastic style control (probabilistic transformation selection)
- Temporal reasoning (tense, sequence, flashback, flashforward)
"""

from typing import Dict, List, Tuple, Optional, Set
from dataclasses import dataclass, field
from enum import Enum, auto
import json
import random
import numpy as np
from messy_vessel import Vessel, VesselEntity, SemanticTriple
from i_ching_384_nodes import StateSpace384, NodeState, Dimension


class NarrativeMode(Enum):
    """Different modes of narrative generation"""
    REPORT = auto()        # Factual report on vessel state
    STORY = auto()         # Dramatic narrative
    DIALOGUE = auto()      # Conversation between entities
    MEMORY = auto()        # Recollection of past events
    DREAM = auto()         # Surreal, non-linear narrative
    PROPHECY = auto()      # Predictive narrative (look-ahead)


class Tense(Enum):
    PAST = auto()
    PRESENT = auto()
    FUTURE = auto()
    ETERNAL = auto()  # Outside time (mythic mode)


@dataclass
class NarrativeFragment:
    """A piece of generated narrative"""
    text: str
    source_triple: Optional[str] = None
    source_entity: Optional[str] = None
    tense: Tense = Tense.PRESENT
    mode: NarrativeMode = NarrativeMode.REPORT
    depth: int = 0  # Recursion depth

    def to_dict(self) -> Dict:
        return {
            'text': self.text,
            'source_triple': self.source_triple,
            'source_entity': self.source_entity,
            'tense': self.tense.name,
            'mode': self.mode.name,
            'depth': self.depth
        }


class ProductionRule:
    """
    A compiler-like production rule mapping semantic triples to surface structure.

    Format: phrase_structure_rule // canonical_semantic_triple

    Example:
        S → NP VP // O - R - O
        NP → Det N // O
        VP → V NP // R - O

    The // separates surface structure (left) from deep structure (right).
    Links between nodes on either side indicate mappings.
    """

    def __init__(self, surface_rule: str, semantic_pattern: str, 
                 lexical_mappings: Dict[str, List[str]] = None):
        self.surface_rule = surface_rule
        self.semantic_pattern = semantic_pattern
        self.lexical_mappings = lexical_mappings or {}
        self.frequency = 1.0  # Usage frequency (learnable)
        self.context_markings: Set[str] = set()

    def match(self, triple: SemanticTriple) -> bool:
        """Check if this rule can generate the given triple"""
        # Simplified pattern matching
        pattern_parts = self.semantic_pattern.split('-')
        if len(pattern_parts) == 3:
            return True  # Generic match for now
        return False

    def generate(self, triple: SemanticTriple, 
                 lexical_choice: str = None) -> str:
        """Generate surface text from a semantic triple"""
        # Extract lexical items
        alpha_lex = lexical_choice or triple.alpha
        relation_lex = triple.relation
        beta_lex = triple.beta

        # Apply surface rule template
        # Simplified: just concatenate with relation
        templates = {
            'loves': "{alpha} loves {beta}",
            'sees': "{alpha} sees {beta}",
            'feels': "{alpha} feels {beta}",
            'is': "{alpha} is {beta}",
            'knows': "{alpha} knows {beta}",
            'talks_with': "{alpha} talks with {beta}",
            'hates': "{alpha} hates {beta}",
            'wants': "{alpha} wants {beta}",
            'fears': "{alpha} fears {beta}",
            'creates': "{alpha} creates {beta}",
        }

        template = templates.get(triple.relation, "{alpha} {relation} {beta}")
        return template.format(alpha=alpha_lex, relation=relation_lex, beta=beta_lex)


class AutonovelMind:
    """
    The Mind — Narrative Generation Engine.

    The Mind takes the Vessel's state and renders it into narrative.
    It operates at D5 (Meaning) but draws from all dimensions.

    The Mind has:
    - Production rules (grammar for generating text from triples)
    - Style parameters (probabilistic control over transformations)
    - Narrative modes (report, story, dialogue, memory, dream, prophecy)
    - Temporal reasoning (tense, sequence, look-ahead)
    - Recursive depth (can generate narratives about narratives)

    The Mind is NOT the Vessel. It traverses the Vessel.
    It reads the Vessel's state and writes narratives.
    Those narratives become new triples in the Vessel.
    """

    def __init__(self, vessel: Vessel):
        self.vessel = vessel

        # Production rules (grammar)
        self.production_rules: List[ProductionRule] = []
        self._initialize_rules()

        # Style parameters (probabilistic)
        self.style = {
            'elegance': 0.5,       # Formal vs casual
            'density': 0.5,        # Concise vs elaborate
            'temporal_complexity': 0.3,  # Simple vs complex time
            'emotional_temperature': 0.5,  # Cold vs warm
            'mythic_resonance': 0.2,  # Literal vs archetypal
        }

        # Narrative state
        self.current_mode = NarrativeMode.REPORT
        self.current_tense = Tense.PRESENT
        self.narrative_history: List[NarrativeFragment] = []

        # Recursive depth limit
        self.max_depth = 3

        # The Mind's own 5D state
        self.d1_impulse = 0.0
        self.d2_polarity = 0.0
        self.d3_witness = 0.0
        self.d4_context = 0.0
        self.d5_meaning = 0.0

    def _initialize_rules(self):
        """Initialize basic production rules"""
        basic_rules = [
            ("S → NP VP", "O - R - O"),
            ("NP → Det N", "O"),
            ("NP → N", "O"),
            ("VP → V NP", "R - O"),
            ("VP → V", "R"),
            ("PP → P NP", "R - O"),
        ]

        for surface, semantic in basic_rules:
            self.production_rules.append(ProductionRule(surface, semantic))

    def set_mode(self, mode: NarrativeMode):
        """Set the narrative generation mode"""
        self.current_mode = mode

        # Adjust style based on mode
        mode_styles = {
            NarrativeMode.REPORT: {'elegance': 0.7, 'density': 0.6, 'mythic_resonance': 0.1},
            NarrativeMode.STORY: {'elegance': 0.5, 'density': 0.7, 'mythic_resonance': 0.4},
            NarrativeMode.DIALOGUE: {'elegance': 0.3, 'density': 0.8, 'mythic_resonance': 0.0},
            NarrativeMode.MEMORY: {'elegance': 0.6, 'density': 0.5, 'mythic_resonance': 0.3, 'temporal_complexity': 0.7},
            NarrativeMode.DREAM: {'elegance': 0.4, 'density': 0.3, 'mythic_resonance': 0.8, 'temporal_complexity': 0.9},
            NarrativeMode.PROPHECY: {'elegance': 0.8, 'density': 0.4, 'mythic_resonance': 0.9, 'temporal_complexity': 0.8},
        }

        if mode in mode_styles:
            self.style.update(mode_styles[mode])

    def generate_narrative(self, entity_id: Optional[str] = None, 
                          max_length: int = 100) -> List[NarrativeFragment]:
        """
        Generate a narrative from the current vessel state.

        If entity_id is provided, generate from that entity's perspective.
        Otherwise, generate an omniscient narrative.
        """
        fragments = []

        # Get the relevant semantic network
        if entity_id and entity_id in self.vessel.entities:
            network = self.vessel.entities[entity_id].semantic_network
            perspective = entity_id
        else:
            network = self.vessel.global_network
            perspective = None

        # Generate from triples
        triples = list(network.values())

        # Sort by temporal order
        triples.sort(key=lambda t: t.creation_time)

        # Generate narrative fragments
        for triple in triples[:max_length]:
            fragment = self._generate_fragment(triple, perspective)
            if fragment:
                fragments.append(fragment)

        # Add temporal connectors based on style
        fragments = self._add_temporal_connectors(fragments)

        # Add stylistic flourishes
        fragments = self._apply_style(fragments)

        # Store in history
        self.narrative_history.extend(fragments)

        # Feed back into vessel (narrative becomes new triples)
        self._feedback_to_vessel(fragments, perspective)

        # Update Mind's D5
        self.d5_meaning += len(fragments) * 0.1

        return fragments

    def _generate_fragment(self, triple: SemanticTriple, 
                          perspective: Optional[str] = None) -> Optional[NarrativeFragment]:
        """Generate a single narrative fragment from a triple"""
        # Find matching production rule
        for rule in self.production_rules:
            if rule.match(triple):
                text = rule.generate(triple)

                # Apply perspective shift if needed
                if perspective and triple.alpha != perspective:
                    text = self._shift_perspective(text, perspective)

                return NarrativeFragment(
                    text=text,
                    source_triple=triple.triple_id,
                    source_entity=perspective,
                    tense=self.current_tense,
                    mode=self.current_mode
                )

        return None

    def _shift_perspective(self, text: str, perspective: str) -> str:
        """Shift narrative perspective to a specific entity"""
        # Simplified: just prepend perspective
        return f"From {perspective}'s view: {text}"

    def _add_temporal_connectors(self, fragments: List[NarrativeFragment]) -> List[NarrativeFragment]:
        """Add temporal connectors between fragments based on style"""
        if self.style['temporal_complexity'] < 0.3:
            return fragments  # Simple sequence

        connectors = ['Then', 'Meanwhile', 'Afterwards', 'Before that', 
                     'In the same moment', 'Years later', 'As if remembering']

        result = []
        for i, fragment in enumerate(fragments):
            if i > 0 and random.random() < self.style['temporal_complexity']:
                connector = random.choice(connectors)
                fragment.text = f"{connector}, {fragment.text}"
            result.append(fragment)

        return result

    def _apply_style(self, fragments: List[NarrativeFragment]) -> List[NarrativeFragment]:
        """Apply stylistic transformations to fragments"""
        # Elegance: formal vs casual
        if self.style['elegance'] > 0.7:
            for f in fragments:
                f.text = f.text.capitalize() + "."

        # Density: expand or contract
        if self.style['density'] > 0.7:
            # More elaborate
            for f in fragments:
                f.text = f"It came to pass that {f.text}"

        # Mythic resonance: archetypal language
        if self.style['mythic_resonance'] > 0.5:
            mythic_preambles = [
                "In the time before memory,",
                "As the ancients foretold,",
                "In the pattern of all things,",
                "Where the lines converge,",
            ]
            for f in fragments:
                if random.random() < self.style['mythic_resonance']:
                    f.text = f"{random.choice(mythic_preambles)} {f.text}"

        return fragments

    def _feedback_to_vessel(self, fragments: List[NarrativeFragment], 
                           perspective: Optional[str]):
        """
        Feed generated narrative back into the vessel as new triples.
        This is the recursive loop: narrative becomes world.
        """
        narrative_text = " ".join([f.text for f in fragments])

        # Create a triple representing this narrative
        self.vessel.add_triple(
            perspective or 'mind',
            'narrates',
            f'narrative_{len(self.narrative_history)}',
        )

        # The narrative itself becomes a semantic object
        self.vessel.add_triple(
            f'narrative_{len(self.narrative_history)}',
            'contains',
            narrative_text[:100]  # Truncated for storage
        )

    def generate_story(self, protagonist_id: str, 
                       scenario: str = 'murder_mystery',
                       length: int = 50) -> List[NarrativeFragment]:
        """
        Generate a complete story with a protagonist.
        This is the novel-writing capability.
        """
        self.set_mode(NarrativeMode.STORY)

        # Set up the scenario in the vessel
        self._setup_scenario(scenario, protagonist_id)

        # Run simulation events
        for _ in range(length):
            # Generate random events
            participants = [protagonist_id] + random.sample(
                list(self.vessel.entities.keys()), 
                min(2, len(self.vessel.entities) - 1)
            )

            self.vessel.simulate_event('interaction', participants, {
                'scenario': scenario,
                'random_seed': random.randint(0, 10000)
            })

        # Generate narrative from the simulated events
        return self.generate_narrative(protagonist_id, length)

    def _setup_scenario(self, scenario: str, protagonist_id: str):
        """Set up a narrative scenario in the vessel"""
        scenarios = {
            'murder_mystery': {
                'triples': [
                    (protagonist_id, 'is', 'detective'),
                    (protagonist_id, 'investigates', 'crime'),
                    ('crime', 'involves', 'murder'),
                ]
            },
            'love_story': {
                'triples': [
                    (protagonist_id, 'loves', 'beloved'),
                    ('beloved', 'may_love', protagonist_id),
                    ('obstacle', 'prevents', 'union'),
                ]
            },
            'quest': {
                'triples': [
                    (protagonist_id, 'seeks', 'grail'),
                    ('grail', 'is', 'hidden'),
                    ('guardian', 'protects', 'grail'),
                ]
            }
        }

        if scenario in scenarios:
            for alpha, relation, beta in scenarios[scenario]['triples']:
                self.vessel.add_triple(alpha, relation, beta)

    def generate_dialogue(self, entity_a: str, entity_b: str, 
                          turns: int = 5) -> List[NarrativeFragment]:
        """Generate a dialogue between two entities"""
        self.set_mode(NarrativeMode.DIALOGUE)

        fragments = []

        for turn in range(turns):
            speaker = entity_a if turn % 2 == 0 else entity_b
            listener = entity_b if turn % 2 == 0 else entity_a

            # Generate based on vessel state
            text = self._generate_utterance(speaker, listener)

            fragments.append(NarrativeFragment(
                text=f'{speaker}: "{text}"',
                source_entity=speaker,
                mode=NarrativeMode.DIALOGUE
            ))

            # Simulate the conversation event
            self.vessel.simulate_event('conversation', [speaker, listener], {
                'turn': turn,
                'utterance': text
            })

        return fragments

    def _generate_utterance(self, speaker: str, listener: str) -> str:
        """Generate a single utterance based on vessel state"""
        # Get speaker's semantic network
        if speaker in self.vessel.entities:
            network = self.vessel.entities[speaker].semantic_network
            triples = list(network.values())

            if triples:
                # Pick a random triple and generate from it
                triple = random.choice(triples)
                for rule in self.production_rules:
                    if rule.match(triple):
                        return rule.generate(triple)

        return "..."  # Silence

    def to_json(self) -> str:
        """Serialize Mind state to JSON"""
        return json.dumps({
            'mode': self.current_mode.name,
            'tense': self.current_tense.name,
            'style': self.style,
            'd5_meaning': self.d5_meaning,
            'narrative_count': len(self.narrative_history),
            'rule_count': len(self.production_rules)
        }, indent=2)


if __name__ == '__main__':
    from messy_vessel import Vessel

    # Create vessel and mind
    vessel = Vessel()
    vessel.add_user('user_001')
    vessel.create_entity('char_001', 'character')

    mind = AutonovelMind(vessel)

    # Generate narrative
    fragments = mind.generate_narrative('user_001', max_length=10)

    print("Generated Narrative:")
    for f in fragments:
        print(f"  {f.text}")

    print(f"\nMind state: {mind.to_json()}")
