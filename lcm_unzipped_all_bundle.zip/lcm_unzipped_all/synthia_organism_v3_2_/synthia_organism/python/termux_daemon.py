#!/usr/bin/env python3
"""
termux_daemon.py
The Termux Daemon — The Autonomous Agent System (Non-Energy Circuit / Python)

This is the final piece. The daemon runs continuously on your phone
(via Termux), watches for changes, and keeps everything synchronized.

It:
1. Watches directories for file changes (new projects, modifications)
2. Auto-ingests new files into the organism
3. Auto-compiles ingested projects
4. Auto-generates applications from patterns
5. Auto-deploys to local server
6. Syncs with remote repositories
7. Handles user intents via natural language
8. Manages the full lifecycle: ingest → compile → generate → deploy

The daemon is the Intent Engine + Autonomous Agent System combined.
It understands your requests and executes them autonomously.

Architecture:
┌─────────────────────────────────────────┐
│  Intent Engine (Natural Language)       │
│  → parses user commands                 │
│  → routes to appropriate agent          │
├─────────────────────────────────────────┤
│  Agent Swarm                            │
│  ├─ Ingestor Agent  → eats files      │
│  ├─ Compiler Agent    → digests code    │
│  ├─ Generator Agent   → creates apps   │
│  ├─ Repair Agent      → fixes bugs      │
│  ├─ Deploy Agent      → builds & runs │
│  └─ Research Agent    → analyzes state │
├─────────────────────────────────────────┤
│  File System Watcher                    │
│  → detects changes in watched dirs      │
│  → triggers auto-ingestion              │
├─────────────────────────────────────────┤
│  Sync Engine                            │
│  → git sync                             │
│  → websocket sync to browser            │
│  → backup to cloud                      │
└─────────────────────────────────────────┘
"""

import os
import sys
import json
import time
import threading
import subprocess
import hashlib
import urllib.request
from pathlib import Path
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field
from collections import defaultdict

# Add the project directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from organism_orchestrator import DigitalOrganism
    from universal_ingestor import UniversalIngestor
    from semantic_compiler import SemanticCompiler
    from mesh_bridge import MeshBridge
except ImportError as e:
    print(f"[Daemon] Warning: Could not import modules: {e}")
    print("[Daemon] Some features will be unavailable")


@dataclass
class UserIntent:
    """A parsed user intent"""
    raw_text: str
    intent_type: str  # 'ingest', 'generate', 'repair', 'deploy', 'query', 'research'
    target: Optional[str] = None
    parameters: Dict = field(default_factory=dict)
    confidence: float = 0.0


class FileSystemWatcher:
    """Watch directories for changes and trigger actions"""

    def __init__(self, watched_dirs: List[str] = None):
        self.watched_dirs = watched_dirs or [
            os.path.expanduser('~/projects'),
            os.path.expanduser('~/downloads'),
            os.path.expanduser('~/termux/shared'),
        ]
        self.file_hashes: Dict[str, str] = {}
        self.running = False
        self.check_interval = 5.0  # seconds
        self.callbacks: List[Callable] = []

    def add_callback(self, callback: Callable):
        self.callbacks.append(callback)

    def _compute_hash(self, filepath: str) -> str:
        """Compute MD5 hash of a file"""
        try:
            with open(filepath, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()
        except:
            return ''

    def _scan_directory(self, dirpath: str) -> Dict[str, str]:
        """Scan a directory and return file hashes"""
        hashes = {}
        for root, dirs, files in os.walk(dirpath):
            # Skip common non-project directories
            dirs[:] = [d for d in dirs if d not in [
                'node_modules', '.git', '__pycache__', '.venv', 'venv',
                'dist', 'build', '.next', '.nuxt'
            ]]

            for file in files:
                filepath = os.path.join(root, file)
                hashes[filepath] = self._compute_hash(filepath)

        return hashes

    def check_changes(self):
        """Check for changes in watched directories"""
        changes = []

        for dirpath in self.watched_dirs:
            if not os.path.exists(dirpath):
                continue

            current_hashes = self._scan_directory(dirpath)

            # Find new files
            for filepath, file_hash in current_hashes.items():
                if filepath not in self.file_hashes:
                    changes.append(('created', filepath))
                    self.file_hashes[filepath] = file_hash
                elif self.file_hashes[filepath] != file_hash:
                    changes.append(('modified', filepath))
                    self.file_hashes[filepath] = file_hash

            # Find deleted files
            for filepath in list(self.file_hashes.keys()):
                if filepath.startswith(dirpath) and filepath not in current_hashes:
                    changes.append(('deleted', filepath))
                    del self.file_hashes[filepath]

        return changes

    def start(self):
        """Start watching"""
        self.running = True

        # Initial scan
        for dirpath in self.watched_dirs:
            if os.path.exists(dirpath):
                self.file_hashes.update(self._scan_directory(dirpath))

        print(f"[Watcher] Watching {len(self.watched_dirs)} directories")

        def watch_loop():
            while self.running:
                changes = self.check_changes()

                for change_type, filepath in changes:
                    print(f"[Watcher] {change_type}: {filepath}")

                    for callback in self.callbacks:
                        try:
                            callback(change_type, filepath)
                        except Exception as e:
                            print(f"[Watcher] Callback error: {e}")

                time.sleep(self.check_interval)

        self.thread = threading.Thread(target=watch_loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False


class IntentEngine:
    """Parse natural language intents and route to agents"""

    INTENT_PATTERNS = {
        'ingest': [
            r'ingest\s+(.+)',
            r'eat\s+(.+)',
            r'import\s+(.+)',
            r'load\s+(.+)',
            r'add\s+project\s+(.+)',
            r'consume\s+(.+)',
        ],
        'generate': [
            r'generate\s+(.+)',
            r'create\s+(.+)',
            r'build\s+(.+)',
            r'make\s+(.+)',
            r'new\s+(.+)',
            r'scaffold\s+(.+)',
        ],
        'repair': [
            r'repair\s+(.+)',
            r'fix\s+(.+)',
            r'debug\s+(.+)',
            r'resolve\s+(.+)',
            r'heal\s+(.+)',
        ],
        'deploy': [
            r'deploy\s+(.+)',
            r'run\s+(.+)',
            r'start\s+(.+)',
            r'launch\s+(.+)',
            r'host\s+(.+)',
        ],
        'query': [
            r'find\s+(.+)',
            r'search\s+(.+)',
            r'query\s+(.+)',
            r'show\s+(.+)',
            r'what\s+is\s+(.+)',
            r'how\s+does\s+(.+)',
        ],
        'research': [
            r'research\s+(.+)',
            r'analyze\s+(.+)',
            r'study\s+(.+)',
            r'investigate\s+(.+)',
            r'learn\s+about\s+(.+)',
        ],
    }

    def __init__(self):
        self.history: List[UserIntent] = []

    def parse(self, text: str) -> UserIntent:
        """Parse a natural language command into an intent"""
        text_lower = text.lower().strip()

        for intent_type, patterns in self.INTENT_PATTERNS.items():
            for pattern in patterns:
                import re
                match = re.search(pattern, text_lower)
                if match:
                    target = match.group(1).strip()

                    intent = UserIntent(
                        raw_text=text,
                        intent_type=intent_type,
                        target=target,
                        confidence=0.8
                    )

                    self.history.append(intent)
                    return intent

        # Fallback: unknown intent
        return UserIntent(
            raw_text=text,
            intent_type='unknown',
            confidence=0.3
        )

    def execute(self, intent: UserIntent, daemon) -> Dict:
        """Execute a parsed intent using the daemon's agents"""
        result = {'success': False, 'message': '', 'data': None}

        if intent.intent_type == 'ingest':
            result = daemon.agents['ingestor'].ingest(intent.target)

        elif intent.intent_type == 'generate':
            result = daemon.agents['generator'].generate(intent.target)

        elif intent.intent_type == 'repair':
            result = daemon.agents['repair'].repair(intent.target)

        elif intent.intent_type == 'deploy':
            result = daemon.agents['deploy'].deploy(intent.target)

        elif intent.intent_type == 'query':
            result = daemon.agents['research'].query(intent.target)

        elif intent.intent_type == 'research':
            result = daemon.agents['research'].research(intent.target)

        else:
            result['message'] = f"Unknown intent: {intent.raw_text}"

        return result


class Agent:
    """Base class for all agents"""

    def __init__(self, name: str, daemon):
        self.name = name
        self.daemon = daemon
        self.log: List[Dict] = []

    def log_action(self, action: str, details: Dict):
        self.log.append({
            'action': action,
            'details': details,
            'timestamp': time.time()
        })


class IngestorAgent(Agent):
    """Agent that ingests files and projects"""

    def __init__(self, daemon):
        super().__init__('ingestor', daemon)
        self.ingestor = None
        if hasattr(daemon, 'universal_ingestor'):
            self.ingestor = daemon.universal_ingestor

    def ingest(self, target: str) -> Dict:
        """Ingest a file, directory, ZIP, or URL"""
        self.log_action('ingest', {'target': target})

        if not self.ingestor:
            return {'success': False, 'message': 'Ingestor not available'}

        try:
            if target.endswith('.zip'):
                graph = self.ingestor.ingest_zip(target)
                return {
                    'success': True,
                    'message': f"Ingested ZIP: {len(graph.nodes)} artifacts",
                    'data': {'artifacts': len(graph.nodes), 'edges': len(graph.edges)}
                }

            elif target.startswith('http'):
                artifact = self.ingestor.ingest_url(target)
                return {
                    'success': True,
                    'message': f"Ingested URL: {artifact.path}",
                    'data': {'language': artifact.language, 'size': artifact.size}
                }

            elif os.path.isdir(target):
                graph = self.ingestor.ingest_directory(target)
                return {
                    'success': True,
                    'message': f"Ingested directory: {len(graph.nodes)} artifacts",
                    'data': {'artifacts': len(graph.nodes), 'edges': len(graph.edges)}
                }

            elif os.path.isfile(target):
                artifact = self.ingestor.ingest_file(target)
                return {
                    'success': True,
                    'message': f"Ingested file: {artifact.path}",
                    'data': {'language': artifact.language, 'size': artifact.size}
                }

            else:
                return {'success': False, 'message': f"Unknown target type: {target}"}

        except Exception as e:
            return {'success': False, 'message': f"Ingestion failed: {e}"}


class GeneratorAgent(Agent):
    """Agent that generates applications and code"""

    def __init__(self, daemon):
        super().__init__('generator', daemon)
        self.compiler = None
        if hasattr(daemon, 'semantic_compiler'):
            self.compiler = daemon.semantic_compiler

    def generate(self, target: str) -> Dict:
        """Generate an application based on target description"""
        self.log_action('generate', {'target': target})

        if not self.compiler:
            return {'success': False, 'message': 'Compiler not available'}

        try:
            # Parse target to determine type and features
            app_type = 'web'
            features = []

            if 'api' in target.lower():
                app_type = 'api'
            elif 'cli' in target.lower() or 'command' in target.lower():
                app_type = 'cli'
            elif 'game' in target.lower():
                app_type = 'game'

            # Extract features from target
            feature_keywords = ['auth', 'login', 'dashboard', 'chat', 'search', 
                               'payment', 'notification', 'profile', 'admin']
            for keyword in feature_keywords:
                if keyword in target.lower():
                    features.append(keyword)

            # Generate application name
            app_name = target.replace(' ', '_').replace('-', '_')[:30]

            # Generate files
            files = self.compiler.generate_application(app_name, app_type, features)

            # Write files to disk
            output_dir = os.path.expanduser(f'~/synthia_generated/{app_name}')
            os.makedirs(output_dir, exist_ok=True)

            for filepath, content in files.items():
                full_path = os.path.join(output_dir, filepath)
                os.makedirs(os.path.dirname(full_path), exist_ok=True)
                with open(full_path, 'w') as f:
                    f.write(content)

            return {
                'success': True,
                'message': f"Generated {app_type} app: {app_name}",
                'data': {'files': len(files), 'output_dir': output_dir, 'type': app_type}
            }

        except Exception as e:
            return {'success': False, 'message': f"Generation failed: {e}"}


class RepairAgent(Agent):
    """Agent that repairs broken code"""

    def __init__(self, daemon):
        super().__init__('repair', daemon)
        self.compiler = None
        if hasattr(daemon, 'semantic_compiler'):
            self.compiler = daemon.semantic_compiler

    def repair(self, target: str) -> Dict:
        """Repair a file or project"""
        self.log_action('repair', {'target': target})

        if not self.compiler:
            return {'success': False, 'message': 'Compiler not available'}

        try:
            if os.path.isfile(target):
                # Ingest and repair
                if self.daemon.universal_ingestor:
                    artifact = self.daemon.universal_ingestor.ingest_file(target)
                    repaired = self.compiler.repair_code(artifact)

                    # Write repaired version
                    with open(target, 'w') as f:
                        f.write(repaired)

                    return {
                        'success': True,
                        'message': f"Repaired: {target}",
                        'data': {'original_size': len(artifact.content), 'repaired_size': len(repaired)}
                    }

            return {'success': False, 'message': f"Cannot repair: {target}"}

        except Exception as e:
            return {'success': False, 'message': f"Repair failed: {e}"}


class DeployAgent(Agent):
    """Agent that deploys applications"""

    def __init__(self, daemon):
        super().__init__('deploy', daemon)

    def deploy(self, target: str) -> Dict:
        """Deploy an application"""
        self.log_action('deploy', {'target': target})

        try:
            # Check if target is a directory
            if os.path.isdir(target):
                # Try to detect project type and deploy accordingly
                if os.path.exists(os.path.join(target, 'package.json')):
                    # Node.js project
                    return self._deploy_nodejs(target)
                elif os.path.exists(os.path.join(target, 'requirements.txt')) or \
                     os.path.exists(os.path.join(target, 'setup.py')):
                    # Python project
                    return self._deploy_python(target)
                elif os.path.exists(os.path.join(target, 'index.html')):
                    # Static site
                    return self._deploy_static(target)
                else:
                    return {'success': False, 'message': f"Unknown project type: {target}"}

            return {'success': False, 'message': f"Not a directory: {target}"}

        except Exception as e:
            return {'success': False, 'message': f"Deploy failed: {e}"}

    def _deploy_nodejs(self, target: str) -> Dict:
        """Deploy a Node.js project"""
        try:
            subprocess.run(['npm', 'install'], cwd=target, check=True, capture_output=True)
            return {'success': True, 'message': f"Deployed Node.js app: {target}"}
        except subprocess.CalledProcessError as e:
            return {'success': False, 'message': f"npm install failed: {e}"}

    def _deploy_python(self, target: str) -> Dict:
        """Deploy a Python project"""
        try:
            # Try to run the main file
            main_files = ['main.py', 'app.py', 'server.py', 'run.py']
            for main_file in main_files:
                if os.path.exists(os.path.join(target, main_file)):
                    return {
                        'success': True,
                        'message': f"Python app ready: {main_file}",
                        'data': {'run_command': f"python {main_file}", 'cwd': target}
                    }

            return {'success': False, 'message': "No main file found"}
        except Exception as e:
            return {'success': False, 'message': f"Deploy failed: {e}"}

    def _deploy_static(self, target: str) -> Dict:
        """Deploy a static site"""
        return {
            'success': True,
            'message': f"Static site ready: {target}",
            'data': {'open': os.path.join(target, 'index.html')}
        }


class ResearchAgent(Agent):
    """Agent that researches and analyzes"""

    def __init__(self, daemon):
        super().__init__('research', daemon)
        self.compiler = None
        if hasattr(daemon, 'semantic_compiler'):
            self.compiler = daemon.semantic_compiler

    def query(self, target: str) -> Dict:
        """Query the semantic graph"""
        self.log_action('query', {'target': target})

        if not self.compiler:
            return {'success': False, 'message': 'Compiler not available'}

        try:
            results = self.compiler.query_graph(target)

            return {
                'success': True,
                'message': f"Found {len(results)} results",
                'data': [
                    {'name': r.name, 'type': r.type, 'source': r.source}
                    for r in results[:10]
                ]
            }

        except Exception as e:
            return {'success': False, 'message': f"Query failed: {e}"}

    def research(self, target: str) -> Dict:
        """Research a topic"""
        self.log_action('research', {'target': target})

        # Generate insights about the organism's state
        insights = []

        if self.compiler:
            insights.append(f"Semantic graph has {len(self.compiler.semantic_graph)} nodes")
            insights.append(f"Detected {len(self.compiler.conflicts)} conflicts")
            insights.append(f"Learned {len(self.compiler.templates)} templates")

        if self.daemon and hasattr(self.daemon, 'organism'):
            organism = self.daemon.organism
            insights.append(f"Organism state: {organism.state.name if hasattr(organism.state, 'name') else organism.state}")
            insights.append(f"Connected users: {len(organism.connected_users)}")

        return {
            'success': True,
            'message': f"Research on '{target}' complete",
            'data': {'insights': insights}
        }


class TermuxDaemon:
    """
    The Termux Daemon.

    The central orchestrator that runs continuously on your phone.
    It coordinates all agents, watches for changes, and executes user intents.
    """

    def __init__(self):
        # Core systems
        self.organism = None
        self.universal_ingestor = None
        self.semantic_compiler = None
        self.mesh_bridge = None

        # Initialize if available
        try:
            self.organism = DigitalOrganism()
            self.universal_ingestor = UniversalIngestor(self.organism)
            self.semantic_compiler = SemanticCompiler(self.universal_ingestor, self.organism)
        except Exception as e:
            print(f"[Daemon] Warning: Could not initialize core systems: {e}")

        # Agents
        self.agents: Dict[str, Agent] = {
            'ingestor': IngestorAgent(self),
            'generator': GeneratorAgent(self),
            'repair': RepairAgent(self),
            'deploy': DeployAgent(self),
            'research': ResearchAgent(self),
        }

        # Intent engine
        self.intent_engine = IntentEngine()

        # File watcher
        self.watcher = FileSystemWatcher()
        self.watcher.add_callback(self._on_file_change)

        # State
        self.running = False
        self.start_time = 0

    def _on_file_change(self, change_type: str, filepath: str):
        """Handle file system changes"""
        print(f"[Daemon] Auto-ingesting {change_type}: {filepath}")

        # Auto-ingest new/modified files
        if change_type in ['created', 'modified']:
            result = self.agents['ingestor'].ingest(filepath)
            print(f"[Daemon] Auto-ingest result: {result['message']}")

            # If it's a project directory, also compile
            if os.path.isdir(filepath):
                project_id = Path(filepath).name
                if self.semantic_compiler:
                    self.semantic_compiler.compile_project(project_id)
                    print(f"[Daemon] Auto-compiled project: {project_id}")

    def process_intent(self, text: str) -> Dict:
        """Process a natural language intent"""
        print(f"[Daemon] Processing intent: {text}")

        # Parse intent
        intent = self.intent_engine.parse(text)
        print(f"[Daemon] Parsed intent: {intent.intent_type} -> {intent.target}")

        # Execute
        result = self.intent_engine.execute(intent, self)

        print(f"[Daemon] Result: {result['message']}")
        return result

    def start(self):
        """Start the daemon"""
        self.running = True
        self.start_time = time.time()

        print("=" * 50)
        print("  SYNTHIA TERMUX DAEMON")
        print("  The organism is alive.")
        print("=" * 50)

        # Start file watcher
        self.watcher.start()

        # Start organism if available
        if self.organism:
            self.organism.awaken()
            self.organism.start()
            print("[Daemon] Organism awakened")

        # Start mesh bridge if available
        if self.mesh_bridge:
            # This would start the WebSocket server
            pass

        print("[Daemon] Running. Type 'help' for commands, 'quit' to exit.")

        # Command loop
        while self.running:
            try:
                text = input("\n> ").strip()

                if not text:
                    continue

                if text.lower() in ['quit', 'exit', 'q']:
                    self.stop()
                    break

                elif text.lower() == 'help':
                    print(self._get_help())

                elif text.lower() == 'status':
                    print(self._get_status())

                elif text.lower().startswith('ingest '):
                    target = text[7:].strip()
                    result = self.agents['ingestor'].ingest(target)
                    print(result['message'])

                elif text.lower().startswith('generate '):
                    target = text[9:].strip()
                    result = self.agents['generator'].generate(target)
                    print(result['message'])

                elif text.lower().startswith('repair '):
                    target = text[7:].strip()
                    result = self.agents['repair'].repair(target)
                    print(result['message'])

                elif text.lower().startswith('deploy '):
                    target = text[7:].strip()
                    result = self.agents['deploy'].deploy(target)
                    print(result['message'])

                elif text.lower().startswith('query '):
                    target = text[6:].strip()
                    result = self.agents['research'].query(target)
                    print(result['message'])
                    if result['data']:
                        for item in result['data']:
                            print(f"  - {item['name']} ({item['type']}) from {item['source']}")

                elif text.lower().startswith('research '):
                    target = text[9:].strip()
                    result = self.agents['research'].research(target)
                    print(result['message'])
                    if result['data'] and 'insights' in result['data']:
                        for insight in result['data']['insights']:
                            print(f"  • {insight}")

                else:
                    # Try to parse as natural language intent
                    result = self.process_intent(text)
                    print(result['message'])

            except KeyboardInterrupt:
                print("\n[Daemon] Interrupted. Stopping...")
                self.stop()
                break
            except Exception as e:
                print(f"[Daemon] Error: {e}")

    def stop(self):
        """Stop the daemon"""
        self.running = False

        if self.watcher:
            self.watcher.stop()

        if self.organism:
            self.organism.stop()

        print("[Daemon] Stopped.")

    def _get_help(self) -> str:
        return """
Commands:
  ingest <path/url/zip>     - Ingest a file, directory, or ZIP
  generate <description>    - Generate an application
  repair <path>             - Repair broken code
  deploy <path>             - Deploy an application
  query <question>          - Query the semantic graph
  research <topic>          - Research the organism's state
  status                    - Show daemon status
  help                      - Show this help
  quit                      - Exit daemon

Natural language:
  You can also type natural language commands like:
  "ingest my project folder"
  "create a web app with auth"
  "fix the bug in app.py"
  "deploy the generated app"
  "what classes are in the project?"
"""

    def _get_status(self) -> str:
        uptime = time.time() - self.start_time

        status = f"""
Daemon Status:
  Uptime: {uptime:.0f}s
  Organism: {'Awake' if self.organism else 'Unavailable'}
  Ingestor: {'Ready' if self.universal_ingestor else 'Unavailable'}
  Compiler: {'Ready' if self.semantic_compiler else 'Unavailable'}
  Agents: {', '.join(self.agents.keys())}
  Watched dirs: {len(self.watcher.watched_dirs)}
"""

        if self.semantic_compiler:
            stats = self.semantic_compiler.get_stats()
            status += f"\nSemantic Graph:\n"
            status += f"  Nodes: {stats['nodes']}\n"
            status += f"  Conflicts: {stats['conflicts']}\n"
            status += f"  Templates: {stats['templates']}\n"

        if self.universal_ingestor:
            ingestor_stats = self.universal_ingestor.get_stats()
            status += f"\nIngested:\n"
            status += f"  Projects: {ingestor_stats['projects']}\n"
            status += f"  Artifacts: {ingestor_stats['artifacts']}\n"
            status += f"  Triples: {ingestor_stats['triples']}\n"

        return status


if __name__ == '__main__':
    daemon = TermuxDaemon()
    daemon.start()
