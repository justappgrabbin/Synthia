"""
diseminer_body.py
The Body — DISEMINER Reimagined (Non-Energy Circuit / Python)

The Body is the distributional semantics inference engine.
It learns patterns from the Vessel's semantic network and
infers relationships that are not explicitly stated.

The Body operates at D1 (Impulse) and D2 (Polarity):
- D1: It receives raw signals from the Vessel (semantic triples)
- D2: It detects polarity — attraction/repulsion, co-occurrence patterns

The Body is the SENSORY layer. It feels the Vessel.
It does not think (that's the Mind) and it does not feel deeply
(that's the Heart). It SENSES and INFERS.

The Body uses:
- Dependency matrix analysis (Klein's original DISEMINER method)
- Distributional learning (what co-occurs with what)
- Transitive inference (if A→B and B→C, then A→C)
- Pattern recognition (clustering of semantic fields)
- Boolean group operations (Klein's ATO logic for analogy)

The Body learns from:
- The Vessel's semantic network (global triples)
- Entity interactions (who talks to whom, about what)
- Temporal sequences (what follows what)
- User behavior (what the user engages with)

The Body produces:
- Inferred triples (new relationships not explicitly stated)
- Semantic clusters (groups of related concepts)
- Analogy mappings (A is to B as C is to D)
- Predictive patterns (what is likely to happen next)
"""

from typing import Dict, List, Tuple, Optional, Set
from dataclasses import dataclass, field
from collections import defaultdict
import numpy as np
import json
from messy_vessel import Vessel, SemanticTriple
from i_ching_384_nodes import StateSpace384, NodeState


@dataclass
class SemanticCluster:
    """A cluster of semantically related concepts"""
    cluster_id: str
    members: Set[str] = field(default_factory=set)
    centroid: np.ndarray = field(default_factory=lambda: np.zeros(5))
    coherence: float = 0.0

    def add_member(self, concept: str, vector: np.ndarray):
        self.members.add(concept)
        # Update centroid
        if len(self.members) == 1:
            self.centroid = vector
        else:
            self.centroid = (self.centroid * (len(self.members) - 1) + vector) / len(self.members)

    def resonance(self, vector: np.ndarray) -> float:
        """Compute resonance between cluster and a vector"""
        dot = np.dot(self.centroid, vector)
        mag = np.linalg.norm(self.centroid) * np.linalg.norm(vector)
        return dot / mag if mag > 0 else 0.0


@dataclass
class AnalogyMapping:
    """
    An analogy: A is to B as C is to D.
    Computed using Klein's ATO (Analogical Transformation Operator)
    logic with Boolean groups.
    """
    a: str
    b: str
    c: str
    d: str  # Inferred

    # Boolean feature vectors
    a_vector: np.ndarray = field(default_factory=lambda: np.zeros(8))
    b_vector: np.ndarray = field(default_factory=lambda: np.zeros(8))
    c_vector: np.ndarray = field(default_factory=lambda: np.zeros(8))
    d_vector: np.ndarray = field(default_factory=lambda: np.zeros(8))

    # Confidence
    confidence: float = 0.0

    @property
    def analogy_text(self) -> str:
        return f"{self.a} is to {self.b} as {self.c} is to {self.d}"


class DiseminerBody:
    """
    The Body — Semantic Inference Engine.

    The Body learns distributional patterns from the Vessel
    and infers new relationships. It is the sensory layer.

    Key capabilities:
    1. Dependency Matrix: Track co-occurrence of all concepts
    2. Cluster Detection: Find semantic fields
    3. Transitive Inference: A→B, B→C implies A→C
    4. Analogy Computation: ATO logic for A:B::C:D
    5. Predictive Patterns: What follows what

    The Body feeds the Heart (AUTOLING) with inferred patterns
    that become new grammar rules. It feeds the Mind (Autonovel)
    with semantic clusters that become narrative themes.
    """

    def __init__(self, vessel: Vessel):
        self.vessel = vessel

        # Dependency matrix: concept -> {related_concept: count}
        self.dependency_matrix: Dict[str, Dict[str, float]] = defaultdict(
            lambda: defaultdict(float)
        )

        # Semantic clusters (emergent)
        self.clusters: Dict[str, SemanticCluster] = {}

        # Analogy mappings (inferred)
        self.analogies: List[AnalogyMapping] = []

        # Feature vectors for concepts (Boolean features)
        self.concept_features: Dict[str, np.ndarray] = {}

        # Predictive model: what follows what
        self.transition_matrix: Dict[str, Dict[str, float]] = defaultdict(
            lambda: defaultdict(float)
        )

        # Learning rate
        self.learning_rate = 0.1

        # The Body's 5D state
        self.d1_impulse = 0.0
        self.d2_polarity = 0.0
        self.d3_witness = 0.0
        self.d4_context = 0.0
        self.d5_meaning = 0.0

        # Inference history
        self.inference_log: List[Dict] = []

    def ingest_triple(self, triple: SemanticTriple):
        """
        Ingest a semantic triple into the dependency matrix.
        This is the fundamental learning operation.
        """
        # Update dependency matrix
        self.dependency_matrix[triple.alpha][triple.beta] += 1.0
        self.dependency_matrix[triple.beta][triple.alpha] += 1.0
        self.dependency_matrix[triple.alpha][triple.relation] += 0.5
        self.dependency_matrix[triple.beta][triple.relation] += 0.5

        # Update feature vectors
        self._update_features(triple)

        # Update transition matrix (temporal)
        self._update_transitions(triple)

        # Update D1 (impulse) — the Body feels the input
        self.d1_impulse += 0.1

    def _update_features(self, triple: SemanticTriple):
        """Update Boolean feature vectors for concepts"""
        # Initialize features if not present
        for concept in [triple.alpha, triple.beta, triple.relation]:
            if concept not in self.concept_features:
                # Random 8-bit feature vector
                self.concept_features[concept] = np.random.randint(0, 2, 8).astype(float)

        # Update features based on co-occurrence
        # When two concepts co-occur, their features become more similar
        a_vec = self.concept_features[triple.alpha]
        b_vec = self.concept_features[triple.beta]

        # Make them more similar (Hebbian learning)
        similarity = np.dot(a_vec, b_vec) / (np.linalg.norm(a_vec) * np.linalg.norm(b_vec) + 1e-10)

        self.concept_features[triple.alpha] += self.learning_rate * b_vec * (1 - similarity)
        self.concept_features[triple.beta] += self.learning_rate * a_vec * (1 - similarity)

        # Normalize
        self.concept_features[triple.alpha] = np.clip(self.concept_features[triple.alpha], 0, 1)
        self.concept_features[triple.beta] = np.clip(self.concept_features[triple.beta], 0, 1)

    def _update_transitions(self, triple: SemanticTriple):
        """Update temporal transition matrix"""
        # What tends to follow what in the vessel's history
        recent_triples = [
            t for t in self.vessel.global_network.values()
            if t.creation_time < triple.creation_time and 
            t.creation_time > triple.creation_time - 10.0
        ]

        for prev in recent_triples:
            self.transition_matrix[prev.beta][triple.alpha] += 1.0

    def infer_relationship(self, concept_a: str, concept_b: str) -> Optional[str]:
        """
        Infer a relationship between two concepts that have not been
        explicitly connected in the vessel.

        Uses transitive inference and distributional similarity.
        """
        # Check if directly connected
        if concept_b in self.dependency_matrix[concept_a]:
            return "directly_related"

        # Find common neighbors (transitive inference)
        neighbors_a = set(self.dependency_matrix[concept_a].keys())
        neighbors_b = set(self.dependency_matrix[concept_b].keys())
        common = neighbors_a & neighbors_b

        if common:
            # Infer relationship through common neighbor
            bridge = list(common)[0]
            return f"related_through_{bridge}"

        # Check feature similarity (distributional similarity)
        if concept_a in self.concept_features and concept_b in self.concept_features:
            sim = np.dot(
                self.concept_features[concept_a],
                self.concept_features[concept_b]
            ) / (
                np.linalg.norm(self.concept_features[concept_a]) * 
                np.linalg.norm(self.concept_features[concept_b]) + 1e-10
            )

            if sim > 0.7:
                return "distributional_similarity"

        return None

    def compute_analogy(self, a: str, b: str, c: str) -> Optional[AnalogyMapping]:
        """
        Compute an analogy: A is to B as C is to ?

        Uses Klein's ATO logic with Boolean groups (Klein-4).
        The strong equivalence operator computes the transformation.
        """
        if not all(x in self.concept_features for x in [a, b, c]):
            return None

        a_vec = self.concept_features[a]
        b_vec = self.concept_features[b]
        c_vec = self.concept_features[c]

        # Compute transformation: *ab (using XOR-like operation)
        # In Boolean groups: *ab = a XOR b (mod 2 addition)
        transform = np.mod(a_vec + b_vec, 2)

        # Apply transformation to c: d = *c*ab = c XOR transform
        d_vec = np.mod(c_vec + transform, 2)

        # Find the concept closest to d_vec
        best_match = None
        best_score = -1

        for concept, features in self.concept_features.items():
            if concept in [a, b, c]:
                continue

            score = np.dot(d_vec, features) / (np.linalg.norm(d_vec) * np.linalg.norm(features) + 1e-10)

            if score > best_score:
                best_score = score
                best_match = concept

        if best_match and best_score > 0.5:
            analogy = AnalogyMapping(
                a=a, b=b, c=c, d=best_match,
                a_vector=a_vec, b_vector=b_vec,
                c_vector=c_vec, d_vector=d_vec,
                confidence=best_score
            )
            self.analogies.append(analogy)
            return analogy

        return None

    def detect_clusters(self, min_size: int = 3) -> List[SemanticCluster]:
        """
        Detect semantic clusters from the dependency matrix.
        Clusters are groups of concepts that co-occur frequently.
        """
        # Build adjacency matrix
        concepts = list(self.dependency_matrix.keys())
        n = len(concepts)

        if n < min_size:
            return []

        # Compute similarity matrix
        sim_matrix = np.zeros((n, n))
        for i, ci in enumerate(concepts):
            for j, cj in enumerate(concepts):
                if i == j:
                    sim_matrix[i, j] = 1.0
                else:
                    # Cosine similarity of dependency vectors
                    vi = np.array([self.dependency_matrix[ci].get(k, 0) for k in concepts])
                    vj = np.array([self.dependency_matrix[cj].get(k, 0) for k in concepts])

                    dot = np.dot(vi, vj)
                    mag = np.linalg.norm(vi) * np.linalg.norm(vj)
                    sim_matrix[i, j] = dot / mag if mag > 0 else 0.0

        # Simple clustering: connected components above threshold
        threshold = 0.3
        clusters = []
        visited = set()

        for i in range(n):
            if i in visited:
                continue

            # BFS to find cluster
            cluster = SemanticCluster(cluster_id=f"cluster_{len(clusters)}")
            queue = [i]
            visited.add(i)

            while queue:
                curr = queue.pop(0)
                cluster.add_member(concepts[curr], 
                    self.concept_features.get(concepts[curr], np.zeros(5)))

                for j in range(n):
                    if j not in visited and sim_matrix[curr, j] > threshold:
                        visited.add(j)
                        queue.append(j)

            if len(cluster.members) >= min_size:
                clusters.append(cluster)
                self.clusters[cluster.cluster_id] = cluster

        return clusters

    def predict_next(self, current_concept: str) -> List[Tuple[str, float]]:
        """
        Predict what concepts are likely to follow the current one.
        Uses the transition matrix.
        """
        if current_concept not in self.transition_matrix:
            return []

        transitions = self.transition_matrix[current_concept]
        total = sum(transitions.values())

        if total == 0:
            return []

        # Return sorted by probability
        predictions = [
            (concept, count / total)
            for concept, count in transitions.items()
        ]
        predictions.sort(key=lambda x: x[1], reverse=True)

        return predictions[:5]

    def learn_from_vessel(self):
        """
        Learn from the current state of the vessel.
        Ingest all triples, detect clusters, compute analogies.
        """
        # Ingest all global triples
        for triple in self.vessel.global_network.values():
            self.ingest_triple(triple)

        # Ingest all entity triples
        for entity in self.vessel.entities.values():
            for triple in entity.semantic_network.values():
                self.ingest_triple(triple)

        # Detect clusters
        self.detect_clusters()

        # Compute analogies for random concept triples
        concepts = list(self.concept_features.keys())
        if len(concepts) >= 3:
            for _ in range(min(10, len(concepts) // 3)):
                a, b, c = np.random.choice(concepts, 3, replace=False)
                self.compute_analogy(a, b, c)

        # Update Body state
        self.d2_polarity = len(self.clusters) * 0.1
        self.d4_context = len(self.analogies) * 0.05

    def get_inferred_triples(self) -> List[Tuple[str, str, str, float]]:
        """
        Get all inferred triples with confidence scores.
        These can be added to the vessel as new knowledge.
        """
        inferred = []

        # From transitive inference
        for a in self.dependency_matrix:
            for b in self.dependency_matrix:
                if a == b:
                    continue
                if b not in self.dependency_matrix[a]:
                    relation = self.infer_relationship(a, b)
                    if relation:
                        # Compute confidence from path strength
                        confidence = 0.3  # Base confidence for inference
                        inferred.append((a, relation, b, confidence))

        # From analogies
        for analogy in self.analogies:
            inferred.append((
                analogy.c, 
                f"analogous_to_{analogy.a}_through_{analogy.b}",
                analogy.d,
                analogy.confidence
            ))

        return inferred

    def to_json(self) -> str:
        """Serialize Body state to JSON"""
        return json.dumps({
            'concepts': len(self.concept_features),
            'clusters': len(self.clusters),
            'analogies': len(self.analogies),
            'd1_impulse': self.d1_impulse,
            'd2_polarity': self.d2_polarity,
            'd4_context': self.d4_context,
            'inferred_triples': len(self.get_inferred_triples())
        }, indent=2)


if __name__ == '__main__':
    from messy_vessel import Vessel

    # Create vessel and body
    vessel = Vessel()
    vessel.add_user('user_001')

    # Add some triples
    vessel.add_triple('user_001', 'loves', 'music')
    vessel.add_triple('user_001', 'creates', 'art')
    vessel.add_triple('music', 'inspires', 'art')
    vessel.add_triple('art', 'expresses', 'emotion')
    vessel.add_triple('emotion', 'drives', 'creation')

    body = DiseminerBody(vessel)
    body.learn_from_vessel()

    print(f"Body state: {body.to_json()}")

    # Test inference
    print(f"\nInferred: {body.infer_relationship('user_001', 'emotion')}")

    # Test analogy
    analogy = body.compute_analogy('user_001', 'music', 'art')
    if analogy:
        print(f"Analogy: {analogy.analogy_text}")

    # Test prediction
    print(f"\nPredictions from 'music': {body.predict_next('music')}")
