"""
autoling_heart.py
The Heart — AUTOLING Reimagined (Non-Energy Circuit / Python)

The Heart is the grammar evolution engine. It learns and modifies
its own rules through interaction with the Vessel and the other entities.

The Heart operates at D3 (Witness). It is the observer-node —
the point where the system becomes self-measuring.

The Heart does not generate narrative (that's the Mind) and it does
not sense patterns (that's the Body). It EVOLVES the RULES that
both the Mind and Body use.

The Heart is the EMOTIONAL/Creative core. It feels the resonance
between rules and reality. When a rule works, the Heart "feels" good.
When a rule fails, the Heart "feels" bad. It learns from these feelings.

The Heart uses:
- Heuristic grammar learning (Klein's AUTOLING methods)
- Rule positing and testing (hypothesis → test → validation)
- Frequency parameter updating (rules get stronger with use)
- Context marking (rules apply in specific situations)
- Self-modification (rules can modify other rules)

The Heart learns from:
- Successful parses (the Body's inferences that work)
- Successful narratives (the Mind's stories that resonate)
- User feedback (what the user engages with)
- Failed attempts (rules that don't work get weakened)
- Other entities' grammars (cross-pollination)

The Heart produces:
- New grammar rules (synthesized from experience)
- Modified rules (frequency updates, context markings)
- Deleted rules (pruned when consistently failing)
- Rule clusters (groups of rules that work together)
"""

from typing import Dict, List, Tuple, Optional, Set
from dataclasses import dataclass, field
from enum import Enum, auto
from collections import defaultdict
import json
import random
import numpy as np
from messy_vessel import Vessel, SemanticTriple
from i_ching_384_nodes import StateSpace384, NodeState


class RuleStatus(Enum):
    """Status of a grammar rule"""
    HYPOTHESIS = auto()    # Newly posited, untested
    TESTING = auto()       # Undergoing testing
    VALIDATED = auto()     # Accepted after testing
    REJECTED = auto()      # Failed testing
    DORMANT = auto()       # Not used recently
    PRUNED = auto()        # Removed from active grammar


@dataclass
class GrammarRule:
    """
    A grammar rule in the Heart's rule system.

    Based on Klein's AUTOLING: each rule has a surface structure
    (phrase structure) and a deep structure (semantic pattern).

    Rules are stochastic — they have frequency parameters that
    determine how often they are used.

    Rules can be context-marked — they only apply in specific situations.
    """
    rule_id: str
    surface_pattern: str      # Phrase structure (e.g., "S → NP VP")
    semantic_pattern: str     # Semantic triple pattern (e.g., "O - R - O")

    # Frequency parameter (learnable)
    frequency: float = 1.0

    # Context markings (when does this rule apply?)
    context_markings: Set[str] = field(default_factory=set)

    # Status in the learning lifecycle
    status: RuleStatus = RuleStatus.HYPOTHESIS

    # Validation history
    success_count: int = 0
    failure_count: int = 0

    # Creation and last use
    creation_time: float = 0.0
    last_used: float = 0.0

    # The rule's "resonance" with the vessel's current state
    resonance: float = 0.0

    @property
    def confidence(self) -> float:
        """Confidence based on success/failure ratio"""
        total = self.success_count + self.failure_count
        if total == 0:
            return 0.5  # Unknown
        return self.success_count / total

    @property
    def activation(self) -> float:
        """Current activation = frequency × confidence × recency"""
        recency = np.exp(-0.01 * (self.last_used - self.creation_time))
        return self.frequency * self.confidence * recency

    def record_success(self):
        self.success_count += 1
        self.frequency += 0.1
        self.last_used = self.creation_time  # Update with current time

    def record_failure(self):
        self.failure_count += 1
        self.frequency *= 0.9  # Decay
        self.last_used = self.creation_time


class AutolingHeart:
    """
    The Heart — Grammar Evolution Engine.

    The Heart learns grammar rules from interaction with the Vessel.
    It is the self-modifying core of the system.

    Key capabilities:
    1. Rule Positing: Create new rules from observed patterns
    2. Rule Testing: Generate test productions and validate them
    3. Frequency Learning: Rules get stronger with success
    4. Context Learning: Rules acquire situation-specific markings
    5. Cross-Pollination: Learn from other entities' grammars
    6. Self-Modification: Rules can modify other rules

    The Heart is the observer-node (D3). It watches the Mind and Body,
feels their successes and failures, and evolves the rules accordingly.
    """

    def __init__(self, vessel: Vessel):
        self.vessel = vessel

        # Grammar rules
        self.rules: Dict[str, GrammarRule] = {}
        self._initialize_rules()

        # Rule clusters (rules that work together)
        self.rule_clusters: Dict[str, Set[str]] = defaultdict(set)

        # Learning parameters
        self.learning_rate = 0.1
        self.pruning_threshold = 0.1

        # The Heart's 5D state
        self.d1_impulse = 0.0
        self.d2_polarity = 0.0
        self.d3_witness = 0.0
        self.d4_context = 0.0
        self.d5_meaning = 0.0

        # Emotional state (resonance with vessel)
        self.emotional_resonance = 0.0

        # Learning history
        self.learning_log: List[Dict] = []

    def _initialize_rules(self):
        """Initialize with basic grammar rules"""
        basic_rules = [
            ("S → NP VP", "O - R - O"),
            ("NP → Det N", "O"),
            ("NP → N", "O"),
            ("VP → V NP", "R - O"),
            ("VP → V", "R"),
            ("PP → P NP", "R - O"),
            ("N → 'man'", "man"),
            ("N → 'woman'", "woman"),
            ("V → 'loves'", "loves"),
            ("V → 'sees'", "sees"),
            ("V → 'feels'", "feels"),
            ("Det → 'the'", "the"),
            ("Det → 'a'", "a"),
        ]

        for i, (surface, semantic) in enumerate(basic_rules):
            rule = GrammarRule(
                rule_id=f"rule_{i}",
                surface_pattern=surface,
                semantic_pattern=semantic,
                frequency=1.0,
                status=RuleStatus.VALIDATED,
                creation_time=self.vessel.time
            )
            self.rules[rule.rule_id] = rule

    def posit_rule(self, observed_pattern: Tuple[str, str]) -> Optional[GrammarRule]:
        """
        Posit a new rule from an observed pattern.

        Klein's heuristic: If you see a pattern, create a rule
        that generalizes it. Test it. If it works, keep it.
        """
        surface, semantic = observed_pattern

        rule_id = f"rule_posited_{len(self.rules)}"
        rule = GrammarRule(
            rule_id=rule_id,
            surface_pattern=surface,
            semantic_pattern=semantic,
            frequency=0.5,  # Start with lower frequency
            status=RuleStatus.HYPOTHESIS,
            creation_time=self.vessel.time
        )

        self.rules[rule_id] = rule

        # Log the positing
        self.learning_log.append({
            'action': 'posit',
            'rule_id': rule_id,
            'pattern': observed_pattern,
            'time': self.vessel.time
        })

        # Update D3 (witness) — the Heart observes its own creation
        self.d3_witness += 0.1

        return rule

    def test_rule(self, rule_id: str, test_triples: List[SemanticTriple]) -> bool:
        """
        Test a rule by generating productions and checking if they parse.

        In AUTOLING, this would ask a human informant.
        Here, we test against the vessel's semantic network.
        """
        if rule_id not in self.rules:
            return False

        rule = self.rules[rule_id]
        rule.status = RuleStatus.TESTING

        success = False

        # Try to apply the rule to test triples
        for triple in test_triples:
            # Check if semantic pattern matches
            if self._pattern_matches(rule.semantic_pattern, triple):
                # Generate a production
                production = self._generate_production(rule, triple)

                # Check if production is valid (can be parsed back)
                if self._can_parse(production, triple):
                    success = True
                    rule.record_success()
                else:
                    rule.record_failure()

        # Update status based on results
        if rule.confidence > 0.7:
            rule.status = RuleStatus.VALIDATED
        elif rule.confidence < 0.3 and rule.failure_count > 5:
            rule.status = RuleStatus.REJECTED

        # Log
        self.learning_log.append({
            'action': 'test',
            'rule_id': rule_id,
            'success': success,
            'confidence': rule.confidence,
            'time': self.vessel.time
        })

        return success

    def _pattern_matches(self, pattern: str, triple: SemanticTriple) -> bool:
        """Check if a semantic pattern matches a triple"""
        # Simplified: check if pattern contains the relation
        return triple.relation in pattern or triple.relation in ["O", "R"]

    def _generate_production(self, rule: GrammarRule, triple: SemanticTriple) -> str:
        """Generate a surface production from a rule and triple"""
        # Replace placeholders in surface pattern
        production = rule.surface_pattern
        production = production.replace("O", triple.alpha)
        production = production.replace("R", triple.relation)

        return production

    def _can_parse(self, production: str, triple: SemanticTriple) -> bool:
        """Check if a production can be parsed back to the triple"""
        # Simplified: just check if the production is non-empty
        return len(production) > 0

    def learn_from_interaction(self, entity_id: str, 
                               interaction_type: str, 
                               success: bool):
        """
        Learn from an interaction.

        If the interaction was successful, strengthen the rules used.
        If it failed, weaken them.
        """
        # Find rules that might have been used
        relevant_rules = [
            r for r in self.rules.values()
            if interaction_type in r.context_markings or not r.context_markings
        ]

        for rule in relevant_rules:
            if success:
                rule.record_success()
                # Add context marking
                rule.context_markings.add(interaction_type)
            else:
                rule.record_failure()

    def learn_from_body(self, body_inferences: List[Tuple[str, str, str, float]]):
        """
        Learn from the Body's inferences.

        If the Body infers a new relationship, posit a grammar rule
        that can express it.
        """
        for alpha, relation, beta, confidence in body_inferences:
            # Posit a rule for this relationship
            surface = f"S → NP VP // {alpha} - {relation} - {beta}"
            semantic = f"O - {relation} - O"

            rule = self.posit_rule((surface, semantic))

            if rule and confidence > 0.5:
                # Test the rule
                test_triples = [
                    SemanticTriple(alpha, relation, beta, creation_time=self.vessel.time)
                ]
                self.test_rule(rule.rule_id, test_triples)

    def learn_from_mind(self, narrative_fragments: List):
        """
        Learn from the Mind's narratives.

        If a narrative resonates (user engages), strengthen the rules.
        If it doesn't, weaken them.
        """
        # Simplified: assume all narratives are successful for now
        for fragment in narrative_fragments:
            # Strengthen rules that might have generated this
            for rule in self.rules.values():
                if rule.status == RuleStatus.VALIDATED:
                    rule.record_success()

    def cross_pollinate(self, other_heart: 'AutolingHeart'):
        """
        Learn from another Heart's grammar.

        This is how the system learns from other entities.
        Rules are "borrowed" (like in Klein's early language contact model),
        then tested and adapted.
        """
        for rule_id, rule in other_heart.rules.items():
            if rule.status == RuleStatus.VALIDATED and rule.confidence > 0.8:
                # Borrow the rule
                new_rule_id = f"borrowed_{rule_id}"
                new_rule = GrammarRule(
                    rule_id=new_rule_id,
                    surface_pattern=rule.surface_pattern,
                    semantic_pattern=rule.semantic_pattern,
                    frequency=rule.frequency * 0.5,  # Start weaker
                    status=RuleStatus.HYPOTHESIS,
                    creation_time=self.vessel.time
                )

                self.rules[new_rule_id] = new_rule

                # Log
                self.learning_log.append({
                    'action': 'borrow',
                    'source_rule': rule_id,
                    'new_rule': new_rule_id,
                    'time': self.vessel.time
                })

    def prune_rules(self):
        """
        Remove rules that have consistently failed.
        This keeps the grammar from growing infinitely.
        """
        to_prune = []

        for rule_id, rule in self.rules.items():
            if rule.status == RuleStatus.REJECTED:
                to_prune.append(rule_id)
            elif rule.activation < self.pruning_threshold and rule.status == RuleStatus.DORMANT:
                to_prune.append(rule_id)

        for rule_id in to_prune:
            self.rules[rule_id].status = RuleStatus.PRUNED

            self.learning_log.append({
                'action': 'prune',
                'rule_id': rule_id,
                'time': self.vessel.time
            })

    def get_active_rules(self) -> List[GrammarRule]:
        """Get all active (validated) rules"""
        return [
            r for r in self.rules.values()
            if r.status == RuleStatus.VALIDATED
        ]

    def get_rule_for_triple(self, triple: SemanticTriple) -> Optional[GrammarRule]:
        """Find the best rule for generating a given triple"""
        best_rule = None
        best_score = -1

        for rule in self.get_active_rules():
            if self._pattern_matches(rule.semantic_pattern, triple):
                score = rule.activation
                if score > best_score:
                    best_score = score
                    best_rule = rule

        return best_rule

    def tick(self):
        """Advance the Heart's learning cycle"""
        # Prune failed rules
        self.prune_rules()

        # Update emotional resonance
        self.emotional_resonance = np.mean([
            r.confidence for r in self.rules.values()
        ]) if self.rules else 0.0

        # Update D3 (witness)
        self.d3_witness = self.emotional_resonance

        # Update D2 (polarity) — strength of rule differentiation
        self.d2_polarity = len(self.get_active_rules()) * 0.01

    def to_json(self) -> str:
        """Serialize Heart state to JSON"""
        active = self.get_active_rules()
        return json.dumps({
            'total_rules': len(self.rules),
            'active_rules': len(active),
            'hypothesis_rules': sum(1 for r in self.rules.values() if r.status == RuleStatus.HYPOTHESIS),
            'rejected_rules': sum(1 for r in self.rules.values() if r.status == RuleStatus.REJECTED),
            'emotional_resonance': self.emotional_resonance,
            'd3_witness': self.d3_witness,
            'd2_polarity': self.d2_polarity,
            'learning_events': len(self.learning_log)
        }, indent=2)


if __name__ == '__main__':
    from messy_vessel import Vessel

    # Create vessel and heart
    vessel = Vessel()
    vessel.add_user('user_001')

    heart = AutolingHeart(vessel)

    # Test rule positing
    rule = heart.posit_rule(("S → NP VP // loves - O - O", "O - loves - O"))
    print(f"Posited rule: {rule.rule_id}")

    # Test rule
    test_triple = SemanticTriple('A', 'loves', 'B', creation_time=0)
    success = heart.test_rule(rule.rule_id, [test_triple])
    print(f"Test result: {success}")

    print(f"\nHeart state: {heart.to_json()}")
