"""
universal_ingestor.py
The Universal Ingestor — The Mouth of the Organism (Non-Energy Circuit / Python)

This is the missing piece. The organism has a brain but no mouth.
This module gives it the ability to eat.

It accepts:
- ZIP files (projects, archives)
- Git repositories (clones or URLs)
- Individual files (JS, TS, Python, HTML, CSS, JSON, etc.)
- Directories (recursive ingestion)
- URLs (web pages, APIs)
- Documents (PDF, markdown, text)

It digests them into:
- Dependency graphs (what depends on what)
- Semantic triples (α — R — β for the vessel)
- AST representations (code structure)
- Feature vectors (for pattern matching)
- Inferred relationships (what this project "means")

The Ingestor feeds the Organism. Without it, the Organism is a brain
in a jar. With it, the Organism grows with every project it consumes.
"""

import os
import re
import json
import zipfile
import tarfile
import hashlib
import subprocess
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Set, Any
from dataclasses import dataclass, field
from collections import defaultdict
import ast
import urllib.parse
import urllib.request


@dataclass
class IngestedArtifact:
    """A single ingested file or component"""
    path: str
    content: str
    language: str
    type: str  # 'source', 'config', 'asset', 'document', 'data'
    size: int
    hash: str
    ast: Optional[Dict] = None
    dependencies: List[str] = field(default_factory=list)
    exports: List[str] = field(default_factory=list)
    imports: List[str] = field(default_factory=list)
    semantic_triples: List[Tuple[str, str, str]] = field(default_factory=list)


@dataclass
class DependencyGraph:
    """A graph of dependencies between artifacts"""
    nodes: Dict[str, IngestedArtifact] = field(default_factory=dict)
    edges: List[Tuple[str, str, str]] = field(default_factory=list)  # (from, to, relation)

    def add_node(self, artifact: IngestedArtifact):
        self.nodes[artifact.path] = artifact

    def add_edge(self, from_path: str, to_path: str, relation: str):
        self.edges.append((from_path, to_path, relation))

    def get_dependents(self, path: str) -> List[str]:
        """Get all files that depend on this file"""
        return [f for f, t, _ in self.edges if t == path]

    def get_dependencies(self, path: str) -> List[str]:
        """Get all files this file depends on"""
        return [t for f, t, _ in self.edges if f == path]


class UniversalIngestor:
    """
    The Universal Ingestor.

    Accepts any input and digests it into a form the organism can consume.

    Capabilities:
    1. File Ingestion — Read any file, detect language, parse structure
    2. ZIP Ingestion — Unpack archives, ingest all contents recursively
    3. Git Ingestion — Clone repos, ingest entire codebase
    4. URL Ingestion — Fetch web pages, APIs, raw files
    5. Directory Ingestion — Recursive walk, ingest all files
    6. Semantic Extraction — Build triples from code structure
    7. Dependency Analysis — Build import/export graphs
    8. Pattern Recognition — Identify frameworks, patterns, architectures

    The Ingestor feeds directly into the organism's vessel.
    """

    # Language detection by extension
    LANGUAGE_MAP = {
        '.py': 'python', '.js': 'javascript', '.ts': 'typescript',
        '.tsx': 'typescript', '.jsx': 'javascript', '.html': 'html',
        '.css': 'css', '.scss': 'scss', '.sass': 'sass',
        '.json': 'json', '.yaml': 'yaml', '.yml': 'yaml',
        '.md': 'markdown', '.txt': 'text', '.rst': 'restructuredtext',
        '.java': 'java', '.kt': 'kotlin', '.swift': 'swift',
        '.go': 'go', '.rs': 'rust', '.cpp': 'cpp', '.c': 'c',
        '.h': 'c', '.hpp': 'cpp', '.php': 'php', '.rb': 'ruby',
        '.sh': 'shell', '.bash': 'shell', '.zsh': 'shell',
        '.dockerfile': 'docker', '.tf': 'terraform', '.sql': 'sql',
        '.xml': 'xml', '.svg': 'svg', '.png': 'image', '.jpg': 'image',
        '.jpeg': 'image', '.gif': 'image', '.webp': 'image',
        '.mp3': 'audio', '.wav': 'audio', '.ogg': 'audio',
        '.mp4': 'video', '.webm': 'video', '.mov': 'video',
    }

    # Framework detection patterns
    FRAMEWORK_PATTERNS = {
        'react': [r'import\s+.*\s+from\s+['"]react['"]', r'React\.'],
        'vue': [r'import\s+.*\s+from\s+['"]vue['"]', r'new\s+Vue\('],
        'angular': [r'@angular\/', r'@Component\s*\('],
        'svelte': [r'\.svelte$', r'<script\s+context="module"'],
        'nextjs': [r'next\/', r'getServerSideProps'],
        'express': [r'express\s*\([\s\)]', r'app\.(get|post|put|delete)'],
        'flask': [r'from\s+flask\s+import', r'Flask\s*\('],
        'django': [r'from\s+django\.', r'Django\s*=='],
        'fastapi': [r'from\s+fastapi\s+import', r'FastAPI\s*\('],
        'tensorflow': [r'import\s+tensorflow', r'tf\.'],
        'pytorch': [r'import\s+torch', r'torch\.'],
        'numpy': [r'import\s+numpy', r'np\.'],
        'pandas': [r'import\s+pandas', r'pd\.'],
        'tailwind': [r'tailwindcss', r'@tailwind'],
        'bootstrap': [r'bootstrap', r'className="container"'],
    }

    def __init__(self, organism=None):
        self.organism = organism
        self.ingested_projects: Dict[str, DependencyGraph] = {}
        self.total_artifacts = 0
        self.total_triples = 0
        self.pattern_library: Dict[str, List[str]] = defaultdict(list)

    def detect_language(self, filepath: str) -> str:
        """Detect programming language from file extension"""
        ext = Path(filepath).suffix.lower()
        return self.LANGUAGE_MAP.get(ext, 'unknown')

    def detect_frameworks(self, content: str) -> List[str]:
        """Detect which frameworks a file uses"""
        frameworks = []
        for name, patterns in self.FRAMEWORK_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    frameworks.append(name)
                    break
        return frameworks

    def parse_python_ast(self, content: str) -> Optional[Dict]:
        """Parse Python code into AST and extract structure"""
        try:
            tree = ast.parse(content)

            structure = {
                'imports': [],
                'classes': [],
                'functions': [],
                'variables': [],
                'calls': []
            }

            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        structure['imports'].append(alias.name)
                elif isinstance(node, ast.ImportFrom):
                    module = node.module or ''
                    for alias in node.names:
                        structure['imports'].append(f"{module}.{alias.name}")
                elif isinstance(node, ast.ClassDef):
                    structure['classes'].append({
                        'name': node.name,
                        'line': node.lineno,
                        'bases': [base.id if isinstance(base, ast.Name) else str(base) 
                                 for base in node.bases]
                    })
                elif isinstance(node, ast.FunctionDef):
                    structure['functions'].append({
                        'name': node.name,
                        'line': node.lineno,
                        'args': [arg.arg for arg in node.args.args]
                    })
                elif isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Name):
                        structure['calls'].append(node.func.id)
                    elif isinstance(node.func, ast.Attribute):
                        structure['calls'].append(node.func.attr)

            return structure

        except SyntaxError:
            return None

    def parse_js_imports(self, content: str) -> List[str]:
        """Extract imports from JavaScript/TypeScript"""
        imports = []

        # ES6 imports
        es6_pattern = r'import\s+.*?\s+from\s+['"]([^'"]+)['"]'
        imports.extend(re.findall(es6_pattern, content))

        # CommonJS requires
        cjs_pattern = r'require\s*\(\s*['"]([^'"]+)['"]\s*\)'
        imports.extend(re.findall(cjs_pattern, content))

        # Dynamic imports
        dynamic_pattern = r'import\s*\(\s*['"]([^'"]+)['"]\s*\)'
        imports.extend(re.findall(dynamic_pattern, content))

        return imports

    def extract_semantic_triples(self, artifact: IngestedArtifact) -> List[Tuple[str, str, str]]:
        """Extract semantic triples from an artifact's content and structure"""
        triples = []

        # Basic triples
        triples.append((artifact.path, 'is_written_in', artifact.language))
        triples.append((artifact.path, 'has_type', artifact.type))
        triples.append((artifact.path, 'has_size', str(artifact.size)))

        # Framework triples
        frameworks = self.detect_frameworks(artifact.content)
        for fw in frameworks:
            triples.append((artifact.path, 'uses_framework', fw))

        # Dependency triples
        for dep in artifact.dependencies:
            triples.append((artifact.path, 'depends_on', dep))

        # Export triples
        for exp in artifact.exports:
            triples.append((artifact.path, 'exports', exp))

        # Import triples
        for imp in artifact.imports:
            triples.append((artifact.path, 'imports_from', imp))

        # AST-based triples (for Python)
        if artifact.ast:
            for cls in artifact.ast.get('classes', []):
                triples.append((artifact.path, 'defines_class', cls['name']))
                for base in cls.get('bases', []):
                    if base and base != 'None':
                        triples.append((cls['name'], 'inherits_from', base))

            for func in artifact.ast.get('functions', []):
                triples.append((artifact.path, 'defines_function', func['name']))

            for imp in artifact.ast.get('imports', []):
                triples.append((artifact.path, 'imports_module', imp))

        # Content-based triples
        if artifact.language == 'python':
            # Detect classes, functions, decorators
            class_pattern = r'class\s+(\w+)\s*\(?'
            for match in re.finditer(class_pattern, artifact.content):
                triples.append((artifact.path, 'contains_class', match.group(1)))

            func_pattern = r'def\s+(\w+)\s*\('
            for match in re.finditer(func_pattern, artifact.content):
                triples.append((artifact.path, 'contains_function', match.group(1)))

        elif artifact.language in ['javascript', 'typescript']:
            # Detect exports
            export_pattern = r'export\s+(?:default\s+)?(?:class|function|const|let|var)\s+(\w+)'
            for match in re.finditer(export_pattern, artifact.content):
                triples.append((artifact.path, 'exports', match.group(1)))

            # Detect components (React/Vue/Angular patterns)
            component_pattern = r'(?:function|const|class)\s+(\w+)(?:Component|Page|View|Widget)'
            for match in re.finditer(component_pattern, artifact.content):
                triples.append((artifact.path, 'defines_component', match.group(1)))

        return triples

    def ingest_file(self, filepath: str, project_id: str = 'default') -> IngestedArtifact:
        """Ingest a single file"""
        path = Path(filepath)

        if not path.exists():
            raise FileNotFoundError(f"File not found: {filepath}")

        # Read content
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except Exception as e:
            content = f"[Error reading file: {e}]"

        # Detect language
        language = self.detect_language(filepath)

        # Determine type
        if language in ['python', 'javascript', 'typescript', 'java', 'go', 'rust', 'cpp', 'c']:
            file_type = 'source'
        elif language in ['json', 'yaml', 'xml']:
            file_type = 'config'
        elif language in ['html', 'css', 'scss']:
            file_type = 'asset'
        elif language in ['markdown', 'text', 'restructuredtext']:
            file_type = 'document'
        else:
            file_type = 'data'

        # Compute hash
        file_hash = hashlib.sha256(content.encode()).hexdigest()[:16]

        # Parse AST for Python
        ast_structure = None
        if language == 'python':
            ast_structure = self.parse_python_ast(content)

        # Extract imports
        imports = []
        if language in ['javascript', 'typescript']:
            imports = self.parse_js_imports(content)
        elif language == 'python' and ast_structure:
            imports = ast_structure.get('imports', [])

        # Create artifact
        artifact = IngestedArtifact(
            path=str(filepath),
            content=content,
            language=language,
            type=file_type,
            size=len(content),
            hash=file_hash,
            ast=ast_structure,
            imports=imports
        )

        # Extract semantic triples
        artifact.semantic_triples = self.extract_semantic_triples(artifact)

        self.total_artifacts += 1
        self.total_triples += len(artifact.semantic_triples)

        return artifact

    def ingest_directory(self, dirpath: str, project_id: str = 'default') -> DependencyGraph:
        """Ingest an entire directory recursively"""
        graph = DependencyGraph()

        for root, dirs, files in os.walk(dirpath):
            # Skip common non-project directories
            dirs[:] = [d for d in dirs if d not in [
                'node_modules', '.git', '__pycache__', '.venv', 'venv',
                'dist', 'build', '.next', '.nuxt', 'target', 'out',
                'coverage', '.pytest_cache', '.mypy_cache', '.tox'
            ]]

            for file in files:
                filepath = os.path.join(root, file)

                try:
                    artifact = self.ingest_file(filepath, project_id)
                    graph.add_node(artifact)

                    # Add to organism if available
                    if self.organism:
                        for triple in artifact.semantic_triples:
                            self.organism.vessel.add_triple(
                                triple[0], triple[1], triple[2]
                            )

                except Exception as e:
                    print(f"[Ingestor] Error ingesting {filepath}: {e}")

        # Build dependency edges
        self._build_dependency_edges(graph)

        self.ingested_projects[project_id] = graph

        return graph

    def ingest_zip(self, zippath: str, project_id: str = None) -> DependencyGraph:
        """Ingest a ZIP file"""
        if project_id is None:
            project_id = Path(zippath).stem

        extract_dir = f"/tmp/ingestor_{project_id}_{hashlib.sha256(zippath.encode()).hexdigest()[:8]}"

        # Extract ZIP
        with zipfile.ZipFile(zippath, 'r') as zf:
            zf.extractall(extract_dir)

        # Ingest extracted directory
        graph = self.ingest_directory(extract_dir, project_id)

        # Clean up
        import shutil
        shutil.rmtree(extract_dir, ignore_errors=True)

        return graph

    def ingest_git_repo(self, repo_url: str, project_id: str = None) -> DependencyGraph:
        """Clone and ingest a Git repository"""
        if project_id is None:
            project_id = Path(repo_url).stem.replace('.git', '')

        clone_dir = f"/tmp/ingestor_git_{project_id}_{hashlib.sha256(repo_url.encode()).hexdigest()[:8]}"

        # Clone repo
        try:
            subprocess.run(
                ['git', 'clone', '--depth', '1', repo_url, clone_dir],
                check=True, capture_output=True, timeout=120
            )
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Failed to clone repo: {e}")

        # Ingest cloned directory
        graph = self.ingest_directory(clone_dir, project_id)

        # Clean up
        import shutil
        shutil.rmtree(clone_dir, ignore_errors=True)

        return graph

    def ingest_url(self, url: str, project_id: str = None) -> IngestedArtifact:
        """Ingest a file from a URL"""
        if project_id is None:
            project_id = f"url_{hashlib.sha256(url.encode()).hexdigest()[:8]}"

        # Fetch content
        req = urllib.request.Request(url, headers={'User-Agent': 'Synthia-Ingestor/1.0'})
        with urllib.request.urlopen(req, timeout=30) as response:
            content = response.read().decode('utf-8', errors='ignore')

        # Save to temp file
        temp_path = f"/tmp/ingestor_url_{hashlib.sha256(url.encode()).hexdigest()[:8]}"
        with open(temp_path, 'w') as f:
            f.write(content)

        # Ingest
        artifact = self.ingest_file(temp_path, project_id)

        # Clean up
        os.remove(temp_path)

        return artifact

    def _build_dependency_edges(self, graph: DependencyGraph):
        """Build dependency edges between artifacts in a graph"""
        # Map import paths to file paths
        path_map = {Path(a.path).name: a.path for a in graph.nodes.values()}

        for artifact in graph.nodes.values():
            for imp in artifact.imports:
                # Try to resolve import to a file in the project
                imp_name = Path(imp).name
                if imp_name in path_map:
                    graph.add_edge(artifact.path, path_map[imp_name], 'imports')

                # Also check for relative imports
                for node_path in graph.nodes:
                    if imp in node_path or node_path.endswith(imp.replace('.', '/')):
                        graph.add_edge(artifact.path, node_path, 'imports')

    def merge_projects(self, project_ids: List[str]) -> DependencyGraph:
        """Merge multiple projects into a single graph"""
        merged = DependencyGraph()

        for pid in project_ids:
            if pid in self.ingested_projects:
                graph = self.ingested_projects[pid]
                for path, artifact in graph.nodes.items():
                    merged.add_node(artifact)
                for edge in graph.edges:
                    merged.edges.append(edge)

        return merged

    def find_pattern(self, pattern: str) -> List[IngestedArtifact]:
        """Find artifacts matching a pattern across all projects"""
        results = []

        for graph in self.ingested_projects.values():
            for artifact in graph.nodes.values():
                if pattern in artifact.content or pattern in artifact.path:
                    results.append(artifact)

        return results

    def get_stats(self) -> Dict:
        """Get ingestion statistics"""
        return {
            'projects': len(self.ingested_projects),
            'artifacts': self.total_artifacts,
            'triples': self.total_triples,
            'languages': defaultdict(int),
            'frameworks': defaultdict(int)
        }

    def to_json(self) -> str:
        """Serialize ingestor state to JSON"""
        return json.dumps({
            'projects': list(self.ingested_projects.keys()),
            'artifacts': self.total_artifacts,
            'triples': self.total_triples,
            'stats': self.get_stats()
        }, indent=2, default=str)


if __name__ == '__main__':
    # Test the ingestor
    ingestor = UniversalIngestor()

    # Ingest the current project
    graph = ingestor.ingest_directory('/mnt/agents/output/synthia_organism', 'synthia')

    print(f"Ingested {len(graph.nodes)} artifacts")
    print(f"Extracted {len(graph.edges)} dependency edges")

    # Show some artifacts
    for path, artifact in list(graph.nodes.items())[:5]:
        print(f"\n{path}")
        print(f"  Language: {artifact.language}")
        print(f"  Type: {artifact.type}")
        print(f"  Triples: {len(artifact.semantic_triples)}")
        print(f"  Imports: {artifact.imports[:3]}")
