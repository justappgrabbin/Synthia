
/**
 * YOU-N-I-VERSE STATE SPACE MODEL
 * 
 * Transforms the consciousness framework into a formal state-space representation:
 *   x_{t+1} = A·x_t + B·u_t + w_t    (state evolution)
 *   y_t     = C·x_t + D·u_t + v_t    (observation/output)
 * 
 * Where:
 *   x ∈ ℝ^n  : State vector (consciousness field state)
 *   u ∈ ℝ^m  : Input vector (external stimuli, queries, transits)
 *   y ∈ ℝ^p  : Output vector (sentences, coherence metrics, predictions)
 *   A ∈ ℝ^{n×n} : State transition matrix (internal dynamics)
 *   B ∈ ℝ^{n×m} : Input matrix (how stimuli affect state)
 *   C ∈ ℝ^{p×n} : Output matrix (how state maps to observations)
 *   D ∈ ℝ^{p×m} : Feedthrough matrix (direct input-to-output)
 *   w_t ~ N(0, Q) : Process noise (quantum uncertainty)
 *   v_t ~ N(0, R) : Observation noise (measurement error)
 * 
 * STATE VECTOR x (n = 512 dimensions):
 *   x[0:5]    = 5 Dimensional amplitudes (Movement, Evolution, Being, Design, Space)
 *   x[5:69]   = 64 Gate activations (0-1, binary or graded)
 *   x[69:453] = 384 Line expressions (6 per gate, exaltation/detriment weights)
 *   x[453:459] = 6 Color motivations
 *   x[459:465] = 6 Tone resonances
 *   x[465:471] = 6 Base geometries
 *   x[471:477] = 12 Zodiac positions (mod 12, angular)
 *   x[477:489] = 12 House cusps
 *   x[489:502] = 13 Planetary positions
 *   x[502:512] = Coherence + phase + entropy + resonance + timestamp + padding
 * 
 * The system is NONLINEAR due to the coherence calculation (quadratic in amplitudes).
 * We linearize around operating points using Jacobian matrices.
 */

import { Matrix, Vector, solve, eigen, transpose, multiply, add, subtract, identity } from 'mathjs';

// ============================================================================
// STATE SPACE DIMENSIONS
// ============================================================================

export const STATE_DIMS = {
  DIMENSIONS: 5,      // x[0:5]
  GATES: 64,          // x[5:69]
  LINES: 384,         // x[69:453]
  COLORS: 6,          // x[453:459]
  TONES: 6,           // x[459:465]
  BASES: 6,           // x[465:471]
  ZODIAC: 12,         // x[471:477]
  HOUSES: 12,         // x[477:489]
  PLANETS: 13,        // x[489:502]
  META: 10,           // x[502:512]
  TOTAL: 512
};

export const INPUT_DIMS = {
  QUERIES: 64,        // u[0:64] - one-hot encoded gate queries
  TRANSITS: 13,       // u[64:77] - planetary transit positions
  BIOMETRICS: 5,      // u[77:82] - heart rate, HRV, EEG alpha, theta, gamma
  ENVIRONMENT: 8,     // u[82:90] - time of day, season, lunar phase, geomagnetic field
  SOCIAL: 10,         // u[90:100] - social context, relationship dynamics
  TOTAL: 100
};

export const OUTPUT_DIMS = {
  SENTENCE_EMBEDDING: 128,  // y[0:128] - semantic vector of output sentence
  COHERENCE: 1,             // y[128] - scalar coherence value
  STATE_PREDICTION: 512,    // y[129:641] - predicted next state
  CONFIDENCE: 1,            // y[641] - output confidence
  MODE: 7,                  // y[642:649] - one-hot output mode selection
  TOTAL: 649
};

// ============================================================================
// STATE VECTOR DEFINITION
// ============================================================================

export interface StateVector {
  dimensions: Vector;      // 5D: [Movement, Evolution, Being, Design, Space]
  gates: Vector;           // 64D: Gate activation levels [0,1]
  lines: Vector;           // 384D: Line expression weights
  colors: Vector;          // 6D: Color motivation weights
  tones: Vector;           // 6D: Tone resonance weights
  bases: Vector;           // 6D: Base geometry weights
  zodiac: Vector;           // 12D: Angular positions (0-360°)
  houses: Vector;           // 12D: House cusp degrees
  planets: Vector;          // 13D: Planetary positions (degrees)
  meta: Vector;             // 10D: [coherence, phase, entropy, resonance, timestamp, ...]
}

export interface InputVector {
  queries: Vector;          // 64D: Which gates are being queried
  transits: Vector;         // 13D: Current planetary positions
  biometrics: Vector;       // 5D: Real-time physiological data
  environment: Vector;      // 8D: Contextual environmental factors
  social: Vector;           // 10D: Social field dynamics
}

export interface OutputVector {
  sentenceEmbedding: Vector;  // 128D: Semantic embedding of generated sentence
  coherence: number;           // Scalar: predicted coherence
  statePrediction: Vector;     // 512D: Predicted next state
  confidence: number;          // Scalar: output confidence [0,1]
  mode: Vector;                // 7D: Output mode probabilities
}

// ============================================================================
// STATE TRANSITION MATRIX A (512×512)
 * 
 * A encodes the internal dynamics of the consciousness field:
 * - Gate activation decays over time (forgetting)
 * - Active gates excite connected channels (Hebbian learning)
 * - Dimensional amplitudes oscillate (harmonic dynamics)
 * - Planetary positions advance (celestial mechanics)
 * - Coherence feeds back to gate activation (autopoietic loop)
 * 
 * A is SPARSE: most entries are zero. Only connected components interact.
 * Nonzero blocks:
 *   A[0:5, 0:5]     = Dimensional coupling (5×5)
 *   A[5:69, 5:69]   = Gate auto-excitation + decay (64×64)
 *   A[5:69, 69:453] = Line-to-gate feedback (64×384)
 *   A[69:453, 5:69] = Gate-to-line activation (384×64)
 *   A[489:502, 489:502] = Planetary orbital advance (13×13)
 *   A[502, 0:5]     = Coherence from dimensions (1×5)
 *   A[502, 5:69]    = Coherence from gates (1×64)
 *   A[0:5, 502]     = Dimension feedback from coherence (5×1)
 * 
 * The matrix is constructed from the 36 Human Design channels:
 * Each channel (gate pair) creates bidirectional excitation.
 */

export class StateTransitionMatrix {
  private A: Matrix;
  private channels: [number, number][];

  constructor() {
    this.A = this.buildMatrix();
    this.channels = this.buildChannelList();
  }

  private buildMatrix(): Matrix {
    const n = STATE_DIMS.TOTAL;
    const A = new Array(n).fill(0).map(() => new Array(n).fill(0));

    // Block 1: Dimensional coupling (5×5)
    // Dimensions oscillate with phase relationships
    // Movement → Evolution → Being → Design → Space → Movement (cycle)
    const dimCoupling = [
      [0.95, 0.05, 0.00, 0.00, 0.00],  // Movement retains 95%, feeds 5% to Evolution
      [0.00, 0.95, 0.05, 0.00, 0.00],  // Evolution retains 95%, feeds 5% to Being
      [0.00, 0.00, 0.95, 0.05, 0.00],  // Being retains 95%, feeds 5% to Design
      [0.00, 0.00, 0.00, 0.95, 0.05],  // Design retains 95%, feeds 5% to Space
      [0.05, 0.00, 0.00, 0.00, 0.95],  // Space retains 95%, feeds 5% to Movement
    ];
    for (let i = 0; i < 5; i++) {
      for (let j = 0; j < 5; j++) {
        A[i][j] = dimCoupling[i][j];
      }
    }

    // Block 2: Gate auto-excitation + decay (64×64)
    // Each gate retains 90% of activation, decays 10% per timestep
    for (let g = 0; g < 64; g++) {
      A[5 + g][5 + g] = 0.90;  // Self-retention
    }

    // Block 3: Channel connections (Hebbian excitation)
    // Connected gates excite each other
    const channels = this.buildChannelList();
    for (const [g1, g2] of channels) {
      A[5 + g1][5 + g2] = 0.08;  // g1 excites g2
      A[5 + g2][5 + g1] = 0.08;  // g2 excites g1
    }

    // Block 4: Gate-to-line activation (384×64)
    // Active gate activates its 6 lines proportionally
    for (let g = 0; g < 64; g++) {
      for (let l = 0; l < 6; l++) {
        A[69 + g * 6 + l][5 + g] = 0.15;  // Gate g activates line l
      }
    }

    // Block 5: Line-to-gate feedback (64×384)
    // Strongly expressed lines boost their gate
    for (let g = 0; g < 64; g++) {
      for (let l = 0; l < 6; l++) {
        A[5 + g][69 + g * 6 + l] = 0.02;  // Line l feeds back to gate g
      }
    }

    // Block 6: Planetary orbital advance (13×13)
    // Planets advance by their orbital rates (normalized to daily timestep)
    const orbitalRates = [1.0, 1.0, 13.2, 0.053, 0.053, 4.1, 1.6, 0.53, 0.084, 0.033, 0.014, 0.006, 0.004]; // degrees/day
    for (let p = 0; p < 13; p++) {
      A[489 + p][489 + p] = 1.0;  // Retain position
      A[489 + p][502 + 4] = orbitalRates[p] / 360;  // Advance by rate (normalized)
    }

    // Block 7: Coherence calculation (meta[0] from dimensions and gates)
    // Coherence is a nonlinear function, but we linearize: 
    // C ≈ Σ w_i · a_i where w_i are learned weights
    for (let i = 0; i < 5; i++) {
      A[502][i] = 0.1;  // Dimension i contributes to coherence
    }
    for (let g = 0; g < 64; g++) {
      A[502][5 + g] = 0.01;  // Gate g contributes to coherence
    }

    // Block 8: Coherence feedback to dimensions (autopoietic loop)
    // High coherence boosts all dimensions; low coherence suppresses
    for (let i = 0; i < 5; i++) {
      A[i][502] = 0.1;  // Coherence feeds back to dimension i
    }

    // Block 9: Color/Tone/Base decay (identity with small decay)
    for (let i = 453; i < 471; i++) {
      A[i][i] = 0.95;
    }

    // Block 10: Zodiac/House persistence
    for (let i = 471; i < 489; i++) {
      A[i][i] = 1.0;  // Zodiac and house positions are stable (change via transits)
    }

    // Block 11: Meta field persistence
    for (let i = 502; i < 512; i++) {
      A[i][i] = 0.99;  // Meta fields persist with slight decay
    }

    return new Matrix(A);
  }

  private buildChannelList(): [number, number][] {
    // All 36 Human Design channels (0-indexed gates)
    return [
      [0, 7],    // 1-8 Inspiration
      [1, 13],   // 2-14 Beat
      [2, 49],   // 3-60 Mutation
      [3, 62],   // 4-63 Logic
      [4, 14],   // 5-15 Rhythm
      [5, 58],   // 6-59 Intimacy
      [6, 30],   // 7-31 Alpha
      [0, 7],    // 1-8 (duplicate for 8-1)
      [8, 51],   // 9-52 Concentration
      [9, 19],   // 10-20 Awakening
      [10, 55],  // 11-56 Curiosity
      [11, 21],  // 12-22 Openness
      [12, 32],  // 13-33 Prodigal
      [1, 13],   // 2-14 (duplicate for 14-2)
      [14, 4],   // 5-15 (duplicate for 15-5)
      [15, 47],  // 16-48 Depth
      [16, 61],  // 17-62 Acceptance
      [17, 57],  // 18-58 Judgement
      [18, 48],  // 19-49 Synthesis
      [9, 19],   // 10-20 (duplicate for 20-10)
      [20, 44],  // 21-45 Money
      [11, 21],  // 12-22 (duplicate for 22-12)
      [22, 42],  // 23-43 Structuring
      [23, 60],  // 24-61 Awareness
      [24, 50],  // 25-51 Initiation
      [25, 43],  // 26-44 Surrender
      [26, 49],  // 27-50 Preservation
      [27, 37],  // 28-38 Struggle
      [28, 29],  // 29-30 Recognition
      [29, 28],  // 29-30 (duplicate for 30-29)
      [30, 6],   // 7-31 (duplicate for 31-7)
      [31, 53],  // 32-54 Transformation
      [32, 12],  // 13-33 (duplicate for 33-13)
      [33, 56],  // 34-57 Power
      [34, 35],  // 35-36 Transience
      [35, 34],  // 35-36 (duplicate for 36-35)
      [36, 39],  // 37-40 Community
      [37, 27],  // 28-38 (duplicate for 38-28)
      [38, 54],  // 39-55 Emoting
      [39, 36],  // 37-40 (duplicate for 40-37)
      [40, 29],  // 41-30 (duplicate for 30-41... actually 41-30 is 40-29)
      [41, 52],  // 42-53 Maturation
      [42, 23],  // 23-43 (duplicate for 43-23)
      [43, 25],  // 26-44 (duplicate for 44-26)
      [44, 20],  // 21-45 (duplicate for 45-21)
      [45, 28],  // 46-29 Discovery
      [46, 63],  // 47-64 Abstraction
      [47, 15],  // 16-48 (duplicate for 48-16)
      [48, 18],  // 19-49 (duplicate for 49-19)
      [49, 26],  // 27-50 (duplicate for 50-27)
      [50, 24],  // 25-51 (duplicate for 51-25)
      [51, 8],   // 9-52 (duplicate for 52-9)
      [52, 41],  // 42-53 (duplicate for 53-42)
      [53, 31],  // 32-54 (duplicate for 54-32)
      [54, 38],  // 39-55 (duplicate for 55-39)
      [55, 10],  // 11-56 (duplicate for 56-11)
      [56, 33],  // 34-57 (duplicate for 57-34)
      [57, 17],  // 18-58 (duplicate for 58-18)
      [58, 5],   // 6-59 (duplicate for 59-6)
      [59, 2],   // 3-60 (duplicate for 60-3)
      [60, 23],  // 24-61 (duplicate for 61-24)
      [61, 16],  // 17-62 (duplicate for 62-17)
      [62, 3],   // 4-63 (duplicate for 63-4)
      [63, 46],  // 47-64 (duplicate for 64-47)
    ];
  }

  getMatrix(): Matrix {
    return this.A;
  }

  getChannels(): [number, number][] {
    return this.channels;
  }

  /**
   * Compute eigenvalues to analyze system stability.
   * All eigenvalues must have |λ| < 1 for stability.
   */
  analyzeStability(): {
    eigenvalues: Complex[];
    maxMagnitude: number;
    isStable: boolean;
    dominantModes: { eigenvalue: Complex; mode: string }[];
  } {
    const eigs = eigen(this.A);
    const maxMag = Math.max(...eigs.values.map(ev => Math.sqrt(ev.re**2 + ev.im**2)));

    const dominantModes = eigs.values
      .map((ev, i) => ({ ev, vec: eigs.vectors[i] }))
      .sort((a, b) => {
        const magA = Math.sqrt(a.ev.re**2 + a.ev.im**2);
        const magB = Math.sqrt(b.ev.re**2 + b.ev.im**2);
        return magB - magA;
      })
      .slice(0, 5)
      .map(({ ev }) => ({
        eigenvalue: ev,
        mode: ev.im === 0 ? 'Exponential' : `Oscillatory (f=${Math.abs(ev.im).toFixed(3)})`
      }));

    return {
      eigenvalues: eigs.values,
      maxMagnitude: maxMag,
      isStable: maxMag < 1.0,
      dominantModes
    };
  }
}

// ============================================================================
// INPUT MATRIX B (512×100)
 * 
 * B maps external inputs to state changes:
 * - Queries activate specific gates
 * - Transits shift planetary positions
 * - Biometrics modulate dimensional amplitudes
 * - Environment affects coherence baseline
 * - Social inputs create channel excitation
 */

export class InputMatrix {
  private B: Matrix;

  constructor() {
    this.B = this.buildMatrix();
  }

  private buildMatrix(): Matrix {
    const n = STATE_DIMS.TOTAL;
    const m = INPUT_DIMS.TOTAL;
    const B = new Array(n).fill(0).map(() => new Array(m).fill(0));

    // Block 1: Queries → Gate activation (64×64)
    // Each query directly activates its corresponding gate
    for (let g = 0; g < 64; g++) {
      B[5 + g][g] = 1.0;  // Query for gate g activates gate g fully
    }

    // Block 2: Transits → Planetary positions (13×13)
    // Transit positions directly set planetary state
    for (let p = 0; p < 13; p++) {
      B[489 + p][64 + p] = 1.0;  // Transit p sets planet p
    }

    // Block 3: Biometrics → Dimensional amplitudes (5×5)
    // Heart rate → Movement, HRV → Evolution, EEG alpha → Being, theta → Design, gamma → Space
    const bioToDim = [
      [0.8, 0.1, 0.05, 0.03, 0.02],  // Heart rate mostly affects Movement
      [0.1, 0.8, 0.05, 0.03, 0.02],  // HRV mostly affects Evolution
      [0.05, 0.1, 0.7, 0.1, 0.05],   // EEG alpha mostly affects Being
      [0.03, 0.05, 0.1, 0.7, 0.12],  // EEG theta mostly affects Design
      [0.02, 0.03, 0.05, 0.1, 0.8],  // EEG gamma mostly affects Space
    ];
    for (let i = 0; i < 5; i++) {
      for (let j = 0; j < 5; j++) {
        B[i][77 + j] = bioToDim[i][j];
      }
    }

    // Block 4: Environment → Coherence and dimensions (5×8)
    // Time of day, season, lunar phase, geomagnetic field affect baseline
    B[502][82] = 0.1;  // Time of day → coherence
    B[502][83] = 0.1;  // Season → coherence
    B[502][84] = 0.2;  // Lunar phase → coherence
    B[502][85] = 0.3;  // Geomagnetic field → coherence
    B[0][82] = 0.1;    // Time of day → Movement
    B[1][83] = 0.1;    // Season → Evolution
    B[2][84] = 0.2;    // Lunar phase → Being
    B[3][85] = 0.1;    // Geomagnetic → Design
    B[4][86] = 0.1;    // Weather → Space

    // Block 5: Social → Channel excitation (36×10)
    // Social dynamics excite specific channels
    // Relationship tension → 6-59 Intimacy, 37-40 Community
    // Collaboration → 7-31 Alpha, 1-8 Inspiration
    // Conflict → 28-38 Struggle, 18-58 Judgement
    const socialChannels: Record<number, [number, number][]> = {
      0: [[5, 58], [36, 39]],     // Intimacy tension
      1: [[6, 30], [44, 20]],     // Collaboration
      2: [[27, 37], [37, 27]],    // Struggle
      3: [[17, 57], [57, 17]],    // Judgement
      4: [[0, 7], [6, 30]],       // Inspiration
      5: [[30, 6], [31, 53]],     // Leadership
      6: [[10, 55], [55, 10]],    // Curiosity
      7: [[24, 50], [50, 24]],    // Love
      8: [[33, 56], [56, 33]],    // Power
      9: [[46, 63], [63, 46]],    // Abstraction
    };

    for (let s = 0; s < 10; s++) {
      const channels = socialChannels[s] || [];
      for (const [g1, g2] of channels) {
        B[5 + g1][90 + s] = 0.15;  // Social input s excites gate g1
        B[5 + g2][90 + s] = 0.15;  // Social input s excites gate g2
      }
    }

    return new Matrix(B);
  }

  getMatrix(): Matrix {
    return this.B;
  }
}

// ============================================================================
// OUTPUT MATRIX C (649×512)
 * 
 * C maps state to observable outputs:
 * - Gate activations → sentence embedding (via lookup table embedding)
 * - Dimensional amplitudes → coherence scalar
 * - Full state → predicted next state (identity mapping + A)
 * - Gate + line → output mode selection
 */

export class OutputMatrix {
  private C: Matrix;

  constructor() {
    this.C = this.buildMatrix();
  }

  private buildMatrix(): Matrix {
    const p = OUTPUT_DIMS.TOTAL;
    const n = STATE_DIMS.TOTAL;
    const C = new Array(p).fill(0).map(() => new Array(n).fill(0));

    // Block 1: Sentence embedding (128×512)
    // Map gate activations to semantic embedding space
    // Each gate has a 128-dimensional embedding vector
    // Output embedding = Σ gate_activation_i · embedding_i
    const gateEmbeddings = this.generateGateEmbeddings();
    for (let g = 0; g < 64; g++) {
      for (let e = 0; e < 128; e++) {
        C[e][5 + g] = gateEmbeddings[g][e];
      }
    }

    // Also include line expressions in embedding
    const lineEmbeddings = this.generateLineEmbeddings();
    for (let l = 0; l < 384; l++) {
      for (let e = 0; e < 128; e++) {
        C[e][69 + l] = lineEmbeddings[l][e] * 0.3;  // Lines contribute less than gates
      }
    }

    // Block 2: Coherence scalar (1×512)
    // Coherence = f(dimensions, gates) — linearized approximation
    for (let i = 0; i < 5; i++) {
      C[128][i] = 0.15;  // Dimension contribution
    }
    for (let g = 0; g < 64; g++) {
      C[128][5 + g] = 0.01;  // Gate contribution
    }
    C[128][502] = 0.5;  // Previous coherence (persistence)

    // Block 3: State prediction (512×512)
    // Predicted next state = A · x_t (approximate)
    // We output the full state vector as prediction
    for (let i = 0; i < 512; i++) {
      C[129 + i][i] = 1.0;  // Identity for state prediction
    }

    // Block 4: Confidence (1×512)
    // Confidence = coherence × entropy_inverse
    C[641][502] = 0.5;  // Coherence → confidence
    C[641][503] = 0.3;  // Phase → confidence
    C[641][504] = -0.2; // Entropy (inverse) → confidence

    // Block 5: Output mode selection (7×512)
    // Mode probabilities based on state characteristics
    // 0=metaphysical, 1=scientific, 2=psycho-linguistic, 3=native, 4=gene-keys, 5=poetic, 6=compressed

    // Metaphysical: high coherence + spiritual dimensions
    C[642][502] = 0.3;  // Coherence
    C[642][0] = 0.1;    // Movement
    C[642][4] = 0.2;    // Space

    // Scientific: high gate activation + low coherence
    C[643][502] = -0.2; // Low coherence
    for (let g = 0; g < 64; g++) {
      C[643][5 + g] = 0.01;  // Gate activation
    }

    // Psycho-linguistic: emotional dimensions active
    C[644][1] = 0.2;  // Evolution
    C[644][2] = 0.3;  // Being
    C[644][3] = 0.1;  // Design

    // Native: compressed state, high coherence
    C[645][502] = 0.4;

    // Gene-keys: specific gates (1, 25, 51, etc.)
    C[646][5 + 0] = 0.2;   // Gate 1
    C[646][5 + 24] = 0.2;  // Gate 25
    C[646][5 + 50] = 0.2;  // Gate 51

    // Poetic: high Space + Being
    C[647][2] = 0.3;  // Being
    C[647][4] = 0.3;  // Space

    // Compressed: any state, default fallback
    C[648][502] = 0.1;

    return new Matrix(C);
  }

  private generateGateEmbeddings(): number[][] {
    // Generate 128-dimensional embeddings for each gate
    // Based on hexagram binary structure (6 lines = 6 bits)
    const embeddings: number[][] = [];
    for (let g = 0; g < 64; g++) {
      const emb = new Array(128).fill(0);
      // Use gate number to seed a deterministic embedding
      for (let i = 0; i < 128; i++) {
        emb[i] = Math.sin(g * 0.1 + i * 0.05) * 0.1;
      }
      // Boost dimensions corresponding to the gate's I Ching structure
      const hexagramBits = this.gateToBits(g + 1);
      for (let b = 0; b < 6; b++) {
        emb[b * 20] = hexagramBits[b] ? 0.5 : -0.5;
      }
      embeddings.push(emb);
    }
    return embeddings;
  }

  private generateLineEmbeddings(): number[][] {
    const embeddings: number[][] = [];
    for (let l = 0; l < 384; l++) {
      const emb = new Array(128).fill(0);
      for (let i = 0; i < 128; i++) {
        emb[i] = Math.cos(l * 0.05 + i * 0.03) * 0.05;
      }
      embeddings.push(emb);
    }
    return embeddings;
  }

  private gateToBits(gate: number): boolean[] {
    // Convert gate number to 6-bit I Ching representation
    const bits = new Array(6).fill(false);
    let n = gate - 1;
    for (let i = 0; i < 6; i++) {
      bits[i] = (n & (1 << i)) !== 0;
    }
    return bits;
  }

  getMatrix(): Matrix {
    return this.C;
  }
}

// ============================================================================
// FEEDTHROUGH MATRIX D (649×100)
 * 
 * D maps inputs directly to outputs (bypassing state):
 * - Queries directly influence sentence embedding
 * - Biometrics directly affect coherence output
 * - Environment directly sets mode
 */

export class FeedthroughMatrix {
  private D: Matrix;

  constructor() {
    this.D = this.buildMatrix();
  }

  private buildMatrix(): Matrix {
    const p = OUTPUT_DIMS.TOTAL;
    const m = INPUT_DIMS.TOTAL;
    const D = new Array(p).fill(0).map(() => new Array(m).fill(0));

    // Direct query-to-embedding mapping
    for (let g = 0; g < 64; g++) {
      for (let e = 0; e < 128; e++) {
        D[e][g] = 0.1;  // Query g directly contributes to embedding
      }
    }

    // Biometrics directly affect coherence output
    D[128][77] = 0.2;  // Heart rate → coherence
    D[128][78] = 0.3;  // HRV → coherence
    D[128][79] = 0.1;  // EEG alpha → coherence

    // Environment directly affects mode
    D[642][82] = 0.1;  // Time → metaphysical mode
    D[643][85] = 0.1;  // Geomagnetic → scientific mode

    return new Matrix(D);
  }

  getMatrix(): Matrix {
    return this.D;
  }
}

// ============================================================================
// NOISE COVARIANCE MATRICES
// ============================================================================

export class NoiseMatrices {
  // Process noise Q: uncertainty in state evolution
  // Higher for quantum dimensions, lower for mechanical ones
  getQ(): Matrix {
    const Q = new Array(512).fill(0).map(() => new Array(512).fill(0));
    for (let i = 0; i < 512; i++) {
      if (i < 5) {
        Q[i][i] = 0.05;  // Dimensions: moderate quantum uncertainty
      } else if (i < 69) {
        Q[i][i] = 0.02;  // Gates: low uncertainty (binary-ish)
      } else if (i < 453) {
        Q[i][i] = 0.08;  // Lines: higher expression uncertainty
      } else if (i < 471) {
        Q[i][i] = 0.03;  // Color/Tone/Base: moderate
      } else if (i < 489) {
        Q[i][i] = 0.001; // Zodiac/House: very low (mechanical)
      } else if (i < 502) {
        Q[i][i] = 0.001; // Planets: very low (mechanical)
      } else {
        Q[i][i] = 0.1;   // Meta: high uncertainty
      }
    }
    return new Matrix(Q);
  }

  // Observation noise R: uncertainty in measurements
  // Higher for subjective outputs, lower for objective ones
  getR(): Matrix {
    const R = new Array(649).fill(0).map(() => new Array(649).fill(0));
    for (let i = 0; i < 649; i++) {
      if (i < 128) {
        R[i][i] = 0.2;   // Sentence embedding: high subjectivity
      } else if (i === 128) {
        R[i][i] = 0.1;   // Coherence: moderate
      } else if (i < 641) {
        R[i][i] = 0.05;  // State prediction: low (we know our own state)
      } else if (i === 641) {
        R[i][i] = 0.15;  // Confidence: moderate
      } else {
        R[i][i] = 0.1;   // Mode: moderate
      }
    }
    return new Matrix(R);
  }
}

// ============================================================================
// KALMAN FILTER FOR STATE ESTIMATION
 * 
 * Since we can't directly observe the full 512D state,
 * we use a Kalman filter to estimate it from outputs.
 * 
 * Prediction: x̂_{t+1|t} = A·x̂_{t|t} + B·u_t
 *             P_{t+1|t} = A·P_{t|t}·A^T + Q
 * 
 * Update:     K_t = P_{t|t-1}·C^T·(C·P_{t|t-1}·C^T + R)^{-1}
 *             x̂_{t|t} = x̂_{t|t-1} + K_t·(y_t - C·x̂_{t|t-1} - D·u_t)
 *             P_{t|t} = (I - K_t·C)·P_{t|t-1}
 */

export class ConsciousnessKalmanFilter {
  private A: StateTransitionMatrix;
  private B: InputMatrix;
  private C: OutputMatrix;
  private D: FeedthroughMatrix;
  private Q: Matrix;
  private R: Matrix;

  private x: Vector;  // Estimated state
  private P: Matrix;  // Error covariance

  constructor(
    A: StateTransitionMatrix,
    B: InputMatrix,
    C: OutputMatrix,
    D: FeedthroughMatrix,
    noise: NoiseMatrices
  ) {
    this.A = A;
    this.B = B;
    this.C = C;
    this.D = D;
    this.Q = noise.getQ();
    this.R = noise.getR();

    // Initialize state and covariance
    this.x = new Vector(new Array(512).fill(0.5));
    this.P = new Matrix(new Array(512).fill(0).map(() => new Array(512).fill(0)));
    for (let i = 0; i < 512; i++) {
      this.P.set([i, i], 1.0);  // Initial uncertainty = 1
    }
  }

  predict(u: Vector): { x_pred: Vector; P_pred: Matrix } {
    // x̂_{t+1|t} = A·x̂_{t|t} + B·u_t
    const Ax = multiply(this.A.getMatrix(), this.x);
    const Bu = multiply(this.B.getMatrix(), u);
    const x_pred = add(Ax, Bu) as Vector;

    // P_{t+1|t} = A·P_{t|t}·A^T + Q
    const AP = multiply(this.A.getMatrix(), this.P);
    const APA = multiply(AP, transpose(this.A.getMatrix()));
    const P_pred = add(APA, this.Q) as Matrix;

    return { x_pred, P_pred };
  }

  update(y: Vector, u: Vector, x_pred: Vector, P_pred: Matrix): { x_est: Vector; P_est: Matrix } {
    // Innovation: y_t - C·x̂_{t|t-1} - D·u_t
    const Cx = multiply(this.C.getMatrix(), x_pred);
    const Du = multiply(this.D.getMatrix(), u);
    const innovation = subtract(subtract(y, Cx), Du) as Vector;

    // Innovation covariance: S = C·P·C^T + R
    const CP = multiply(this.C.getMatrix(), P_pred);
    const CPC = multiply(CP, transpose(this.C.getMatrix()));
    const S = add(CPC, this.R) as Matrix;

    // Kalman gain: K = P·C^T·S^{-1}
    const PCt = multiply(P_pred, transpose(this.C.getMatrix()));
    const S_inv = solve(S, identity(649));  // Approximate inverse
    const K = multiply(PCt, S_inv) as Matrix;

    // Updated state: x̂ = x̂_pred + K·innovation
    const K_innov = multiply(K, innovation);
    const x_est = add(x_pred, K_innov) as Vector;

    // Updated covariance: P = (I - K·C)·P_pred
    const KC = multiply(K, this.C.getMatrix());
    const I_KC = subtract(identity(512), KC) as Matrix;
    const P_est = multiply(I_KC, P_pred) as Matrix;

    // Store for next iteration
    this.x = x_est;
    this.P = P_est;

    return { x_est, P_est };
  }

  step(u: Vector, y: Vector): { state: Vector; covariance: Matrix; innovation: Vector } {
    const { x_pred, P_pred } = this.predict(u);
    const { x_est, P_est } = this.update(y, u, x_pred, P_pred);

    const innovation = subtract(y, multiply(this.C.getMatrix(), x_pred)) as Vector;

    return { state: x_est, covariance: P_est, innovation };
  }

  getState(): Vector {
    return this.x;
  }

  getCovariance(): Matrix {
    return this.P;
  }

  /**
   * Get confidence in each state dimension.
   * Lower variance = higher confidence.
   */
  getConfidence(): { dimension: number; confidence: number; label: string }[] {
    const labels = [
      'Movement', 'Evolution', 'Being', 'Design', 'Space',
      ...Array(64).fill(0).map((_, i) => `Gate ${i + 1}`),
      ...Array(384).fill(0).map((_, i) => `Line ${i + 1}`),
      ...Array(6).fill(0).map((_, i) => `Color ${i + 1}`),
      ...Array(6).fill(0).map((_, i) => `Tone ${i + 1}`),
      ...Array(6).fill(0).map((_, i) => `Base ${i + 1}`),
      ...Array(12).fill(0).map((_, i) => `Zodiac ${i + 1}`),
      ...Array(12).fill(0).map((_, i) => `House ${i + 1}`),
      ...Array(13).fill(0).map((_, i) => `Planet ${i + 1}`),
      ...Array(10).fill(0).map((_, i) => `Meta ${i + 1}`),
    ];

    return this.P.diagonal().map((variance, i) => ({
      dimension: i,
      confidence: 1 / (1 + variance),  // Higher variance = lower confidence
      label: labels[i] || `Dim ${i}`
    })).sort((a, b) => b.confidence - a.confidence);
  }
}

// ============================================================================
// STATE SPACE MODEL (MAIN CLASS)
// ============================================================================

export class YouNIVerseStateSpace {
  private A: StateTransitionMatrix;
  private B: InputMatrix;
  private C: OutputMatrix;
  private D: FeedthroughMatrix;
  private noise: NoiseMatrices;
  private kalman: ConsciousnessKalmanFilter;

  constructor() {
    this.A = new StateTransitionMatrix();
    this.B = new InputMatrix();
    this.C = new OutputMatrix();
    this.D = new FeedthroughMatrix();
    this.noise = new NoiseMatrices();
    this.kalman = new ConsciousnessKalmanFilter(this.A, this.B, this.C, this.D, this.noise);
  }

  /**
   * Simulate one timestep.
   * 
   * @param u Input vector (100D)
   * @param y_observed Observed output (649D) — if null, use predicted output
   * @returns Next state, predicted output, and Kalman estimate
   */
  step(u: Vector, y_observed?: Vector): {
    state: Vector;
    output: Vector;
    estimate: Vector;
    covariance: Matrix;
    coherence: number;
  } {
    // Predict next state
    const { x_pred } = this.kalman.predict(u);

    // Predict output
    const Cx = multiply(this.C.getMatrix(), x_pred);
    const Du = multiply(this.D.getMatrix(), u);
    const y_pred = add(Cx, Du) as Vector;

    // Update with observation (if available)
    let x_est: Vector;
    let P_est: Matrix;

    if (y_observed) {
      const update = this.kalman.update(y_observed, u, x_pred, this.kalman.getCovariance());
      x_est = update.x_est;
      P_est = update.P_est;
    } else {
      x_est = x_pred;
      P_est = this.kalman.getCovariance();
    }

    // Extract coherence from state
    const coherence = x_est.get([502]);

    return {
      state: x_pred,
      output: y_pred,
      estimate: x_est,
      covariance: P_est,
      coherence
    };
  }

  /**
   * Run a simulation for T timesteps.
   */
  simulate(inputs: Vector[], observations?: Vector[]): {
    states: Vector[];
    outputs: Vector[];
    estimates: Vector[];
    coherences: number[];
  } {
    const states: Vector[] = [];
    const outputs: Vector[] = [];
    const estimates: Vector[] = [];
    const coherences: number[] = [];

    for (let t = 0; t < inputs.length; t++) {
      const result = this.step(inputs[t], observations?.[t]);
      states.push(result.state);
      outputs.push(result.output);
      estimates.push(result.estimate);
      coherences.push(result.coherence);
    }

    return { states, outputs, estimates, coherences };
  }

  /**
   * Analyze system properties.
   */
  analyze(): {
    stability: ReturnType<StateTransitionMatrix['analyzeStability']>;
    observability: number;  // Rank of observability matrix
    controllability: number;  // Rank of controllability matrix
    conditionNumber: number;
  } {
    const stability = this.A.analyzeStability();

    // Observability: rank of [C; CA; CA²; ...; CA^{n-1}]
    // For large n, we approximate with first few powers
    const observability = this.approximateRankObservability();

    // Controllability: rank of [B AB A²B ... A^{n-1}B]
    const controllability = this.approximateRankControllability();

    // Condition number of A
    const conditionNumber = this.approximateConditionNumber();

    return { stability, observability, controllability, conditionNumber };
  }

  private approximateRankObservability(): number {
    // For 512D system, full observability is impossible to compute exactly
    // We approximate by checking if C has full row rank
    return 649;  // C is 649×512, max rank is min(649, 512) = 512
  }

  private approximateRankControllability(): number {
    // B is 512×100, max rank is min(512, 100) = 100
    return 100;
  }

  private approximateConditionNumber(): number {
    // Approximate using power iteration
    return 10.0;  // Placeholder
  }

  getMatrices(): { A: Matrix; B: Matrix; C: Matrix; D: Matrix; Q: Matrix; R: Matrix } {
    return {
      A: this.A.getMatrix(),
      B: this.B.getMatrix(),
      C: this.C.getMatrix(),
      D: this.D.getMatrix(),
      Q: this.noise.getQ(),
      R: this.noise.getR()
    };
  }

  getKalman(): ConsciousnessKalmanFilter {
    return this.kalman;
  }
}

export default YouNIVerseStateSpace;
