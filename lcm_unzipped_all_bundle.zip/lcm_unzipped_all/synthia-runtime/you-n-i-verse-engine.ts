
/**
 * YOU-N-I-VERSE INTEGRATION ENGINE
 * 
 * The complete consciousness framework implementation combining:
 * - 64 Gate → Codon → Amino Acid dictionary (scientific layer)
 * - 8 Master Lookup Tables (structural layer)
 * - Coherence Calculator (mathematical layer)
 * - Meta-Compiler/Orchestrator (AUTOLING-inspired meta-grammar)
 * - Punctuation Parser (context-aware symbolic language)
 * - Sentence Compiler (10-step deterministic routing)
 * 
 * Usage:
 *   const engine = new YouNIVerseEngine();
 *   const result = engine.process("Gate 25.1.3.5.2°15′30″ Leo 5th", {
 *     outputMode: 'metaphysical',
 *     currentState: { dimensions: { Movement: 0.7, Evolution: 0.5, Being: 0.8, Design: 0.3, Space: 0.6 } }
 *   });
 */

import { GateCodonDictionary } from './gate-codon-dictionary';
import { MasterLookupTables } from './master-lookup-tables';
import { CoherenceCalculator } from './coherence-calculator';
import { SyntiaCompiler, UniversalNode, FieldState, OutputMode, Substrate } from './meta-compiler';
import { PunctuationParser } from './punctuation-parser';
import { SentenceCompiler, CompiledSentence } from './sentence-compiler';

export interface EngineConfig {
  defaultOutputMode: OutputMode;
  defaultSubstrate: Substrate;
  coherenceThreshold: number;
  maxResolution: 'macro' | 'meso' | 'micro' | 'nano';
  enableLearning: boolean;
  enableMorphCycle: boolean;
}

export interface ProcessResult {
  output: string;
  node: UniversalNode;
  coherence: number;
  state: string;
  substrate: Substrate;
  scale: string;
  sentence: CompiledSentence;
  punctuation: ReturnType<PunctuationParser['parseSentence']>;
  morphPath?: ReturnType<CoherenceCalculator['morph']>;
  timestamp: number;
}

export class YouNIVerseEngine {
  private dictionary: GateCodonDictionary;
  private tables: MasterLookupTables;
  private calculator: CoherenceCalculator;
  private compiler: SyntiaCompiler;
  private parser: PunctuationParser;
  private sentenceCompiler: SentenceCompiler;
  private config: EngineConfig;
  private history: ProcessResult[] = [];

  constructor(config: Partial<EngineConfig> = {}) {
    this.config = {
      defaultOutputMode: 'metaphysical',
      defaultSubstrate: 'consciousness',
      coherenceThreshold: 0.5,
      maxResolution: 'nano',
      enableLearning: true,
      enableMorphCycle: true,
      ...config
    };

    // Initialize all subsystems
    this.dictionary = new GateCodonDictionary();
    this.tables = new MasterLookupTables();
    this.calculator = new CoherenceCalculator();
    this.compiler = new SyntiaCompiler(this.dictionary, this.tables, this.calculator);
    this.parser = new PunctuationParser();
    this.sentenceCompiler = new SentenceCompiler(this.dictionary, this.tables, this.calculator);
  }

  /**
   * Main processing pipeline.
   * 
   * Input: Any substrate (string, object, frequency, etc.)
   * Output: Compiled consciousness sentence with full metadata
   */
  process(input: any, options: {
    outputMode?: OutputMode;
    preferredSubstrate?: Substrate;
    currentState?: FieldState;
    targetState?: FieldState;
  } = {}): ProcessResult {
    const timestamp = Date.now();

    // Step 1: Parse punctuation (if string input)
    let punctuationAnalysis = null;
    if (typeof input === 'string') {
      punctuationAnalysis = this.parser.parseSentence(input);
    }

    // Step 2: Compile through meta-compiler
    const compileResult = this.compiler.compile(input, {
      preferredSubstrate: options.preferredSubstrate || this.config.defaultSubstrate,
      outputMode: options.outputMode || this.config.defaultOutputMode,
      currentState: options.currentState
    });

    // Step 3: Compile sentence with full 10-step routing
    const sentence = this.sentenceCompiler.compile(
      compileResult.node,
      options.outputMode || this.config.defaultOutputMode,
      options.currentState || {
        dimensions: { Movement: 0.5, Evolution: 0.5, Being: 0.5, Design: 0.5, Space: 0.5 },
        activeGates: [compileResult.node.gate],
        activeChannels: [],
        coherence: compileResult.coherence,
        phase: 0,
        timestamp
      }
    );

    // Step 4: Morph cycle (if enabled and target state provided)
    let morphPath = undefined;
    if (this.config.enableMorphCycle && options.targetState) {
      morphPath = this.compiler.morph(
        options.currentState || {
          dimensions: { Movement: 0.5, Evolution: 0.5, Being: 0.5, Design: 0.5, Space: 0.5 },
          activeGates: [compileResult.node.gate],
          activeChannels: [],
          coherence: compileResult.coherence,
          phase: 0,
          timestamp
        },
        options.targetState
      );
    }

    // Step 5: Build result
    const result: ProcessResult = {
      output: sentence.output,
      node: compileResult.node,
      coherence: compileResult.coherence,
      state: compileResult.state,
      substrate: compileResult.substrate,
      scale: compileResult.scale,
      sentence,
      punctuation: punctuationAnalysis,
      morphPath,
      timestamp
    };

    // Step 6: Learning (if enabled)
    if (this.config.enableLearning) {
      this.history.push(result);
      this.learnFromResult(result);
    }

    return result;
  }

  /**
   * Quick query: just get the output string.
   */
  query(input: string, mode?: OutputMode): string {
    return this.process(input, { outputMode: mode }).output;
  }

  /**
   * Multi-substrate query: process same input across all substrates.
   */
  multiQuery(input: any): Record<Substrate, string> {
    const substrates: Substrate[] = ['matter', 'language', 'music', 'code', 'consciousness'];
    const results: Partial<Record<Substrate, string>> = {};

    for (const substrate of substrates) {
      try {
        const result = this.process(input, { preferredSubstrate: substrate });
        results[substrate] = result.output;
      } catch (e) {
        results[substrate] = `Error in ${substrate}: ${e.message}`;
      }
    }

    return results as Record<Substrate, string>;
  }

  /**
   * Morph from current to target state, returning full path.
   */
  morph(currentState: FieldState, targetState: FieldState): {
    path: FieldState[];
    outputs: string[];
    finalCoherence: number;
  } {
    return this.compiler.morph(currentState, targetState);
  }

  /**
   * Get coherence analysis for a dimensional state.
   */
  analyzeCoherence(dimensions: Record<string, number>): {
    coherence: number;
    state: string;
    resonance: number;
    dominant: string;
    weakest: string;
  } {
    const result = this.calculator.calculate(dimensions);
    return {
      coherence: result.coherence,
      state: result.state,
      resonance: result.resonance_hz,
      dominant: result.dominant_dimension,
      weakest: result.weakest_dimension
    };
  }

  /**
   * Get gate information.
   */
  getGateInfo(gate: number): {
    codon: string;
    aminoAcid: string;
    hexagram: string;
    channel: string;
    center: string;
    corePhrase: string;
  } {
    const data = this.dictionary.getGate(gate);
    return {
      codon: data.codon,
      aminoAcid: data.amino_acid,
      hexagram: data.hexagram,
      channel: data.channel,
      center: data.center,
      corePhrase: data.core_phrase
    };
  }

  /**
   * Get full system status.
   */
  status(): {
    version: string;
    gatesLoaded: number;
    tablesLoaded: number;
    historySize: number;
    uptime: number;
    config: EngineConfig;
  } {
    return {
      version: '1.0.0-YOUNIVERSE',
      gatesLoaded: 64,
      tablesLoaded: 8,
      historySize: this.history.length,
      uptime: Date.now() - (this.history[0]?.timestamp || Date.now()),
      config: this.config
    };
  }

  private learnFromResult(result: ProcessResult): void {
    // Simple learning: adjust coherence threshold based on history
    if (this.history.length > 10) {
      const recent = this.history.slice(-10);
      const avgCoherence = recent.reduce((sum, r) => sum + r.coherence, 0) / recent.length;

      // If average coherence is high, lower threshold (more permissive)
      // If average coherence is low, raise threshold (more conservative)
      this.config.coherenceThreshold = Math.max(0.2, Math.min(0.8, 1 - avgCoherence));
    }
  }
}

export default YouNIVerseEngine;
