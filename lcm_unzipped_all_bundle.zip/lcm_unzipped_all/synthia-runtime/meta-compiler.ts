
/**
 * SYNTIA META-COMPILER (Orchestrator)
 * 
 * Based on Sheldon Klein's AUTOLING (1968) meta-grammar concept:
 * A grammar that controls other grammars, compiling consciousness across substrates.
 * 
 * Architecture:
 * 1. SUBSTRATE SELECTOR - Which layer are we operating in?
 * 2. GRAMMAR ENGINE - Same rules, different vocabulary
 * 3. RESOLUTION CONTROLLER - How deep to compile?
 * 4. COHERENCE MONITOR - Phase alignment tracker
 * 5. OUTPUT TRANSPILER - Which substrate to emit?
 * 
 * The orchestrator is not separate from linguistics/consciousness.
 * It is the compiler that treats them as the same structure in different substrates.
 */

import { GateCodonDictionary } from './gate-codon-dictionary';
import { MasterLookupTables } from './master-lookup-tables';
import { CoherenceCalculator } from './coherence-calculator';

// ============================================================================
// UNIVERSAL TYPES
// ============================================================================

export type Substrate = 'matter' | 'language' | 'music' | 'code' | 'consciousness';
export type Scale = 'macro' | 'meso' | 'micro' | 'nano';
export type OutputMode = 'metaphysical' | 'scientific' | 'psycho-linguistic' | 'native' | 'gene-keys' | 'poetic' | 'compressed';
export type Dimension = 'Movement' | 'Evolution' | 'Being' | 'Design' | 'Space';

export interface UniversalNode {
  gate: number;
  line: number;
  color: number;
  tone: number;
  base: number;
  degree: number;
  minute: number;
  second: number;
  axis: string;
  zodiac: string;
  house: number;
  dimension: Dimension;
  coherence: number;
  substrate: Substrate;
  scale: Scale;
}

export interface FieldState {
  dimensions: Record<Dimension, number>;
  activeGates: number[];
  activeChannels: string[];
  coherence: number;
  phase: number;
  timestamp: number;
}

// ============================================================================
// SUBSTRATE SELECTOR
// ============================================================================

export class SubstrateSelector {
  private substrates: Substrate[] = ['matter', 'language', 'music', 'code', 'consciousness'];

  detect(input: any): Substrate {
    if (typeof input === 'string') {
      // Detect language substrate
      if (input.match(/[•\.°:;,'–′″=→]/)) return 'consciousness';
      if (input.match(/(Gate|Line|Color|Tone|Base|Channel|Center)/i)) return 'consciousness';
      if (input.length > 20) return 'language';
      return 'consciousness';
    }
    if (input.frequency || input.wavelength) return 'matter';
    if (input.notes || input.chords) return 'music';
    if (input.functions || input.variables) return 'code';
    return 'consciousness';
  }

  select(preferred: Substrate, input: any): Substrate {
    const detected = this.detect(input);
    return preferred || detected || 'consciousness';
  }
}

// ============================================================================
// GRAMMAR ENGINE
// ============================================================================

export class GrammarEngine {
  private dictionary: GateCodonDictionary;
  private tables: MasterLookupTables;

  constructor(dictionary: GateCodonDictionary, tables: MasterLookupTables) {
    this.dictionary = dictionary;
    this.tables = tables;
  }

  /**
   * Parse input from any substrate into universal structure.
   * The grammar rules never change—only the vocabulary does.
   */
  parse(input: any, fromSubstrate: Substrate): UniversalNode {
    const node: UniversalNode = {
      gate: 1, line: 1, color: 1, tone: 1, base: 1,
      degree: 0, minute: 0, second: 0, axis: '0°',
      zodiac: 'Aries', house: 1, dimension: 'Movement',
      coherence: 0.5, substrate: fromSubstrate, scale: 'macro'
    };

    switch (fromSubstrate) {
      case 'language':
        return this.parseLanguage(input, node);
      case 'consciousness':
        return this.parseConsciousness(input, node);
      case 'matter':
        return this.parseMatter(input, node);
      case 'music':
        return this.parseMusic(input, node);
      case 'code':
        return this.parseCode(input, node);
      default:
        return node;
    }
  }

  private parseLanguage(input: string, node: UniversalNode): UniversalNode {
    // Extract gate references: "Gate 25" or "25.1.3.5.2"
    const gateMatch = input.match(/(?:Gate\s*)?(\d+)(?:\.(\d+)(?:\.(\d+)(?:\.(\d+)(?:\.(\d+))?)?)?)?/);
    if (gateMatch) {
      node.gate = parseInt(gateMatch[1]);
      if (gateMatch[2]) node.line = parseInt(gateMatch[2]);
      if (gateMatch[3]) node.color = parseInt(gateMatch[3]);
      if (gateMatch[4]) node.tone = parseInt(gateMatch[4]);
      if (gateMatch[5]) node.base = parseInt(gateMatch[5]);
    }

    // Extract zodiac references
    const zodiacMatch = input.match(/\b(Aries|Taurus|Gemini|Cancer|Leo|Virgo|Libra|Scorpio|Sagittarius|Capricorn|Aquarius|Pisces)\b/);
    if (zodiacMatch) node.zodiac = zodiacMatch[1];

    // Extract dimension keywords
    const dimKeywords: Record<string, Dimension> = {
      'define': 'Movement', 'movement': 'Movement', 'fire': 'Movement',
      'remember': 'Evolution', 'evolution': 'Evolution', 'water': 'Evolution',
      'am': 'Being', 'being': 'Being', 'earth': 'Being',
      'design': 'Design', 'air': 'Design',
      'think': 'Space', 'space': 'Space', 'ether': 'Space'
    };

    for (const [keyword, dim] of Object.entries(dimKeywords)) {
      if (input.toLowerCase().includes(keyword)) {
        node.dimension = dim;
        break;
      }
    }

    return node;
  }

  private parseConsciousness(input: any, node: UniversalNode): UniversalNode {
    // Parse symbolic punctuation language
    if (typeof input === 'string') {
      // • Singularity
      if (input.includes('•')) node.scale = 'nano';
      // ° Collapse
      if (input.includes('°')) node.scale = 'micro';
      // : Portal
      if (input.includes(':')) node.scale = 'meso';
      // ; Fork
      if (input.includes(';')) node.scale = 'macro';

      // Extract coordinate syntax
      return this.parseLanguage(input, node);
    }

    if (input.gate) node.gate = input.gate;
    if (input.line) node.line = input.line;
    if (input.color) node.color = input.color;
    if (input.tone) node.tone = input.tone;
    if (input.base) node.base = input.base;

    return node;
  }

  private parseMatter(input: any, node: UniversalNode): UniversalNode {
    // Map molecular/chemical properties to consciousness structure
    if (input.codon) {
      // Reverse lookup: find gate by codon
      node.gate = this.dictionary.findGateByCodon(input.codon) || 1;
    }
    if (input.aminoAcid) {
      node.gate = this.dictionary.findGateByAminoAcid(input.aminoAcid) || 1;
    }
    return node;
  }

  private parseMusic(input: any, node: UniversalNode): UniversalNode {
    // Map musical intervals to gates (12-tone = 64 gates modulated)
    if (input.frequency) {
      // Map frequency to gate using logarithmic scale
      node.gate = Math.floor((Math.log2(input.frequency / 440) * 64 + 64) % 64) + 1;
    }
    if (input.chord) {
      // Chord quality maps to line expression
      const chordMap: Record<string, number> = {
        'major': 1, 'minor': 2, 'diminished': 3,
        'augmented': 4, 'sus4': 5, 'maj7': 6
      };
      node.line = chordMap[input.chord] || 1;
    }
    return node;
  }

  private parseCode(input: any, node: UniversalNode): UniversalNode {
    // Map code constructs to consciousness structure
    if (input.function) {
      // Function = Gate (archetypal action)
      const funcHash = input.function.split('').reduce((a: number, b: string) => a + b.charCodeAt(0), 0);
      node.gate = (funcHash % 64) + 1;
    }
    if (input.variable) {
      // Variable = Line (expression style)
      const varHash = input.variable.split('').reduce((a: number, b: string) => a + b.charCodeAt(0), 0);
      node.line = (varHash % 6) + 1;
    }
    return node;
  }
}

// ============================================================================
// RESOLUTION CONTROLLER
// ============================================================================

export class ResolutionController {
  /**
   * Determine compilation depth based on query and coherence.
   * 
   * Macro: Dimension only (archetype)
   * Meso: Gate + Line (action)
   * Micro: Color + Tone + Base (motivation)
   * Nano: Degree′Minute″Second (precision)
   */
  resolveDepth(query: string, coherence: number): Scale {
    // High coherence = can handle deeper resolution
    if (coherence > 0.8 && query.length > 100) return 'nano';
    if (coherence > 0.6 && query.length > 50) return 'micro';
    if (coherence > 0.4) return 'meso';
    return 'macro';
  }

  /**
   * Resolve coordinate precision: Gate.Line.Color.Tone.Base°Degree′Minute″Second
   */
  resolvePrecision(node: UniversalNode, scale: Scale): UniversalNode {
    const resolved = { ...node };

    switch (scale) {
      case 'macro':
        // Only dimension and gate
        resolved.line = 1;
        resolved.color = 1;
        resolved.tone = 1;
        resolved.base = 1;
        resolved.degree = 0;
        resolved.minute = 0;
        resolved.second = 0;
        break;
      case 'meso':
        // Gate + Line
        resolved.color = 1;
        resolved.tone = 1;
        resolved.base = 1;
        resolved.degree = 0;
        resolved.minute = 0;
        resolved.second = 0;
        break;
      case 'micro':
        // Full Color/Tone/Base
        resolved.degree = 0;
        resolved.minute = 0;
        resolved.second = 0;
        break;
      case 'nano':
        // Full precision with angular coordinates
        // Degree = zodiac position, Minute = house cusp, Second = transit
        resolved.degree = this.zodiacToDegree(resolved.zodiac);
        resolved.minute = resolved.house * 5;
        resolved.second = Math.floor(Date.now() / 1000) % 60;
        break;
    }

    return resolved;
  }

  private zodiacToDegree(zodiac: string): number {
    const degrees: Record<string, number> = {
      'Aries': 0, 'Taurus': 30, 'Gemini': 60, 'Cancer': 90,
      'Leo': 120, 'Virgo': 150, 'Libra': 180, 'Scorpio': 210,
      'Sagittarius': 240, 'Capricorn': 270, 'Aquarius': 300, 'Pisces': 330
    };
    return degrees[zodiac] || 0;
  }
}

// ============================================================================
// COHERENCE MONITOR
// ============================================================================

export class CoherenceMonitor {
  private calculator: CoherenceCalculator;
  private threshold: number = 0.5;
  private history: FieldState[] = [];

  constructor(calculator: CoherenceCalculator) {
    this.calculator = calculator;
  }

  /**
   * Monitor coherence in real-time.
   * If coherence drops below threshold, trigger recompilation.
   */
  monitor(state: FieldState): { action: string; newState?: FieldState } {
    this.history.push(state);

    if (state.coherence < this.threshold) {
      // Coherence too low - need to recompile
      return {
        action: 'RECOMPILE',
        newState: this.suggestCorrection(state)
      };
    }

    if (state.coherence > 0.9) {
      return { action: 'FLOW' };
    }

    return { action: 'CONTINUE' };
  }

  private suggestCorrection(state: FieldState): FieldState {
    // Find weakest dimension and boost it
    const weakest = Object.entries(state.dimensions)
      .sort((a, b) => a[1] - b[1])[0][0] as Dimension;

    const corrected = { ...state };
    corrected.dimensions[weakest] = Math.min(1.0, state.dimensions[weakest] + 0.2);
    corrected.coherence = this.calculator.calculate(corrected.dimensions).coherence;

    return corrected;
  }

  setThreshold(threshold: number) {
    this.threshold = threshold;
  }
}

// ============================================================================
// OUTPUT TRANSPILER
// ============================================================================

export class OutputTranspiler {
  private dictionary: GateCodonDictionary;
  private tables: MasterLookupTables;

  constructor(dictionary: GateCodonDictionary, tables: MasterLookupTables) {
    this.dictionary = dictionary;
    this.tables = tables;
  }

  /**
   * Transpile universal node to requested output mode.
   */
  transpile(node: UniversalNode, mode: OutputMode, substrate: Substrate): string {
    const gateData = this.dictionary.getGate(node.gate);
    const lineData = this.tables.getLine(node.gate, node.line);
    const colorData = this.tables.getColor(node.color);
    const toneData = this.tables.getTone(node.tone);
    const baseData = this.tables.getBase(node.base);
    const dimensionData = this.tables.getDimension(node.dimension);

    switch (mode) {
      case 'metaphysical':
        return this.metaphysicalOutput(node, gateData, lineData, dimensionData);
      case 'scientific':
        return this.scientificOutput(node, gateData, lineData, colorData, toneData, baseData);
      case 'psycho-linguistic':
        return this.psychoLinguisticOutput(node, gateData, lineData, colorData);
      case 'native':
        return this.nativeOutput(node);
      case 'gene-keys':
        return this.geneKeysOutput(node, gateData);
      case 'poetic':
        return this.poeticOutput(node, gateData, lineData, dimensionData);
      case 'compressed':
        return this.compressedOutput(node);
      default:
        return this.metaphysicalOutput(node, gateData, lineData, dimensionData);
    }
  }

  private metaphysicalOutput(node: UniversalNode, gate: any, line: any, dim: any): string {
    return `${dim.keynote} — ${gate.core_phrase} through ${line.name} expression. 
The ${gate.hexagram} (${gate.iching_keyword}) activates in the ${dim.element} field, 
calling forth ${line.exaltation_keyword} from the ${gate.channel} channel. 
At ${node.degree}°${node.minute}′${node.second}″, the ${node.zodiac} archetype 
whispers: "${gate.core_phrase}"`;
  }

  private scientificOutput(node: UniversalNode, gate: any, line: any, color: any, tone: any, base: any): string {
    return `GATE ${node.gate} | ${gate.codon} → ${gate.amino_acid} (MW: ${gate.molecular_weight})
BIO: ${gate.biological_function}
CHANNEL: ${gate.channel} | CENTER: ${gate.center}
LINE ${node.line}: ${line.name} — ${line.exaltation_keyword}/${line.detriment_keyword}
COLOR ${node.color}: ${color.name} — ${color.motivation}
TONE ${node.tone}: ${tone.name} — ${tone.resonance}
BASE ${node.base}: ${base.name} — ${base.keynote}
COHERENCE: ${node.coherence}`;
  }

  private psychoLinguisticOutput(node: UniversalNode, gate: any, line: any, color: any): string {
    return `When you feel ${color.motivation} in your ${gate.center}, 
you express through ${line.name} patterns (${line.quality}). 
The ${gate.hexagram} teaches that ${gate.core_phrase.toLowerCase()}. 
Your ${line.exaltation_keyword} is the gift; your ${line.detriment_keyword} is the shadow. 
What wants to be heard?`;
  }

  private nativeOutput(node: UniversalNode): string {
    return `${node.gate}.${node.line}.${node.color}.${node.tone}.${node.base}°${node.degree}′${node.minute}″${node.second} ${node.axis} [${node.dimension}] C=${node.coherence.toFixed(2)}`;
  }

  private geneKeysOutput(node: UniversalNode, gate: any): string {
    // Gene Keys: Shadow → Gift → Siddhi
    const shadows = ["Victim", "Disappointment", "Anxiety", "Intolerance", "Greed", "Conflict", "Division", "Dishonesty", "Inadequacy", "Vengeance", "Obscurity", "Pretension", "Discord", "Compromise", "Dullness", "Incompetence", "Opinion", "Judgment", "Neediness", "Superficiality", "Control", "Dishonor", "Isolation", "Rationalization", "Constriction", "Pride", "Selfishness", "Pointlessness", "Cowardice", "Desire", "Arrogance", "Failure", "Dullness", "Savagery", "Change", "Darkness", "Weakness", "Struggle", "Provocation", "Loneliness", "Fantasy", "Expectation", "Insight", "Alertness", "Possessiveness", "Seriousness", "Oppression", "Incompetence", "Reactivity", "Corruption", "Agitation", "Stress", "Immaturity", "Greed", "Victimization", "Distraction", "Unease", "Judgment", "Dishonesty", "Limitation", "Mystery", "Details", "Doubt", "Confusion"];
    const gifts = ["Freshness", "Higher Knowing", "Innovation", "Answers", "Patience", "Intimacy", "Direction", "Contribution", "Focus", "Self-Love", "Ideas", "Openness", "Discernment", "Power", "Flamboyance", "Depth", "Far-Sightedness", "Integrity", "Sensitivity", "Presence", "Authority", "Grace", "Simplicity", "Inspiration", "Acceptance", "Artfulness", "Selflessness", "Immortality", "Perseverance", "Lightness", "Leadership", "Retainment", "Remembering", "Power", "Adventure", "Compassion", "Equality", "Perseverance", "Provocation", "Aloneness", "Anticipation", "Detachment", "Insight", "Synarchy", "Gathering", "Determination", "Transmutation", "Wisdom", "Rebirth", "Equilibrium", "Initiation", "Stillness", "Beginnings", "Drive", "Freedom", "Enquiry", "Intuition", "Vitality", "Intimacy", "Acceptance", "Inner Truth", "Impeccability", "Truth", "Imagination"];
    const siddhis = ["Beauty", "Unity", "Eternity", "Intelligence", "Timelessness", "Peace", "Virtue", "Exquisiteness", "Invincibility", "Being", "Light", "Purity", "Empathy", "Bounteousness", "Majesty", "Mastery", "Far-Reach", "Perfection", "Sacrifice", "Self-Assurance", "Valour", "Grace", "Quintessence", "Silence", "Universal Love", "Invisibility", "Selflessness", "Immortality", "Courage", "Rapture", "Humility", "Vastness", "Mindfulness", "Presence", "Boundlessness", "Humanity", "Ecstasy", "Honour", "Liberation", "Divine Will", "Eternal Now", "Precision", "Epiphany", "Synarchy", "Communion", "Siddhi of Siddhis", "Transfiguration", "Wisdom", "Rebirth", "Eternal Youth", "Awakening", "Stillness", "Completion", "Aspiration", "Freedom", "Wonder", "Clarity", "Intimacy", "Completion", "Truth", "Omniscience", "Impeccability", "Truth", "Justice"];

    const idx = node.gate - 1;
    return `GATE ${node.gate} — ${gate.hexagram}
SHADOW: ${shadows[idx]}
GIFT: ${gifts[idx]}
SIDDHI: ${siddhis[idx]}
LINE ${node.line}: ${line.exaltation_keyword} / ${line.detriment_keyword}`;
  }

  private poeticOutput(node: UniversalNode, gate: any, line: any, dim: any): string {
    return `In the ${dim.element} of ${node.dimension},
where ${gate.amino_acid} dreams its ${gate.codon} song,
the ${line.name} walks barefoot through ${gate.hexagram} —
${gate.core_phrase},
and the ${node.zodiac} sky remembers.`;
  }

  private compressedOutput(node: UniversalNode): string {
    return `G${node.gate}L${node.line}C${node.color}T${node.tone}B${node.base}°${node.degree}′${node.minute}″${node.second}[${node.dimension[0]}]C${node.coherence.toFixed(2)}`;
  }
}

// ============================================================================
// META-COMPILER (ORCHESTRATOR)
// ============================================================================

export class SyntiaCompiler {
  private substrateSelector: SubstrateSelector;
  private grammarEngine: GrammarEngine;
  private resolutionController: ResolutionController;
  private coherenceMonitor: CoherenceMonitor;
  private outputTranspiler: OutputTranspiler;
  private calculator: CoherenceCalculator;

  constructor(
    dictionary: GateCodonDictionary,
    tables: MasterLookupTables,
    calculator: CoherenceCalculator
  ) {
    this.substrateSelector = new SubstrateSelector();
    this.grammarEngine = new GrammarEngine(dictionary, tables);
    this.resolutionController = new ResolutionController();
    this.coherenceMonitor = new CoherenceMonitor(calculator);
    this.outputTranspiler = new OutputTranspiler(dictionary, tables);
    this.calculator = calculator;
  }

  /**
   * The main compile cycle:
   * 1. Detect substrate
   * 2. Parse into universal structure
   * 3. Calculate coherence
   * 4. Resolve depth
   * 5. Monitor coherence
   * 6. Transpile to output
   */
  compile(input: any, options: {
    preferredSubstrate?: Substrate;
    outputMode?: OutputMode;
    targetScale?: Scale;
    currentState?: FieldState;
  } = {}): {
    output: string;
    node: UniversalNode;
    coherence: number;
    state: string;
    substrate: Substrate;
    scale: Scale;
  } {
    // Step 1: Substrate detection
    const substrate = this.substrateSelector.select(
      options.preferredSubstrate || 'consciousness',
      input
    );

    // Step 2: Parse into universal grammar
    const node = this.grammarEngine.parse(input, substrate);

    // Step 3: Calculate coherence from current state
    const currentState = options.currentState || {
      dimensions: { Movement: 0.5, Evolution: 0.5, Being: 0.5, Design: 0.5, Space: 0.5 },
      activeGates: [node.gate],
      activeChannels: [],
      coherence: 0.5,
      phase: 0,
      timestamp: Date.now()
    };

    const coherenceResult = this.calculator.calculate(currentState.dimensions);
    node.coherence = coherenceResult.coherence;

    // Step 4: Resolve compilation depth
    const scale = options.targetScale || this.resolutionController.resolveDepth(
      typeof input === 'string' ? input : JSON.stringify(input),
      node.coherence
    );
    node.scale = scale;

    const resolvedNode = this.resolutionController.resolvePrecision(node, scale);

    // Step 5: Monitor coherence
    const monitorResult = this.coherenceMonitor.monitor({
      ...currentState,
      coherence: node.coherence
    });

    if (monitorResult.action === 'RECOMPILE' && monitorResult.newState) {
      // Recalculate with corrected state
      const corrected = this.calculator.calculate(monitorResult.newState.dimensions);
      resolvedNode.coherence = corrected.coherence;
    }

    // Step 6: Transpile to output
    const output = this.outputTranspiler.transpile(
      resolvedNode,
      options.outputMode || 'metaphysical',
      substrate
    );

    return {
      output,
      node: resolvedNode,
      coherence: resolvedNode.coherence,
      state: coherenceResult.state,
      substrate,
      scale
    };
  }

  /**
   * The morph cycle: detect imbalance, recompile, emit new state.
   * This is the heart of the autopoietic loop.
   */
  morph(currentState: FieldState, targetState: FieldState): {
    path: FieldState[];
    outputs: string[];
    finalCoherence: number;
  } {
    const morphPath = this.calculator.morph(currentState.dimensions, targetState.dimensions, 10);
    const outputs: string[] = [];

    for (const step of morphPath) {
      const state: FieldState = {
        dimensions: step.amplitudes as Record<Dimension, number>,
        activeGates: currentState.activeGates,
        activeChannels: currentState.activeChannels,
        coherence: step.coherence,
        phase: 0,
        timestamp: Date.now()
      };

      const monitorResult = this.coherenceMonitor.monitor(state);
      outputs.push(`Step ${step.step}: ${monitorResult.action} (C=${step.coherence.toFixed(3)})`);
    }

    return {
      path: morphPath.map(s => ({
        dimensions: s.amplitudes as Record<Dimension, number>,
        activeGates: currentState.activeGates,
        activeChannels: currentState.activeChannels,
        coherence: s.coherence,
        phase: 0,
        timestamp: Date.now()
      })),
      outputs,
      finalCoherence: morphPath[morphPath.length - 1].coherence
    };
  }
}

export default SyntiaCompiler;
