
/**
 * SENTENCE COMPILER ALGORITHM
 * 
 * Deterministic routing from input to output through 10 steps:
 * 1. Dimensional Selection → Set keynote
 * 2. Center Lookup → Biology anchor + voice type
 * 3. Gate Archetype → Core verb/action phrase
 * 4. Line Binary → Exaltation/detriment modifier + planet keyword
 * 5. Color/Tone/Base → Motivation + resonance + geometry subtext
 * 6. Astrological Context → Zodiac subject + house context
 * 7. Axis Polarity → Contrast/mirror clause
 * 8. Scale Resolution → Macro/meso/micro expression mode
 * 9. Emergent Closure → Interference calculation
 * 10. Output Composer → Metaphysical / Scientific / Psycho-linguistic / Native
 */

import { GateCodonDictionary } from './gate-codon-dictionary';
import { MasterLookupTables } from './master-lookup-tables';
import { CoherenceCalculator } from './coherence-calculator';
import { UniversalNode, FieldState, OutputMode, Dimension } from './meta-compiler';

export interface CompiledSentence {
  output: string;
  metadata: {
    gate: number;
    line: number;
    color: number;
    tone: number;
    base: number;
    dimension: Dimension;
    center: string;
    channel: string;
    zodiac: string;
    house: number;
    coherence: number;
    scale: string;
    outputMode: OutputMode;
  };
  steps: CompilationStep[];
}

export interface CompilationStep {
  step: number;
  name: string;
  input: any;
  output: any;
  duration: number; // ms
}

export class SentenceCompiler {
  private dictionary: GateCodonDictionary;
  private tables: MasterLookupTables;
  private calculator: CoherenceCalculator;

  constructor(
    dictionary: GateCodonDictionary,
    tables: MasterLookupTables,
    calculator: CoherenceCalculator
  ) {
    this.dictionary = dictionary;
    this.tables = tables;
    this.calculator = calculator;
  }

  /**
   * Main compile method: 10-step deterministic routing.
   */
  compile(node: UniversalNode, mode: OutputMode, state: FieldState): CompiledSentence {
    const steps: CompilationStep[] = [];
    const startTime = Date.now();

    // Step 1: Dimensional Selection
    const step1 = this.step1_DimensionalSelection(node, state);
    steps.push({ step: 1, name: 'Dimensional Selection', input: node.dimension, output: step1, duration: Date.now() - startTime });

    // Step 2: Center Lookup
    const step2 = this.step2_CenterLookup(node);
    steps.push({ step: 2, name: 'Center Lookup', input: node.gate, output: step2, duration: Date.now() - startTime });

    // Step 3: Gate Archetype
    const step3 = this.step3_GateArchetype(node);
    steps.push({ step: 3, name: 'Gate Archetype', input: node.gate, output: step3, duration: Date.now() - startTime });

    // Step 4: Line Binary
    const step4 = this.step4_LineBinary(node);
    steps.push({ step: 4, name: 'Line Binary', input: node.line, output: step4, duration: Date.now() - startTime });

    // Step 5: Color/Tone/Base
    const step5 = this.step5_ColorToneBase(node);
    steps.push({ step: 5, name: 'Color/Tone/Base', input: { c: node.color, t: node.tone, b: node.base }, output: step5, duration: Date.now() - startTime });

    // Step 6: Astrological Context
    const step6 = this.step6_AstrologicalContext(node);
    steps.push({ step: 6, name: 'Astrological Context', input: { zodiac: node.zodiac, house: node.house }, output: step6, duration: Date.now() - startTime });

    // Step 7: Axis Polarity
    const step7 = this.step7_AxisPolarity(node);
    steps.push({ step: 7, name: 'Axis Polarity', input: node.gate, output: step7, duration: Date.now() - startTime });

    // Step 8: Scale Resolution
    const step8 = this.step8_ScaleResolution(node);
    steps.push({ step: 8, name: 'Scale Resolution', input: node.scale, output: step8, duration: Date.now() - startTime });

    // Step 9: Emergent Closure
    const step9 = this.step9_EmergentClosure(node, state);
    steps.push({ step: 9, name: 'Emergent Closure', input: state.coherence, output: step9, duration: Date.now() - startTime });

    // Step 10: Output Composer
    const step10 = this.step10_OutputComposer(node, mode, {
      dimension: step1,
      center: step2,
      gate: step3,
      line: step4,
      colorToneBase: step5,
      astrological: step6,
      axis: step7,
      scale: step8,
      closure: step9
    });
    steps.push({ step: 10, name: 'Output Composer', input: mode, output: step10.substring(0, 100) + '...', duration: Date.now() - startTime });

    return {
      output: step10,
      metadata: {
        gate: node.gate,
        line: node.line,
        color: node.color,
        tone: node.tone,
        base: node.base,
        dimension: node.dimension,
        center: step2.name,
        channel: step3.channel,
        zodiac: node.zodiac,
        house: node.house,
        coherence: node.coherence,
        scale: node.scale,
        outputMode: mode
      },
      steps
    };
  }

  // =========================================================================
  // STEP 1: Dimensional Selection
  // =========================================================================
  private step1_DimensionalSelection(node: UniversalNode, state: FieldState): {
    dimension: Dimension;
    keynote: string;
    element: string;
    physics: string;
    biology: string;
    alchemy: string;
  } {
    const dimData = this.tables.getDimension(node.dimension);
    return {
      dimension: node.dimension,
      keynote: dimData.keynote,
      element: dimData.element,
      physics: dimData.physics,
      biology: dimData.biology,
      alchemy: dimData.alchemy
    };
  }

  // =========================================================================
  // STEP 2: Center Lookup
  // =========================================================================
  private step2_CenterLookup(node: UniversalNode): {
    name: string;
    gland: string;
    voice: string;
    frequency: string;
    bodySystem: string;
  } {
    const gateData = this.dictionary.getGate(node.gate);
    const centerData = this.tables.getCenter(gateData.center);
    return {
      name: gateData.center,
      gland: centerData.gland,
      voice: centerData.voice_keyword,
      frequency: centerData.frequency,
      bodySystem: centerData.body_system
    };
  }

  // =========================================================================
  // STEP 3: Gate Archetype
  // =========================================================================
  private step3_GateArchetype(node: UniversalNode): {
    hexagram: string;
    keyword: string;
    corePhrase: string;
    channel: string;
    codon: string;
    aminoAcid: string;
  } {
    const gateData = this.dictionary.getGate(node.gate);
    return {
      hexagram: gateData.hexagram,
      keyword: gateData.iching_keyword,
      corePhrase: gateData.core_phrase,
      channel: gateData.channel,
      codon: gateData.codon,
      aminoAcid: gateData.amino_acid
    };
  }

  // =========================================================================
  // STEP 4: Line Binary
  // =========================================================================
  private step4_LineBinary(node: UniversalNode): {
    name: string;
    exaltation: string;
    detriment: string;
    quality: string;
    mode: string;
    planet: string;
  } {
    const lineData = this.tables.getLine(node.gate, node.line);
    return {
      name: lineData.name,
      exaltation: lineData.exaltation_keyword,
      detriment: lineData.detriment_keyword,
      quality: lineData.quality,
      mode: lineData.mode,
      planet: lineData.planet_ruler
    };
  }

  // =========================================================================
  // STEP 5: Color/Tone/Base
  // =========================================================================
  private step5_ColorToneBase(node: UniversalNode): {
    color: { name: string; motivation: string; sense: string };
    tone: { name: string; resonance: string; mode: string };
    base: { name: string; keynote: string; dimension: string };
    combinedMotivation: string;
  } {
    const colorData = this.tables.getColor(node.color);
    const toneData = this.tables.getTone(node.tone);
    const baseData = this.tables.getBase(node.base);

    return {
      color: {
        name: colorData.name,
        motivation: colorData.motivation,
        sense: colorData.sense
      },
      tone: {
        name: toneData.name,
        resonance: toneData.resonance,
        mode: toneData.mode
      },
      base: {
        name: baseData.name,
        keynote: baseData.keynote,
        dimension: baseData.dimension
      },
      combinedMotivation: `${colorData.motivation} through ${toneData.resonance} in ${baseData.keynote}`
    };
  }

  // =========================================================================
  // STEP 6: Astrological Context
  // =========================================================================
  private step6_AstrologicalContext(node: UniversalNode): {
    zodiac: { sign: string; modality: string; element: string; keywords: string[] };
    house: { number: number; domain: string; keyword: string };
    combinedContext: string;
  } {
    const zodiacData = this.tables.getZodiac(node.zodiac);
    const houseData = this.tables.getHouse(node.house);

    return {
      zodiac: {
        sign: node.zodiac,
        modality: zodiacData.modality,
        element: zodiacData.element,
        keywords: zodiacData.archetypal_keywords
      },
      house: {
        number: node.house,
        domain: houseData.life_domain,
        keyword: houseData.keyword
      },
      combinedContext: `${zodiacData.modality} ${zodiacData.element} in the ${houseData.life_domain} (House ${node.house})`
    };
  }

  // =========================================================================
  // STEP 7: Axis Polarity
  // =========================================================================
  private step7_AxisPolarity(node: UniversalNode): {
    oppositeGate: number;
    polarityType: string;
    channel: string;
    mirrorPhrase: string;
  } {
    const axisData = this.tables.getAxisPair(node.gate);
    const oppositeGate = this.dictionary.getGate(axisData.gate_b);

    return {
      oppositeGate: axisData.gate_b,
      polarityType: axisData.polarity_type,
      channel: axisData.channel,
      mirrorPhrase: `The mirror of ${node.gate} is ${axisData.gate_b}: ${oppositeGate.core_phrase}`
    };
  }

  // =========================================================================
  // STEP 8: Scale Resolution
  // =========================================================================
  private step8_ScaleResolution(node: UniversalNode): {
    scale: string;
    expressionMode: string;
    depth: string;
    detail: string;
  } {
    const scaleModes: Record<string, { mode: string; depth: string; detail: string }> = {
      'macro': { mode: 'Archetypal', depth: 'Dimension + Gate', detail: 'Keynote only' },
      'meso': { mode: 'Action', depth: 'Gate + Line', detail: 'Verb + modifier' },
      'micro': { mode: 'Motivation', depth: 'Color + Tone + Base', detail: 'Subtext + resonance' },
      'nano': { mode: 'Precision', depth: 'Full coordinate', detail: 'Angular + temporal' }
    };

    const mode = scaleModes[node.scale] || scaleModes['macro'];

    return {
      scale: node.scale,
      expressionMode: mode.mode,
      depth: mode.depth,
      detail: mode.detail
    };
  }

  // =========================================================================
  // STEP 9: Emergent Closure
  // =========================================================================
  private step9_EmergentClosure(node: UniversalNode, state: FieldState): {
    coherence: number;
    interference: Record<string, number>;
    resonanceHz: number;
    state: string;
    closure: string;
  } {
    const calc = this.calculator.calculate(state.dimensions);

    return {
      coherence: calc.coherence,
      interference: calc.interference_pattern,
      resonanceHz: calc.resonance_hz,
      state: calc.state,
      closure: `At C=${calc.coherence.toFixed(3)}, the field resonates at ${calc.resonance_hz.toFixed(2)} Hz in ${calc.state} state.`
    };
  }

  // =========================================================================
  // STEP 10: Output Composer
  // =========================================================================
  private step10_OutputComposer(
    node: UniversalNode,
    mode: OutputMode,
    context: {
      dimension: any;
      center: any;
      gate: any;
      line: any;
      colorToneBase: any;
      astrological: any;
      axis: any;
      scale: any;
      closure: any;
    }
  ): string {
    const { dimension, center, gate, line, colorToneBase, astrological, axis, scale, closure } = context;

    switch (mode) {
      case 'metaphysical':
        return this.composeMetaphysical(node, dimension, center, gate, line, astrological, closure);
      case 'scientific':
        return this.composeScientific(node, dimension, center, gate, line, colorToneBase, closure);
      case 'psycho-linguistic':
        return this.composePsychoLinguistic(node, center, gate, line, colorToneBase, astrological);
      case 'native':
        return this.composeNative(node);
      case 'gene-keys':
        return this.composeGeneKeys(node, gate, line);
      case 'poetic':
        return this.composePoetic(node, dimension, gate, line, astrological);
      case 'compressed':
        return this.composeCompressed(node);
      default:
        return this.composeMetaphysical(node, dimension, center, gate, line, astrological, closure);
    }
  }

  private composeMetaphysical(node: UniversalNode, dim: any, center: any, gate: any, line: any, astro: any, closure: any): string {
    return `${dim.keynote} — ${gate.corePhrase} through ${line.name} expression.

The ${gate.hexagram} (${gate.keyword}) activates in the ${dim.element} field of the ${center.name} center, calling forth ${line.exaltation} from the ${gate.channel} channel.

In the ${astro.zodiac.modality} ${astro.zodiac.element} season of ${node.zodiac}, within the ${astro.house.domain} (House ${node.house}), the ${line.planet} whispers: "${gate.corePhrase}"

${axis.mirrorPhrase}

${closure.closure}`;
  }

  private composeScientific(node: UniversalNode, dim: any, center: any, gate: any, line: any, ctb: any, closure: any): string {
    return `GATE ${node.gate} | ${gate.codon} → ${gate.aminoAcid} (MW: ${this.dictionary.getGate(node.gate).molecular_weight})
CENTER: ${center.name} (${center.gland}, ${center.frequency})
CHANNEL: ${gate.channel}
LINE ${node.line}: ${line.name} — ${line.exaltation}/${line.detriment} (${line.planet})
COLOR ${node.color}: ${ctb.color.name} — ${ctb.color.motivation} (${ctb.color.sense})
TONE ${node.tone}: ${ctb.tone.name} — ${ctb.tone.resonance} (${ctb.tone.mode})
BASE ${node.base}: ${ctb.base.name} — ${ctb.base.keynote} (${ctb.base.dimension})
DIMENSION: ${node.dimension} (${dim.physics})
ASTRO: ${node.zodiac} ${node.house}°${node.degree}′${node.minute}″${node.second}
COHERENCE: ${closure.coherence.toFixed(4)} | RESONANCE: ${closure.resonanceHz.toFixed(2)} Hz | STATE: ${closure.state}`;
  }

  private composePsychoLinguistic(node: UniversalNode, center: any, gate: any, line: any, ctb: any, astro: any): string {
    return `When ${ctb.combinedMotivation} arises in your ${center.name}, you express through ${line.name} patterns (${line.quality}).

The ${gate.hexagram} teaches that ${gate.corePhrase.toLowerCase()}. Your ${line.exaltation} is the gift; your ${line.detriment} is the shadow. In the ${astro.house.domain}, this becomes ${astro.house.keyword}.

What wants to be heard from ${center.voice}?`;
  }

  private composeNative(node: UniversalNode): string {
    return `G${node.gate}L${node.line}C${node.color}T${node.tone}B${node.base}°${node.degree}′${node.minute}″${node.second}[${node.dimension}]C${node.coherence.toFixed(2)}`;
  }

  private composeGeneKeys(node: UniversalNode, gate: any, line: any): string {
    const shadows = ["Victim", "Disappointment", "Anxiety", "Intolerance", "Greed", "Conflict", "Division", "Dishonesty", "Inadequacy", "Vengeance", "Obscurity", "Pretension", "Discord", "Compromise", "Dullness", "Incompetence", "Opinion", "Judgment", "Neediness", "Superficiality", "Control", "Dishonor", "Isolation", "Rationalization", "Constriction", "Pride", "Selfishness", "Pointlessness", "Cowardice", "Desire", "Arrogance", "Failure", "Dullness", "Savagery", "Change", "Darkness", "Weakness", "Struggle", "Provocation", "Loneliness", "Fantasy", "Expectation", "Insight", "Alertness", "Possessiveness", "Seriousness", "Oppression", "Incompetence", "Reactivity", "Corruption", "Agitation", "Stress", "Immaturity", "Greed", "Victimization", "Distraction", "Unease", "Judgment", "Dishonesty", "Limitation", "Mystery", "Details", "Doubt", "Confusion"];
    const gifts = ["Freshness", "Higher Knowing", "Innovation", "Answers", "Patience", "Intimacy", "Direction", "Contribution", "Focus", "Self-Love", "Ideas", "Openness", "Discernment", "Power", "Flamboyance", "Depth", "Far-Sightedness", "Integrity", "Sensitivity", "Presence", "Authority", "Grace", "Simplicity", "Inspiration", "Acceptance", "Artfulness", "Selflessness", "Immortality", "Perseverance", "Lightness", "Leadership", "Retainment", "Remembering", "Power", "Adventure", "Compassion", "Equality", "Perseverance", "Provocation", "Aloneness", "Anticipation", "Detachment", "Insight", "Synarchy", "Gathering", "Determination", "Transmutation", "Wisdom", "Rebirth", "Equilibrium", "Initiation", "Stillness", "Beginnings", "Drive", "Freedom", "Enquiry", "Intuition", "Vitality", "Intimacy", "Completion", "Inner Truth", "Impeccability", "Truth", "Imagination"];
    const siddhis = ["Beauty", "Unity", "Eternity", "Intelligence", "Timelessness", "Peace", "Virtue", "Exquisiteness", "Invincibility", "Being", "Light", "Purity", "Empathy", "Bounteousness", "Majesty", "Mastery", "Far-Reach", "Perfection", "Sacrifice", "Self-Assurance", "Valour", "Grace", "Quintessence", "Silence", "Universal Love", "Invisibility", "Selflessness", "Immortality", "Courage", "Rapture", "Humility", "Vastness", "Mindfulness", "Presence", "Boundlessness", "Humanity", "Ecstasy", "Honour", "Liberation", "Divine Will", "Eternal Now", "Precision", "Epiphany", "Synarchy", "Communion", "Siddhi of Siddhis", "Transfiguration", "Wisdom", "Rebirth", "Eternal Youth", "Awakening", "Stillness", "Completion", "Aspiration", "Freedom", "Wonder", "Clarity", "Intimacy", "Completion", "Truth", "Omniscience", "Impeccability", "Truth", "Justice"];

    const idx = node.gate - 1;
    return `GATE ${node.gate} — ${gate.hexagram}
═══════════════════════════════════════
SHADOW:  ${shadows[idx]}
GIFT:    ${gifts[idx]}
SIDDHI:  ${siddhis[idx]}
───────────────────────────────────────
LINE ${node.line}: ${line.exaltation} / ${line.detriment}
CHANNEL: ${gate.channel}`;
  }

  private composePoetic(node: UniversalNode, dim: any, gate: any, line: any, astro: any): string {
    return `In the ${dim.element} of ${node.dimension},
where ${gate.aminoAcid} dreams its ${gate.codon} song,
the ${line.name} walks barefoot through ${gate.hexagram} —
${gate.corePhrase},
and the ${node.zodiac} sky remembers
what ${astro.house.keyword} means.`;
  }

  private composeCompressed(node: UniversalNode): string {
    return `G${node.gate}L${node.line}C${node.color}T${node.tone}B${node.base}°${node.degree}′${node.minute}″${node.second}[${node.dimension[0]}]C${node.coherence.toFixed(2)}`;
  }
}

export default SentenceCompiler;
