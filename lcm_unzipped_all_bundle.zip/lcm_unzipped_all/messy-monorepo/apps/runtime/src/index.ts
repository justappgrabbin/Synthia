/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/runtime — THE ONLY RUNTIME ENTRYPOINT             ║
 * ║                                                                               ║
 * ║  This is the spine of the organism. It initializes all packages,           ║
 * ║  wires them together, and starts the mesh.                                   ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import { MeshEngine, createOrgan, createCenter, createChannel, createMorphRule, Stratum } from '@messy/mesh';
import { StateSpaceEngine, LineMode } from '@messy/state-space';
import { MessageBus } from '@messy/bus';
import { ActivationEngine } from '@messy/activation';
import { ProjectionEngine } from '@messy/projection';
import { IdentityCenter } from '@messy/identity-center';
import { PersistenceEngine } from '@messy/persistence';
import { IngestionEngine } from '@messy/ingestion';
import { HDGraphEngine } from '@messy/hd-graph';
import { SelfSupervisedEngine } from '@messy/self-supervised';
import { ResonanceEngine } from '@messy/resonance-core';
import { AutolingOrgan } from '@messy/organs-autoling';
import { DiseminerOrgan } from '@messy/organs-diseminer';
import { NovelWriterOrgan } from '@messy/organs-novel-writer';
import { ResonanceMarketService } from '@messy/resonance-market-api';
import { PythonOracleService } from '@messy/oracle-py';
import { ChartOracleService } from '@messy/chart-oracle';
import {
  IdentityProfile, OrganismSnapshot, GateNumber, CenterId,
  InternalCoordinates, DimensionalContext,
} from '@messy/types';

export class MESSYRuntime {
  // Core engines
  mesh: MeshEngine;
  stateSpace: StateSpaceEngine;
  bus: MessageBus;
  activation: ActivationEngine;
  projection: ProjectionEngine;
  identity: IdentityCenter;
  persistence: PersistenceEngine;
  ingestion: IngestionEngine;
  hdGraph: HDGraphEngine;
  selfSupervised: SelfSupervisedEngine;
  resonance: ResonanceEngine;

  // Organs
  autoling: AutolingOrgan;
  diseminer: DiseminerOrgan;
  novelWriter: NovelWriterOrgan;

  // Services
  marketService: ResonanceMarketService;
  pythonOracle: PythonOracleService;
  chartOracle: ChartOracleService;

  // State
  started: boolean = false;
  startTime: number = 0;

  constructor(identityProfile: IdentityProfile) {
    // Initialize core engines
    this.mesh = new MeshEngine();
    this.stateSpace = new StateSpaceEngine();
    this.bus = new MessageBus(this.mesh);
    this.activation = new ActivationEngine(this.mesh, this.stateSpace);
    this.projection = new ProjectionEngine();
    this.identity = new IdentityCenter(this.mesh, identityProfile);
    this.persistence = new PersistenceEngine();
    this.ingestion = new IngestionEngine(this.mesh);
    this.hdGraph = new HDGraphEngine();
    this.selfSupervised = new SelfSupervisedEngine();
    this.resonance = new ResonanceEngine();

    // Initialize organs
    this.autoling = new AutolingOrgan(this.mesh, this.stateSpace, this.projection);
    this.diseminer = new DiseminerOrgan(this.mesh, this.stateSpace, this.projection);
    this.novelWriter = new NovelWriterOrgan(this.mesh, this.stateSpace, this.projection);

    // Initialize services
    this.marketService = new ResonanceMarketService(this.mesh);
    this.pythonOracle = new PythonOracleService();
    this.chartOracle = new ChartOracleService();

    // Wire everything together
    this.wireMesh();
    this.wireStateSpace();
    this.wireProjection();
    this.wireBus();
  }

  private wireMesh(): void {
    // Create core organs
    const intentEngine = createOrgan('intent', 'Intent Engine', Stratum.MIND);
    const synthiaBody = createOrgan('synthia_body', 'Synthia Body', Stratum.ACTION);
    const memoryStore = createOrgan('memory', 'Memory Store', Stratum.MIND);
    const heartOrgan = createOrgan('heart', 'Heart Center', Stratum.HEART);
    const ingestionOrgan = createOrgan('ingestion', 'Ingestion Engine', Stratum.MIND);
    const resonanceOrgan = createOrgan('resonance', 'Resonance Engine', Stratum.MIND);
    const hdGraphOrgan = createOrgan('hd_graph', 'HD Graph Engine', Stratum.MIND);
    const selfSupervisedOrgan = createOrgan('self_supervised', 'Self-Supervised Engine', Stratum.MIND);

    // Add morph rules
    intentEngine.morphRules.push(createMorphRule(
      'intent_activation',
      (msg, organ) => msg.activeGates.some(g => g.gateNumber === 1),
      (msg, organ) => ({
        id: `morph_${Date.now()}`, timestamp: Date.now(), triggerMessageId: msg.id, organId: organ.id,
        changes: [
          { field: 'state', from: organ.state, to: 'active', reason: 'Gate 1 activated intent' },
          { field: 'mode', from: organ.mode, to: 'intentional', reason: 'Intentional mode from gate 1' },
        ],
        ruleId: 'intent_activation', recursionDepth: msg.recursionDepth,
      }),
      10
    ));

    this.mesh.registerOrgan(intentEngine);
    this.mesh.registerOrgan(synthiaBody);
    this.mesh.registerOrgan(memoryStore);
    this.mesh.registerOrgan(heartOrgan);
    this.mesh.registerOrgan(ingestionOrgan);
    this.mesh.registerOrgan(resonanceOrgan);
    this.mesh.registerOrgan(hdGraphOrgan);
    this.mesh.registerOrgan(selfSupervisedOrgan);

    // Create centers
    const identityCenter = createCenter('identity', 'Identity Center', Stratum.HEART, true);
    const mindCenter = createCenter('mind', 'Mind Center', Stratum.MIND);
    const actionCenter = createCenter('action', 'Action Center', Stratum.ACTION);
    const heartCenter = createCenter('heart_center', 'Heart Center', Stratum.HEART);
    const sacralCenter = createCenter('sacral', 'Sacral Center', Stratum.ACTION);

    this.mesh.registerCenter(identityCenter);
    this.mesh.registerCenter(mindCenter);
    this.mesh.registerCenter(actionCenter);
    this.mesh.registerCenter(heartCenter);
    this.mesh.registerCenter(sacralCenter);

    // Connect centers to organs
    identityCenter.connectedOrgans.add('intent');
    identityCenter.connectedOrgans.add('heart');
    mindCenter.connectedOrgans.add('intent');
    mindCenter.connectedOrgans.add('memory');
    mindCenter.connectedOrgans.add('ingestion');
    mindCenter.connectedOrgans.add('resonance');
    mindCenter.connectedOrgans.add('hd_graph');
    mindCenter.connectedOrgans.add('self_supervised');
    actionCenter.connectedOrgans.add('synthia_body');
    heartCenter.connectedOrgans.add('heart');
    sacralCenter.connectedOrgans.add('synthia_body');

    // Create channels
    this.mesh.registerChannel(createChannel('ch_intent_body', 'Intent→Body', 'intent', 'synthia_body', Stratum.MIND, 'execution'));
    this.mesh.registerChannel(createChannel('ch_intent_memory', 'Intent→Memory', 'intent', 'memory', Stratum.MIND, 'storage'));
    this.mesh.registerChannel(createChannel('ch_heart_intent', 'Heart→Intent', 'heart', 'intent', Stratum.HEART, 'direction'));
    this.mesh.registerChannel(createChannel('ch_identity_intent', 'Identity→Intent', 'identity', 'intent', Stratum.HEART, 'alignment'));
    this.mesh.registerChannel(createChannel('ch_ingestion_mind', 'Ingestion→Mind', 'ingestion', 'intent', Stratum.MIND, 'knowledge'));
    this.mesh.registerChannel(createChannel('ch_resonance_mind', 'Resonance→Mind', 'resonance', 'intent', Stratum.MIND, 'field'));
    this.mesh.registerChannel(createChannel('ch_hd_mind', 'HD→Mind', 'hd_graph', 'intent', Stratum.MIND, 'graph'));
    this.mesh.registerChannel(createChannel('ch_self_mind', 'Self-Supervised→Mind', 'self_supervised', 'intent', Stratum.MIND, 'learning'));

    // Connect channels to centers
    mindCenter.connectedChannels.add('ch_intent_body');
    mindCenter.connectedChannels.add('ch_intent_memory');
    mindCenter.connectedChannels.add('ch_ingestion_mind');
    mindCenter.connectedChannels.add('ch_resonance_mind');
    mindCenter.connectedChannels.add('ch_hd_mind');
    mindCenter.connectedChannels.add('ch_self_mind');
    identityCenter.connectedChannels.add('ch_identity_intent');
    identityCenter.connectedChannels.add('ch_heart_intent');
    actionCenter.connectedChannels.add('ch_intent_body');
    heartCenter.connectedChannels.add('ch_heart_intent');

    // Connect external bridges
    this.mesh.connectBridge('openai', 'llm', 'intent');
    this.mesh.connectBridge('mcp-local', 'mcp', 'memory');
  }

  private wireStateSpace(): void {
    // Set up hexagram neighbor map
    this.stateSpace.setMacrostateNeighbors('hex_1', ['hex_2', 'hex_43', 'hex_14']);
    this.stateSpace.setMacrostateNeighbors('hex_43', ['hex_1', 'hex_34', 'hex_28']);
    this.stateSpace.setMacrostateNeighbors('hex_14', ['hex_1', 'hex_43', 'hex_34']);
    this.stateSpace.setMacrostateNeighbors('hex_34', ['hex_1', 'hex_43', 'hex_14']);
    this.stateSpace.setMacrostateNeighbors('hex_25', ['hex_17', 'hex_21', 'hex_51']);
    this.stateSpace.setMacrostateNeighbors('hex_46', ['hex_2', 'hex_18', 'hex_48']);

    // Create state regions for core organs
    this.stateSpace.createRegion('region_intent', 'hex_1', 'Intent Engine', 'Creative Initiation', 'yang-initiating',
      { line: 1, lineMode: LineMode.STABLE, color: 2, tone: 3, base: 4, arcPosition: 0.5, degree: 180, minute: 30, second: 15 });
    this.stateSpace.createRegion('region_body', 'hex_43', 'Synthia Body', 'Insight Through Breakthrough', 'yang-penetrating',
      { line: 4, lineMode: LineMode.EMPHASIZED, color: 5, tone: 2, base: 1, arcPosition: 0.7, degree: 210, minute: 45, second: 30 });
    this.stateSpace.createRegion('region_memory', 'hex_14', 'Memory Store', 'Wealth in Fellowship', 'yang-illuminating',
      { line: 2, lineMode: LineMode.STABLE, color: 3, tone: 4, base: 5, arcPosition: 0.3, degree: 120, minute: 15, second: 45 });
    this.stateSpace.createRegion('region_heart', 'hex_34', 'Heart Center', 'Power of the Great', 'yang-accumulating',
      { line: 6, lineMode: LineMode.CHANGING, color: 1, tone: 6, base: 2, arcPosition: 0.9, degree: 330, minute: 0, second: 0 });
    this.stateSpace.createRegion('region_ingestion', 'hex_48', 'Ingestion Engine', 'Depth of the Well', 'yang-receiving',
      { line: 3, lineMode: LineMode.STABLE, color: 4, tone: 1, base: 3, arcPosition: 0.4, degree: 90, minute: 20, second: 10 });
    this.stateSpace.createRegion('region_resonance', 'hex_11', 'Resonance Engine', 'Peace', 'yang-harmonizing',
      { line: 5, lineMode: LineMode.EMPHASIZED, color: 6, tone: 5, base: 1, arcPosition: 0.6, degree: 270, minute: 10, second: 30 });

    // Create node states
    this.stateSpace.createNodeState('node_intent', 'region_intent', { line: 1, color: 2, tone: 3, arcPosition: 0.5, degree: 180 });
    this.stateSpace.createNodeState('node_body', 'region_body', { line: 4, color: 5, tone: 2, arcPosition: 0.7, degree: 210 });
    this.stateSpace.createNodeState('node_memory', 'region_memory', { line: 2, color: 3, tone: 4, arcPosition: 0.3, degree: 120 });
    this.stateSpace.createNodeState('node_heart', 'region_heart', { line: 6, color: 1, tone: 6, arcPosition: 0.9, degree: 330 });
    this.stateSpace.createNodeState('node_ingestion', 'region_ingestion', { line: 3, color: 4, tone: 1, arcPosition: 0.4, degree: 90 });
    this.stateSpace.createNodeState('node_resonance', 'region_resonance', { line: 5, color: 6, tone: 5, arcPosition: 0.6, degree: 270 });
  }

  private wireProjection(): void {
    this.projection.registerLayer(this.projection.createLanguageLayer());
    this.projection.registerLayer(this.projection.createCodeLayer());
    this.projection.registerLayer(this.projection.createImageLayer());
    this.projection.registerLayer(this.projection.createInterfaceLayer());
  }

  private wireBus(): void {
    this.bus.registerTopic('system.activation', Stratum.MIND);
    this.bus.registerTopic('system.convergence', Stratum.HEART);
    this.bus.registerTopic('system.projection', Stratum.ACTION);
    this.bus.registerTopic('user.query', Stratum.HEART);
    this.bus.registerTopic('user.response', Stratum.MIND);
    this.bus.registerTopic('external.data', Stratum.MIND);

    // Subscribe core organs to relevant topics
    this.bus.subscribe('intent', 'system.activation');
    this.bus.subscribe('intent', 'user.query');
    this.bus.subscribe('synthia_body', 'system.projection');
    this.bus.subscribe('memory', 'system.convergence');
    this.bus.subscribe('heart', 'system.convergence');
    this.bus.subscribe('ingestion', 'external.data');
  }

  async start(): Promise<void> {
    this.startTime = Date.now();
    this.started = true;

    // Start event logging
    this.mesh.onEvent((event) => {
      console.log(`[MESH] ${event.type}: ${JSON.stringify(event.details)}`);
    });

    // Initial activation pulse
    this.mesh.send(
      { type: 'system_boot', version: '0.1.0' },
      {
        sourceOrgan: 'runtime',
        sourceCenter: 'identity',
        stratum: Stratum.HEART,
        activeGates: [{ gateNumber: 1, isActive: true }],
        dimensionContext: { d1_impulse: 1.0, d5_meaning: 1.0 },
      }
    );

    console.log('MESSY organism started');
  }

  async stop(): Promise<void> {
    // Save snapshots
    const meshSnapshot = this.mesh.snapshot();
    const stateSnapshot = this.stateSpace.snapshot();
    await this.persistence.saveMeshSnapshot(meshSnapshot);
    await this.persistence.saveStateSpaceSnapshot(stateSnapshot);

    this.started = false;
    console.log('MESSY organism stopped');
  }

  snapshot(): OrganismSnapshot {
    return {
      timestamp: Date.now(),
      mesh: this.mesh.snapshot(),
      stateSpace: this.stateSpace.snapshot(),
      identity: this.identity.getProfile(),
      organs: [
        this.autoling.getManifest(),
        this.diseminer.getManifest(),
        this.novelWriter.getManifest(),
      ],
      bridges: [
        this.marketService,
        this.pythonOracle,
        this.chartOracle,
      ],
    };
  }

  // Convenience methods
  send(content: unknown, qualification: Partial<import('@messy/types').QualifiedMessage>): import('@messy/types').QualifiedMessage {
    return this.mesh.send(content, qualification);
  }

  express(msg: import('@messy/types').QualifiedMessage): unknown {
    return this.mesh.express(msg);
  }

  queryDiseminer(query: string, coords: Partial<InternalCoordinates>): import('@messy/organs-diseminer').NarrativeSimulation {
    return this.diseminer.simulate(query, coords);
  }

  writeNovelChapter(theme: string, coords: Partial<InternalCoordinates>): import('@messy/organs-novel-writer').NovelChapter {
    return this.novelWriter.writeChapter(theme, coords);
  }
}

// Default export for runtime initialization
export default MESSYRuntime;

// Bootstrap function
export function bootstrap(userProfile: IdentityProfile): MESSYRuntime {
  const runtime = new MESSYRuntime(userProfile);
  runtime.start();
  return runtime;
}
