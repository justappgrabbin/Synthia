/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/browser-shell — BROWSER SHELL                       ║
 * ║                                                                               ║
 * ║  The browser-based interface for the MESSY organism.                        ║
 * ║  Connects to the runtime via the mesh and renders state-space visualization. ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import { UIManager } from '@messy/ui';
import { MeshEngine, QualifiedMessage, Stratum } from '@messy/mesh';
import { StateSpaceEngine } from '@messy/state-space';
import { IdentityCenter } from '@messy/identity-center';
import { ResonanceEngine } from '@messy/resonance-core';
import { IdentityProfile } from '@messy/types';

export class BrowserShell {
  private ui: UIManager;
  private mesh: MeshEngine;
  private stateSpace: StateSpaceEngine;
  private identity: IdentityCenter;
  private resonance: ResonanceEngine;
  private container: HTMLElement;

  constructor(container: HTMLElement, mesh: MeshEngine, stateSpace: StateSpaceEngine, identity: IdentityCenter, resonance: ResonanceEngine) {
    this.container = container;
    this.mesh = mesh;
    this.stateSpace = stateSpace;
    this.identity = identity;
    this.resonance = resonance;
    this.ui = new UIManager();
  }

  mount(): void {
    this.ui.mount(this.container);

    // Create main panels
    this.ui.register({
      id: 'mesh-viz', type: 'panel',
      render: () => {
        const div = document.createElement('div');
        div.id = 'mesh-viz';
        div.style.cssText = 'border: 1px solid #333; padding: 10px; margin: 5px; background: #111; color: #0f0; font-family: monospace;';
        div.innerHTML = '<h3>Mesh Visualization</h3><div id="mesh-stats">Loading...</div>';
        return div;
      },
      update: (data) => {
        const stats = document.getElementById('mesh-stats');
        if (stats) stats.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
      },
    });

    this.ui.register({
      id: 'state-space-viz', type: 'panel',
      render: () => {
        const div = document.createElement('div');
        div.id = 'state-space-viz';
        div.style.cssText = 'border: 1px solid #333; padding: 10px; margin: 5px; background: #111; color: #0ff; font-family: monospace;';
        div.innerHTML = '<h3>State Space</h3><div id="state-stats">Loading...</div>';
        return div;
      },
      update: (data) => {
        const stats = document.getElementById('state-stats');
        if (stats) stats.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
      },
    });

    this.ui.register({
      id: 'input-control', type: 'control',
      render: () => {
        const div = document.createElement('div');
        div.style.cssText = 'padding: 10px; margin: 5px;';
        div.innerHTML = `
          <input type="text" id="user-input" placeholder="Enter query..." style="width: 70%; padding: 8px; background: #222; color: #fff; border: 1px solid #444;">
          <button id="send-btn" style="padding: 8px 16px; background: #0f0; color: #000; border: none; cursor: pointer;">Send</button>
        `;
        const btn = div.querySelector('#send-btn');
        const input = div.querySelector('#user-input');
        if (btn && input) {
          btn.addEventListener('click', () => {
            const value = (input as HTMLInputElement).value;
            if (value) this.handleUserInput(value);
          });
          input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
              const value = (input as HTMLInputElement).value;
              if (value) this.handleUserInput(value);
            }
          });
        }
        return div;
      },
      update: () => {},
    });

    // Start update loop
    this.startUpdateLoop();
  }

  private handleUserInput(input: string): void {
    const route = this.identity.routeBySemanticPattern(input);
    this.mesh.send(input, {
      sourceOrgan: 'browser_shell',
      sourceCenter: 'identity',
      targetOrgan: route?.targetOrgan || 'intent',
      targetCenter: route?.targetCenter || 'mind',
      stratum: Stratum.HEART,
      userAlignmentContext: { userId: this.identity.getProfile().userId, query: input },
    });
  }

  private startUpdateLoop(): void {
    setInterval(() => {
      const meshSnapshot = this.mesh.snapshot();
      const stateSnapshot = this.stateSpace.snapshot();
      this.ui.update('mesh-viz', meshSnapshot);
      this.ui.update('state-space-viz', stateSnapshot);
    }, 1000);
  }
}

export default BrowserShell;
