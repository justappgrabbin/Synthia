# MESSY — Local-First Digital Organism

> "All possible forms already exist in the state space as latent structure. The organism does not primarily compute forms into existence. It addresses, activates, and expresses the relevant form."

## Architecture

```
ONTOLOGY (Constitution) — what may exist
    ↓
MESH (Circulatory/Nervous) — how structure moves and changes
    gate → message → mesh → channel → edge → morph → convergence → expression → center
    ↓
STATE SPACE (Cellular) — how states are internally organized
    macrostate → coordinates → gradients → stability → projection → delivery
    ↓
INTEGRATION (Synaptic Bridge) — mesh messages carry state-space context
    organs morph based on internal coordinates
    convergence is coordinate-aligned and gradient-harmonious
```

## Monorepo Structure

```
messy-monorepo/
├── apps/
│   ├── runtime/           # The only runtime entrypoint
│   └── browser-shell/     # The only browser shell
├── packages/
│   ├── types/             # Shared type system (one only)
│   ├── ontology/          # Canonical meaning structure
│   ├── state-space/       # Internal organization of being
│   ├── mesh/              # Living relation field
│   ├── bus/               # Message bus layer on mesh
│   ├── activation/        # Activation grammars
│   ├── projection/        # Projection layers
│   ├── identity-center/   # User alignment hub
│   ├── persistence/       # Local storage
│   ├── ingestion/         # Discerning ingestion system
│   ├── hd-graph/          # Human Design graph engine
│   ├── self-supervised/   # Learning engine
│   ├── resonance-core/    # Core resonance engine
│   ├── ui/                # Shared UI components
│   ├── organs-autoling/   # AUTOLING organ
│   ├── organs-diseminer/  # DISEMINER organ
│   └── organs-novel-writer/ # Novel writer organ
├── services/
│   ├── resonance-market-api/ # Market data service
│   ├── oracle-py/            # Python oracle
│   └── chart-oracle/         # Chart computation
└── archive/               # Preserved superseded work
```

## Canonicality Rules

1. **One runtime only** — `apps/runtime`
2. **One browser shell only** — `apps/browser-shell`
3. **One shared type system only** — `packages/types`
4. **One message substrate only** — `packages/mesh`
5. **One persistence layer only** — `packages/persistence`
6. **One implementation per concern stays canonical**
7. **Everything else is extracted or archived**
8. **No archived code is imported by live code**

## Getting Started

```bash
# Install dependencies
pnpm install

# Build all packages
pnpm build

# Start the runtime
pnpm runtime start

# Start the browser shell
pnpm browser dev
```

## The 12 Mesh Operational Rules

1. All subsystems communicate through the mesh.
2. All live messages are qualified, not raw.
3. Traversal path changes meaning.
4. Receiving a message may morph the receiver.
5. Channels define relation quality, not just adjacency.
6. Edges record relational becoming.
7. Convergence may be partial.
8. Centers may be dynamically stabilized through traversal.
9. The Identity Center is a privileged routing and alignment hub.
10. External bridges participate but do not define truth.
11. Recursion is canonical.
12. Projection follows qualified traversal.

## State Space Mechanics

A state is not a single point. It is a bounded region with:
- Internal coordinates (line, color, tone, base, arc, degree, minute, second)
- Local gradients (expression strength, inward/outward, receptive/projective, etc.)
- Stability regimes (stable interior, threshold, metastable, instability ridge, changing, resolving)
- Neighbor tendencies
- Projection bias
- Expressive delivery

## Design Principles

- **Local-First**: Core operates locally. External bridges amplify but do not define meaning.
- **Qualified Not Raw**: Every message carries full structural and qualitative context.
- **Traversal Changes Meaning**: The path alters significance.
- **Reception May Transform**: Receiving a message can morph the receiver.
- **Partial Convergence**: Convergence is graded, not binary.
- **State Is a Region**: Not a point. Internal coordinates determine expression.
- **Perspective-Relative**: Different observers read the same macrostate differently.
- **Recursion Is Canonical**: Messages may trigger further messages.
- **Projection Follows Traversal**: Output only after sufficient qualification.
- **Edges Record Becoming**: Relations are historical and dynamic.

## Final Rule

> The code is not the constitution. The ontology is the constitution.
