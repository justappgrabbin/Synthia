/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/organs-novel-writer — NOVEL WRITER ORGAN          ║
 * ║                                                                               ║
 * ║  Automatic novel writer that generates narrative from state-space context.    ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import { MeshEngine, createOrgan, Stratum } from '@messy/mesh';
import { StateSpaceEngine } from '@messy/state-space';
import { ProjectionEngine } from '@messy/projection';
import { GateNumber, OrganManifest, InternalCoordinates } from '@messy/types';

export interface NovelChapter {
  title: string;
  content: string;
  gates: GateNumber[];
  coordinates: Partial<InternalCoordinates>;
  resonance: number;
}

export class NovelWriterOrgan {
  private mesh: MeshEngine;
  private stateSpace: StateSpaceEngine;
  private projection: ProjectionEngine;
  private organId: string = 'novel_writer';
  private chapters: NovelChapter[] = [];

  constructor(mesh: MeshEngine, stateSpace: StateSpaceEngine, projection: ProjectionEngine) {
    this.mesh = mesh;
    this.stateSpace = stateSpace;
    this.projection = projection;

    const organ = createOrgan(this.organId, 'Automatic Novel Writer', Stratum.ACTION, {
      mode: 'creative',
      projectionPreference: 'narrative',
      responseStyle: 'expressive',
    });
    organ.morphRules.push({
      id: 'novel_activation',
      condition: (msg, organ) => msg.activeGates.some(g => [1, 43, 14, 34].includes(g.gateNumber)),
      effect: (msg, organ) => ({
        id: `morph_${Date.now()}`, timestamp: Date.now(), triggerMessageId: msg.id, organId: organ.id,
        changes: [{ field: 'mode', from: organ.mode, to: 'story_generation', reason: 'Creative/Insight gates activated' }],
        ruleId: 'novel_activation', recursionDepth: msg.recursionDepth,
      }),
      priority: 7,
    });
    mesh.registerOrgan(organ);
  }

  writeChapter(theme: string, coords: Partial<InternalCoordinates>): NovelChapter {
    const chapter: NovelChapter = {
      title: `Chapter ${this.chapters.length + 1}: ${theme}`,
      content: `In the space between Gate ${coords.line || 1} and Gate ${(coords.line || 1) + 10}, a story emerged...`,
      gates: [1, 43, 14, 34].filter(g => g <= 64) as GateNumber[],
      coordinates: coords,
      resonance: coords.arcPosition || 0.5,
    };
    this.chapters.push(chapter);
    return chapter;
  }

  getNovel(): NovelChapter[] { return [...this.chapters]; }

  getManifest(): OrganManifest {
    return {
      id: this.organId, name: 'Automatic Novel Writer', type: 'novel-writer', stratum: Stratum.ACTION,
      capabilities: ['narrative_generation', 'chapter_writing', 'theme_expansion', 'resonance_weaving'],
      dependencies: ['mesh', 'state-space', 'projection'],
      activationGates: [1, 43, 14, 34],
    };
  }
}

export default NovelWriterOrgan;
