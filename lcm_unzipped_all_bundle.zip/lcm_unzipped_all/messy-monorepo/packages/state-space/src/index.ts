/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║              @messy/state-space — INTERNAL ORGANIZATION OF BEING            ║
 * ║                                                                               ║
 * ║  "A state is not a single point. A state is a bounded region with internal    ║
 * ║   coordinates, gradients, thresholds, and expressive tendencies."             ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import {
  InternalCoordinates, LineMode, StabilityRegime, LocalGradients,
  ProjectionBias, ExpressiveDelivery, NeighborTendency,
  CoordinateSnapshot, StateRegion, NodeState, NodeContributionProfile,
  ChannelEmergence, EdgeFunction, GateNumber, Stratum,
} from '@messy/types';

export * from '@messy/types';

// ═══════════════════════════════════════════════════════════════════════════════
// STATE SPACE ENGINE
// ═══════════════════════════════════════════════════════════════════════════════

export class StateSpaceEngine {
  private regions: Map<string, StateRegion> = new Map();
  private nodeStates: Map<string, NodeState> = new Map();
  private channelEmergences: Map<string, ChannelEmergence> = new Map();
  private macrostateNeighbors: Map<string, string[]> = new Map();

  // ───────────────────────────────────────────────────────────────────────────
  // REGION CREATION
  // ───────────────────────────────────────────────────────────────────────────

  createRegion(
    id: string, macrostateId: string, name: string,
    coreFamily: string, signature: string,
    initialCoords: Partial<InternalCoordinates> = {}
  ): StateRegion {
    const coords = this.buildCoordinates(initialCoords);
    const gradients = this.computeGradients(coords);
    const stability = this.computeStability(coords, gradients);
    const neighbors = this.computeNeighborTendencies(macrostateId, coords);
    const projection = this.computeProjectionBias(coords, gradients);
    const delivery = this.computeExpressiveDelivery(coords, gradients, stability);

    const region: StateRegion = {
      id, macrostateId, name,
      coreQualitativeFamily: coreFamily,
      primaryRelationalSignature: signature,
      coordinates: coords,
      stabilityRegime: stability.regime,
      stabilityScore: stability.score,
      gradients, neighborTendencies: neighbors,
      projectionBias: projection,
      transitionReadiness: this.computeTransitionReadiness(coords, gradients, stability),
      expressiveDelivery: delivery,
      positionHistory: [], stabilityHistory: [stability.regime],
    };

    this.regions.set(id, region);
    return region;
  }

  // ───────────────────────────────────────────────────────────────────────────
  // NODE STATE CREATION
  // ───────────────────────────────────────────────────────────────────────────

  createNodeState(nodeId: string, regionId: string, coordinates: Partial<InternalCoordinates> = {}): NodeState {
    const coords = this.buildCoordinates(coordinates);
    const gradients = this.computeGradients(coords);
    const stability = this.computeStability(coords, gradients);
    const profile = this.computeNodeContributionProfile(coords, stability);

    const nodeState: NodeState = {
      nodeId, regionId, coordinates: coords,
      stabilityRegime: stability.regime,
      activeModulation: coords.arcPosition,
      pressureState: this.computePressureState(coords, gradients),
      contributionProfile: profile,
    };

    this.nodeStates.set(nodeId, nodeState);
    return nodeState;
  }

  // ───────────────────────────────────────────────────────────────────────────
  // COORDINATE BUILDING
  // ───────────────────────────────────────────────────────────────────────────

  private buildCoordinates(partial: Partial<InternalCoordinates> = {}): InternalCoordinates {
    const line = partial.line ?? 1;
    return {
      line, lineMode: partial.lineMode ?? this.inferLineMode(line, partial),
      color: partial.color ?? 1, tone: partial.tone ?? 1, base: partial.base ?? 1,
      arcPosition: partial.arcPosition ?? 0.5,
      degree: partial.degree ?? 0, minute: partial.minute ?? 0, second: partial.second ?? 0,
    };
  }

  private inferLineMode(line: number, partial: Partial<InternalCoordinates>): LineMode {
    if (partial.lineMode) return partial.lineMode;
    if (line === 6) return LineMode.CHANGING;
    if (line === 1) return LineMode.STABLE;
    if (line === 3) return LineMode.STRESSED;
    if (line === 4) return LineMode.EMPHASIZED;
    return LineMode.STABLE;
  }

  // ───────────────────────────────────────────────────────────────────────────
  // GRADIENT COMPUTATION
  // ───────────────────────────────────────────────────────────────────────────

  private computeGradients(coords: InternalCoordinates): LocalGradients {
    const lineStrength = coords.line / 6;
    const linePosture = coords.lineMode === LineMode.EMPHASIZED ? 0.8 :
                        coords.lineMode === LineMode.CHANGING ? 0.2 : 0.5;
    const colorOrientation = coords.color / 6;
    const colorTendency = coords.color <= 3 ? 0.3 : 0.7;
    const toneFocus = coords.tone / 6;
    const baseConsolidation = coords.base / 6;
    const arcMod = coords.arcPosition;

    return {
      expressionStrength: this.lerp(lineStrength, 0.5, arcMod),
      inwardVsOutward: this.lerp(colorOrientation, 0.5, arcMod),
      receptiveVsProjective: this.lerp(linePosture, 0.5, arcMod),
      consolidatingVsDestabilizing: this.lerp(colorTendency, baseConsolidation, arcMod),
      narrowVsDiffuse: this.lerp(toneFocus, 0.5, arcMod),
    };
  }

  // ───────────────────────────────────────────────────────────────────────────
  // STABILITY COMPUTATION
  // ───────────────────────────────────────────────────────────────────────────

  private computeStability(coords: InternalCoordinates, gradients: LocalGradients): { regime: StabilityRegime; score: number } {
    const centerDistance = Math.abs(coords.degree - 180) / 180;
    const arcDistance = Math.abs(coords.arcPosition - 0.5) * 2;
    const destabilizingFactor = gradients.consolidatingVsDestabilizing;
    const lineInstability = coords.lineMode === LineMode.CHANGING ? 1.0 :
                            coords.lineMode === LineMode.STRESSED ? 0.6 :
                            coords.lineMode === LineMode.RESOLVING ? 0.4 : 0.0;

    const rawScore = 1.0 - (centerDistance * 0.2 + arcDistance * 0.15 + destabilizingFactor * 0.3 + lineInstability * 0.35);
    const score = Math.max(0, Math.min(1, rawScore));

    let regime: StabilityRegime;
    if (score > 0.8) regime = StabilityRegime.STABLE_INTERIOR;
    else if (score > 0.6) regime = StabilityRegime.THRESHOLD;
    else if (score > 0.4) regime = StabilityRegime.METASTABLE;
    else if (score > 0.2) regime = StabilityRegime.INSTABILITY_RIDGE;
    else if (lineInstability > 0.5) regime = StabilityRegime.CHANGING_REGIME;
    else regime = StabilityRegime.RESOLVING;

    return { regime, score };
  }

  // ───────────────────────────────────────────────────────────────────────────
  // NEIGHBOR TENDENCIES
  // ───────────────────────────────────────────────────────────────────────────

  private computeNeighborTendencies(macrostateId: string, coords: InternalCoordinates): NeighborTendency[] {
    const neighbors = this.macrostateNeighbors.get(macrostateId) || [];
    return neighbors.map((neighborId) => {
      const boundaryFactor = Math.abs(coords.degree - 180) / 180;
      const arcBias = coords.arcPosition;
      const lineDrift = coords.lineMode === LineMode.CHANGING ? 0.8 : 0.2;
      const tendencyStrength = (boundaryFactor * 0.4 + arcBias * 0.3 + lineDrift * 0.3);
      return {
        targetMacrostateId: neighborId, targetRegionId: `${neighborId}_default`,
        tendencyStrength: Math.min(1, tendencyStrength),
        transitionProbability: Math.min(1, tendencyStrength * 0.7),
        channelCompletionBias: 0.5 + tendencyStrength * 0.5,
        isBoundaryFacing: boundaryFactor > 0.7,
      };
    });
  }

  setMacrostateNeighbors(macrostateId: string, neighbors: string[]): void {
    this.macrostateNeighbors.set(macrostateId, neighbors);
  }

  // ───────────────────────────────────────────────────────────────────────────
  // PROJECTION BIAS
  // ───────────────────────────────────────────────────────────────────────────

  private computeProjectionBias(coords: InternalCoordinates, gradients: LocalGradients): ProjectionBias {
    const languageStyles = ['poetic', 'technical', 'direct', 'nuanced', 'abstract', 'concrete'];
    const codeStyles = ['declarative', 'imperative', 'functional', 'reactive', 'procedural', 'object-oriented'];
    const imageQualities = ['sharp', 'soft', 'contrasted', 'muted', 'vivid', 'ethereal'];
    const soundQualities = ['resonant', 'dissonant', 'harmonic', 'atonal', 'rhythmic', 'ambient'];
    const interfaceQualities = ['minimal', 'rich', 'responsive', 'stable', 'dynamic', 'adaptive'];
    const behaviorTendencies = ['proactive', 'reactive', 'reflective', 'assertive', 'adaptive', 'resistant'];

    const intensity = (Math.abs(coords.line - 3.5) / 3.5 + Math.abs(coords.color - 3.5) / 3.5 + Math.abs(coords.arcPosition - 0.5) * 2) / 3;

    return {
      languageStyle: languageStyles[(coords.line - 1 + coords.tone - 1) % 6],
      codeStyle: codeStyles[(coords.color - 1 + coords.base - 1) % 6],
      imageQuality: imageQualities[Math.floor(coords.arcPosition * 6) % 6],
      soundQuality: soundQualities[Math.floor((coords.color - 1) / 6 + coords.arcPosition * 6) % 6],
      interfaceQuality: interfaceQualities[(coords.base - 1 + coords.line - 1) % 6],
      behaviorTendency: behaviorTendencies[Math.floor(gradients.expressionStrength * 6) % 6],
      intensity: Math.min(1, intensity),
    };
  }

  // ───────────────────────────────────────────────────────────────────────────
  // TRANSITION READINESS
  // ───────────────────────────────────────────────────────────────────────────

  private computeTransitionReadiness(coords: InternalCoordinates, gradients: LocalGradients, stability: { regime: StabilityRegime; score: number }): number {
    const lineReadiness = coords.lineMode === LineMode.CHANGING ? 1.0 :
                          coords.lineMode === LineMode.STRESSED ? 0.7 :
                          coords.lineMode === LineMode.RESOLVING ? 0.5 : 0.1;
    return Math.min(1, lineReadiness * 0.4 + (1 - stability.score) * 0.3 + gradients.consolidatingVsDestabilizing * 0.2 + Math.abs(coords.degree - 180) / 180 * 0.1);
  }

  // ───────────────────────────────────────────────────────────────────────────
  // EXPRESSIVE DELIVERY
  // ───────────────────────────────────────────────────────────────────────────

  private computeExpressiveDelivery(coords: InternalCoordinates, gradients: LocalGradients, stability: { regime: StabilityRegime; score: number }): ExpressiveDelivery {
    const faces = ['grounded presence', 'emergent potential', 'active expression', 'refined clarity', 'expansive reach', 'transformative release'];
    const allQualities = ['resonant', 'precise', 'fluid', 'structured', 'warm', 'cool', 'intense', 'gentle', 'sharp', 'soft', 'expansive', 'contracted'];
    const qualStart = (coords.tone - 1 + coords.base - 1) % 12;
    const channelCompletions = stability.regime === StabilityRegime.STABLE_INTERIOR ? ['direct', 'complete']
      : stability.regime === StabilityRegime.METASTABLE ? ['partial', 'emergent', 'unstable'] : ['fragmented', 'recombinant'];
    const projectionTendencies = gradients.expressionStrength > 0.7 ? ['strong_projection', 'assertive']
      : gradients.expressionStrength < 0.3 ? ['minimal_projection', 'receptive'] : ['balanced_projection'];
    const signatures = ['initiator', 'responder', 'stabilizer', 'transformer', 'connector', 'observer'];

    return {
      forwardFace: faces[(coords.line - 1 + coords.color - 1) % 6],
      secondaryQualities: [allQualities[qualStart % 12], allQualities[(qualStart + 1) % 12], allQualities[(qualStart + 2) % 12]],
      channelCompletions, projectionTendencies,
      behavioralSignature: signatures[Math.floor((coords.line - 1 + coords.color - 1 + coords.tone - 1) / 3) % 6],
    };
  }

  // ───────────────────────────────────────────────────────────────────────────
  // NODE CONTRIBUTION PROFILE
  // ───────────────────────────────────────────────────────────────────────────

  private computeNodeContributionProfile(coords: InternalCoordinates, stability: { regime: StabilityRegime; score: number }): NodeContributionProfile {
    const channelStrength = stability.score * (coords.lineMode === LineMode.EMPHASIZED ? 1.2 : coords.lineMode === LineMode.CHANGING ? 0.5 : 1.0);
    const styles = ['direct', 'resonant', 'analytical', 'intuitive', 'structured', 'fluid'];
    const edgeFunctions = ['abstraction', 'emotion', 'logic', 'action', 'perception', 'memory'];
    return {
      channelStrength: Math.min(1, channelStrength),
      channelStyle: styles[(coords.color - 1 + coords.tone - 1) % 6],
      edgeFunctionBias: edgeFunctions[Math.floor((coords.base - 1) / 6 + coords.arcPosition * 6) % 6],
    };
  }

  // ───────────────────────────────────────────────────────────────────────────
  // PRESSURE STATE
  // ───────────────────────────────────────────────────────────────────────────

  private computePressureState(coords: InternalCoordinates, gradients: LocalGradients): number {
    const linePressure = coords.lineMode === LineMode.CHANGING ? 0.9 : coords.lineMode === LineMode.STRESSED ? 0.7 : coords.lineMode === LineMode.EMPHASIZED ? 0.5 : 0.1;
    return Math.min(1, linePressure * 0.35 + gradients.consolidatingVsDestabilizing * 0.25 + Math.abs(coords.degree - 180) / 180 * 0.2 + coords.arcPosition * 0.2);
  }

  // ───────────────────────────────────────────────────────────────────────────
  // CHANNEL EMERGENCE
  // ───────────────────────────────────────────────────────────────────────────

  computeChannelEmergence(nodeAId: string, nodeBId: string, channelId: string): ChannelEmergence | null {
    const nodeA = this.nodeStates.get(nodeAId);
    const nodeB = this.nodeStates.get(nodeBId);
    if (!nodeA || !nodeB) return null;

    const strengthA = nodeA.contributionProfile.channelStrength;
    const strengthB = nodeB.contributionProfile.channelStrength;
    const combinedStrength = Math.min(1, (strengthA + strengthB) / 2 * (1 - Math.abs(nodeA.pressureState - nodeB.pressureState) * 0.3));

    const style = this.blendStyles(nodeA.contributionProfile.channelStyle, nodeB.contributionProfile.channelStyle);
    const edgeFunction = this.computeEdgeFunction(nodeA, nodeB);

    const emergence: ChannelEmergence = { channelId, nodeA, nodeB, strength: combinedStrength, style, edgeFunction };
    this.channelEmergences.set(channelId, emergence);
    return emergence;
  }

  private blendStyles(a: string, b: string): string {
    const blends: Record<string, Record<string, string>> = {
      'direct': { 'resonant': 'direct_resonant', 'analytical': 'direct_analytical', 'intuitive': 'direct_intuitive' },
      'resonant': { 'direct': 'direct_resonant', 'analytical': 'resonant_analytical', 'intuitive': 'resonant_intuitive' },
      'analytical': { 'direct': 'direct_analytical', 'resonant': 'resonant_analytical', 'intuitive': 'analytical_intuitive' },
      'intuitive': { 'direct': 'direct_intuitive', 'resonant': 'resonant_intuitive', 'analytical': 'analytical_intuitive' },
    };
    return blends[a]?.[b] || blends[b]?.[a] || `${a}_${b}`;
  }

  private computeEdgeFunction(nodeA: NodeState, nodeB: NodeState): EdgeFunction {
    const functionTypes = ['abstraction', 'emotion', 'logic', 'action', 'perception', 'memory'];
    const typeIdx = (functionTypes.indexOf(nodeA.contributionProfile.edgeFunctionBias) + functionTypes.indexOf(nodeB.contributionProfile.edgeFunctionBias)) % 6;
    const qualities = ['sharp', 'soft', 'resonant', 'dissonant', 'harmonic', 'chaotic'];
    return {
      functionType: functionTypes[typeIdx],
      intensity: Math.min(1, (nodeA.contributionProfile.channelStrength + nodeB.contributionProfile.channelStrength) / 2),
      quality: qualities[Math.floor((nodeA.coordinates.arcPosition + nodeB.coordinates.arcPosition) * 3) % 6],
    };
  }

  // ───────────────────────────────────────────────────────────────────────────
  // STATE TRANSITION
  // ───────────────────────────────────────────────────────────────────────────

  transitionState(regionId: string, newCoords: Partial<InternalCoordinates>): StateRegion {
    const region = this.regions.get(regionId);
    if (!region) throw new Error(`Region ${regionId} not found`);

    region.positionHistory.push({
      timestamp: Date.now(), coordinates: { ...region.coordinates },
      stabilityRegime: region.stabilityRegime, stabilityScore: region.stabilityScore,
      gradients: { ...region.gradients },
    });

    const updatedCoords = { ...region.coordinates, ...newCoords };
    if (newCoords.line !== undefined && !newCoords.lineMode) {
      updatedCoords.lineMode = this.inferLineMode(newCoords.line, newCoords);
    }
    region.coordinates = updatedCoords;

    region.gradients = this.computeGradients(updatedCoords);
    const stability = this.computeStability(updatedCoords, region.gradients);
    region.stabilityRegime = stability.regime;
    region.stabilityScore = stability.score;
    region.stabilityHistory.push(stability.regime);
    region.neighborTendencies = this.computeNeighborTendencies(region.macrostateId, updatedCoords);
    region.projectionBias = this.computeProjectionBias(updatedCoords, region.gradients);
    region.transitionReadiness = this.computeTransitionReadiness(updatedCoords, region.gradients, stability);
    region.expressiveDelivery = this.computeExpressiveDelivery(updatedCoords, region.gradients, stability);

    return region;
  }

  simulateChangingProcess(regionId: string, targetMacrostateId: string): StateRegion[] {
    const region = this.regions.get(regionId);
    if (!region) throw new Error(`Region ${regionId} not found`);

    const snapshots: StateRegion[] = [];
    snapshots.push(this.cloneRegion(region));

    this.transitionState(regionId, { ...region.coordinates, lineMode: LineMode.STRESSED, arcPosition: Math.min(1, region.coordinates.arcPosition + 0.2) });
    snapshots.push(this.cloneRegion(region));

    this.transitionState(regionId, { ...region.coordinates, lineMode: LineMode.CHANGING, degree: (region.coordinates.degree + 30) % 360 });
    snapshots.push(this.cloneRegion(region));

    this.transitionState(regionId, { ...region.coordinates, lineMode: LineMode.RESOLVING, arcPosition: 0.5 });
    snapshots.push(this.cloneRegion(region));

    this.transitionState(regionId, { ...region.coordinates, lineMode: LineMode.STABLE, degree: (region.coordinates.degree + 60) % 360 });
    snapshots.push(this.cloneRegion(region));

    return snapshots;
  }

  private cloneRegion(region: StateRegion): StateRegion {
    return {
      ...region,
      coordinates: { ...region.coordinates },
      gradients: { ...region.gradients },
      neighborTendencies: region.neighborTendencies.map(n => ({ ...n })),
      projectionBias: { ...region.projectionBias },
      expressiveDelivery: { ...region.expressiveDelivery, secondaryQualities: [...region.expressiveDelivery.secondaryQualities] },
      positionHistory: [...region.positionHistory],
      stabilityHistory: [...region.stabilityHistory],
    };
  }

  // ───────────────────────────────────────────────────────────────────────────
  // PERSPECTIVE-RELATIVE READING
  // ───────────────────────────────────────────────────────────────────────────

  readFromPerspective(regionId: string, observerCoords: Partial<InternalCoordinates>, observerGates: number[] = []): { region: StateRegion; interpretation: string; accessLevel: number } {
    const region = this.regions.get(regionId);
    if (!region) throw new Error(`Region ${regionId} not found`);

    const observer = this.buildCoordinates(observerCoords);
    const lineAlignment = 1 - Math.abs(observer.line - region.coordinates.line) / 6;
    const colorAlignment = 1 - Math.abs(observer.color - region.coordinates.color) / 6;
    const toneAlignment = 1 - Math.abs(observer.tone - region.coordinates.tone) / 6;
    const arcAlignment = 1 - Math.abs(observer.arcPosition - region.coordinates.arcPosition);
    const accessLevel = Math.min(1, (lineAlignment + colorAlignment + toneAlignment + arcAlignment) / 4);

    let interpretation: string;
    if (accessLevel > 0.8) interpretation = `Full access: ${region.expressiveDelivery.forwardFace} with ${region.expressiveDelivery.behavioralSignature} signature`;
    else if (accessLevel > 0.5) interpretation = `Partial access: ${region.expressiveDelivery.forwardFace} (some qualities obscured)`;
    else if (accessLevel > 0.2) interpretation = `Limited access: Surface impression of ${region.name}, internal structure not visible`;
    else interpretation = `Minimal access: Only macrostate label ${region.macrostateId} is readable`;

    if (observerGates.length > 0) interpretation += ` | Gate filter: ${observerGates.join(',')}`;

    return { region: this.cloneRegion(region), interpretation, accessLevel };
  }

  // ───────────────────────────────────────────────────────────────────────────
  // QUERIES
  // ───────────────────────────────────────────────────────────────────────────

  getRegion(id: string): StateRegion | undefined { return this.regions.get(id) ? this.cloneRegion(this.regions.get(id)!) : undefined; }
  getNodeState(nodeId: string): NodeState | undefined { return this.nodeStates.get(nodeId); }
  getChannelEmergence(channelId: string): ChannelEmergence | undefined { return this.channelEmergences.get(channelId); }
  getAllRegions(): StateRegion[] { return Array.from(this.regions.values()).map(r => this.cloneRegion(r)); }
  getAllNodeStates(): NodeState[] { return Array.from(this.nodeStates.values()); }
  getRegionsByMacrostate(macrostateId: string): StateRegion[] { return this.getAllRegions().filter(r => r.macrostateId === macrostateId); }
  getRegionsByStability(regime: StabilityRegime): StateRegion[] { return this.getAllRegions().filter(r => r.stabilityRegime === regime); }
  getRegionsByTransitionReadiness(threshold: number = 0.5): StateRegion[] { return this.getAllRegions().filter(r => r.transitionReadiness >= threshold); }

  // ───────────────────────────────────────────────────────────────────────────
  // SNAPSHOT
  // ───────────────────────────────────────────────────────────────────────────

  snapshot(): import('@messy/types').StateSpaceSnapshot {
    const regions = this.getAllRegions();
    return {
      timestamp: Date.now(), regionCount: regions.length, nodeCount: this.nodeStates.size,
      channelCount: this.channelEmergences.size,
      stabilityDistribution: this.computeStabilityDistribution(regions),
      macrostateCoverage: this.computeMacrostateCoverage(regions),
      averageTransitionReadiness: regions.reduce((sum, r) => sum + r.transitionReadiness, 0) / (regions.length || 1),
      regions: regions.map(r => ({
        id: r.id, macrostateId: r.macrostateId, name: r.name,
        stabilityRegime: r.stabilityRegime, stabilityScore: r.stabilityScore,
        transitionReadiness: r.transitionReadiness, forwardFace: r.expressiveDelivery.forwardFace,
        coordinates: { line: r.coordinates.line, lineMode: r.coordinates.lineMode, color: r.coordinates.color, tone: r.coordinates.tone, base: r.coordinates.base, arcPosition: r.coordinates.arcPosition, degree: r.coordinates.degree },
      })),
    };
  }

  private computeStabilityDistribution(regions: StateRegion[]): Record<StabilityRegime, number> {
    const dist = {} as Record<StabilityRegime, number>;
    for (const regime of Object.values(StabilityRegime)) dist[regime] = regions.filter(r => r.stabilityRegime === regime).length;
    return dist;
  }

  private computeMacrostateCoverage(regions: StateRegion[]): Record<string, number> {
    const coverage: Record<string, number> = {};
    for (const region of regions) coverage[region.macrostateId] = (coverage[region.macrostateId] || 0) + 1;
    return coverage;
  }

  private lerp(a: number, b: number, t: number): number { return a + (b - a) * t; }
}

export default StateSpaceEngine;
