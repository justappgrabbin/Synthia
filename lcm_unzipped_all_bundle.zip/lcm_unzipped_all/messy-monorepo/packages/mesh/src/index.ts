/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/mesh — THE LIVING RELATION FIELD                    ║
 * ║                                                                               ║
 * ║  "The mesh is not merely a transport layer. It is the generative relational  ║
 * ║   field through which states are qualified, routed, morphed, converged,      ║
 * ║   and expressed."                                                            ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import {
  QualifiedMessage, Organ, Center, Channel, Edge, GateContext,
  MorphRule, MorphEvent, MorphChange, ConvergenceState, ConvergentQuality,
  MeshEvent, MeshEventType, Stratum, DimensionalContext, LineColorToneBase,
  MeshSnapshot, OrganState, CenterState, ConvergenceLevel, EdgeState,
} from '@messy/types';

export * from '@messy/types';

// ═══════════════════════════════════════════════════════════════════════════════
// MESH ENGINE
// ═══════════════════════════════════════════════════════════════════════════════

export class MeshEngine {
  private organs: Map<string, Organ> = new Map();
  private centers: Map<string, Center> = new Map();
  private channels: Map<string, Channel> = new Map();
  private edges: Map<string, Edge> = new Map();
  private messages: Map<string, QualifiedMessage> = new Map();
  private identityCenterId: string | null = null;
  private eventLog: MeshEvent[] = [];
  private eventListeners: ((event: MeshEvent) => void)[] = [];
  private stats = {
    messagesQualified: 0, messagesRouted: 0, channelsTraversed: 0, edgesFormed: 0,
    edgesStrengthened: 0, organsMorphed: 0, centersActivated: 0,
    convergencesPartial: 0, convergencesFull: 0, projectionsExpressed: 0, recursionsTriggered: 0,
  };

  registerOrgan(organ: Organ): void {
    this.organs.set(organ.id, organ);
    this.emitEvent({ type: 'organ_morphed', timestamp: Date.now(), organId: organ.id, details: { action: 'registered', state: organ.state } });
  }

  registerCenter(center: Center): void {
    this.centers.set(center.id, center);
    if (center.isIdentityCenter) this.identityCenterId = center.id;
    this.emitEvent({ type: 'center_activated', timestamp: Date.now(), centerId: center.id, details: { action: 'registered', isIdentity: center.isIdentityCenter } });
  }

  registerChannel(channel: Channel): void { this.channels.set(channel.id, channel); }

  // ───────────────────────────────────────────────────────────────────────────
  // RULE 1: All subsystems communicate through the mesh
  // RULE 2: All live messages are qualified, not raw
  // ───────────────────────────────────────────────────────────────────────────

  send(content: unknown, qualification: Partial<QualifiedMessage>): QualifiedMessage {
    const msg = this.qualifyMessage(content, qualification);
    this.messages.set(msg.id, msg);
    this.stats.messagesQualified++;
    this.emitEvent({ type: 'message_qualified', timestamp: Date.now(), messageId: msg.id, details: { sourceOrgan: msg.sourceOrgan, stratum: msg.stratum } });
    this.route(msg);
    return msg;
  }

  private qualifyMessage(content: unknown, qualification: Partial<QualifiedMessage>): QualifiedMessage {
    const now = Date.now();
    const id = `msg_${now}_${Math.random().toString(36).substr(2, 9)}`;
    return {
      id, content, timestamp: now,
      sourceOrgan: qualification.sourceOrgan || 'unknown',
      sourceCenter: qualification.sourceCenter || 'unknown',
      targetCenter: qualification.targetCenter,
      targetOrgan: qualification.targetOrgan,
      activeGates: qualification.activeGates || [],
      activeChannels: qualification.activeChannels || [],
      dimensionContext: qualification.dimensionContext || {},
      lctb: qualification.lctb || {},
      planetaryInfluence: qualification.planetaryInfluence,
      arcModulation: qualification.arcModulation,
      stratum: qualification.stratum || Stratum.MIND,
      stratumTarget: qualification.stratumTarget,
      recursionDepth: qualification.recursionDepth ?? 0,
      maxRecursionDepth: qualification.maxRecursionDepth ?? 5,
      userAlignmentContext: qualification.userAlignmentContext,
      traversalPath: qualification.traversalPath || [],
      edgesFormed: qualification.edgesFormed || [],
      convergenceState: qualification.convergenceState,
      morphEffects: qualification.morphEffects || [],
      identityAlignmentWeight: qualification.identityAlignmentWeight ?? 0.5,
      isFromBridge: qualification.isFromBridge ?? false,
      bridgeId: qualification.bridgeId,
      status: 'routing',
      projectionReady: false,
      metadata: qualification.metadata || {},
    };
  }

  // ───────────────────────────────────────────────────────────────────────────
  // RULE 3: Traversal path changes meaning
  // RULE 9: Identity Center is a privileged routing and alignment hub
  // ───────────────────────────────────────────────────────────────────────────

  private route(msg: QualifiedMessage): void {
    msg.status = 'routing';
    if (this.identityCenterId) {
      const identityCenter = this.centers.get(this.identityCenterId)!;
      const alignedMsg = this.applyIdentityRouting(msg, identityCenter);
      msg = alignedMsg;
    }
    const targetCenterId = msg.targetCenter;
    const targetOrganId = msg.targetOrgan;
    if (targetCenterId) this.routeToCenter(msg, targetCenterId);
    else if (targetOrganId) this.routeToOrgan(msg, targetOrganId);
    else this.broadcastRoute(msg);
    this.stats.messagesRouted++;
    this.emitEvent({ type: 'message_routed', timestamp: Date.now(), messageId: msg.id, details: { path: msg.traversalPath } });
  }

  private applyIdentityRouting(msg: QualifiedMessage, identityCenter: Center): QualifiedMessage {
    const alignmentBoost = identityCenter.alignmentWeight;
    msg.identityAlignmentWeight = Math.min(1, msg.identityAlignmentWeight + alignmentBoost * 0.3);
    if (msg.userAlignmentContext) msg.metadata.identityRouted = true;
    this.emitEvent({ type: 'identity_routing', timestamp: Date.now(), messageId: msg.id, centerId: identityCenter.id, details: { alignmentWeight: msg.identityAlignmentWeight } });
    return msg;
  }

  private routeToCenter(msg: QualifiedMessage, centerId: string): void {
    const center = this.centers.get(centerId);
    if (!center) return;
    msg.traversalPath.push(centerId);
    for (const channelId of center.connectedChannels) {
      const channel = this.channels.get(channelId);
      if (channel && channel.isActive) this.traverseChannel(msg, channel);
    }
    this.activateCenter(center, msg);
  }

  private routeToOrgan(msg: QualifiedMessage, organId: string): void {
    const organ = this.organs.get(organId);
    if (!organ) return;
    msg.traversalPath.push(organId);
    for (const [channelId, channel] of this.channels) {
      if (channel.target === organId && channel.isActive) this.traverseChannel(msg, channel);
    }
    this.deliverToOrgan(msg, organ);
  }

  private broadcastRoute(msg: QualifiedMessage): void {
    for (const [_, channel] of this.channels) {
      if (channel.isActive && channel.stratum === msg.stratum) this.traverseChannel(msg, channel);
    }
  }

  // ───────────────────────────────────────────────────────────────────────────
  // RULE 5: Channels define relation quality, not just adjacency
  // ───────────────────────────────────────────────────────────────────────────

  private traverseChannel(msg: QualifiedMessage, channel: Channel): void {
    msg.status = 'traversing';
    channel.traversalCount++;
    this.stats.channelsTraversed++;
    msg.traversalPath.push(channel.id);
    msg.metadata.channelQuality = channel.quality;
    msg.metadata.channelDomain = channel.domainFunction;
    if (channel.stratum !== msg.stratum) {
      msg.stratumTarget = channel.stratum;
      msg.metadata.stratumTransition = `${msg.stratum} → ${channel.stratum}`;
    }
    const edge = this.formOrStrengthenEdge(channel.source, channel.target, channel.id, msg.stratum);
    msg.edgesFormed.push(edge.id);
    this.emitEvent({ type: 'channel_traversed', timestamp: Date.now(), messageId: msg.id, channelId: channel.id, details: { quality: channel.quality, stratum: channel.stratum } });
    const targetOrgan = this.organs.get(channel.target);
    if (targetOrgan) this.deliverToOrgan(msg, targetOrgan);
    const targetCenter = this.centers.get(channel.target);
    if (targetCenter) this.activateCenter(targetCenter, msg);
  }

  // ───────────────────────────────────────────────────────────────────────────
  // RULE 6: Edges record relational becoming
  // ───────────────────────────────────────────────────────────────────────────

  private formOrStrengthenEdge(source: string, target: string, channelId: string, stratum: Stratum): Edge {
    const edgeId = `edge_${source}_${target}_${channelId}`;
    let edge = this.edges.get(edgeId);
    const now = Date.now();
    if (!edge) {
      edge = { id: edgeId, source, target, channelId, state: 'ephemeral', weight: 0.1, traversalCount: 1, lastTraversal: now, createdAt: now, stratum, metadata: {} };
      this.edges.set(edgeId, edge);
      this.stats.edgesFormed++;
      const sourceOrgan = this.organs.get(source);
      const targetOrgan = this.organs.get(target);
      if (sourceOrgan) sourceOrgan.outgoingEdges.add(edgeId);
      if (targetOrgan) targetOrgan.incomingEdges.add(edgeId);
      this.emitEvent({ type: 'edge_formed', timestamp: now, edgeId, details: { source, target, channelId } });
    } else {
      edge.traversalCount++;
      edge.weight = Math.min(1, edge.weight + 0.05);
      edge.lastTraversal = now;
      if (edge.weight > 0.5) edge.state = 'strengthening';
      if (edge.traversalCount > 10) edge.state = 'persistent';
      this.stats.edgesStrengthened++;
      this.emitEvent({ type: 'edge_strengthened', timestamp: now, edgeId, details: { newWeight: edge.weight, traversalCount: edge.traversalCount } });
    }
    return edge;
  }

  // ───────────────────────────────────────────────────────────────────────────
  // RULE 4: Receiving a message may morph the receiver
  // ───────────────────────────────────────────────────────────────────────────

  private deliverToOrgan(msg: QualifiedMessage, organ: Organ): void {
    msg.status = 'morphing';
    organ.receivedMessages.push(msg);
    organ.lastActivated = Date.now();
    organ.activationLevel = Math.min(1, organ.activationLevel + 0.1);
    const morphEvent = this.applyMorphing(msg, organ);
    if (morphEvent) {
      msg.morphEffects.push(morphEvent);
      this.stats.organsMorphed++;
      this.emitEvent({ type: 'organ_morphed', timestamp: Date.now(), organId: organ.id, messageId: msg.id, details: { changes: morphEvent.changes.length } });
    }
    this.checkRecursion(msg, organ);
  }

  private applyMorphing(msg: QualifiedMessage, organ: Organ): MorphEvent | null {
    const sortedRules = [...organ.morphRules].sort((a, b) => b.priority - a.priority);
    for (const rule of sortedRules) {
      if (rule.condition(msg, organ)) {
        const morphEvent = rule.effect(msg, organ);
        morphEvent.recursionDepth = msg.recursionDepth;
        organ.morphHistory.push(morphEvent);
        for (const change of morphEvent.changes) (organ as any)[change.field] = change.to;
        return morphEvent;
      }
    }
    return this.applyDefaultMorphing(msg, organ);
  }

  private applyDefaultMorphing(msg: QualifiedMessage, organ: Organ): MorphEvent | null {
    const now = Date.now();
    const changes: MorphChange[] = [];
    if (organ.activationLevel > 0.7 && organ.state !== 'active') {
      changes.push({ field: 'state', from: organ.state, to: 'active', reason: 'High activation from qualified traversal' });
      organ.state = 'active';
    }
    for (const gate of msg.activeGates) {
      if (!organ.activeGates.has(gate.gateNumber)) {
        organ.activeGates.add(gate.gateNumber);
        changes.push({ field: 'activeGates', from: [...organ.activeGates], to: [...organ.activeGates], reason: `Gate ${gate.gateNumber} activated by message qualification` });
      }
    }
    if (changes.length === 0) return null;
    const morphEvent: MorphEvent = {
      id: `morph_${now}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: now, triggerMessageId: msg.id, organId: organ.id, changes, ruleId: 'default', recursionDepth: msg.recursionDepth,
    };
    organ.morphHistory.push(morphEvent);
    return morphEvent;
  }

  // ───────────────────────────────────────────────────────────────────────────
  // RULE 8: Centers may be dynamically stabilized through traversal
  // ───────────────────────────────────────────────────────────────────────────

  private activateCenter(center: Center, msg: QualifiedMessage): void {
    center.activationHistory.push(Date.now());
    center.formationScore = Math.min(1, center.formationScore + 0.05);
    if (center.state === 'latent' && center.formationScore > 0.3) {
      center.state = 'modulating';
      this.emitEvent({ type: 'center_modulated', timestamp: Date.now(), centerId: center.id, details: { from: 'latent', to: 'modulating', formationScore: center.formationScore } });
    }
    if (center.state === 'modulating' && center.formationScore > 0.7) {
      center.state = 'expressed';
      this.emitEvent({ type: 'center_activated', timestamp: Date.now(), centerId: center.id, details: { from: 'modulating', to: 'expressed', formationScore: center.formationScore } });
      this.stats.centersActivated++;
    }
    if (center.isIdentityCenter) msg.identityAlignmentWeight = Math.min(1, msg.identityAlignmentWeight + 0.2);
  }

  // ───────────────────────────────────────────────────────────────────────────
  // RULE 7: Convergence may be partial
  // ───────────────────────────────────────────────────────────────────────────

  converge(msg: QualifiedMessage): void {
    msg.status = 'converging';
    for (const [centerId, center] of this.centers) {
      const recentMessages = center.activationHistory.filter(t => Date.now() - t < 5000);
      if (recentMessages.length >= 2) {
        const convergence: ConvergenceState = {
          level: recentMessages.length >= 5 ? 'full' : 'partial',
          contributingMessages: [msg.id], contributingChannels: [...center.connectedChannels],
          contributingEdges: [...center.incomingEdges],
          qualities: this.generateConvergentQualities(msg, center), centerId, timestamp: Date.now(),
        };
        msg.convergenceState = convergence;
        center.convergenceLevel = convergence.level;
        center.convergentQualities = convergence.qualities;
        if (convergence.level === 'full') { this.stats.convergencesFull++; this.emitEvent({ type: 'convergence_full', timestamp: Date.now(), centerId, messageId: msg.id, details: { qualities: convergence.qualities.length } }); }
        else { this.stats.convergencesPartial++; this.emitEvent({ type: 'convergence_partial', timestamp: Date.now(), centerId, messageId: msg.id, details: { level: convergence.level } }); }
        if (convergence.level === 'full' || convergence.level === 'graded') {
          msg.projectionReady = true;
          this.emitEvent({ type: 'projection_ready', timestamp: Date.now(), messageId: msg.id, details: { convergenceLevel: convergence.level } });
        }
      }
    }
  }

  private generateConvergentQualities(msg: QualifiedMessage, center: Center): ConvergentQuality[] {
    const colorMap: Record<Stratum, string> = { [Stratum.HEART]: 'warm crimson', [Stratum.MIND]: 'electric blue', [Stratum.ACTION]: 'golden amber' };
    const qualities: ConvergentQuality[] = [{ color: colorMap[msg.stratum], intensity: msg.dimensionContext.d5_meaning || 0.5 }];
    if (msg.dimensionContext.d2_polarity !== undefined) qualities.push({ tone: msg.dimensionContext.d2_polarity > 0.5 ? 'ascending' : 'descending', intensity: msg.dimensionContext.d2_polarity });
    if (msg.activeGates.length > 0) qualities.push({ stateEmphasis: `gate-${msg.activeGates[0].gateNumber}`, intensity: 0.7 });
    return qualities;
  }

  // ───────────────────────────────────────────────────────────────────────────
  // RULE 11: Recursion is canonical
  // ───────────────────────────────────────────────────────────────────────────

  private checkRecursion(msg: QualifiedMessage, organ: Organ): void {
    if (msg.recursionDepth >= msg.maxRecursionDepth) return;
    const shouldRecurse = organ.activationLevel > 0.8 || msg.activeGates.some(g => g.isActive) || (msg.dimensionContext.d5_meaning !== undefined && msg.dimensionContext.d5_meaning > 0.8);
    if (shouldRecurse) {
      this.stats.recursionsTriggered++;
      const recursiveMsg = this.qualifyMessage(
        { parentMessageId: msg.id, recursive: true },
        { sourceOrgan: organ.id, sourceCenter: msg.sourceCenter, stratum: msg.stratum, recursionDepth: msg.recursionDepth + 1, maxRecursionDepth: msg.maxRecursionDepth, activeGates: msg.activeGates, dimensionContext: msg.dimensionContext, metadata: { ...msg.metadata, recursiveTrigger: true } }
      );
      this.messages.set(recursiveMsg.id, recursiveMsg);
      this.emitEvent({ type: 'recursion_triggered', timestamp: Date.now(), messageId: msg.id, details: { recursiveMessageId: recursiveMsg.id, depth: recursiveMsg.recursionDepth } });
      this.route(recursiveMsg);
    }
  }

  // ───────────────────────────────────────────────────────────────────────────
  // RULE 12: Projection follows qualified traversal
  // ───────────────────────────────────────────────────────────────────────────

  express(msg: QualifiedMessage): unknown {
    if (!msg.projectionReady && msg.convergenceState?.level !== 'full') this.converge(msg);
    if (!msg.projectionReady) return { status: 'not_ready', reason: 'Insufficient relational qualification for projection', messageId: msg.id, traversalPath: msg.traversalPath };
    msg.status = 'expressed';
    this.stats.projectionsExpressed++;
    const expression = {
      status: 'expressed', messageId: msg.id, content: msg.content, stratum: msg.stratum, stratumTarget: msg.stratumTarget,
      convergenceLevel: msg.convergenceState?.level, qualities: msg.convergenceState?.qualities,
      morphEffects: msg.morphEffects.map(m => ({ organId: m.organId, changes: m.changes.map(c => ({ field: c.field, to: c.to })) })),
      traversalPath: msg.traversalPath, edgesFormed: msg.edgesFormed.length, identityAlignment: msg.identityAlignmentWeight,
      recursionDepth: msg.recursionDepth, metadata: msg.metadata,
    };
    this.emitEvent({ type: 'projection_expressed', timestamp: Date.now(), messageId: msg.id, details: { expression } });
    return expression;
  }

  // ───────────────────────────────────────────────────────────────────────────
  // RULE 10: External bridges participate but do not define truth
  // ───────────────────────────────────────────────────────────────────────────

  connectBridge(bridgeId: string, bridgeType: string, organId: string): void {
    const organ = this.organs.get(organId);
    if (!organ) return;
    organ.isExternal = true;
    organ.bridgeType = bridgeType as any;
    this.emitEvent({ type: 'bridge_connected', timestamp: Date.now(), organId, details: { bridgeId, bridgeType } });
  }

  disconnectBridge(organId: string): void {
    const organ = this.organs.get(organId);
    if (!organ) return;
    organ.isExternal = false;
    organ.bridgeType = undefined;
    this.emitEvent({ type: 'bridge_disconnected', timestamp: Date.now(), organId, details: {} });
  }

  // ───────────────────────────────────────────────────────────────────────────
  // EVENT SYSTEM
  // ───────────────────────────────────────────────────────────────────────────

  onEvent(listener: (event: MeshEvent) => void): () => void {
    this.eventListeners.push(listener);
    return () => { const idx = this.eventListeners.indexOf(listener); if (idx >= 0) this.eventListeners.splice(idx, 1); };
  }

  private emitEvent(event: MeshEvent): void {
    this.eventLog.push(event);
    for (const listener of this.eventListeners) { try { listener(event); } catch (e) {} }
  }

  getEvents(): MeshEvent[] { return [...this.eventLog]; }
  getEventsByType(type: MeshEventType): MeshEvent[] { return this.eventLog.filter(e => e.type === type); }

  // ───────────────────────────────────────────────────────────────────────────
  // QUERIES
  // ───────────────────────────────────────────────────────────────────────────

  getOrgan(id: string): Organ | undefined { return this.organs.get(id); }
  getCenter(id: string): Center | undefined { return this.centers.get(id); }
  getChannel(id: string): Channel | undefined { return this.channels.get(id); }
  getEdge(id: string): Edge | undefined { return this.edges.get(id); }
  getMessage(id: string): QualifiedMessage | undefined { return this.messages.get(id); }
  getAllOrgans(): Organ[] { return Array.from(this.organs.values()); }
  getAllCenters(): Center[] { return Array.from(this.centers.values()); }
  getAllChannels(): Channel[] { return Array.from(this.channels.values()); }
  getAllEdges(): Edge[] { return Array.from(this.edges.values()); }
  getAllMessages(): QualifiedMessage[] { return Array.from(this.messages.values()); }
  getStats() { return { ...this.stats }; }

  snapshot(): MeshSnapshot {
    return {
      timestamp: Date.now(), organCount: this.organs.size, centerCount: this.centers.size,
      channelCount: this.channels.size, edgeCount: this.edges.size, messageCount: this.messages.size,
      identityCenterId: this.identityCenterId, stats: { ...this.stats },
      organs: Array.from(this.organs.values()).map(o => ({ id: o.id, name: o.name, state: o.state, activationLevel: o.activationLevel, activeGates: Array.from(o.activeGates), stratum: o.stratum, isExternal: o.isExternal })),
      centers: Array.from(this.centers.values()).map(c => ({ id: c.id, name: c.name, state: c.state, isIdentityCenter: c.isIdentityCenter, formationScore: c.formationScore, convergenceLevel: c.convergenceLevel })),
      edges: Array.from(this.edges.values()).map(e => ({ id: e.id, source: e.source, target: e.target, state: e.state, weight: e.weight, traversalCount: e.traversalCount })),
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// FACTORY HELPERS
// ═══════════════════════════════════════════════════════════════════════════════

export function createOrgan(id: string, name: string, stratum: Stratum = Stratum.MIND, options: Partial<Organ> = {}): Organ {
  return {
    id, name, state: 'latent', activeGates: new Set(), activeCenters: new Set(),
    mode: 'default', projectionPreference: 'neutral', routingBehavior: 'default', responseStyle: 'balanced',
    stratum, isExternal: false, morphRules: [], receivedMessages: [], morphHistory: [],
    incomingEdges: new Set(), outgoingEdges: new Set(), activationLevel: 0, lastActivated: 0, ...options,
  };
}

export function createCenter(id: string, name: string, stratum: Stratum = Stratum.MIND, isIdentityCenter: boolean = false): Center {
  return {
    id, name, state: 'latent', stratum, connectedOrgans: new Set(), connectedChannels: new Set(),
    incomingEdges: new Set(), convergenceLevel: 'none', isIdentityCenter, formationScore: 0,
    projectionStyle: 'default', alignmentWeight: isIdentityCenter ? 0.9 : 0.5, convergentQualities: [], activationHistory: [],
  };
}

export function createChannel(id: string, name: string, source: string, target: string, stratum: Stratum = Stratum.MIND, quality: string = 'relation', options: Partial<Channel> = {}): Channel {
  return { id, name, source, target, stratum, quality, isActive: true, traversalCount: 0, weight: 0.5, bidirectional: false, createdAt: Date.now(), ...options };
}

export function createMorphRule(id: string, condition: (msg: QualifiedMessage, organ: Organ) => boolean, effect: (msg: QualifiedMessage, organ: Organ) => MorphEvent, priority: number = 0, triggerGate?: number, triggerChannel?: string, triggerStratum?: Stratum): MorphRule {
  return { id, triggerGate, triggerChannel, triggerStratum, condition, effect, priority };
}

export default MeshEngine;
