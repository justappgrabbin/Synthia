/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/self-supervised — LEARNING ENGINE                   ║
 * ║                                                                               ║
 * ║  Self-supervised learning that evolves pattern weights, thresholds, and       ║
 * ║  capabilities from success and failure.                                     ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import { LearningEpisode, PatternWeight, GateContext, InternalCoordinates } from '@messy/types';

export class SelfSupervisedEngine {
  private episodes: LearningEpisode[] = [];
  private patternWeights: Map<string, PatternWeight> = new Map();
  private threshold: number = 0.5;
  private capabilityExtractors: Map<string, (episode: LearningEpisode) => string[]> = new Map();

  recordEpisode(episode: LearningEpisode): void {
    this.episodes.push(episode);
    this.updatePatternWeights(episode);
    this.evolveThreshold();
  }

  private updatePatternWeights(episode: LearningEpisode): void {
    const pattern = this.extractPattern(episode);
    const existing = this.patternWeights.get(pattern);
    if (existing) {
      if (episode.error < 0.1) {
        existing.successCount++;
        existing.weight = Math.min(1, existing.weight + 0.05);
      } else {
        existing.failureCount++;
        existing.weight = Math.max(0, existing.weight - 0.03);
      }
      existing.lastUpdated = Date.now();
    } else {
      this.patternWeights.set(pattern, {
        pattern, weight: episode.error < 0.1 ? 0.6 : 0.4,
        successCount: episode.error < 0.1 ? 1 : 0,
        failureCount: episode.error < 0.1 ? 0 : 1,
        lastUpdated: Date.now(),
      });
    }
  }

  private extractPattern(episode: LearningEpisode): string {
    const gate = episode.gateContext.gateNumber;
    const line = episode.stateContext.line;
    return `gate_${gate}_line_${line}`;
  }

  private evolveThreshold(): void {
    const recent = this.episodes.slice(-100);
    const avgError = recent.reduce((sum, e) => sum + e.error, 0) / (recent.length || 1);
    this.threshold = 0.3 + avgError * 0.7;
  }

  getPatternWeight(pattern: string): number {
    return this.patternWeights.get(pattern)?.weight || 0.5;
  }

  getTopPatterns(count: number = 10): PatternWeight[] {
    return Array.from(this.patternWeights.values())
      .sort((a, b) => b.weight - a.weight)
      .slice(0, count);
  }

  getLearningStats(): { totalEpisodes: number; averageError: number; threshold: number; patternCount: number } {
    const avgError = this.episodes.reduce((sum, e) => sum + e.error, 0) / (this.episodes.length || 1);
    return { totalEpisodes: this.episodes.length, averageError, threshold: this.threshold, patternCount: this.patternWeights.size };
  }

  spawnSubsystem(episode: LearningEpisode): string | null {
    if (episode.error < 0.05 && this.episodes.length > 50) {
      const pattern = this.extractPattern(episode);
      const weight = this.getPatternWeight(pattern);
      if (weight > 0.8) {
        return `subsystem_${pattern}_${Date.now()}`;
      }
    }
    return null;
  }
}

export default SelfSupervisedEngine;
