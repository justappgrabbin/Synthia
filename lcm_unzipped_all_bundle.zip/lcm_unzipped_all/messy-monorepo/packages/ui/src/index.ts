/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/ui — SHARED UI COMPONENTS                           ║
 * ║                                                                               ║
 * ║  UI components for the browser shell and runtime visualization.             ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

export interface UIComponent {
  id: string;
  type: 'panel' | 'node' | 'edge' | 'message' | 'center' | 'control';
  render: () => HTMLElement | string;
  update: (data: unknown) => void;
}

export class UIManager {
  private components: Map<string, UIComponent> = new Map();
  private container: HTMLElement | null = null;

  mount(container: HTMLElement): void {
    this.container = container;
  }

  register(component: UIComponent): void {
    this.components.set(component.id, component);
    if (this.container) {
      const rendered = component.render();
      if (typeof rendered === 'string') {
        const div = document.createElement('div');
        div.innerHTML = rendered;
        this.container.appendChild(div);
      } else {
        this.container.appendChild(rendered);
      }
    }
  }

  update(componentId: string, data: unknown): void {
    const component = this.components.get(componentId);
    if (component) component.update(data);
  }

  getComponent(id: string): UIComponent | undefined { return this.components.get(id); }
}

export default UIManager;
