/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                         @messy/types — SHARED TYPE SYSTEM                    ║
 * ║                                                                               ║
 * ║  The canonical type system for the entire organism.                           ║
 * ║  Every package imports from here. No package defines its own duplicates.      ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

// ───────────────────────────────────────────────────────────────────────────────
// ONTOLOGICAL PRIMITIVES
// ───────────────────────────────────────────────────────────────────────────────

/** 64 canonical gates / hexagram nodes */
export type GateNumber = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
  11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 |
  21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 |
  31 | 32 | 33 | 34 | 35 | 36 | 37 | 38 | 39 | 40 |
  41 | 42 | 43 | 44 | 45 | 46 | 47 | 48 | 49 | 50 |
  51 | 52 | 53 | 54 | 55 | 56 | 57 | 58 | 59 | 60 |
  61 | 62 | 63 | 64;

/** 36 canonical channels */
export type ChannelNumber = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
  11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 |
  21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 |
  31 | 32 | 33 | 34 | 35 | 36;

/** 9 centers */
export type CenterId =
  | 'head' | 'ajna' | 'throat' | 'ego' | 'sacral'
  | 'solar' | 'spleen' | 'root' | 'g';

/** 13 planetary influences */
export type PlanetaryInfluence =
  | 'sun' | 'earth' | 'moon' | 'north-node' | 'south-node'
  | 'mercury' | 'venus' | 'mars' | 'jupiter' | 'saturn'
  | 'uranus' | 'neptune' | 'pluto';

/** The five dimensions */
export type Dimension = 'movement' | 'evolution' | 'being' | 'design' | 'space';

export const DIMENSIONS: Dimension[] = ['movement', 'evolution', 'being', 'design', 'space'];

export const DIMENSION_CORRESPONDENCE: Record<Dimension, { center: string; phrase: string }> = {
  movement: { center: 'individuality', phrase: 'I Define' },
  evolution: { center: 'mind', phrase: 'I Remember' },
  being: { center: 'body', phrase: 'I Am' },
  design: { center: 'ego', phrase: 'I Design' },
  space: { center: 'personality', phrase: 'I Think' },
};

// ───────────────────────────────────────────────────────────────────────────────
// STRATA
// ───────────────────────────────────────────────────────────────────────────────

export enum Stratum {
  HEART = 'heart',       // Direction, purpose, alignment
  MIND = 'mind',         // Structure, code, logic
  ACTION = 'action',       // Embodiment, interface, image
}

export const STRATA_ORDER: Stratum[] = [Stratum.HEART, Stratum.MIND, Stratum.ACTION];

// ───────────────────────────────────────────────────────────────────────────────
// INTERNAL COORDINATES (State Space Mechanics)
// ───────────────────────────────────────────────────────────────────────────────

export enum LineMode {
  STABLE = 'stable',
  EMPHASIZED = 'emphasized',
  STRESSED = 'stressed',
  CHANGING = 'changing',
  RESOLVING = 'resolving',
}

export enum StabilityRegime {
  STABLE_INTERIOR = 'stable_interior',
  THRESHOLD = 'threshold',
  METASTABLE = 'metastable',
  INSTABILITY_RIDGE = 'instability_ridge',
  CHANGING_REGIME = 'changing_regime',
  RESOLVING = 'resolving',
}

export interface InternalCoordinates {
  line: number;              // 1-6
  lineMode: LineMode;
  color: number;             // 1-6
  tone: number;              // 1-6
  base: number;              // 1-6 (note: ontology says 5 bases, but mechanics uses 6)
  arcPosition: number;       // 0-1 continuous
  degree: number;            // 0-360
  minute: number;            // 0-60
  second: number;            // 0-60
}

export interface LocalGradients {
  expressionStrength: number;       // 0-1: weaker → stronger
  inwardVsOutward: number;          // 0-1: inward → outward
  receptiveVsProjective: number;    // 0-1: receptive → projective
  consolidatingVsDestabilizing: number; // 0-1: consolidating → destabilizing
  narrowVsDiffuse: number;          // 0-1: narrow → diffuse
}

export interface ProjectionBias {
  languageStyle: string;
  codeStyle: string;
  imageQuality: string;
  soundQuality: string;
  interfaceQuality: string;
  behaviorTendency: string;
  intensity: number;            // 0-1
}

export interface ExpressiveDelivery {
  forwardFace: string;
  secondaryQualities: string[];
  channelCompletions: string[];
  projectionTendencies: string[];
  behavioralSignature: string;
}

// ───────────────────────────────────────────────────────────────────────────────
// MESH TYPES
// ───────────────────────────────────────────────────────────────────────────────

export type EdgeState = 'ephemeral' | 'persistent' | 'strengthening' | 'weakening' | 'convergent' | 'dormant';
export type OrganState = 'latent' | 'modulating' | 'expressed' | 'active' | 'dormant' | 'morphing';
export type CenterState = 'latent' | 'converging' | 'modulating' | 'expressed' | 'actioning';
export type ConvergenceLevel = 'none' | 'partial' | 'graded' | 'sub-expressive' | 'full';

export interface DimensionalContext {
  d1_impulse?: number;     // 0-1
  d2_polarity?: number;    // 0-1
  d3_witness?: number;     // 0-1
  d4_context?: number;     // 0-1
  d5_meaning?: number;     // 0-1
}

export interface LineColorToneBase {
  line?: number;
  color?: number;
  tone?: number;
  base?: number;
}

export interface GateContext {
  gateNumber: GateNumber;
  gateName?: string;
  channel?: ChannelNumber;
  center?: CenterId;
  isDefined?: boolean;
  isActive?: boolean;
  planetaryInfluence?: PlanetaryInfluence;
  arcModulation?: number;
}

export interface Edge {
  id: string;
  source: string;
  target: string;
  channelId: string;
  state: EdgeState;
  weight: number;
  traversalCount: number;
  lastTraversal: number;
  createdAt: number;
  stratum: Stratum;
  metadata?: Record<string, unknown>;
}

export interface Channel {
  id: string;
  name: string;
  source: string;
  target: string;
  stratum: Stratum;
  quality: string;
  isActive: boolean;
  traversalCount: number;
  weight: number;
  domainFunction?: string;
  bidirectional: boolean;
  createdAt: number;
}

export interface MorphChange {
  field: string;
  from: unknown;
  to: unknown;
  reason: string;
}

export interface MorphEvent {
  id: string;
  timestamp: number;
  triggerMessageId: string;
  organId: string;
  changes: MorphChange[];
  ruleId: string;
  recursionDepth: number;
}

export interface MorphRule {
  id: string;
  triggerGate?: number;
  triggerChannel?: string;
  triggerStratum?: Stratum;
  triggerDimension?: keyof DimensionalContext;
  condition: (msg: QualifiedMessage, organ: Organ) => boolean;
  effect: (msg: QualifiedMessage, organ: Organ) => MorphEvent;
  priority: number;
}

export interface Organ {
  id: string;
  name: string;
  state: OrganState;
  activeGates: Set<number>;
  activeCenters: Set<string>;
  mode: string;
  projectionPreference: string;
  routingBehavior: string;
  responseStyle: string;
  stratum: Stratum;
  isExternal: boolean;
  bridgeType?: 'llm' | 'mcp' | 'python' | 'api' | 'oracle';
  morphRules: MorphRule[];
  receivedMessages: QualifiedMessage[];
  morphHistory: MorphEvent[];
  incomingEdges: Set<string>;
  outgoingEdges: Set<string>;
  activationLevel: number;
  lastActivated: number;
}

export interface ConvergentQuality {
  color?: string;
  tone?: string;
  image?: string;
  sound?: string;
  stateEmphasis?: string;
  interfaceQuality?: string;
  routingBias?: string;
  intensity: number;
}

export interface Center {
  id: string;
  name: string;
  state: CenterState;
  stratum: Stratum;
  connectedOrgans: Set<string>;
  connectedChannels: Set<string>;
  incomingEdges: Set<string>;
  convergenceLevel: ConvergenceLevel;
  isIdentityCenter: boolean;
  formationScore: number;
  projectionStyle: string;
  alignmentWeight: number;
  convergentQualities: ConvergentQuality[];
  activationHistory: number[];
}

export interface ConvergenceState {
  level: ConvergenceLevel;
  contributingMessages: string[];
  contributingChannels: string[];
  contributingEdges: string[];
  qualities: ConvergentQuality[];
  centerId?: string;
  timestamp: number;
}

export interface QualifiedMessage {
  id: string;
  content: unknown;
  timestamp: number;
  sourceOrgan: string;
  sourceCenter: string;
  targetCenter?: string;
  targetOrgan?: string;
  activeGates: GateContext[];
  activeChannels: string[];
  dimensionContext: DimensionalContext;
  lctb: LineColorToneBase;
  planetaryInfluence?: PlanetaryInfluence;
  arcModulation?: number;
  stratum: Stratum;
  stratumTarget?: Stratum;
  recursionDepth: number;
  maxRecursionDepth: number;
  userAlignmentContext?: Record<string, unknown>;
  traversalPath: string[];
  edgesFormed: string[];
  convergenceState?: ConvergenceState;
  morphEffects: MorphEvent[];
  identityAlignmentWeight: number;
  isFromBridge: boolean;
  bridgeId?: string;
  status: 'routing' | 'traversing' | 'morphing' | 'converging' | 'expressed' | 'dropped';
  projectionReady: boolean;
  metadata: Record<string, unknown>;
}

export type MeshEventType =
  | 'message_qualified'
  | 'message_routed'
  | 'channel_traversed'
  | 'edge_formed'
  | 'edge_strengthened'
  | 'edge_weakened'
  | 'organ_morphed'
  | 'center_activated'
  | 'center_modulated'
  | 'convergence_partial'
  | 'convergence_full'
  | 'projection_ready'
  | 'projection_expressed'
  | 'recursion_triggered'
  | 'bridge_connected'
  | 'bridge_disconnected'
  | 'identity_routing';

export interface MeshEvent {
  type: MeshEventType;
  timestamp: number;
  messageId?: string;
  organId?: string;
  centerId?: string;
  channelId?: string;
  edgeId?: string;
  details: Record<string, unknown>;
}

// ───────────────────────────────────────────────────────────────────────────────
// NODE FUNCTIONS (Pre-Channel Contributions)
// ───────────────────────────────────────────────────────────────────────────────

export type NodeContribution =
  | 'initiation' | 'reception' | 'pressure' | 'response' | 'stabilization'
  | 'mutation' | 'expression' | 'formulation' | 'correction' | 'attraction'
  | 'repulsion' | 'gating' | 'memory' | 'compression' | 'decompression'
  | 'direction' | 'attention' | 'resonance' | 'filtering' | 'propagation'
  | 'opposition' | 'rhythm' | 'timing' | 'salience' | 'containment' | 'opening';

export type NodePolarity =
  | 'forward' | 'reverse' | 'inward' | 'outward'
  | 'receptive' | 'projective' | 'stabilizing' | 'destabilizing'
  | 'selective' | 'distributive';

export type RelationalAffordance =
  | 'complementary' | 'oppositional' | 'amplifying' | 'constraining'
  | 'resolving' | 'destabilizing' | 'harmonizing' | 'redirecting';

export type EdgeFunctionType =
  | 'feedforward_articulation' | 'bidirectional_constraint' | 'correction_toward_attractor'
  | 'sparse_compression' | 'self_organization' | 'adversarial_tension'
  | 'reservoir_pulse' | 'gating_loop' | 'radial_activation'
  | 'attentional_highlighting' | 'recursive_memory_access' | 'unpacking_expression';

export interface NodeFunctionProfile {
  nodeId: string;
  gateNumber: GateNumber;
  intrinsicContributions: NodeContribution[];
  polarity: NodePolarity;
  relationalAffordances: RelationalAffordance[];
  edgeFunctionTendencies: EdgeFunctionType[];
  // Placement-sensitive
  placementModulation: (coords: InternalCoordinates) => NodeContribution[];
}

// ───────────────────────────────────────────────────────────────────────────────
// STATE SPACE
// ───────────────────────────────────────────────────────────────────────────────

export interface StateRegion {
  id: string;
  macrostateId: string;
  name: string;
  coreQualitativeFamily: string;
  primaryRelationalSignature: string;
  coordinates: InternalCoordinates;
  stabilityRegime: StabilityRegime;
  stabilityScore: number;
  gradients: LocalGradients;
  neighborTendencies: NeighborTendency[];
  projectionBias: ProjectionBias;
  transitionReadiness: number;
  expressiveDelivery: ExpressiveDelivery;
  positionHistory: CoordinateSnapshot[];
  stabilityHistory: StabilityRegime[];
}

export interface NeighborTendency {
  targetMacrostateId: string;
  targetRegionId: string;
  tendencyStrength: number;
  transitionProbability: number;
  channelCompletionBias: number;
  isBoundaryFacing: boolean;
}

export interface CoordinateSnapshot {
  timestamp: number;
  coordinates: InternalCoordinates;
  stabilityRegime: StabilityRegime;
  stabilityScore: number;
  gradients: LocalGradients;
}

export interface NodeState {
  nodeId: string;
  regionId: string;
  coordinates: InternalCoordinates;
  stabilityRegime: StabilityRegime;
  activeModulation: number;
  pressureState: number;
  contributionProfile: NodeContributionProfile;
}

export interface NodeContributionProfile {
  channelStrength: number;
  channelStyle: string;
  edgeFunctionBias: string;
}

export interface ChannelEmergence {
  channelId: string;
  nodeA: NodeState;
  nodeB: NodeState;
  strength: number;
  style: string;
  edgeFunction: EdgeFunction;
}

export interface EdgeFunction {
  functionType: string;
  intensity: number;
  quality: string;
}

// ───────────────────────────────────────────────────────────────────────────────
// IDENTITY CENTER
// ───────────────────────────────────────────────────────────────────────────────

export interface IdentityProfile {
  userId: string;
  activeGates: GateNumber[];
  definedCenters: CenterId[];
  undefinedCenters: CenterId[];
  strategy: string;
  authority: string;
  profile: string;
  incarnationCross: string;
  llmPreferences: LLMPreference[];
  mcpConnections: MCPConnection[];
  semanticRouting: SemanticRoute[];
}

export interface LLMPreference {
  provider: string;
  model: string;
  purpose: string;
  alignmentWeight: number;
}

export interface MCPConnection {
  serverId: string;
  serverUrl: string;
  tools: string[];
  isActive: boolean;
  bridgeType: 'llm' | 'mcp' | 'python' | 'api' | 'oracle';
}

export interface SemanticRoute {
  pattern: string;
  targetOrgan: string;
  targetCenter: string;
  priority: number;
}

// ───────────────────────────────────────────────────────────────────────────────
// ACTIVATION
// ───────────────────────────────────────────────────────────────────────────────

export interface ActivationGrammar {
  id: string;
  name: string;
  triggerGates: GateNumber[];
  triggerChannels: ChannelNumber[];
  triggerDimensions: Dimension[];
  activationSequence: ActivationStep[];
  convergenceTarget: string;
  projectionTarget: string;
}

export interface ActivationStep {
  step: number;
  organId: string;
  centerId: string;
  gate?: GateNumber;
  channel?: ChannelNumber;
  requiredState: OrganState;
  timeout: number;
}

// ───────────────────────────────────────────────────────────────────────────────
// PROJECTION
// ───────────────────────────────────────────────────────────────────────────────

export interface ProjectionLayer {
  id: string;
  name: string;
  stratum: Stratum;
  modality: 'language' | 'code' | 'image' | 'sound' | 'interface' | 'behavior';
  renderFunction: (msg: QualifiedMessage, state: StateRegion) => unknown;
  preconditions: ProjectionPrecondition[];
}

export interface ProjectionPrecondition {
  type: 'traversal_depth' | 'convergence_level' | 'gate_active' | 'center_state' | 'stratum_match';
  value: unknown;
}

// ───────────────────────────────────────────────────────────────────────────────
// PERSISTENCE
// ───────────────────────────────────────────────────────────────────────────────

export interface PersistenceRecord {
  id: string;
  type: 'message' | 'state' | 'edge' | 'organ' | 'center' | 'snapshot';
  data: unknown;
  timestamp: number;
  ttl?: number;
}

// ───────────────────────────────────────────────────────────────────────────────
// INGESTION
// ───────────────────────────────────────────────────────────────────────────────

export interface IngestionPayload {
  source: 'file' | 'url' | 'api' | 'huggingface' | 'git';
  content: string | ArrayBuffer;
  mimeType: string;
  metadata: Record<string, unknown>;
  validationRules: ValidationRule[];
}

export interface ValidationRule {
  type: 'threat' | 'quality' | 'format' | 'size';
  threshold: number;
  action: 'allow' | 'quarantine' | 'reject';
}

// ───────────────────────────────────────────────────────────────────────────────
// HD GRAPH
// ───────────────────────────────────────────────────────────────────────────────

export interface HDGraphNode {
  id: string;
  gate: GateNumber;
  center: CenterId;
  coordinates: InternalCoordinates;
  activationLevel: number;
  defined: boolean;
}

export interface HDGraphEdge {
  id: string;
  source: string;
  target: string;
  channel: ChannelNumber;
  type: 'definition' | 'activation' | 'projection';
  weight: number;
}

// ───────────────────────────────────────────────────────────────────────────────
// SELF-SUPERVISED
// ───────────────────────────────────────────────────────────────────────────────

export interface LearningEpisode {
  id: string;
  timestamp: number;
  input: unknown;
  predicted: unknown;
  actual: unknown;
  error: number;
  gateContext: GateContext;
  stateContext: InternalCoordinates;
}

export interface PatternWeight {
  pattern: string;
  weight: number;
  successCount: number;
  failureCount: number;
  lastUpdated: number;
}

// ───────────────────────────────────────────────────────────────────────────────
// RESONANCE CORE
// ───────────────────────────────────────────────────────────────────────────────

export interface ResonanceField {
  id: string;
  nodes: string[];
  edges: string[];
  frequency: number;
  amplitude: number;
  phase: number;
  coherence: number;
}

export interface ResonanceSnapshot {
  timestamp: number;
  fieldCount: number;
  averageCoherence: number;
  dominantFrequency: number;
  activeNodes: number;
}

// ───────────────────────────────────────────────────────────────────────────────
// ORGANS
// ───────────────────────────────────────────────────────────────────────────────

export interface OrganManifest {
  id: string;
  name: string;
  type: 'autoling' | 'diseminer' | 'novel-writer' | 'custom';
  stratum: Stratum;
  capabilities: string[];
  dependencies: string[];
  activationGates: GateNumber[];
}

// ───────────────────────────────────────────────────────────────────────────────
// SERVICES
// ───────────────────────────────────────────────────────────────────────────────

export interface ServiceBridge {
  id: string;
  serviceType: 'market-api' | 'oracle-py' | 'chart-oracle';
  endpoint: string;
  healthCheck: () => Promise<boolean>;
  query: (params: unknown) => Promise<unknown>;
}

export interface MarketData {
  symbol: string;
  price: number;
  timestamp: number;
  resonance: number;
}

export interface OracleResponse {
  query: string;
  result: unknown;
  confidence: number;
  source: string;
}

export interface ChartData {
  bodygraph: unknown;
  natalChart: unknown;
  vedicKundli: unknown;
  magicSquares: unknown;
}

// ───────────────────────────────────────────────────────────────────────────────
// SNAPSHOTS
// ───────────────────────────────────────────────────────────────────────────────

export interface OrganismSnapshot {
  timestamp: number;
  mesh: MeshSnapshot;
  stateSpace: StateSpaceSnapshot;
  identity: IdentityProfile;
  organs: OrganManifest[];
  bridges: ServiceBridge[];
}

export interface MeshSnapshot {
  timestamp: number;
  organCount: number;
  centerCount: number;
  channelCount: number;
  edgeCount: number;
  messageCount: number;
  identityCenterId: string | null;
  stats: Record<string, number>;
  organs: unknown[];
  centers: unknown[];
  edges: unknown[];
}

export interface StateSpaceSnapshot {
  timestamp: number;
  regionCount: number;
  nodeCount: number;
  channelCount: number;
  stabilityDistribution: Record<StabilityRegime, number>;
  macrostateCoverage: Record<string, number>;
  averageTransitionReadiness: number;
  regions: unknown[];
}
