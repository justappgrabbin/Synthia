/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/projection — PROJECTION LAYERS                      ║
 * ║                                                                               ║
 * ║  Projection is how the organism expresses into language, code, image,         ║
 * ║  sound, interface, and behavior. Projection follows qualified traversal.      ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import { QualifiedMessage, StateRegion, Stratum, ProjectionLayer, ProjectionPrecondition } from '@messy/types';

export class ProjectionEngine {
  private layers: Map<string, ProjectionLayer> = new Map();
  private renderers: Map<string, (msg: QualifiedMessage, state: StateRegion) => unknown> = new Map();

  registerLayer(layer: ProjectionLayer): void {
    this.layers.set(layer.id, layer);
    this.renderers.set(layer.id, layer.renderFunction);
  }

  canProject(msg: QualifiedMessage, layerId: string): boolean {
    const layer = this.layers.get(layerId);
    if (!layer) return false;
    if (!msg.projectionReady) return false;

    for (const precondition of layer.preconditions) {
      switch (precondition.type) {
        case 'traversal_depth':
          if (msg.traversalPath.length < (precondition.value as number)) return false;
          break;
        case 'convergence_level':
          if (msg.convergenceState?.level !== precondition.value) return false;
          break;
        case 'gate_active':
          if (!msg.activeGates.some(g => g.gateNumber === precondition.value)) return false;
          break;
        case 'center_state':
          // Would need center state lookup
          break;
        case 'stratum_match':
          if (msg.stratum !== precondition.value) return false;
          break;
      }
    }
    return true;
  }

  project(msg: QualifiedMessage, layerId: string, state: StateRegion): unknown {
    if (!this.canProject(msg, layerId)) {
      return { status: 'projection_blocked', reason: 'Preconditions not met', messageId: msg.id };
    }
    const renderer = this.renderers.get(layerId);
    if (!renderer) return { status: 'no_renderer', layerId };
    return renderer(msg, state);
  }

  projectAll(msg: QualifiedMessage, state: StateRegion): Record<string, unknown> {
    const results: Record<string, unknown> = {};
    for (const [layerId, layer] of this.layers) {
      if (layer.stratum === msg.stratum || layer.stratum === msg.stratumTarget) {
        results[layerId] = this.project(msg, layerId, state);
      }
    }
    return results;
  }

  createLanguageLayer(): ProjectionLayer {
    return {
      id: 'language', name: 'Language Projection', stratum: Stratum.MIND, modality: 'language',
      renderFunction: (msg, state) => ({
        text: typeof msg.content === 'string' ? msg.content : JSON.stringify(msg.content),
        style: state.projectionBias.languageStyle,
        intensity: state.projectionBias.intensity,
        forwardFace: state.expressiveDelivery.forwardFace,
      }),
      preconditions: [
        { type: 'convergence_level', value: 'partial' },
        { type: 'stratum_match', value: Stratum.MIND },
      ],
    };
  }

  createCodeLayer(): ProjectionLayer {
    return {
      id: 'code', name: 'Code Projection', stratum: Stratum.MIND, modality: 'code',
      renderFunction: (msg, state) => ({
        code: typeof msg.content === 'object' ? msg.content : { raw: msg.content },
        style: state.projectionBias.codeStyle,
        language: 'typescript',
      }),
      preconditions: [
        { type: 'convergence_level', value: 'full' },
        { type: 'stratum_match', value: Stratum.MIND },
      ],
    };
  }

  createImageLayer(): ProjectionLayer {
    return {
      id: 'image', name: 'Image Projection', stratum: Stratum.ACTION, modality: 'image',
      renderFunction: (msg, state) => ({
        prompt: typeof msg.content === 'string' ? msg.content : 'abstract visualization',
        quality: state.projectionBias.imageQuality,
        color: state.projectionBias.intensity > 0.5 ? 'vivid' : 'muted',
      }),
      preconditions: [
        { type: 'convergence_level', value: 'graded' },
        { type: 'stratum_match', value: Stratum.ACTION },
      ],
    };
  }

  createInterfaceLayer(): ProjectionLayer {
    return {
      id: 'interface', name: 'Interface Projection', stratum: Stratum.ACTION, modality: 'interface',
      renderFunction: (msg, state) => ({
        layout: state.projectionBias.interfaceQuality,
        behavior: state.projectionBias.behaviorTendency,
        responsive: state.gradients.expressionStrength > 0.5,
      }),
      preconditions: [
        { type: 'convergence_level', value: 'full' },
        { type: 'stratum_match', value: Stratum.ACTION },
      ],
    };
  }
}

export default ProjectionEngine;
