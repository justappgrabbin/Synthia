/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/hd-graph — HUMAN DESIGN GRAPH ENGINE                ║
 * ║                                                                               ║
 * ║  Graph representation of the Human Design bodygraph with nodes (gates)      ║
 * ║  and edges (channels) as a computational graph.                               ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import { HDGraphNode, HDGraphEdge, GateNumber, ChannelNumber, CenterId, InternalCoordinates } from '@messy/types';
import { getGate, getChannel, getCenter } from '@messy/ontology';

export class HDGraphEngine {
  private nodes: Map<string, HDGraphNode> = new Map();
  private edges: Map<string, HDGraphEdge> = new Map();

  addNode(id: string, gate: GateNumber, center: CenterId, coordinates: Partial<InternalCoordinates>, defined: boolean = true): HDGraphNode {
    const node: HDGraphNode = { id, gate, center, coordinates: coordinates as InternalCoordinates, activationLevel: defined ? 1.0 : 0.0, defined };
    this.nodes.set(id, node);
    return node;
  }

  addEdge(id: string, source: string, target: string, channel: ChannelNumber, type: HDGraphEdge['type'] = 'definition'): HDGraphEdge {
    const edge: HDGraphEdge = { id, source, target, channel, type, weight: 1.0 };
    this.edges.set(id, edge);
    return edge;
  }

  getNode(id: string): HDGraphNode | undefined { return this.nodes.get(id); }
  getEdge(id: string): HDGraphEdge | undefined { return this.edges.get(id); }
  getAllNodes(): HDGraphNode[] { return Array.from(this.nodes.values()); }
  getAllEdges(): HDGraphEdge[] { return Array.from(this.edges.values()); }

  getNodesByCenter(center: CenterId): HDGraphNode[] {
    return this.getAllNodes().filter(n => n.center === center);
  }

  getNodesByGate(gate: GateNumber): HDGraphNode[] {
    return this.getAllNodes().filter(n => n.gate === gate);
  }

  getConnectedNodes(nodeId: string): HDGraphNode[] {
    const connected: HDGraphNode[] = [];
    for (const edge of this.edges.values()) {
      if (edge.source === nodeId) {
        const target = this.nodes.get(edge.target);
        if (target) connected.push(target);
      }
      if (edge.target === nodeId) {
        const source = this.nodes.get(edge.source);
        if (source) connected.push(source);
      }
    }
    return connected;
  }

  getActiveChannels(): HDGraphEdge[] {
    return this.getAllEdges().filter(e => {
      const source = this.nodes.get(e.source);
      const target = this.nodes.get(e.target);
      return source?.defined && target?.defined && source.activationLevel > 0.5 && target.activationLevel > 0.5;
    });
  }

  activateNode(nodeId: string, level: number = 1.0): void {
    const node = this.nodes.get(nodeId);
    if (node) node.activationLevel = Math.min(1, level);
  }

  deactivateNode(nodeId: string): void {
    const node = this.nodes.get(nodeId);
    if (node) node.activationLevel = 0;
  }

  computeResonance(nodeId: string): number {
    const node = this.nodes.get(nodeId);
    if (!node) return 0;
    const connected = this.getConnectedNodes(nodeId);
    const totalActivation = connected.reduce((sum, n) => sum + n.activationLevel, 0);
    return connected.length > 0 ? totalActivation / connected.length : 0;
  }
}

export default HDGraphEngine;
