/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/activation — ACTIVATION GRAMMARS                    ║
 * ║                                                                               ║
 * ║  Activation grammars define how latent structure becomes expressed.         ║
 * ║  They are the rules by which the organism moves from potential to actual.     ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import { MeshEngine, createOrgan, createCenter, createChannel, Stratum } from '@messy/mesh';
import { StateSpaceEngine } from '@messy/state-space';
import { ActivationGrammar, ActivationStep, OrganState, GateNumber, ChannelNumber, Dimension } from '@messy/types';

export class ActivationEngine {
  private mesh: MeshEngine;
  private stateSpace: StateSpaceEngine;
  private grammars: Map<string, ActivationGrammar> = new Map();
  private activeSequences: Map<string, { grammar: ActivationGrammar; currentStep: number; startedAt: number }> = new Map();

  constructor(mesh: MeshEngine, stateSpace: StateSpaceEngine) {
    this.mesh = mesh;
    this.stateSpace = stateSpace;
  }

  registerGrammar(grammar: ActivationGrammar): void {
    this.grammars.set(grammar.id, grammar);
  }

  activate(grammarId: string, triggerPayload: unknown): boolean {
    const grammar = this.grammars.get(grammarId);
    if (!grammar) return false;

    this.activeSequences.set(grammarId, { grammar, currentStep: 0, startedAt: Date.now() });

    // Execute first step
    this.executeStep(grammarId, 0, triggerPayload);
    return true;
  }

  private executeStep(grammarId: string, stepIndex: number, payload: unknown): void {
    const seq = this.activeSequences.get(grammarId);
    if (!seq) return;

    const step = seq.grammar.activationSequence[stepIndex];
    if (!step) {
      // Sequence complete — trigger convergence
      this.mesh.send(
        { type: 'activation_complete', grammarId, payload },
        { sourceOrgan: 'activation_engine', sourceCenter: seq.grammar.convergenceTarget, stratum: Stratum.MIND }
      );
      this.activeSequences.delete(grammarId);
      return;
    }

    const organ = this.mesh.getOrgan(step.organId);
    if (!organ) return;

    // Check if organ is in required state
    if (organ.state !== step.requiredState && step.requiredState !== 'latent') {
      // Wait or retry
      setTimeout(() => this.executeStep(grammarId, stepIndex, payload), step.timeout);
      return;
    }

    // Send activation message
    this.mesh.send(payload, {
      sourceOrgan: 'activation_engine',
      targetOrgan: step.organId,
      targetCenter: step.centerId,
      stratum: organ.stratum,
      activeGates: step.gate ? [{ gateNumber: step.gate, isActive: true }] : [],
      metadata: { grammarId, stepIndex, activationSequence: true },
    });

    seq.currentStep = stepIndex + 1;
    setTimeout(() => this.executeStep(grammarId, stepIndex + 1, payload), step.timeout);
  }

  getActiveSequences(): string[] {
    return Array.from(this.activeSequences.keys());
  }

  getGrammar(id: string): ActivationGrammar | undefined {
    return this.grammars.get(id);
  }
}

export default ActivationEngine;
