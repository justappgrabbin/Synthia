/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/ingestion — DISCERNING INGESTION SYSTEM            ║
 * ║                                                                               ║
 * ║  Upload → Validate → Filter → Decide → Ingest → Learn → Grow                 ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import { IngestionPayload, ValidationRule, MeshEngine, QualifiedMessage, Stratum } from '@messy/types';

export interface IngestionResult {
  accepted: boolean;
  recordId: string;
  quality: number;
  threatLevel: number;
  action: 'allow' | 'quarantine' | 'reject';
  metadata: Record<string, unknown>;
}

export class IngestionEngine {
  private mesh: MeshEngine;
  private learningMemory: Map<string, number> = new Map();
  private patternWeights: Map<string, { weight: number; success: number; failure: number }> = new Map();

  constructor(mesh: MeshEngine) {
    this.mesh = mesh;
  }

  async ingest(payload: IngestionPayload): Promise<IngestionResult> {
    const recordId = `ingest_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Validate
    const validation = this.validate(payload);
    if (validation.action === 'reject') {
      return { accepted: false, recordId, quality: validation.quality, threatLevel: validation.threatLevel, action: 'reject', metadata: { reason: 'validation_failed' } };
    }

    // Quality score
    const quality = this.scoreQuality(payload);

    // Threat detection
    const threatLevel = this.detectThreats(payload);
    if (threatLevel > 0.7) {
      return { accepted: false, recordId, quality, threatLevel, action: 'quarantine', metadata: { reason: 'threat_detected' } };
    }

    // Learn from ingestion
    this.learn(payload, quality);

    // Grow — extract capabilities and spawn subsystems if needed
    const growthResult = this.grow(payload, quality);

    // Send through mesh
    this.mesh.send(payload, {
      sourceOrgan: 'ingestion_engine',
      sourceCenter: 'mind',
      stratum: Stratum.MIND,
      metadata: { ingestionId: recordId, quality, threatLevel, growthResult },
    });

    return { accepted: true, recordId, quality, threatLevel, action: 'allow', metadata: { growthResult } };
  }

  private validate(payload: IngestionPayload): { action: 'allow' | 'quarantine' | 'reject'; quality: number; threatLevel: number } {
    for (const rule of payload.validationRules) {
      if (rule.type === 'format') {
        const validFormats = ['text/plain', 'application/json', 'text/typescript', 'application/javascript'];
        if (!validFormats.includes(payload.mimeType)) return { action: 'reject', quality: 0, threatLevel: 0 };
      }
      if (rule.type === 'size') {
        const contentSize = typeof payload.content === 'string' ? payload.content.length : (payload.content as ArrayBuffer).byteLength;
        if (contentSize > (rule.threshold as number)) return { action: 'quarantine', quality: 0.3, threatLevel: 0.2 };
      }
    }
    return { action: 'allow', quality: 0.8, threatLevel: 0 };
  }

  private scoreQuality(payload: IngestionPayload): number {
    // Quality scoring based on content analysis
    let score = 0.5;
    if (typeof payload.content === 'string') {
      const lines = payload.content.split('\n').length;
      if (lines > 100) score += 0.2;
      if (payload.content.includes('export') || payload.content.includes('import')) score += 0.1;
      if (payload.content.includes('class') || payload.content.includes('interface')) score += 0.1;
    }
    return Math.min(1, score);
  }

  private detectThreats(payload: IngestionPayload): number {
    // Threat detection: check for malicious patterns
    let threat = 0;
    if (typeof payload.content === 'string') {
      const dangerous = ['eval(', 'Function(', 'constructor', '__proto__', 'prototype pollution'];
      for (const pattern of dangerous) {
        if (payload.content.includes(pattern)) threat += 0.3;
      }
    }
    return Math.min(1, threat);
  }

  private learn(payload: IngestionPayload, quality: number): void {
    const sourceKey = payload.source;
    const current = this.learningMemory.get(sourceKey) || 0.5;
    this.learningMemory.set(sourceKey, current * 0.9 + quality * 0.1);
  }

  private grow(payload: IngestionPayload, quality: number): { spawnedSubsystems: string[]; evolvedRules: string[] } {
    const spawned: string[] = [];
    const evolved: string[] = [];

    if (quality > 0.8) {
      // High quality ingestion may spawn new capabilities
      if (typeof payload.content === 'string' && payload.content.includes('function')) {
        spawned.push('function_analyzer');
      }
      if (payload.content.toString().includes('class')) {
        spawned.push('class_extractor');
      }
    }

    return { spawnedSubsystems: spawned, evolvedRules: evolved };
  }

  getLearningMemory(): Map<string, number> { return new Map(this.learningMemory); }
  getPatternWeights(): Map<string, { weight: number; success: number; failure: number }> { return new Map(this.patternWeights); }
}

export default IngestionEngine;
