/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/identity-center — USER ALIGNMENT HUB                ║
 * ║                                                                               ║
 * ║  The Identity Center is the user-alignment hub where:                         ║
 * ║  - the user's LLMs sit                                                        ║
 * ║  - MCP connections are bridged                                                ║
 * ║  - tool routing is aligned                                                    ║
 * ║  - user-specific style and meaning are preserved                              ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import { MeshEngine, createCenter, Stratum } from '@messy/mesh';
import { IdentityProfile, LLMPreference, MCPConnection, SemanticRoute, GateNumber, CenterId } from '@messy/types';

export class IdentityCenter {
  private mesh: MeshEngine;
  private profile: IdentityProfile;
  private centerId: string;

  constructor(mesh: MeshEngine, profile: IdentityProfile) {
    this.mesh = mesh;
    this.profile = profile;
    this.centerId = `identity_${profile.userId}`;

    const center = createCenter(this.centerId, 'Identity Center', Stratum.HEART, true);
    center.alignmentWeight = 0.95;
    mesh.registerCenter(center);
  }

  getProfile(): IdentityProfile { return this.profile; }
  getCenterId(): string { return this.centerId; }

  addLLMPreference(pref: LLMPreference): void {
    this.profile.llmPreferences.push(pref);
  }

  addMCPConnection(conn: MCPConnection): void {
    this.profile.mcpConnections.push(conn);
    // Register as external bridge in mesh
    this.mesh.connectBridge(conn.serverId, conn.bridgeType, conn.serverId);
  }

  addSemanticRoute(route: SemanticRoute): void {
    this.profile.semanticRouting.push(route);
  }

  routeBySemanticPattern(query: string): { targetOrgan: string; targetCenter: string; priority: number } | null {
    for (const route of this.profile.semanticRouting) {
      if (query.includes(route.pattern) || new RegExp(route.pattern).test(query)) {
        return { targetOrgan: route.targetOrgan, targetCenter: route.targetCenter, priority: route.priority };
      }
    }
    return null;
  }

  getActiveLLM(purpose: string): LLMPreference | undefined {
    return this.profile.llmPreferences.find(p => p.purpose === purpose && p.alignmentWeight > 0.5);
  }

  getActiveMCPs(): MCPConnection[] {
    return this.profile.mcpConnections.filter(c => c.isActive);
  }

  isGateDefined(gate: GateNumber): boolean {
    return this.profile.activeGates.includes(gate);
  }

  isCenterDefined(center: CenterId): boolean {
    return this.profile.definedCenters.includes(center);
  }

  getStrategy(): string { return this.profile.strategy; }
  getAuthority(): string { return this.profile.authority; }
  getProfile(): string { return this.profile.profile; }
  getIncarnationCross(): string { return this.profile.incarnationCross; }
}

export default IdentityCenter;
