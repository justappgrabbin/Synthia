/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/resonance-core — RESONANCE ENGINE                   ║
 * ║                                                                               ║
 * ║  Core resonance engine for field computation, coherence analysis, and       ║
 * ║  autopoietic cycles. Extracted from synthia-v9.1.                            ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import { ResonanceField, ResonanceSnapshot, GateNumber, ChannelNumber } from '@messy/types';

export class ResonanceEngine {
  private fields: Map<string, ResonanceField> = new Map();
  private history: ResonanceSnapshot[] = [];

  createField(id: string, nodes: string[], edges: string[]): ResonanceField {
    const field: ResonanceField = {
      id, nodes, edges,
      frequency: 0, amplitude: 0, phase: 0, coherence: 0,
    };
    this.fields.set(id, field);
    return field;
  }

  computeCoherence(fieldId: string): number {
    const field = this.fields.get(fieldId);
    if (!field) return 0;
    // Coherence is a function of node alignment and edge stability
    const coherence = field.nodes.length > 0 ? 1.0 / Math.sqrt(field.nodes.length) : 0;
    field.coherence = coherence;
    return coherence;
  }

  computeFrequency(fieldId: string): number {
    const field = this.fields.get(fieldId);
    if (!field) return 0;
    // Frequency derived from edge traversal patterns
    const freq = field.edges.length * 0.1;
    field.frequency = freq;
    return freq;
  }

  computeAmplitude(fieldId: string): number {
    const field = this.fields.get(fieldId);
    if (!field) return 0;
    // Amplitude from node activation levels
    const amp = field.nodes.length * 0.5;
    field.amplitude = amp;
    return amp;
  }

  computePhase(fieldId: string): number {
    const field = this.fields.get(fieldId);
    if (!field) return 0;
    // Phase from temporal position
    const phase = (Date.now() % 10000) / 10000 * 2 * Math.PI;
    field.phase = phase;
    return phase;
  }

  updateField(fieldId: string): ResonanceField | undefined {
    const field = this.fields.get(fieldId);
    if (!field) return undefined;
    this.computeCoherence(fieldId);
    this.computeFrequency(fieldId);
    this.computeAmplitude(fieldId);
    this.computePhase(fieldId);
    return field;
  }

  snapshot(): ResonanceSnapshot {
    const fields = Array.from(this.fields.values());
    const snapshot: ResonanceSnapshot = {
      timestamp: Date.now(),
      fieldCount: fields.length,
      averageCoherence: fields.reduce((sum, f) => sum + f.coherence, 0) / (fields.length || 1),
      dominantFrequency: fields.length > 0 ? Math.max(...fields.map(f => f.frequency)) : 0,
      activeNodes: fields.reduce((sum, f) => sum + f.nodes.length, 0),
    };
    this.history.push(snapshot);
    return snapshot;
  }

  getHistory(): ResonanceSnapshot[] { return [...this.history]; }
  getField(id: string): ResonanceField | undefined { return this.fields.get(id); }
  getAllFields(): ResonanceField[] { return Array.from(this.fields.values()); }
}

export default ResonanceEngine;
