/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/bus — MESSAGE BUS LAYER ON MESH                   ║
 * ║                                                                               ║
 * ║  The bus is a convenience layer on top of the mesh. It provides           ║
 * ║  topic-based routing, request/response patterns, and broadcast semantics.   ║
 * ║  Underneath, everything still goes through the mesh with full qualification.  ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import { MeshEngine, QualifiedMessage, Organ, Stratum, MeshEvent } from '@messy/mesh';
import { GateContext, DimensionalContext } from '@messy/types';

export interface BusTopic {
  name: string;
  stratum: Stratum;
  requiredGates: number[];
  subscribers: Set<string>;
}

export interface BusRequest {
  id: string;
  topic: string;
  payload: unknown;
  requester: string;
  timeout: number;
  timestamp: number;
}

export interface BusResponse {
  requestId: string;
  responder: string;
  payload: unknown;
  timestamp: number;
}

export class MessageBus {
  private mesh: MeshEngine;
  private topics: Map<string, BusTopic> = new Map();
  private pendingRequests: Map<string, BusRequest> = new Map();
  private responses: Map<string, BusResponse[]> = new Map();

  constructor(mesh: MeshEngine) {
    this.mesh = mesh;
  }

  registerTopic(name: string, stratum: Stratum, requiredGates: number[] = []): BusTopic {
    const topic: BusTopic = { name, stratum, requiredGates, subscribers: new Set() };
    this.topics.set(name, topic);
    return topic;
  }

  subscribe(organId: string, topic: string): void {
    const t = this.topics.get(topic);
    if (t) t.subscribers.add(organId);
  }

  unsubscribe(organId: string, topic: string): void {
    const t = this.topics.get(topic);
    if (t) t.subscribers.delete(organId);
  }

  publish(topic: string, payload: unknown, publisherId: string, qualification?: Partial<QualifiedMessage>): void {
    const t = this.topics.get(topic);
    if (!t) return;
    for (const subscriberId of t.subscribers) {
      this.mesh.send(payload, {
        sourceOrgan: publisherId,
        targetOrgan: subscriberId,
        stratum: t.stratum,
        activeGates: qualification?.activeGates || [],
        ...qualification,
      });
    }
  }

  request(topic: string, payload: unknown, requesterId: string, timeout: number = 5000): Promise<BusResponse[]> {
    const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const request: BusRequest = { id: requestId, topic, payload, requester: requesterId, timeout, timestamp: Date.now() };
    this.pendingRequests.set(requestId, request);
    this.responses.set(requestId, []);

    const t = this.topics.get(topic);
    if (t) {
      for (const responderId of t.subscribers) {
        if (responderId !== requesterId) {
          this.mesh.send(payload, {
            sourceOrgan: requesterId,
            targetOrgan: responderId,
            stratum: t.stratum,
            metadata: { ...qualification?.metadata, busRequestId: requestId, busTopic: topic },
          });
        }
      }
    }

    return new Promise((resolve) => {
      setTimeout(() => {
        const responses = this.responses.get(requestId) || [];
        this.pendingRequests.delete(requestId);
        this.responses.delete(requestId);
        resolve(responses);
      }, timeout);
    });
  }

  respond(requestId: string, responderId: string, payload: unknown): void {
    const request = this.pendingRequests.get(requestId);
    if (!request) return;
    const response: BusResponse = { requestId, responder: responderId, payload, timestamp: Date.now() };
    const responses = this.responses.get(requestId) || [];
    responses.push(response);
    this.responses.set(requestId, responses);
  }

  broadcast(payload: unknown, broadcasterId: string, stratum: Stratum = Stratum.MIND): void {
    for (const [topicName, topic] of this.topics) {
      if (topic.stratum === stratum) {
        this.publish(topicName, payload, broadcasterId);
      }
    }
  }
}

export default MessageBus;
