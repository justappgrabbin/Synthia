/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/persistence — LOCAL STORAGE                         ║
 * ║                                                                               ║
 * ║  Local-first persistence for messages, states, edges, organs, and centers.  ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import { PersistenceRecord, MeshSnapshot, StateSpaceSnapshot } from '@messy/types';

export class PersistenceEngine {
  private storage: Map<string, PersistenceRecord> = new Map();
  private dbName: string = 'messy_organism';

  async save(record: PersistenceRecord): Promise<void> {
    this.storage.set(record.id, record);
    // In browser: IndexedDB; in Node: fs or SQLite
    if (typeof window !== 'undefined' && window.indexedDB) {
      await this.saveToIndexedDB(record);
    }
  }

  async load(id: string): Promise<PersistenceRecord | undefined> {
    return this.storage.get(id);
  }

  async loadByType(type: PersistenceRecord['type']): Promise<PersistenceRecord[]> {
    return Array.from(this.storage.values()).filter(r => r.type === type);
  }

  async saveMeshSnapshot(snapshot: MeshSnapshot): Promise<void> {
    await this.save({ id: `mesh_${snapshot.timestamp}`, type: 'snapshot', data: snapshot, timestamp: snapshot.timestamp });
  }

  async saveStateSpaceSnapshot(snapshot: StateSpaceSnapshot): Promise<void> {
    await this.save({ id: `state_${snapshot.timestamp}`, type: 'snapshot', data: snapshot, timestamp: snapshot.timestamp });
  }

  async prune(maxAge: number = 7 * 24 * 60 * 60 * 1000): Promise<number> {
    const now = Date.now();
    let removed = 0;
    for (const [id, record] of this.storage) {
      if (now - record.timestamp > maxAge) {
        this.storage.delete(id);
        removed++;
      }
    }
    return removed;
  }

  private async saveToIndexedDB(record: PersistenceRecord): Promise<void> {
    // Implementation for browser environment
    return new Promise((resolve) => {
      const request = indexedDB.open(this.dbName, 1);
      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains('records')) {
          db.createObjectStore('records', { keyPath: 'id' });
        }
      };
      request.onsuccess = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        const tx = db.transaction('records', 'readwrite');
        const store = tx.objectStore('records');
        store.put(record);
        tx.oncomplete = () => { db.close(); resolve(); };
      };
      request.onerror = () => resolve();
    });
  }
}

export default PersistenceEngine;
