/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║                    @messy/organs-autoling — AUTOLING ORGAN                    ║
 * ║                                                                               ║
 * ║  Automatic linguistic analysis and generation organ.                          ║
 * ║  Processes language through the mesh with full state-space qualification.   ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import { MeshEngine, createOrgan, Stratum } from '@messy/mesh';
import { StateSpaceEngine } from '@messy/state-space';
import { ProjectionEngine } from '@messy/projection';
import { GateNumber, OrganManifest } from '@messy/types';

export class AutolingOrgan {
  private mesh: MeshEngine;
  private stateSpace: StateSpaceEngine;
  private projection: ProjectionEngine;
  private organId: string = 'autoling';

  constructor(mesh: MeshEngine, stateSpace: StateSpaceEngine, projection: ProjectionEngine) {
    this.mesh = mesh;
    this.stateSpace = stateSpace;
    this.projection = projection;

    const organ = createOrgan(this.organId, 'AUTOLING', Stratum.MIND, {
      mode: 'linguistic',
      projectionPreference: 'language',
      responseStyle: 'analytical',
    });
    organ.morphRules.push({
      id: 'autoling_activation',
      condition: (msg, organ) => msg.activeGates.some(g => [43, 23, 11, 62].includes(g.gateNumber)),
      effect: (msg, organ) => ({
        id: `morph_${Date.now()}`, timestamp: Date.now(), triggerMessageId: msg.id, organId: organ.id,
        changes: [{ field: 'mode', from: organ.mode, to: 'deep_analysis', reason: 'Insight/Concept gates activated' }],
        ruleId: 'autoling_activation', recursionDepth: msg.recursionDepth,
      }),
      priority: 8,
    });
    mesh.registerOrgan(organ);
  }

  analyze(text: string): { sentiment: number; complexity: number; gates: GateNumber[] } {
    const sentiment = text.length > 0 ? (text.split(' ').length / 100) : 0.5;
    const complexity = (text.match(/[;:,]/g) || []).length / 10;
    const gates: GateNumber[] = [];
    if (text.includes('why') || text.includes('how')) gates.push(43);
    if (text.includes('what') || text.includes('is')) gates.push(23);
    if (text.includes('idea') || text.includes('think')) gates.push(11);
    return { sentiment: Math.min(1, sentiment), complexity: Math.min(1, complexity), gates };
  }

  generate(prompt: string, style: string = 'poetic'): string {
    return `[AUTOLING ${style}] ${prompt}`;
  }

  getManifest(): OrganManifest {
    return {
      id: this.organId, name: 'AUTOLING', type: 'autoling', stratum: Stratum.MIND,
      capabilities: ['linguistic_analysis', 'text_generation', 'sentiment_scoring', 'gate_detection'],
      dependencies: ['mesh', 'state-space', 'projection'],
      activationGates: [43, 23, 11, 62],
    };
  }
}

export default AutolingOrgan;
