// ============================================
// SYNTHIA v9.1 RUNTIME
// Social + Cultivation + Generative Universe
// One shared resonance graph. Everything else is a view on it.
// ============================================

import { ResonanceGraph } from './core/resonance-graph';
import { FeedEngine } from './social/feed-engine';
import { CultivationEngine } from './cultivation/growth-path';
import { GenerativeUniverse } from './universe/generator';

export class SynthiaRuntime {
  readonly graph: ResonanceGraph;
  readonly feed: FeedEngine;
  readonly cultivation: CultivationEngine;
  readonly universe: GenerativeUniverse;

  private running: boolean = false;

  constructor() {
    this.graph = new ResonanceGraph();
    this.feed = new FeedEngine(this.graph);
    this.cultivation = new CultivationEngine(this.graph);
    this.universe = new GenerativeUniverse(this.graph);
  }

  async start(): Promise<void> {
    this.running = true;
    this.universe.start(30);
    console.log('Synthia v9.1 — Generative Universe active');
  }

  stop(): void {
    this.running = false;
    this.universe.stop();
  }

  registerPerson(person: any): any {
    return this.graph.registerPerson(person);
  }

  createPost(authorId: string, content: string, type: string, gateResonance: number[]): any {
    return this.graph.createPost({
      authorId, content, type: type as any, gateResonance, dimensionalTag: 3
    });
  }

  resonate(fromId: string, postId: string): any {
    return this.feed.resonate(fromId, postId);
  }

  echo(fromId: string, postId: string): any {
    return this.feed.echo(fromId, postId);
  }

  reply(fromId: string, postId: string, content: string): any {
    return this.feed.reply(fromId, postId, content);
  }

  connect(fromId: string, toId: string): any {
    return this.feed.connect(fromId, toId);
  }

  createPath(personId: string, primaryGate: number): any {
    return this.cultivation.createPath(personId, primaryGate);
  }

  recordInsight(personId: string, gate: number, content: string, evidence: string[]): any {
    return this.cultivation.recordInsight(personId, gate, content, evidence);
  }

  recordBreakthrough(personId: string, gate: number, content: string, evidence: string[]): any {
    return this.cultivation.recordBreakthrough(personId, gate, content, evidence);
  }

  getFeed(personId: string, mode: string = 'resonance'): any {
    return this.feed.generateFeed({
      personId, mode: mode as any, timeRange: 86400000 * 7, diversityBoost: 0.3
    });
  }

  getGrowthPath(personId: string): any {
    return this.cultivation.getPathVisualization(personId);
  }

  getUniverseView(): any {
    return this.universe.getRenderData();
  }

  getStats(): any {
    return {
      universe: this.graph.getUniverseStats(),
      cultivation: this.cultivation.getStats(),
      world: this.universe.getStats()
    };
  }
}
