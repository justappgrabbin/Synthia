// ============================================
// RESONANCE GRAPH — Social Semantic Network
// Every person is a node. Every post, interaction, feeling is a triple.
// The manifold evolves from collective resonance, not individual wills.
// ============================================

export interface Person {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  definedGates: number[];
  definedChannels: number[];
  hdType: string;
  authority: string;
  strategy: string;
  attractorPosition: number[];
  attractorStrength: number;
  growthLevel: number;
  joinedAt: number;
  lastActive: number;
}

export interface Post {
  id: string;
  authorId: string;
  content: string;
  type: 'thought' | 'creation' | 'question' | 'reflection' | 'invitation';
  gateResonance: number[];
  timestamp: number;
  resonance: number;
  replies: string[];
  echoes: string[];
  dimensionalTag: number;
}

export interface Interaction {
  id: string;
  fromId: string;
  toId: string;
  type: 'resonated' | 'echoed' | 'replied' | 'witnessed' | 'cultivated' | 'connected';
  strength: number;
  timestamp: number;
  dimensionalTag: number;
}

export interface CultivationEvent {
  id: string;
  personId: string;
  type: 'insight' | 'practice' | 'breakthrough' | 'integration' | 'teaching';
  gate: number;
  content: string;
  evidence: string[];
  timestamp: number;
  resonance: number;
}

export class ResonanceGraph {
  people: Map<string, Person> = new Map();
  posts: Map<string, Post> = new Map();
  interactions: Map<string, Interaction> = new Map();
  cultivations: Map<string, CultivationEvent> = new Map();

  private clock: number = 0;
  private manifoldCache: Map<string, number> = new Map();

  registerPerson(person: Omit<Person, 'attractorPosition' | 'attractorStrength' | 'growthLevel' | 'joinedAt' | 'lastActive'>): Person {
    this.clock++;
    const position = this.calculateAttractorPosition(person.definedGates, person.definedChannels);
    const strength = 1.0 + person.definedGates.length * 0.2 + person.definedChannels.length * 0.3;

    const fullPerson: Person = {
      ...person,
      attractorPosition: position,
      attractorStrength: strength,
      growthLevel: 0.1,
      joinedAt: Date.now(),
      lastActive: Date.now()
    };

    this.people.set(person.id, fullPerson);
    return fullPerson;
  }

  private calculateAttractorPosition(gates: number[], channels: number[]): number[] {
    const basePositions: Record<number, number[]> = {
      1: [0.9, 0.1, 0.5], 2: [0.1, 0.9, 0.5], 3: [0.5, 0.5, 0.9],
      4: [0.7, 0.3, 0.8], 5: [0.3, 0.7, 0.2], 6: [0.8, 0.2, 0.3],
      7: [0.6, 0.4, 0.7], 8: [0.4, 0.6, 0.1], 10: [0.5, 0.5, 0.5],
      14: [0.2, 0.8, 0.6], 20: [0.8, 0.8, 0.2], 25: [0.3, 0.3, 0.8],
      34: [0.9, 0.5, 0.1], 57: [0.5, 0.9, 0.3]
    };

    let x = 0.5, y = 0.5, z = 0.5;
    let count = 0;
    for (const gate of gates) {
      const pos = basePositions[gate];
      if (pos) { x += pos[0]; y += pos[1]; z += pos[2]; count++; }
    }
    if (count === 0) return [0.5, 0.5, 0.5];
    return [x / count, y / count, z / count];
  }

  createPost(post: Omit<Post, 'id' | 'timestamp' | 'resonance' | 'replies' | 'echoes'>): Post {
    this.clock++;
    const fullPost: Post = {
      ...post,
      id: `post_${this.clock}_${Math.random().toString(36).substr(2, 5)}`,
      timestamp: Date.now(),
      resonance: 0,
      replies: [],
      echoes: []
    };
    this.posts.set(fullPost.id, fullPost);
    const author = this.people.get(post.authorId);
    if (author) { author.attractorStrength += 0.05; author.lastActive = Date.now(); }
    this.manifoldCache.clear();
    return fullPost;
  }

  interact(interaction: Omit<Interaction, 'id' | 'timestamp'>): Interaction {
    this.clock++;
    const fullInteraction: Interaction = {
      ...interaction,
      id: `int_${this.clock}_${Math.random().toString(36).substr(2, 5)}`,
      timestamp: Date.now()
    };
    this.interactions.set(fullInteraction.id, fullInteraction);

    const post = this.posts.get(interaction.toId);
    if (post) {
      post.resonance += interaction.strength;
      if (interaction.type === 'replied') post.replies.push(fullInteraction.id);
      if (interaction.type === 'echoed') post.echoes.push(fullInteraction.id);
    }

    const from = this.people.get(interaction.fromId);
    const to = this.people.get(interaction.toId);
    if (from) { from.attractorStrength += interaction.strength * 0.1; from.lastActive = Date.now(); }
    if (to) { to.attractorStrength += interaction.strength * 0.05; }
    if (from && to && interaction.type === 'resonated') {
      this.pullAttractors(from, to, interaction.strength * 0.01);
    }

    this.manifoldCache.clear();
    return fullInteraction;
  }

  private pullAttractors(a: Person, b: Person, amount: number) {
    for (let i = 0; i < a.attractorPosition.length; i++) {
      const delta = b.attractorPosition[i] - a.attractorPosition[i];
      a.attractorPosition[i] += delta * amount;
      b.attractorPosition[i] -= delta * amount;
    }
  }

  recordCultivation(event: Omit<CultivationEvent, 'id' | 'timestamp' | 'resonance'>): CultivationEvent {
    this.clock++;
    const fullEvent: CultivationEvent = {
      ...event,
      id: `cult_${this.clock}_${Math.random().toString(36).substr(2, 5)}`,
      timestamp: Date.now(),
      resonance: this.calculateCultivationResonance(event)
    };
    this.cultivations.set(fullEvent.id, fullEvent);
    const person = this.people.get(event.personId);
    if (person) {
      person.growthLevel = Math.min(1.0, person.growthLevel + fullEvent.resonance * 0.1);
      person.attractorStrength += fullEvent.resonance * 0.2;
    }
    return fullEvent;
  }

  private calculateCultivationResonance(event: Omit<CultivationEvent, 'id' | 'timestamp' | 'resonance'>): number {
    let base = 0.3;
    if (event.type === 'breakthrough') base = 0.9;
    if (event.type === 'insight') base = 0.6;
    if (event.type === 'teaching') base = 0.7;
    if (event.type === 'integration') base = 0.8;
    base += event.evidence.length * 0.1;
    return Math.min(1.0, base);
  }

  manifoldValue(position: number[]): number {
    const key = position.map(p => p.toFixed(3)).join(',');
    if (this.manifoldCache.has(key)) return this.manifoldCache.get(key)!;
    let M = 0;
    for (const [_, person] of this.people) {
      const dist = this.euclideanDistance(position, person.attractorPosition);
      M += person.attractorStrength / (1 + dist * 10);
    }
    for (const [_, post] of this.posts) {
      if (post.resonance > 0) {
        const postPos = this.postPosition(post);
        const dist = this.euclideanDistance(position, postPos);
        M += post.resonance * 0.1 / (1 + dist * 10);
      }
    }
    this.manifoldCache.set(key, M);
    return M;
  }

  private postPosition(post: Post): number[] {
    const base = [0.5, 0.5, 0.5];
    const author = this.people.get(post.authorId);
    if (author) {
      base[0] += author.attractorPosition[0] * 0.1;
      base[1] += author.attractorPosition[1] * 0.1;
      base[2] += author.attractorPosition[2] * 0.1;
    }
    return base;
  }

  private euclideanDistance(a: number[], b: number[]): number {
    return Math.sqrt(a.reduce((s, v, i) => s + (v - b[i]) ** 2, 0));
  }

  getFeed(personId: string, limit: number = 20): Post[] {
    const person = this.people.get(personId);
    if (!person) return [];
    const allPosts = Array.from(this.posts.values());
    const scored = allPosts.map(post => {
      const postPos = this.postPosition(post);
      const dist = this.euclideanDistance(person.attractorPosition, postPos);
      const score = post.resonance * 0.3 + (1 / (1 + dist)) * 0.7;
      return { post, score };
    });
    return scored.sort((a, b) => b.score - a.score).slice(0, limit).map(s => s.post);
  }

  getResonantPeople(personId: string, limit: number = 10): Array<{ person: Person; resonance: number }> {
    const person = this.people.get(personId);
    if (!person) return [];
    const scored = Array.from(this.people.values())
      .filter(p => p.id !== personId)
      .map(p => {
        const dist = this.euclideanDistance(person.attractorPosition, p.attractorPosition);
        const interactionCount = Array.from(this.interactions.values()).filter(i =>
          (i.fromId === personId && i.toId === p.id) || (i.fromId === p.id && i.toId === personId)
        ).length;
        const resonance = (1 / (1 + dist)) * 0.5 + Math.min(interactionCount * 0.1, 0.5);
        return { person: p, resonance };
      });
    return scored.sort((a, b) => b.resonance - a.resonance).slice(0, limit);
  }

  getCultivationPath(personId: string): CultivationEvent[] {
    return Array.from(this.cultivations.values())
      .filter(c => c.personId === personId)
      .sort((a, b) => a.timestamp - b.timestamp);
  }

  getGrowthStats(personId: string): any {
    const person = this.people.get(personId);
    if (!person) return null;
    const cultivations = this.getCultivationPath(personId);
    const posts = Array.from(this.posts.values()).filter(p => p.authorId === personId);
    const interactions = Array.from(this.interactions.values()).filter(i => i.fromId === personId || i.toId === personId);
    return {
      person, growthLevel: person.growthLevel,
      cultivations: cultivations.length, posts: posts.length, interactions: interactions.length,
      totalResonance: posts.reduce((s, p) => s + p.resonance, 0),
      path: cultivations.map(c => ({ type: c.type, gate: c.gate, timestamp: c.timestamp, resonance: c.resonance }))
    };
  }

  getUniverseStats(): any {
    return {
      people: this.people.size, posts: this.posts.size,
      interactions: this.interactions.size, cultivations: this.cultivations.size,
      totalResonance: Array.from(this.posts.values()).reduce((s, p) => s + p.resonance, 0),
      avgGrowth: Array.from(this.people.values()).reduce((s, p) => s + p.growthLevel, 0) / Math.max(1, this.people.size)
    };
  }
}
