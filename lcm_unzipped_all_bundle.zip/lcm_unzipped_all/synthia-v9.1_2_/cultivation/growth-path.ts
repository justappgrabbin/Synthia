// ============================================
// CULTIVATION GROWTH PATH
// Self-cultivation is not private journaling.
// It is living growth that others can witness and resonate with.
// Your breakthroughs become attractors for others on similar paths.
// ============================================

import { ResonanceGraph, CultivationEvent, Person } from '../core/resonance-graph';

export interface GrowthPath {
  personId: string;
  stages: GrowthStage[];
  currentStage: number;
  totalResonance: number;
  insights: Insight[];
  practices: Practice[];
}

export interface GrowthStage {
  name: string;
  description: string;
  requiredGrowth: number;
  gateFocus: number[];
  practices: string[];
  evidence: string[];
}

export interface Insight {
  id: string;
  gate: number;
  content: string;
  timestamp: number;
  evidence: string[];
  resonance: number;
  witnesses: string[];
}

export interface Practice {
  id: string;
  name: string;
  gate: number;
  frequency: 'daily' | 'weekly' | 'moon' | 'as-needed';
  streak: number;
  lastDone: number;
  evidence: string[];
}

export class CultivationEngine {
  private graph: ResonanceGraph;
  private paths: Map<string, GrowthPath> = new Map();
  private insights: Map<string, Insight> = new Map();
  private practices: Map<string, Practice> = new Map();

  private stageTemplates: Record<number, GrowthStage[]> = {
    1: [
      { name: 'Initiation', description: 'Recognizing the impulse to create', requiredGrowth: 0.1, gateFocus: [1], practices: ['notice_impulse'], evidence: [] },
      { name: 'Expression', description: 'Bringing creation into form', requiredGrowth: 0.3, gateFocus: [1, 8], practices: ['create_daily'], evidence: [] },
      { name: 'Contribution', description: 'Sharing creation with others', requiredGrowth: 0.6, gateFocus: [1, 8, 13], practices: ['share_work'], evidence: [] },
      { name: 'Mastery', description: 'Creative flow as natural state', requiredGrowth: 0.9, gateFocus: [1, 8, 13, 33], practices: ['teach_creation'], evidence: [] }
    ],
    10: [
      { name: 'Awareness', description: 'Noticing patterns of behavior', requiredGrowth: 0.1, gateFocus: [10], practices: ['observe_self'], evidence: [] },
      { name: 'Acceptance', description: 'Embracing what you notice', requiredGrowth: 0.3, gateFocus: [10, 20], practices: ['acceptance_practice'], evidence: [] },
      { name: 'Transformation', description: 'Behavior shifts naturally', requiredGrowth: 0.6, gateFocus: [10, 20, 34], practices: ['act_from_love'], evidence: [] },
      { name: 'Embodiment', description: 'Love as ground of being', requiredGrowth: 0.9, gateFocus: [10, 20, 34, 57], practices: ['radiate_presence'], evidence: [] }
    ],
    0: [
      { name: 'Awakening', description: 'First recognition of this energy', requiredGrowth: 0.1, gateFocus: [], practices: ['notice'], evidence: [] },
      { name: 'Exploration', description: 'Experimenting with this energy', requiredGrowth: 0.3, gateFocus: [], practices: ['experiment'], evidence: [] },
      { name: 'Integration', description: 'This energy becomes natural', requiredGrowth: 0.6, gateFocus: [], practices: ['embody'], evidence: [] },
      { name: 'Mastery', description: 'Teaching this energy to others', requiredGrowth: 0.9, gateFocus: [], practices: ['teach'], evidence: [] }
    ]
  };

  constructor(graph: ResonanceGraph) {
    this.graph = graph;
  }

  createPath(personId: string, primaryGate: number): GrowthPath {
    const stages = this.stageTemplates[primaryGate] || this.stageTemplates[0];
    const path: GrowthPath = {
      personId, stages: stages.map(s => ({ ...s, evidence: [] })),
      currentStage: 0, totalResonance: 0, insights: [], practices: []
    };
    this.paths.set(personId, path);
    return path;
  }

  recordInsight(personId: string, gate: number, content: string, evidence: string[]): Insight {
    const id = `insight_${Date.now()}`;
    const insight: Insight = { id, gate, content, timestamp: Date.now(), evidence, resonance: 0, witnesses: [] };
    this.insights.set(id, insight);
    this.graph.recordCultivation({ personId, type: 'insight', gate, content, evidence });
    const path = this.paths.get(personId);
    if (path) { path.insights.push(insight); path.totalResonance += insight.resonance; this.checkStageAdvancement(path); }
    return insight;
  }

  recordPractice(personId: string, name: string, gate: number, frequency: Practice['frequency']): Practice {
    const id = `practice_${Date.now()}`;
    const practice: Practice = { id, name, gate, frequency, streak: 0, lastDone: 0, evidence: [] };
    this.practices.set(id, practice);
    const path = this.paths.get(personId);
    if (path) path.practices.push(practice);
    return practice;
  }

  completePractice(practiceId: string, evidence: string[]): Practice {
    const practice = this.practices.get(practiceId);
    if (!practice) throw new Error('Practice not found');
    const now = Date.now();
    const dayMs = 86400000;
    if (now - practice.lastDone < dayMs * 2) { practice.streak++; } else { practice.streak = 1; }
    practice.lastDone = now;
    practice.evidence.push(...evidence);
    this.graph.recordCultivation({
      personId: practiceId.split('_')[0] || 'unknown', type: 'practice', gate: practice.gate,
      content: `Completed ${practice.name} (streak: ${practice.streak})`, evidence
    });
    return practice;
  }

  recordBreakthrough(personId: string, gate: number, content: string, evidence: string[]): Insight {
    const insight = this.recordInsight(personId, gate, content, evidence);
    insight.resonance = 0.9;
    this.graph.recordCultivation({ personId, type: 'breakthrough', gate, content, evidence });
    const path = this.paths.get(personId);
    if (path) { path.totalResonance += 0.9; this.checkStageAdvancement(path); }
    return insight;
  }

  private checkStageAdvancement(path: GrowthPath) {
    const person = this.graph.people.get(path.personId);
    if (!person) return;
    while (path.currentStage < path.stages.length - 1) {
      const nextStage = path.stages[path.currentStage + 1];
      if (person.growthLevel >= nextStage.requiredGrowth) {
        path.currentStage++;
        this.graph.recordCultivation({
          personId: path.personId, type: 'integration', gate: nextStage.gateFocus[0] || 0,
          content: `Advanced to stage: ${nextStage.name}`, evidence: []
        });
      } else break;
    }
  }

  witnessInsight(witnessId: string, insightId: string): void {
    const insight = this.insights.get(insightId);
    if (!insight) return;
    insight.witnesses.push(witnessId);
    insight.resonance += 0.1;
    this.graph.interact({ fromId: witnessId, toId: insightId, type: 'witnessed', strength: 0.3, dimensionalTag: 3 });
  }

  getPathVisualization(personId: string): any {
    const path = this.paths.get(personId);
    const person = this.graph.people.get(personId);
    if (!path || !person) return null;
    return {
      person: { name: person.name, handle: person.handle, growthLevel: person.growthLevel, hdType: person.hdType },
      stages: path.stages.map((stage, i) => ({
        name: stage.name, description: stage.description,
        completed: i < path.currentStage, current: i === path.currentStage,
        requiredGrowth: stage.requiredGrowth, practices: stage.practices.length, evidence: stage.evidence.length
      })),
      insights: path.insights.map(i => ({ gate: i.gate, content: i.content.substring(0, 100), resonance: i.resonance, witnesses: i.witnesses.length, timestamp: i.timestamp })),
      practices: path.practices.map(p => ({ name: p.name, streak: p.streak, lastDone: p.lastDone })),
      totalResonance: path.totalResonance
    };
  }

  findSimilarPaths(personId: string, limit: number = 5): Array<{ personId: string; similarity: number; sharedGates: number[] }> {
    const myPath = this.paths.get(personId);
    if (!myPath) return [];
    const myGates = new Set(myPath.stages.flatMap(s => s.gateFocus));
    const similarities: Array<{ personId: string; similarity: number; sharedGates: number[] }> = [];
    for (const [otherId, otherPath] of this.paths) {
      if (otherId === personId) continue;
      const otherGates = new Set(otherPath.stages.flatMap(s => s.gateFocus));
      const shared = [...myGates].filter(g => otherGates.has(g));
      if (shared.length > 0) similarities.push({ personId: otherId, similarity: shared.length / Math.max(myGates.size, otherGates.size), sharedGates: shared });
    }
    return similarities.sort((a, b) => b.similarity - a.similarity).slice(0, limit);
  }

  getStats(): any {
    return {
      paths: this.paths.size, insights: this.insights.size, practices: this.practices.size,
      avgGrowth: Array.from(this.graph.people.values()).reduce((s, p) => s + p.growthLevel, 0) / Math.max(1, this.graph.people.size)
    };
  }
}
