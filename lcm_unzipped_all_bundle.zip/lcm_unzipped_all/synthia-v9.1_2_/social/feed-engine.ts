// ============================================
// SOCIAL FEED ENGINE
// Not chronological. Not algorithmic. Resonance-ordered.
// What you see is what the manifold brings to your attractor.
// ============================================

import { ResonanceGraph, Post, Person, Interaction } from '../core/resonance-graph';

export interface FeedItem {
  post: Post;
  score: number;
  reason: string;
  resonancePath: string[];
}

export interface FeedContext {
  personId: string;
  mode: 'resonance' | 'growth' | 'discovery' | 'cultivation';
  timeRange: number;
  diversityBoost: number;
}

export class FeedEngine {
  private graph: ResonanceGraph;

  constructor(graph: ResonanceGraph) {
    this.graph = graph;
  }

  generateFeed(context: FeedContext): FeedItem[] {
    const person = this.graph.people.get(context.personId);
    if (!person) return [];
    const allPosts = Array.from(this.graph.posts.values())
      .filter(p => p.timestamp > Date.now() - context.timeRange);
    const scored = allPosts.map(post => {
      const { score, reason, path } = this.scorePost(post, person, context);
      return { post, score, reason, resonancePath: path };
    });
    return scored.sort((a, b) => b.score - a.score).slice(0, 50);
  }

  private scorePost(post: Post, viewer: Person, context: FeedContext): { score: number; reason: string; path: string[] } {
    const postPos = this.graph.manifoldValue([0.5, 0.5, 0.5]); // placeholder
    const dist = Math.sqrt(
      viewer.attractorPosition.reduce((s, v, i) => s + (v - (post.gateResonance[0] ? 0.5 : 0.5)) ** 2, 0)
    );
    let score = 0;
    let reason = '';
    const path: string[] = [];

    switch (context.mode) {
      case 'resonance':
        score = (1 / (1 + dist * 5)) * 0.6 + post.resonance * 0.4;
        reason = dist < 0.3 ? 'Close resonance' : 'Field proximity';
        path.push('your-attractor', 'manifold-proximity');
        break;
      case 'growth':
        score = dist * 0.5 + post.resonance * 0.3;
        if (post.type === 'reflection' || post.type === 'question') score += 0.2;
        reason = 'Growth opportunity';
        path.push('your-attractor', 'expansion-zone');
        break;
      case 'discovery':
        score = dist * 0.7 + post.resonance * 0.2 + context.diversityBoost * 0.1;
        reason = 'New resonance';
        path.push('distant-attractor', 'discovery-path');
        break;
      case 'cultivation':
        const cultivations = this.graph.getCultivationPath(viewer.id);
        const relevantGates = new Set(cultivations.map(c => c.gate));
        const overlap = post.gateResonance.filter(g => relevantGates.has(g)).length;
        score = (overlap / Math.max(1, post.gateResonance.length)) * 0.5 + post.resonance * 0.3 + (1 / (1 + dist)) * 0.2;
        reason = overlap > 0 ? 'Cultivation resonance' : 'Field alignment';
        path.push('cultivation-path', 'gate-alignment');
        break;
    }

    const author = this.graph.people.get(post.authorId);
    if (author) {
      const authorDist = Math.sqrt(
        viewer.attractorPosition.reduce((s, v, i) => s + (v - author.attractorPosition[i]) ** 2, 0)
      );
      if (authorDist < 0.3) score += 0.15;
    }

    return { score, reason, path };
  }

  resonate(personId: string, postId: string): Interaction {
    return this.graph.interact({
      fromId: personId, toId: postId, type: 'resonated', strength: 0.5, dimensionalTag: 2
    });
  }

  echo(personId: string, postId: string): Interaction {
    const post = this.graph.posts.get(postId);
    if (post) post.echoes.push(`echo_${Date.now()}`);
    return this.graph.interact({
      fromId: personId, toId: postId, type: 'echoed', strength: 0.8, dimensionalTag: 2
    });
  }

  reply(personId: string, postId: string, content: string): { interaction: Interaction; replyPost: Post } {
    const original = this.graph.posts.get(postId);
    if (!original) throw new Error('Post not found');
    const replyPost = this.graph.createPost({
      authorId: personId, content, type: 'thought', gateResonance: original.gateResonance, dimensionalTag: 3
    });
    original.replies.push(replyPost.id);
    const interaction = this.graph.interact({
      fromId: personId, toId: postId, type: 'replied', strength: 0.6, dimensionalTag: 3
    });
    return { interaction, replyPost };
  }

  witness(personId: string, postId: string): Interaction {
    return this.graph.interact({
      fromId: personId, toId: postId, type: 'witnessed', strength: 0.2, dimensionalTag: 3
    });
  }

  connect(personId: string, otherPersonId: string): Interaction {
    const person = this.graph.people.get(personId);
    const other = this.graph.people.get(otherPersonId);
    if (!person || !other) throw new Error('Person not found');
    for (let i = 0; i < person.attractorPosition.length; i++) {
      const delta = other.attractorPosition[i] - person.attractorPosition[i];
      person.attractorPosition[i] += delta * 0.05;
      other.attractorPosition[i] -= delta * 0.05;
    }
    return this.graph.interact({
      fromId: personId, toId: otherPersonId, type: 'connected', strength: 0.7, dimensionalTag: 2
    });
  }

  getNotifications(personId: string): Array<{ type: string; from: string; content: string; timestamp: number }> {
    const notifications: Array<{ type: string; from: string; content: string; timestamp: number }> = [];
    for (const post of this.graph.posts.values()) {
      if (post.authorId === personId) {
        for (const replyId of post.replies) {
          const reply = this.graph.posts.get(replyId);
          if (reply) {
            notifications.push({ type: 'reply', from: reply.authorId, content: reply.content.substring(0, 100), timestamp: reply.timestamp });
          }
        }
        for (const echoId of post.echoes) {
          notifications.push({ type: 'echo', from: 'someone', content: `Echoed: ${post.content.substring(0, 50)}...`, timestamp: post.timestamp });
        }
      }
    }
    for (const interaction of this.graph.interactions.values()) {
      if (interaction.toId === personId && interaction.type === 'resonated') {
        notifications.push({ type: 'resonance', from: interaction.fromId, content: 'resonated with you', timestamp: interaction.timestamp });
      }
    }
    return notifications.sort((a, b) => b.timestamp - a.timestamp).slice(0, 20);
  }
}
