// ============================================
// GENERATIVE UNIVERSE
// The world is not a game. It is a living visualization of the collective field.
// Terrain = manifold curvature. Entities = people and posts. Weather = field turbulence.
// ============================================

import { ResonanceGraph, Person, Post } from '../core/resonance-graph';

export interface UniverseEntity {
  id: string;
  type: 'person' | 'post' | 'attractor' | 'path' | 'field' | 'weather';
  position: [number, number, number];
  velocity: [number, number, number];
  size: number;
  color: [number, number, number, number];
  pulse: number;
  connections: string[];
  metadata: Record<string, any>;
}

export interface TerrainCell {
  x: number;
  y: number;
  z: number;
  height: number;
  material: 'void' | 'crystal' | 'earth' | 'water' | 'growth' | 'resonance';
  energy: number;
  gateInfluence: number;
}

export interface WeatherState {
  turbulence: number;
  resonanceWaves: Array<{ origin: [number, number, number]; amplitude: number; frequency: number }>;
  growthSpores: number;
  clarity: number;
}

export class GenerativeUniverse {
  private graph: ResonanceGraph;
  private entities: Map<string, UniverseEntity> = new Map();
  private terrain: Map<string, TerrainCell> = new Map();
  private weather: WeatherState;
  private time: number = 0;
  private size: [number, number, number] = [200, 100, 200];
  private running: boolean = false;
  private interval: any;

  constructor(graph: ResonanceGraph) {
    this.graph = graph;
    this.weather = { turbulence: 0.3, resonanceWaves: [], growthSpores: 0.1, clarity: 0.5 };
    this.generateTerrain();
  }

  private generateTerrain() {
    const [sx, sy, sz] = this.size;
    const resolution = 4;
    for (let x = -sx/2; x < sx/2; x += resolution) {
      for (let z = -sz/2; z < sz/2; z += resolution) {
        const pos: [number, number, number] = [x / sx + 0.5, 0.5, z / sz + 0.5];
        const manifoldValue = this.graph.manifoldValue(pos);
        const gateInfluence = this.calculateGateInfluence(pos);
        const cell: TerrainCell = {
          x, y: 0, z,
          height: (manifoldValue * sy * 0.3) - sy * 0.15,
          material: this.selectMaterial(manifoldValue, gateInfluence),
          energy: manifoldValue * 10,
          gateInfluence
        };
        this.terrain.set(`${x},${z}`, cell);
      }
    }
  }

  private selectMaterial(manifold: number, gateInf: number): TerrainCell['material'] {
    if (manifold > 2.0) return 'resonance';
    if (manifold > 1.2) return 'crystal';
    if (gateInf > 0.5) return 'growth';
    if (manifold > 0.6) return 'earth';
    if (manifold > 0.3) return 'water';
    return 'void';
  }

  private calculateGateInfluence(pos: [number, number, number]): number {
    let maxInfluence = 0;
    for (const [_, person] of this.graph.people) {
      const dist = Math.sqrt(
        (pos[0] - person.attractorPosition[0]) ** 2 +
        (pos[1] - person.attractorPosition[1]) ** 2 +
        (pos[2] - person.attractorPosition[2]) ** 2
      );
      maxInfluence = Math.max(maxInfluence, 1 / (1 + dist * 5));
    }
    return maxInfluence;
  }

  sync(): void {
    for (const [_, person] of this.graph.people) {
      const entityId = `person:${person.id}`;
      if (!this.entities.has(entityId)) { this.spawnPersonEntity(person); }
      else { this.updatePersonEntity(entityId, person); }
    }
    for (const [_, post] of this.graph.posts) {
      if (post.resonance > 1.0) {
        const entityId = `post:${post.id}`;
        if (!this.entities.has(entityId)) { this.spawnPostEntity(post); }
      }
    }
    this.updateConnections();
    this.updateWeather();
  }

  private spawnPersonEntity(person: Person): UniverseEntity {
    const entity: UniverseEntity = {
      id: `person:${person.id}`, type: 'person',
      position: [
        person.attractorPosition[0] * this.size[0] - this.size[0]/2,
        person.growthLevel * this.size[1] * 0.5,
        person.attractorPosition[2] * this.size[2] - this.size[2]/2
      ],
      velocity: [0, 0, 0], size: 3 + person.attractorStrength * 2,
      color: this.personColor(person), pulse: 0, connections: [],
      metadata: { name: person.name, growthLevel: person.growthLevel, hdType: person.hdType }
    };
    this.entities.set(entity.id, entity);
    return entity;
  }

  private updatePersonEntity(entityId: string, person: Person) {
    const entity = this.entities.get(entityId);
    if (!entity) return;
    entity.size = 3 + person.attractorStrength * 2;
    entity.color = this.personColor(person);
    entity.metadata.growthLevel = person.growthLevel;
    const targetY = person.growthLevel * this.size[1] * 0.5;
    entity.velocity[1] += (targetY - entity.position[1]) * 0.01;
  }

  private personColor(person: Person): [number, number, number, number] {
    const typeColors: Record<string, [number, number, number]> = {
      'Generator': [0, 212, 170], 'Manifestor': [255, 100, 100],
      'Projector': [180, 120, 255], 'Reflector': [255, 200, 100],
      'Manifesting Generator': [100, 200, 255]
    };
    const base = typeColors[person.hdType] || [150, 150, 150];
    const alpha = 0.4 + person.growthLevel * 0.6;
    return [...base, alpha] as [number, number, number, number];
  }

  private spawnPostEntity(post: Post): UniverseEntity {
    const author = this.graph.people.get(post.authorId);
    const basePos = author ? author.attractorPosition : [0.5, 0.5, 0.5];
    const entity: UniverseEntity = {
      id: `post:${post.id}`, type: 'post',
      position: [
        (basePos[0] + (Math.random() - 0.5) * 0.2) * this.size[0] - this.size[0]/2,
        (basePos[1] + post.resonance * 0.1) * this.size[1] - this.size[1]/2,
        (basePos[2] + (Math.random() - 0.5) * 0.2) * this.size[2] - this.size[2]/2
      ],
      velocity: [0, 0.01, 0], size: 1 + post.resonance * 2,
      color: [255, 255, 255, 0.6], pulse: 0, connections: [],
      metadata: { content: post.content.substring(0, 50), resonance: post.resonance, type: post.type }
    };
    this.entities.set(entity.id, entity);
    return entity;
  }

  private updateConnections() {
    for (const [id, entity] of this.entities) {
      if (entity.type !== 'person') continue;
      const personId = id.replace('person:', '');
      const person = this.graph.people.get(personId);
      if (!person) continue;
      entity.connections = [];
      for (const [otherId, other] of this.entities) {
        if (other.type !== 'person' || otherId === id) continue;
        const otherPersonId = otherId.replace('person:', '');
        const dist = Math.sqrt(
          (entity.position[0] - other.position[0]) ** 2 +
          (entity.position[1] - other.position[1]) ** 2 +
          (entity.position[2] - other.position[2]) ** 2
        );
        if (dist < 30) entity.connections.push(otherId);
      }
      for (const [postId, post] of this.graph.posts) {
        if (post.authorId === personId) {
          const postEntity = this.entities.get(`post:${postId}`);
          if (postEntity) entity.connections.push(`post:${postId}`);
        }
      }
    }
  }

  private updateWeather() {
    const stats = this.graph.getUniverseStats();
    this.weather.turbulence = Math.min(1, stats.people * 0.01 + stats.interactions * 0.001);
    this.weather.clarity = Math.min(1, stats.avgGrowth * 2);
    this.weather.growthSpores = Math.min(1, stats.totalResonance * 0.001);
    this.weather.resonanceWaves = [];
    for (const [_, person] of this.graph.people) {
      if (person.attractorStrength > 2) {
        this.weather.resonanceWaves.push({
          origin: [
            person.attractorPosition[0] * this.size[0] - this.size[0]/2,
            person.attractorPosition[1] * this.size[1] - this.size[1]/2,
            person.attractorPosition[2] * this.size[2] - this.size[2]/2
          ],
          amplitude: person.attractorStrength * 0.1,
          frequency: 0.5 + person.growthLevel
        });
      }
    }
  }

  tick(dt: number = 0.016) {
    this.time += dt;
    for (const [_, entity] of this.entities) {
      for (const connectedId of entity.connections) {
        const connected = this.entities.get(connectedId);
        if (!connected) continue;
        const dx = connected.position[0] - entity.position[0];
        const dy = connected.position[1] - entity.position[1];
        const dz = connected.position[2] - entity.position[2];
        const dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
        if (dist > 0 && dist < 40) {
          const force = 0.0005 * (1 - dist / 40);
          entity.velocity[0] += dx * force;
          entity.velocity[1] += dy * force;
          entity.velocity[2] += dz * force;
        }
      }
      for (const [__, other] of this.entities) {
        if (other.id === entity.id) continue;
        const dx = entity.position[0] - other.position[0];
        const dy = entity.position[1] - other.position[1];
        const dz = entity.position[2] - other.position[2];
        const dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
        if (dist > 0 && dist < 8) {
          const force = 0.005 * (8 - dist) / dist;
          entity.velocity[0] += dx * force;
          entity.velocity[1] += dy * force;
          entity.velocity[2] += dz * force;
        }
      }
      if (this.weather.turbulence > 0.5) {
        entity.velocity[0] += (Math.random() - 0.5) * this.weather.turbulence * 0.01;
        entity.velocity[2] += (Math.random() - 0.5) * this.weather.turbulence * 0.01;
      }
      entity.velocity[0] *= 0.96;
      entity.velocity[1] *= 0.96;
      entity.velocity[2] *= 0.96;
      entity.position[0] += entity.velocity[0];
      entity.position[1] += entity.velocity[1];
      entity.position[2] += entity.velocity[2];
      entity.pulse = Math.sin(this.time * 2 + entity.position[0] * 0.1) * 0.5 + 0.5;
    }
    for (const [_, entity] of this.entities) {
      if (entity.type === 'post') {
        entity.position[1] += entity.velocity[1];
        entity.color[3] *= 0.999;
      }
    }
  }

  getRenderData(): any {
    return {
      time: this.time,
      entities: Array.from(this.entities.values()).map(e => ({
        id: e.id, type: e.type, position: e.position, size: e.size,
        color: e.color, pulse: e.pulse, connections: e.connections.length, metadata: e.metadata
      })),
      terrain: Array.from(this.terrain.values()).slice(0, 2000),
      weather: this.weather, size: this.size
    };
  }

  getStats() {
    return { entities: this.entities.size, terrain: this.terrain.size, weather: this.weather, time: this.time };
  }

  start(fps: number = 30) {
    if (this.running) return;
    this.running = true;
    this.interval = setInterval(() => { this.sync(); this.tick(1/fps); }, 1000/fps);
  }

  stop() {
    this.running = false;
    if (this.interval) clearInterval(this.interval);
  }
}
