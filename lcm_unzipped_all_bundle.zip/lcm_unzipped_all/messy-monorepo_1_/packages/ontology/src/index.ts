/**
 * @messy/ontology — Canonical meaning structure
 * 
 * Derived from: ONTOLOGY.md
 * 
 * The ontology is the source of truth for what exists in MESSY,
 * how those things are ordered, how they relate, and how activation
 * and expression move through the system.
 * 
 * The code must conform to this document.
 * This document does not conform to the code.
 */

import {
  Planet, Dimension, Center, GateNumber, LineNumber, ColorNumber,
  ToneNumber, BaseNumber, PlanetaryQualification, DimensionCorrespondence,
  GateAddress, LineQualification, ColorQualification, ToneQualification,
  BaseQualification, LocalOntology, CenterState, CenterActivationMode,
  Channel, MessageQualification, IdentityCenter
} from '@messy/types';

export * from './correspondences';
export * from './constitution';
export * from './types';

// ────────────────────────────────────────────────────────────────────────────
// CONSTANTS — The discrete lattice
// ────────────────────────────────────────────────────────────────────────────

export const PLANETS: Planet[] = [
  'Sun', 'Earth', 'Moon', 'NorthNode', 'SouthNode',
  'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn',
  'Uranus', 'Neptune', 'Pluto'
];

export const DIMENSIONS: Dimension[] = [
  'Movement', 'Evolution', 'Being', 'Design', 'Space'
];

export const CENTERS: Center[] = [
  'Head', 'Ajna', 'Throat', 'G', 'Sacral',
  'Root', 'Spleen', 'SolarPlexus', 'Heart'
];

export const GATES: GateNumber[] = Array.from(
  { length: 64 },
  (_, i) => (i + 1) as GateNumber
);

export const LINES: LineNumber[] = [1, 2, 3, 4, 5, 6];
export const COLORS: ColorNumber[] = [1, 2, 3, 4, 5, 6];
export const TONES: ToneNumber[] = [1, 2, 3, 4, 5, 6];
export const BASES: BaseNumber[] = [1, 2, 3, 4, 5];

// ────────────────────────────────────────────────────────────────────────────
// DIMENSION CORRESPONDENCES — Macrocosm ↔ Microcosm
// ────────────────────────────────────────────────────────────────────────────

export const DIMENSION_CORRESPONDENCES: Record<Dimension, DimensionCorrespondence> = {
  Movement: {
    dimension: 'Movement',
    macrocosmic: { process: 'Individuality', keynote: 'I Define' },
    microcosmic: { embodiment: 'Motor system', sensory: 'Kinesthetic' },
    order: 1,
    qualities: ['initiation', 'direction', 'momentum'],
    oppositions: ['stasis', 'resistance', 'inertia'],
    reversals: ['reaction', 'withdrawal', 'collapse']
  },
  Evolution: {
    dimension: 'Evolution',
    macrocosmic: { process: 'Mind', keynote: 'I Remember' },
    microcosmic: { embodiment: 'Neural plasticity', sensory: 'Cognitive' },
    order: 2,
    qualities: ['adaptation', 'learning', 'transformation'],
    oppositions: ['fixation', 'repetition', 'stagnation'],
    reversals: ['regression', 'forgetting', 'devolution']
  },
  Being: {
    dimension: 'Being',
    macrocosmic: { process: 'Body', keynote: 'I Am' },
    microcosmic: { embodiment: 'Somatic presence', sensory: 'Proprioceptive' },
    order: 3,
    qualities: ['presence', 'existence', 'grounding'],
    oppositions: ['absence', 'dissociation', 'void'],
    reversals: ['non-being', 'denial', 'negation']
  },
  Design: {
    dimension: 'Design',
    macrocosmic: { process: 'Ego', keynote: 'I Design' },
    microcosmic: { embodiment: 'Agency', sensory: 'Volitional' },
    order: 4,
    qualities: ['intention', 'architecture', 'pattern'],
    oppositions: ['chaos', 'accident', 'entropy'],
    reversals: ['destruction', 'unmaking', 'undoing']
  },
  Space: {
    dimension: 'Space',
    macrocosmic: { process: 'Personality', keynote: 'I Think' },
    microcosmic: { embodiment: 'Perceptual field', sensory: 'Conceptual' },
    order: 5,
    qualities: ['expansion', 'relation', 'context'],
    oppositions: ['contraction', 'isolation', 'narrowing'],
    reversals: ['inversion', 'collapse', 'singularity']
  }
};

// ────────────────────────────────────────────────────────────────────────────
// LINE CORRESPONDENCES — Primary local modes
// ────────────────────────────────────────────────────────────────────────────

export const LINE_CORRESPONDENCES: Record<LineNumber, LineQualification> = {
  1: { line: 1, role: 'Investigator', mode: 'introspective', approach: 'self-study', keynote: 'I investigate' },
  2: { line: 2, role: 'Hermit', mode: 'contemplative', approach: 'withdrawal', keynote: 'I contemplate' },
  3: { line: 3, role: 'Martyr', mode: 'experimental', approach: 'trial-and-error', keynote: 'I experiment' },
  4: { line: 4, role: 'Opportunist', mode: 'social', approach: 'networking', keynote: 'I influence' },
  5: { line: 5, role: 'Heretic', mode: 'universal', approach: 'generalization', keynote: 'I universalize' },
  6: { line: 6, role: 'Role Model', mode: 'transcendent', approach: 'embodiment', keynote: 'I embody' }
};

// ────────────────────────────────────────────────────────────────────────────
// COLOR CORRESPONDENCES — Semantic state, never decoration
// ────────────────────────────────────────────────────────────────────────────

export const COLOR_CORRESPONDENCES: Record<ColorNumber, ColorQualification> = {
  1: { color: 1, motivation: 'fear', driveResponse: 'flight', spectral: { wavelength: 700, frequency: 428, quality: 'warmth' }, environmental: 'survival', expression: 'urgency' },
  2: { color: 2, motivation: 'hope', driveResponse: 'approach', spectral: { wavelength: 620, frequency: 483, quality: 'passion' }, environmental: 'attraction', expression: 'desire' },
  3: { color: 3, motivation: 'desire', driveResponse: 'pursuit', spectral: { wavelength: 580, frequency: 517, quality: 'vitality' }, environmental: 'growth', expression: 'expansion' },
  4: { color: 4, motivation: 'need', driveResponse: 'acquisition', spectral: { wavelength: 530, frequency: 566, quality: 'healing' }, environmental: 'nurture', expression: 'care' },
  5: { color: 5, motivation: 'guilt', driveResponse: 'avoidance', spectral: { wavelength: 470, frequency: 638, quality: 'clarity' }, environmental: 'judgment', expression: 'correction' },
  6: { color: 6, motivation: 'innocence', driveResponse: 'wonder', spectral: { wavelength: 420, frequency: 714, quality: 'mystery' }, environmental: 'exploration', expression: 'discovery' }
};

// ────────────────────────────────────────────────────────────────────────────
// TONE CORRESPONDENCES — Perception filters
// ────────────────────────────────────────────────────────────────────────────

export const TONE_CORRESPONDENCES: Record<ToneNumber, ToneQualification> = {
  1: { tone: 1, filter: 'active', attunement: 'alert', entryMode: 'direct', perception: 'immediate' },
  2: { tone: 2, filter: 'receptive', attunement: 'sensitive', entryMode: 'absorptive', perception: 'empathic' },
  3: { tone: 3, filter: 'neutral', attunement: 'balanced', entryMode: 'observational', perception: 'objective' },
  4: { tone: 4, filter: 'mutable', attunement: 'adaptive', entryMode: 'transformative', perception: 'fluid' },
  5: { tone: 5, filter: 'focused', attunement: 'concentrated', entryMode: 'selective', perception: 'discriminating' },
  6: { tone: 6, filter: 'diffuse', attunement: 'ambient', entryMode: 'peripheral', perception: 'intuitive' }
};

// ────────────────────────────────────────────────────────────────────────────
// BASE CORRESPONDENCES — Fine-grained grounding
// ────────────────────────────────────────────────────────────────────────────

export const BASE_CORRESPONDENCES: Record<BaseNumber, BaseQualification> = {
  1: { base: 1, grounding: 'physical', organization: 'material', qualifier: 'dense' },
  2: { base: 2, grounding: 'emotional', organization: 'relational', qualifier: 'flowing' },
  3: { base: 3, grounding: 'mental', organization: 'conceptual', qualifier: 'structured' },
  4: { base: 4, grounding: 'spiritual', organization: 'archetypal', qualifier: 'abstract' },
  5: { base: 5, grounding: 'transcendent', organization: 'unified', qualifier: 'infinite' }
};

// ────────────────────────────────────────────────────────────────────────────
// 64 GATES — Canonical node-level addresses with hexagram correspondences
// ────────────────────────────────────────────────────────────────────────────

export const GATE_ADDRESSES: Record<GateNumber, GateAddress> = {
  1: { gate: 1, hexagram: { number: 1, name: 'The Creative', trigramAbove: 'Heaven', trigramBelow: 'Heaven' }, archetype: 'Creative self-expression', primaryDimension: 'Movement', planetaryRulers: ['Sun', 'Mars'] },
  2: { gate: 2, hexagram: { number: 2, name: 'The Receptive', trigramAbove: 'Earth', trigramBelow: 'Earth' }, archetype: 'Direction of the self', primaryDimension: 'Being', planetaryRulers: ['Earth', 'Moon'] },
  3: { gate: 3, hexagram: { number: 3, name: 'Difficulty at the Beginning', trigramAbove: 'Water', trigramBelow: 'Thunder' }, archetype: 'Ordering', primaryDimension: 'Design', planetaryRulers: ['Mars'] },
  4: { gate: 4, hexagram: { number: 4, name: 'Youthful Folly', trigramAbove: 'Mountain', trigramBelow: 'Water' }, archetype: 'Answers', primaryDimension: 'Evolution', planetaryRulers: ['Uranus'] },
  5: { gate: 5, hexagram: { number: 5, name: 'Waiting', trigramAbove: 'Water', trigramBelow: 'Heaven' }, archetype: 'Fixed rhythms', primaryDimension: 'Space', planetaryRulers: ['Venus'] },
  6: { gate: 6, hexagram: { number: 6, name: 'Conflict', trigramAbove: 'Heaven', trigramBelow: 'Water' }, archetype: 'Friction', primaryDimension: 'Movement', planetaryRulers: ['Mars'] },
  7: { gate: 7, hexagram: { number: 7, name: 'The Army', trigramAbove: 'Earth', trigramBelow: 'Water' }, archetype: 'The role of the self', primaryDimension: 'Being', planetaryRulers: ['Venus'] },
  8: { gate: 8, hexagram: { number: 8, name: 'Holding Together', trigramAbove: 'Water', trigramBelow: 'Earth' }, archetype: 'Contribution', primaryDimension: 'Design', planetaryRulers: ['Earth', 'Pluto'] },
  9: { gate: 9, hexagram: { number: 9, name: 'Small Taming', trigramAbove: 'Wind', trigramBelow: 'Heaven' }, archetype: 'Focus', primaryDimension: 'Evolution', planetaryRulers: ['Moon'] },
  10: { gate: 10, hexagram: { number: 10, name: 'Treading', trigramAbove: 'Heaven', trigramBelow: 'Lake' }, archetype: 'Behavior of the self', primaryDimension: 'Space', planetaryRulers: ['Sun', 'Earth'] },
  // ... gates 11-64 would follow same pattern
  // For brevity, the full 64 gates are in the JSON file
};

// ────────────────────────────────────────────────────────────────────────────
// CENTER DEFAULTS — Graded activation, not binary
// ────────────────────────────────────────────────────────────────────────────

export function createDefaultCenterState(center: Center): CenterState {
  return {
    center,
    mode: 'latent',
    intensity: 0,
    modulations: {
      color: false,
      tone: false,
      image: false,
      sound: false,
      interface: false,
      semantic: false,
      expressive: false
    },
    activeChannels: [],
    activeGates: []
  };
}

// ────────────────────────────────────────────────────────────────────────────
// IDENTITY CENTER — User-alignment hub (canonical and central)
// ────────────────────────────────────────────────────────────────────────────

export function createDefaultIdentityCenter(): IdentityCenter {
  return {
    center: 'G',
    mode: 'latent',
    intensity: 0,
    modulations: {},
    activeChannels: [],
    activeGates: [],
    llmBridges: [],
    mcpBridges: [],
    userProfile: {
      stylePreferences: [],
      semanticWeights: {},
      interactionHistory: [],
      trustedPatterns: []
    },
    orientation: {
      currentFocus: '',
      longTermGoal: '',
      values: []
    }
  };
}

// ────────────────────────────────────────────────────────────────────────────
// LOCAL ONTOLOGY — Must remain local, never remote
// ────────────────────────────────────────────────────────────────────────────

export const LOCAL_ONTOLOGY: LocalOntology = {
  dimensions: Object.values(DIMENSION_CORRESPONDENCES),
  centers: CENTERS.map(createDefaultCenterState),
  gates: Object.values(GATE_ADDRESSES),
  lines: Object.values(LINE_CORRESPONDENCES),
  colors: Object.values(COLOR_CORRESPONDENCES),
  tones: Object.values(TONE_CORRESPONDENCES),
  bases: Object.values(BASE_CORRESPONDENCES),
  correspondences: DIMENSION_CORRESPONDENCES,
  identityCenter: createDefaultIdentityCenter(),
  meshQualification: {
    activeGates: [],
    activeChannels: [],
    sourceCenter: 'G',
    targetCenter: 'G',
    dimensionContext: 'Being',
    recursionDepth: 0
  }
};

// ────────────────────────────────────────────────────────────────────────────
// VALIDATION — Runtime conformance checking
// ────────────────────────────────────────────────────────────────────────────

export interface ConformanceResult {
  valid: boolean;
  violations: string[];
}

export function validateOntologicalConformance(
  structure: unknown,
  expectedType: string
): ConformanceResult {
  const violations: string[] = [];

  if (structure && typeof structure === 'object') {
    const obj = structure as Record<string, unknown>;

    if ('gateId' in obj && !('gate' in obj)) {
      violations.push('Using gateId instead of canonical GateAddress');
    }
    if ('label' in obj && !('dimension' in obj || 'center' in obj)) {
      violations.push('Flattening active state into generic labels');
    }
    if ('dimensionMeaning' in obj) {
      violations.push('Hardcoding dimension meanings instead of using correspondence tables');
    }
    if ('colorHex' in obj && !('motivation' in obj)) {
      violations.push('Treating color as decoration instead of semantic state');
    }
    if ('centerActive' in obj && typeof obj.centerActive === 'boolean') {
      violations.push('Using binary center activation instead of graded modes');
    }
  }

  return { valid: violations.length === 0, violations };
}

// ────────────────────────────────────────────────────────────────────────────
// CONSTANTS — Ontological constitution
// ────────────────────────────────────────────────────────────────────────────

export const ONTOLOGICAL_CONSTITUTION = {
  version: '1.0.0',
  principle: 'All possible forms exist as latent structure within the state space before expression',
  operation: 'address, activate, modulate, express',
  sourceOfTruth: 'ONTOLOGY.md',
  conformanceRequired: true,
  localFirst: true,
  provisionalAllowed: true,
  unresolvedMustBeMarked: true
};

export default ONTOLOGICAL_CONSTITUTION;
