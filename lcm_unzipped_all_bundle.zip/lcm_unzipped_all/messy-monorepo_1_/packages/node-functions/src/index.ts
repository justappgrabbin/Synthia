/**
 * @messy/node-functions — What nodes contribute before channels emerge
 * 
 * Derived from: NODE_FUNCTIONS.md
 * 
 * A channel is an emergent edge-function produced by the interaction
 * of node-potentials. Node contribution is prior to channel identity.
 * Edge-function is prior to channel identity.
 * Channel identity is prior to functional equivalence labels.
 * 
 * This is the derivation order:
 * node-potentials -> edge-function -> channel identity -> named labels
 */

import {
  NodeFunction, NodeContribution, NodePolarity, RelationalAffordance,
  InternalCoordinates, GateAddress, LineQualification, ColorQualification,
  ToneQualification, BaseQualification, ArcPosition, StabilityPosition
} from '@messy/types';
import { LINE_CORRESPONDENCES, COLOR_CORRESPONDENCES, TONE_CORRESPONDENCES } from '@messy/ontology';
import { InternalCoordinatesImpl, ArcPositionImpl } from '@messy/state-space';

// ────────────────────────────────────────────────────────────────────────────
// NODE CONTRIBUTION CATEGORIES — First-pass classification
// ────────────────────────────────────────────────────────────────────────────

export const CONTRIBUTION_CATEGORIES = {
  initiatory: ['initiation', 'pressure', 'push', 'provoke', 'movement'] as NodeContribution[],
  receptive: ['reception', 'hold', 'filter', 'condition'] as NodeContribution[],
  formulating: ['formulation', 'shape', 'articulate', 'compress', 'render'] as NodeContribution[],
  corrective: ['correction', 'compare', 'judge', 'restore', 'refine'] as NodeContribution[],
  rhythmic: ['rhythm', 'timing', 'pace', 'pulse', 'cycle'] as NodeContribution[],
  directional: ['direction', 'orient', 'steer', 'align', 'bias'] as NodeContribution[],
  attentional: ['attention', 'highlight', 'prioritize', 'focus', 'select'] as NodeContribution[],
  mutative: ['mutation', 'destabilize', 'transform', 'break', 'reconfigure'] as NodeContribution[],
  resonant: ['resonance', 'amplify', 'harmonize', 'synchronize', 'detect'] as NodeContribution[],
  gatekeeping: ['gating', 'allow', 'deny', 'open', 'close', 'threshold', 'regulate'] as NodeContribution[]
};

// ────────────────────────────────────────────────────────────────────────────
// NODE POLARITY MODES — How polarity affects contribution
// ────────────────────────────────────────────────────────────────────────────

export const POLARITY_MODES: Record<NodePolarity, { direction: string; effect: string }> = {
  forward: { direction: 'outward', effect: 'projective' },
  reverse: { direction: 'inward', effect: 'receptive' },
  inward: { direction: 'internal', effect: 'containment' },
  outward: { direction: 'external', effect: 'expression' },
  receptive: { direction: 'incoming', effect: 'absorption' },
  projective: { direction: 'outgoing', effect: 'emission' },
  stabilizing: { direction: 'centering', effect: 'equilibrium' },
  destabilizing: { direction: 'dispersing', effect: 'perturbation' },
  selective: { direction: 'focused', effect: 'filtering' },
  distributive: { direction: 'spread', effect: 'broadcasting' }
};

// ────────────────────────────────────────────────────────────────────────────
// RELATIONAL AFFORDANCES — How nodes relate to each other
// ────────────────────────────────────────────────────────────────────────────

export const AFFORDANCE_PATTERNS: Record<RelationalAffordance, { description: string; examples: string[] }> = {
  complementary: {
    description: 'Nodes complete each other\'s functions',
    examples: ['initiation + reception', 'formulation + expression']
  },
  oppositional: {
    description: 'Nodes create tension or resistance',
    examples: ['stabilization + destabilization', 'compression + expansion']
  },
  amplifying: {
    description: 'Nodes strengthen each other\'s effects',
    examples: ['resonance + resonance', 'attention + attention']
  },
  constraining: {
    description: 'Nodes limit or bound each other',
    examples: ['gating + initiation', 'direction + mutation']
  },
  resolving: {
    description: 'Nodes resolve tension into stability',
    examples: ['correction + formulation', 'direction + stabilization']
  },
  destabilizing: {
    description: 'Nodes create instability together',
    examples: ['mutation + mutation', 'pressure + pressure']
  },
  harmonizing: {
    description: 'Nodes synchronize into coherent pattern',
    examples: ['rhythm + rhythm', 'resonance + formulation']
  },
  redirecting: {
    description: 'Nodes change each other\'s direction',
    examples: ['direction + direction', 'attention + mutation']
  }
};

// ────────────────────────────────────────────────────────────────────────────
// NODE FUNCTION MODEL — Intrinsic contribution + relational affordance
// ────────────────────────────────────────────────────────────────────────────

export class NodeFunctionModel implements NodeFunction {
  identity: string;
  contributions: NodeContribution[];
  polarity: NodePolarity;
  currentPlacement: Partial<InternalCoordinates>;
  stabilityRegime: 'stable' | 'changing' | 'metastable';
  relationalAffordances: RelationalAffordance[];
  edgeFunctionTendencies: string[];

  // Internal state
  private _intrinsicPressure: number = 0.5;
  private _receptivity: number = 0.5;
  private _expressivity: number = 0.5;

  constructor(config: {
    identity: string;
    contributions: NodeContribution[];
    polarity: NodePolarity;
    affordances: RelationalAffordance[];
  }) {
    this.identity = config.identity;
    this.contributions = config.contributions;
    this.polarity = config.polarity;
    this.currentPlacement = {};
    this.stabilityRegime = 'stable';
    this.relationalAffordances = config.affordances;
    this.edgeFunctionTendencies = this.inferEdgeFunctionTendencies();
  }

  /** Node contribution is placement-sensitive */
  updatePlacement(placement: Partial<InternalCoordinates>): void {
    this.currentPlacement = placement;
    this.recalculateIntrinsicProperties();
  }

  /** Same node identity may contribute differently depending on polarity and placement */
  private recalculateIntrinsicProperties(): void {
    const line = this.currentPlacement.line?.line || 3;
    const color = this.currentPlacement.color?.color || 3;
    const tone = this.currentPlacement.tone?.tone || 3;

    // Line affects pressure/expressivity
    if (line <= 2) {
      this._intrinsicPressure = 0.3;  // Introspective/contemplative
      this._expressivity = 0.4;
    } else if (line === 3 || line === 4) {
      this._intrinsicPressure = 0.6;  // Experimental/social
      this._expressivity = 0.7;
    } else {
      this._intrinsicPressure = 0.8;  // Universal/transcendent
      this._expressivity = 0.9;
    }

    // Color affects receptivity
    if (color <= 2) {
      this._receptivity = 0.3;  // Fear/hope
    } else if (color <= 4) {
      this._receptivity = 0.6;  // Desire/need
    } else {
      this._receptivity = 0.8;  // Guilt/innocence
    }

    // Tone affects how contributions are expressed
    // Active (1) = direct, Diffuse (6) = ambient
  }

  /** Infer edge-function tendencies from contributions + polarity + affordances */
  private inferEdgeFunctionTendencies(): string[] {
    const tendencies: string[] = [];

    // Check contribution combinations
    if (this.hasContribution('initiation') && this.hasContribution('pressure')) {
      tendencies.push('feedforward_articulation');
    }
    if (this.hasContribution('reception') && this.hasContribution('filtering')) {
      tendencies.push('bidirectional_constraint');
    }
    if (this.hasContribution('correction') && this.hasContribution('formulation')) {
      tendencies.push('correction_toward_attractor');
    }
    if (this.hasContribution('compression') && this.hasContribution('memory')) {
      tendencies.push('sparse_compression');
    }
    if (this.hasContribution('resonance') && this.hasContribution('amplification')) {
      tendencies.push('self_organization');
    }
    if (this.hasContribution('opposition') && this.hasContribution('expression')) {
      tendencies.push('adversarial_tension');
    }
    if (this.hasContribution('rhythm') && this.hasContribution('timing')) {
      tendencies.push('reservoir_pulse');
    }
    if (this.hasContribution('gating') && this.hasContribution('direction')) {
      tendencies.push('gating_loop');
    }
    if (this.hasContribution('attention') && this.hasContribution('salience')) {
      tendencies.push('attentional_highlighting');
    }
    if (this.hasContribution('memory') && this.hasContribution('recursion')) {
      tendencies.push('recursive_memory_access');
    }

    return tendencies;
  }

  hasContribution(contribution: NodeContribution): boolean {
    return this.contributions.includes(contribution);
  }

  /** Get intrinsic pressure — what the node tends to push */
  getIntrinsicPressure(): number {
    return this._intrinsicPressure;
  }

  /** Get receptivity — what the node tends to receive */
  getReceptivity(): number {
    return this._receptivity;
  }

  /** Get expressivity — what the node tends to express */
  getExpressivity(): number {
    return this._expressivity;
  }

  /** Calculate relational match with another node */
  calculateRelationalMatch(other: NodeFunctionModel): {
    affordance: RelationalAffordance | null;
    strength: number;
    edgeFunction: string | null;
  } {
    // Find matching affordance
    for (const affordance of this.relationalAffordances) {
      if (other.relationalAffordances.includes(affordance)) {
        const strength = this.calculateAffordanceStrength(other, affordance);
        const edgeFunction = this.selectEdgeFunction(other, affordance);
        return { affordance, strength, edgeFunction };
      }
    }

    // Check for complementary patterns
    const complementary = this.findComplementaryPattern(other);
    if (complementary) {
      return {
        affordance: 'complementary',
        strength: complementary.strength,
        edgeFunction: complementary.edgeFunction
      };
    }

    return { affordance: null, strength: 0, edgeFunction: null };
  }

  private calculateAffordanceStrength(other: NodeFunctionModel, affordance: RelationalAffordance): number {
    const baseStrength = 0.5;

    // Polarity compatibility
    const polarityBoost = POLARITY_MODES[this.polarity].direction === 
                          POLARITY_MODES[other.polarity].direction ? 0.1 : 0.2;

    // Placement similarity
    const placementSimilarity = this.calculatePlacementSimilarity(other);

    // Stability regime compatibility
    const stabilityBoost = this.stabilityRegime === other.stabilityRegime ? 0.1 : 0;

    return Math.min(1, baseStrength + polarityBoost + placementSimilarity + stabilityBoost);
  }

  private calculatePlacementSimilarity(other: NodeFunctionModel): number {
    let similarity = 0;
    let count = 0;

    if (this.currentPlacement.line && other.currentPlacement.line) {
      similarity += this.currentPlacement.line.line === other.currentPlacement.line.line ? 0.2 : 0;
      count++;
    }
    if (this.currentPlacement.color && other.currentPlacement.color) {
      similarity += this.currentPlacement.color.color === other.currentPlacement.color.color ? 0.15 : 0;
      count++;
    }
    if (this.currentPlacement.tone && other.currentPlacement.tone) {
      similarity += this.currentPlacement.tone.tone === other.currentPlacement.tone.tone ? 0.1 : 0;
      count++;
    }

    return count > 0 ? similarity / count : 0;
  }

  private selectEdgeFunction(other: NodeFunctionModel, affordance: RelationalAffordance): string | null {
    const myTendencies = this.edgeFunctionTendencies;
    const otherTendencies = other.edgeFunctionTendencies;

    // Find common tendency
    for (const tendency of myTendencies) {
      if (otherTendencies.includes(tendency)) {
        return tendency;
      }
    }

    // Generate composite edge function
    const myPrimary = this.contributions[0];
    const otherPrimary = other.contributions[0];
    return `${myPrimary}_${affordance}_${otherPrimary}`;
  }

  private findComplementaryPattern(other: NodeFunctionModel): { strength: number; edgeFunction: string } | null {
    // Initiatory + Receptive = feedforward
    if (this.hasCategory('initiatory') && other.hasCategory('receptive')) {
      return { strength: 0.7, edgeFunction: 'feedforward_articulation' };
    }

    // Formulating + Expression = rendering
    if (this.hasCategory('formulating') && other.hasCategory('initiatory')) {
      return { strength: 0.6, edgeFunction: 'rendering_expression' };
    }

    // Corrective + Formulating = refinement
    if (this.hasCategory('corrective') && other.hasCategory('formulating')) {
      return { strength: 0.8, edgeFunction: 'correction_refinement' };
    }

    // Resonant + Resonant = amplification
    if (this.hasCategory('resonant') && other.hasCategory('resonant')) {
      return { strength: 0.9, edgeFunction: 'resonant_amplification' };
    }

    return null;
  }

  private hasCategory(category: keyof typeof CONTRIBUTION_CATEGORIES): boolean {
    return CONTRIBUTION_CATEGORIES[category].some(c => this.contributions.includes(c));
  }

  /** Describe node function */
  describe(): string {
    return `Node ${this.identity}:
  Contributions: ${this.contributions.join(', ')}
  Polarity: ${this.polarity} (${POLARITY_MODES[this.polarity].effect})
  Affordances: ${this.relationalAffordances.join(', ')}
  Edge tendencies: ${this.edgeFunctionTendencies.join(', ')}
  Placement: ${this.currentPlacement.line ? 'L' + this.currentPlacement.line.line : 'none'}
  Pressure: ${this._intrinsicPressure.toFixed(2)}
  Receptivity: ${this._receptivity.toFixed(2)}
  Expressivity: ${this._expressivity.toFixed(2)}`;
  }
}

// ────────────────────────────────────────────────────────────────────────────
// EDGE FUNCTION EMERGENCE — What emerges when node-potentials meet
// ────────────────────────────────────────────────────────────────────────────

export class EdgeFunctionEmergence {
  /** Calculate what emerges when two node-potentials relate */
  static emerge(
    nodeA: NodeFunctionModel,
    nodeB: NodeFunctionModel
  ): {
    edgeFunction: string | null;
    strength: number;
    style: string;
    description: string;
  } {
    const match = nodeA.calculateRelationalMatch(nodeB);

    if (!match.edgeFunction) {
      return {
        edgeFunction: null,
        strength: 0,
        style: 'none',
        description: 'No emergent edge-function'
      };
    }

    // Determine style from node placements
    const lineA = nodeA.currentPlacement.line?.line || 3;
    const lineB = nodeB.currentPlacement.line?.line || 3;
    const style = `L${lineA}_L${lineB}_${match.affordance}`;

    // Description from contributions
    const description = `${nodeA.contributions[0]} + ${nodeB.contributions[0]} -> ${match.edgeFunction}`;

    return {
      edgeFunction: match.edgeFunction,
      strength: match.strength,
      style,
      description
    };
  }

  /** Named architecture labels are descriptive, not ontological */
  static describeAsArchitecture(edgeFunction: string): string {
    const mappings: Record<string, string> = {
      'feedforward_articulation': 'Hopfield-like attractor network',
      'adversarial_tension': 'GAN-like adversarial dynamics',
      'sparse_compression': 'Autoencoder-like compression',
      'reservoir_pulse': 'Reservoir computing-like dynamics',
      'attentional_highlighting': 'Attention mechanism-like dynamics',
      'recursive_memory_access': 'RNN-like recursive dynamics',
      'self_organization': 'Self-organizing map-like dynamics',
      'gating_loop': 'LSTM-like gating dynamics'
    };

    return mappings[edgeFunction] || 'Novel emergent dynamics';
  }
}

// ────────────────────────────────────────────────────────────────────────────
// NODE FUNCTION ENGINE — Main orchestrator
// ────────────────────────────────────────────────────────────────────────────

export class NodeFunctionEngine {
  private nodes: Map<string, NodeFunctionModel> = new Map();

  /** Register a node with its intrinsic function */
  registerNode(
    id: string,
    contributions: NodeContribution[],
    polarity: NodePolarity,
    affordances: RelationalAffordance[]
  ): NodeFunctionModel {
    const node = new NodeFunctionModel({
      identity: id,
      contributions,
      polarity,
      affordances
    });
    this.nodes.set(id, node);
    return node;
  }

  /** Update node placement */
  updatePlacement(nodeId: string, placement: Partial<InternalCoordinates>): void {
    const node = this.nodes.get(nodeId);
    if (node) {
      node.updatePlacement(placement);
    }
  }

  /** Calculate emergent edge-function between two nodes */
  emergeEdgeFunction(nodeIdA: string, nodeIdB: string): ReturnType<typeof EdgeFunctionEmergence.emerge> {
    const nodeA = this.nodes.get(nodeIdA);
    const nodeB = this.nodes.get(nodeIdB);

    if (!nodeA || !nodeB) {
      return {
        edgeFunction: null,
        strength: 0,
        style: 'none',
        description: 'Node not found'
      };
    }

    return EdgeFunctionEmergence.emerge(nodeA, nodeB);
  }

  /** Get all nodes with specific contribution */
  getNodesByContribution(contribution: NodeContribution): NodeFunctionModel[] {
    return Array.from(this.nodes.values()).filter(n => n.hasContribution(contribution));
  }

  /** Get all nodes with specific affordance */
  getNodesByAffordance(affordance: RelationalAffordance): NodeFunctionModel[] {
    return Array.from(this.nodes.values()).filter(n => n.relationalAffordances.includes(affordance));
  }

  /** Get node description */
  describeNode(nodeId: string): string {
    const node = this.nodes.get(nodeId);
    return node ? node.describe() : 'Node not found';
  }

  /** Get all registered nodes */
  getAllNodes(): NodeFunctionModel[] {
    return Array.from(this.nodes.values());
  }
}

export default NodeFunctionEngine;
