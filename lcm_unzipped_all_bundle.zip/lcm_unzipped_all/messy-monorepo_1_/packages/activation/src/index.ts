/**
 * @messy/activation — Multiple activation grammars, same latent state space
 * 
 * Derived from: ONTOLOGY.md (Activation Grammars section)
 * 
 * Multiple input grammars may activate the same underlying ontological state.
 * Human Design is one activation grammar. It is not the only one.
 */

import {
  ActivationGrammar, ActivationEvent, FullyQualifiedState,
  GateAddress, LineQualification, ColorQualification,
  ToneQualification, BaseQualification, PlanetaryQualification,
  Center, CenterActivationMode, Dimension, ContinuousModulation
} from '@messy/types';
import {
  GATE_ADDRESSES, LINE_CORRESPONDENCES, COLOR_CORRESPONDENCES,
  TONE_CORRESPONDENCES, BASE_CORRESPONDENCES, DIMENSIONS, CENTERS
} from '@messy/ontology';
import { StateRegion, InternalCoordinatesImpl, ArcPositionImpl } from '@messy/state-space';

// ────────────────────────────────────────────────────────────────────────────
// ACTIVATION GRAMMAR REGISTRY — All valid input grammars
// ────────────────────────────────────────────────────────────────────────────

export const ACTIVATION_GRAMMARS: ActivationGrammar[] = [
  'human_design',
  'user_response',
  'language_pattern',
  'behavioral_pattern',
  'code_pattern',
  'interaction_trace',
  'sound_signature',
  'image_signature'
];

// ────────────────────────────────────────────────────────────────────────────
// GRAMMAR PARSERS — Each grammar has its own parser
// ────────────────────────────────────────────────────────────────────────────

export interface GrammarParser {
  grammar: ActivationGrammar;
  parse(input: unknown): FullyQualifiedState[];
  validate(input: unknown): boolean;
}

export class HumanDesignParser implements GrammarParser {
  grammar: ActivationGrammar = 'human_design';

  parse(input: unknown): FullyQualifiedState[] {
    // Parse Human Design chart data
    const chart = input as {
      gates?: number[];
      channels?: [number, number][];
      centers?: string[];
      planets?: Record<string, { gate: number; line: number; color: number; tone: number; base: number }>;
    };

    const states: FullyQualifiedState[] = [];

    if (chart.gates) {
      for (const gateNum of chart.gates) {
        const gate = GATE_ADDRESSES[gateNum as keyof typeof GATE_ADDRESSES];
        if (gate) {
          states.push({
            gate,
            timestamp: Date.now(),
            source: 'human_design'
          });
        }
      }
    }

    if (chart.planets) {
      for (const [planet, position] of Object.entries(chart.planets)) {
        const gate = GATE_ADDRESSES[position.gate as keyof typeof GATE_ADDRESSES];
        if (gate) {
          states.push({
            gate,
            line: LINE_CORRESPONDENCES[position.line as 1|2|3|4|5|6],
            color: COLOR_CORRESPONDENCES[position.color as 1|2|3|4|5|6],
            tone: TONE_CORRESPONDENCES[position.tone as 1|2|3|4|5|6],
            base: BASE_CORRESPONDENCES[position.base as 1|2|3|4|5],
            planetary: {
              planet: planet as any,
              degree: 0,
              minute: 0,
              second: 0
            },
            timestamp: Date.now(),
            source: 'human_design'
          });
        }
      }
    }

    return states;
  }

  validate(input: unknown): boolean {
    return typeof input === 'object' && input !== null &&
           ('gates' in (input as any) || 'planets' in (input as any));
  }
}

export class LanguagePatternParser implements GrammarParser {
  grammar: ActivationGrammar = 'language_pattern';

  parse(input: unknown): FullyQualifiedState[] {
    const text = String(input);
    const states: FullyQualifiedState[] = [];

    // Pattern detection: keywords map to gates
    const keywordMap: Record<string, number[]> = {
      'create': [1, 3],
      'express': [1, 10],
      'receive': [2, 5],
      'know': [4, 24],
      'speak': [12, 13],
      'lead': [7, 31],
      'feel': [22, 30],
      'think': [17, 43],
      'transform': [49, 51],
      'wait': [5, 52]
    };

    const lowerText = text.toLowerCase();
    for (const [keyword, gates] of Object.entries(keywordMap)) {
      if (lowerText.includes(keyword)) {
        for (const gateNum of gates) {
          const gate = GATE_ADDRESSES[gateNum as keyof typeof GATE_ADDRESSES];
          if (gate) {
            states.push({
              gate,
              timestamp: Date.now(),
              source: 'language_pattern'
            });
          }
        }
      }
    }

    return states;
  }

  validate(input: unknown): boolean {
    return typeof input === 'string' && input.length > 0;
  }
}

export class UserResponseParser implements GrammarParser {
  grammar: ActivationGrammar = 'user_response';

  parse(input: unknown): FullyQualifiedState[] {
    const response = input as {
      emotion?: string;
      intensity?: number;
      focus?: string;
      action?: string;
    };

    const states: FullyQualifiedState[] = [];

    // Emotion mapping to gates
    const emotionMap: Record<string, number[]> = {
      'joy': [25, 58],
      'fear': [9, 36],
      'anger': [21, 38],
      'sadness': [55, 47],
      'surprise': [51, 42],
      'anticipation': [5, 35],
      'trust': [37, 13],
      'disgust': [18, 17]
    };

    if (response.emotion && emotionMap[response.emotion]) {
      for (const gateNum of emotionMap[response.emotion]) {
        const gate = GATE_ADDRESSES[gateNum as keyof typeof GATE_ADDRESSES];
        if (gate) {
          states.push({
            gate,
            timestamp: Date.now(),
            source: 'user_response'
          });
        }
      }
    }

    // Intensity maps to line
    if (response.intensity) {
      const line = Math.min(6, Math.max(1, Math.ceil(response.intensity * 6)));
      if (states.length > 0) {
        states[0].line = LINE_CORRESPONDENCES[line as 1|2|3|4|5|6];
      }
    }

    return states;
  }

  validate(input: unknown): boolean {
    return typeof input === 'object' && input !== null;
  }
}

export class CodePatternParser implements GrammarParser {
  grammar: ActivationGrammar = 'code_pattern';

  parse(input: unknown): FullyQualifiedState[] {
    const code = String(input);
    const states: FullyQualifiedState[] = [];

    // Code pattern detection
    const patternMap: Record<string, number[]> = {
      'function': [1, 3],
      'class': [2, 7],
      'if': [4, 18],
      'for': [5, 53],
      'while': [52, 29],
      'return': [24, 42],
      'import': [8, 44],
      'export': [1, 43],
      'async': [35, 36],
      'await': [5, 52]
    };

    for (const [pattern, gates] of Object.entries(patternMap)) {
      if (code.includes(pattern)) {
        for (const gateNum of gates) {
          const gate = GATE_ADDRESSES[gateNum as keyof typeof GATE_ADDRESSES];
          if (gate) {
            states.push({
              gate,
              timestamp: Date.now(),
              source: 'code_pattern'
            });
          }
        }
      }
    }

    return states;
  }

  validate(input: unknown): boolean {
    return typeof input === 'string';
  }
}

// ────────────────────────────────────────────────────────────────────────────
// ACTIVATION RESOLVER — Merge addresses from multiple grammars
// ────────────────────────────────────────────────────────────────────────────

export class ActivationResolver {
  private parsers: Map<ActivationGrammar, GrammarParser> = new Map();

  constructor() {
    this.registerParser(new HumanDesignParser());
    this.registerParser(new LanguagePatternParser());
    this.registerParser(new UserResponseParser());
    this.registerParser(new CodePatternParser());
  }

  registerParser(parser: GrammarParser): void {
    this.parsers.set(parser.grammar, parser);
  }

  /** Resolve activation event to fully qualified states */
  resolve(event: ActivationEvent): {
    states: FullyQualifiedState[];
    merged: FullyQualifiedState[];
    confidence: number[];
  } {
    const parser = this.parsers.get(event.grammar);

    if (!parser || !parser.validate(event.input)) {
      return { states: [], merged: [], confidence: [] };
    }

    const states = parser.parse(event.input);

    // Merge overlapping states
    const merged = this.mergeStates(states);

    // Calculate confidence
    const confidence = states.map(() => 1.0 / states.length);

    return { states, merged, confidence };
  }

  /** Merge states that share the same gate */
  private mergeStates(states: FullyQualifiedState[]): FullyQualifiedState[] {
    const gateMap = new Map<number, FullyQualifiedState[]>();

    for (const state of states) {
      if (state.gate) {
        const existing = gateMap.get(state.gate.gate) || [];
        existing.push(state);
        gateMap.set(state.gate.gate, existing);
      }
    }

    const merged: FullyQualifiedState[] = [];

    for (const [, gateStates] of gateMap) {
      if (gateStates.length === 1) {
        merged.push(gateStates[0]);
      } else {
        // Merge: keep most detailed state
        const mostDetailed = gateStates.reduce((best, current) => {
          const bestDetail = (best.line ? 1 : 0) + (best.color ? 1 : 0) + (best.tone ? 1 : 0);
          const currentDetail = (current.line ? 1 : 0) + (current.color ? 1 : 0) + (current.tone ? 1 : 0);
          return currentDetail > bestDetail ? current : best;
        });
        merged.push(mostDetailed);
      }
    }

    return merged;
  }

  /** Multi-grammar resolution: same input through multiple grammars */
  multiResolve(
    input: unknown,
    grammars: ActivationGrammar[]
  ): {
    grammar: ActivationGrammar;
    states: FullyQualifiedState[];
    confidence: number;
  }[] {
    const results = [];

    for (const grammar of grammars) {
      const event: ActivationEvent = {
        grammar,
        input,
        addresses: [],
        confidence: [],
        source: 'multi_resolve',
        timestamp: Date.now()
      };

      const resolved = this.resolve(event);

      if (resolved.states.length > 0) {
        results.push({
          grammar,
          states: resolved.states,
          confidence: resolved.confidence.reduce((a, b) => a + b, 0) / resolved.confidence.length
        });
      }
    }

    return results;
  }
}

// ────────────────────────────────────────────────────────────────────────────
// ACTIVATION ENGINE — Main orchestrator
// ────────────────────────────────────────────────────────────────────────────

export class ActivationEngine {
  resolver: ActivationResolver;

  constructor() {
    this.resolver = new ActivationResolver();
  }

  /** Activate from single grammar */
  activate(
    grammar: ActivationGrammar,
    input: unknown
  ): {
    states: FullyQualifiedState[];
    merged: FullyQualifiedState[];
    confidence: number[];
  } {
    const event: ActivationEvent = {
      grammar,
      input,
      addresses: [],
      confidence: [],
      source: 'activation_engine',
      timestamp: Date.now()
    };

    return this.resolver.resolve(event);
  }

  /** Activate from multiple grammars simultaneously */
  activateMulti(
    input: unknown,
    grammars: ActivationGrammar[] = ACTIVATION_GRAMMARS
  ): {
    grammar: ActivationGrammar;
    states: FullyQualifiedState[];
    confidence: number;
  }[] {
    return this.resolver.multiResolve(input, grammars);
  }

  /** Get available grammars */
  getGrammars(): ActivationGrammar[] {
    return ACTIVATION_GRAMMARS;
  }

  /** Register custom parser */
  registerParser(parser: GrammarParser): void {
    this.resolver.registerParser(parser);
  }
}

export default ActivationEngine;
