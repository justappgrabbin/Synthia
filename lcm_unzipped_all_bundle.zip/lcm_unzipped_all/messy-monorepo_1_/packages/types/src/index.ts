/**
 * @messy/types — Shared canonical types for the entire organism
 * 
 * Derived from: FOUNDATION, ONTOLOGY, STATE SPACE MECHANICS, MESH, NODE FUNCTIONS
 * 
 * This is the single source of truth for all type definitions.
 * No package may redefine these types.
 */

// ────────────────────────────────────────────────────────────────────────────
// FOUNDATION: Core organism types
// ────────────────────────────────────────────────────────────────────────────

export interface OrganismConfig {
  version: string;
  localFirst: boolean;
  strata: Stratum[];
  organs: Organ[];
}

export type Stratum = 'Heart' | 'Mind' | 'Action';

export interface Organ {
  name: string;
  type: 'autoling' | 'diseminer' | 'novel-writer';
  active: boolean;
  meshQualified: boolean;
}

// ────────────────────────────────────────────────────────────────────────────
// ONTOLOGY: Discrete lattice types
// ────────────────────────────────────────────────────────────────────────────

export type Planet = 
  | 'Sun' | 'Earth' | 'Moon' | 'NorthNode' | 'SouthNode'
  | 'Mercury' | 'Venus' | 'Mars' | 'Jupiter' | 'Saturn'
  | 'Uranus' | 'Neptune' | 'Pluto';

export type Dimension = 'Movement' | 'Evolution' | 'Being' | 'Design' | 'Space';

export type Center = 
  | 'Head' | 'Ajna' | 'Throat' | 'G' | 'Sacral' 
  | 'Root' | 'Spleen' | 'SolarPlexus' | 'Heart';

export type GateNumber = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10
  | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20
  | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30
  | 31 | 32 | 33 | 34 | 35 | 36 | 37 | 38 | 39 | 40
  | 41 | 42 | 43 | 44 | 45 | 46 | 47 | 48 | 49 | 50
  | 51 | 52 | 53 | 54 | 55 | 56 | 57 | 58 | 59 | 60
  | 61 | 62 | 63 | 64;

export type LineNumber = 1 | 2 | 3 | 4 | 5 | 6;
export type ColorNumber = 1 | 2 | 3 | 4 | 5 | 6;
export type ToneNumber = 1 | 2 | 3 | 4 | 5 | 6;
export type BaseNumber = 1 | 2 | 3 | 4 | 5;

export type CenterActivationMode = 
  | 'latent' | 'converging' | 'modulating' | 'expressed' | 'actioning';

export interface PlanetaryQualification {
  planet: Planet;
  degree?: number;
  minute?: number;
  second?: number;
  retrograde?: boolean;
  phase?: number;
}

export interface DimensionCorrespondence {
  dimension: Dimension;
  macrocosmic: { process: string; keynote: string };
  microcosmic: { embodiment: string; sensory: string };
  order: number;
  qualities: string[];
  oppositions: string[];
  reversals: string[];
}

export interface GateAddress {
  gate: GateNumber;
  hexagram: {
    number: number;
    name: string;
    trigramAbove: string;
    trigramBelow: string;
  };
  archetype: string;
  primaryDimension: Dimension;
  planetaryRulers: Planet[];
}

export interface LineQualification {
  line: LineNumber;
  role: string;
  mode: string;
  approach: string;
  keynote: string;
}

export interface ColorQualification {
  color: ColorNumber;
  motivation: string;
  driveResponse: string;
  spectral: { wavelength: number; frequency: number; quality: string };
  environmental: string;
  expression: string;
}

export interface ToneQualification {
  tone: ToneNumber;
  filter: string;
  attunement: string;
  entryMode: string;
  perception: string;
}

export interface BaseQualification {
  base: BaseNumber;
  grounding: string;
  organization: string;
  qualifier: string;
}

// ────────────────────────────────────────────────────────────────────────────
// STATE SPACE MECHANICS: Region and coordinate types
// ────────────────────────────────────────────────────────────────────────────

export interface InternalCoordinates {
  line?: LineQualification;
  color?: ColorQualification;
  tone?: ToneQualification;
  base?: BaseQualification;
  arcPosition?: ArcPosition;
  degree?: number;
  minute?: number;
  second?: number;
  coordinateHash: string;
}

export interface ArcPosition {
  position: number;
  modulation: number;
  splitContribution?: { twelve: number; eight: number; four: number };
  soundVariation: number;
  colorVariation: number;
  intensity: number;
  phase: number;
  interpolation: number;
  status: 'provisional' | 'resolved';
}

export interface StabilityMap {
  stableZones: Zone[];
  transitionBands: Zone[];
  metastablePockets: Zone[];
  instabilityRidges: Zone[];
  boundarySurfaces: Zone[];
  currentPosition: StabilityPosition;
}

export interface Zone {
  name: string;
  coordinates: Partial<InternalCoordinates>;
  stability: number;
  resilience: number;
  description: string;
}

export interface StabilityPosition {
  zone: string;
  stability: number;
  pressure: number;
  changing: boolean;
  metastable: boolean;
}

export interface TransitionReadiness {
  phase: 'stable' | 'pressurizing' | 'changing' | 'resolving' | 'resolved';
  tension: number;
  threshold: number;
  nearestNeighbor?: NeighborRelation;
  resolutionTarget?: number;
  phaseDuration: number;
}

export interface NeighborRelation {
  targetGate: number;
  direction: string;
  tendency: number;
  activatingConditions: Partial<InternalCoordinates>[];
  boundaryType: 'smooth' | 'ridged' | 'permeable' | 'resistant';
  path: TransitionPath;
}

export interface TransitionPath {
  waypoints: Partial<InternalCoordinates>[];
  estimatedDuration: number;
  requiredPressure: number;
}

export interface Macrostate {
  identity: {
    gate?: GateAddress;
    center?: string;
    dimension?: string;
    archetype: string;
    relationalSignature: string;
  };
  coordinates: InternalCoordinates;
  stabilityMap: StabilityMap;
  expressiveDelivery: ExpressiveDelivery;
  neighbors: NeighborRelation[];
  transitionReadiness: TransitionReadiness;
  convergenceReadiness: number;
  timestamp: number;
}

export interface ExpressiveDelivery {
  forwardFace: string;
  alternativeFaces: AlternativeFace[];
  currentFace: string;
  projectionBias: Record<string, number>;
  channelTendencies: ChannelTendency[];
}

export interface AlternativeFace {
  name: string;
  coordinates: Partial<InternalCoordinates>;
  expression: string;
  probability: number;
}

export interface ChannelTendency {
  targetGate: number;
  strength: number;
  style: string;
  conditions: Partial<InternalCoordinates>;
}

// ────────────────────────────────────────────────────────────────────────────
// MESH: Message and traversal types
// ────────────────────────────────────────────────────────────────────────────

export interface MeshMessage {
  content: unknown;
  qualification: MessageQualification;
  traversal: TraversalMetadata;
  timestamp: number;
}

export interface MessageQualification {
  sourceOrgan?: string;
  sourceCenter?: Center;
  targetCenter?: Center;
  activeGates: GateNumber[];
  activeChannels: string[];
  dimensionContext: Dimension;
  lineContext?: LineNumber;
  colorContext?: ColorNumber;
  toneContext?: ToneNumber;
  baseContext?: BaseNumber;
  planetaryInfluence?: PlanetaryQualification;
  arcModulation?: ArcPosition;
  stratumContext?: Stratum;
  recursionDepth: number;
  userAlignmentContext?: string;
}

export interface TraversalMetadata {
  path: string[];
  hops: number;
  latency: number;
  morphCount: number;
}

export interface Channel {
  from: GateNumber;
  to: GateNumber;
  type: 'definition' | 'conditioning' | 'transit' | 'resonance';
  centers: [Center, Center];
  active: boolean;
  qualification: {
    dimension: Dimension;
    planetary?: Planet;
    intensity: number;
  };
}

export interface Edge {
  from: string;
  to: string;
  traversalCount: number;
  lastTraversal: number;
  channel?: Channel;
  weight: number;
  stability: number;
}

// ────────────────────────────────────────────────────────────────────────────
// NODE FUNCTIONS: Contribution and affordance types
// ────────────────────────────────────────────────────────────────────────────

export type NodeContribution = 
  | 'initiation' | 'reception' | 'pressure' | 'response'
  | 'stabilization' | 'mutation' | 'expression' | 'formulation'
  | 'correction' | 'attraction' | 'repulsion' | 'gating'
  | 'memory' | 'compression' | 'decompression' | 'direction'
  | 'attention' | 'resonance' | 'filtering' | 'propagation'
  | 'opposition' | 'rhythm' | 'timing' | 'salience'
  | 'containment' | 'opening';

export type NodePolarity = 
  | 'forward' | 'reverse' | 'inward' | 'outward'
  | 'receptive' | 'projective' | 'stabilizing' | 'destabilizing'
  | 'selective' | 'distributive';

export type RelationalAffordance = 
  | 'complementary' | 'oppositional' | 'amplifying'
  | 'constraining' | 'resolving' | 'destabilizing'
  | 'harmonizing' | 'redirecting';

export interface NodeFunction {
  identity: string;
  contributions: NodeContribution[];
  polarity: NodePolarity;
  currentPlacement: Partial<InternalCoordinates>;
  stabilityRegime: 'stable' | 'changing' | 'metastable';
  relationalAffordances: RelationalAffordance[];
  edgeFunctionTendencies: string[];
}

// ────────────────────────────────────────────────────────────────────────────
// ACTIVATION: Grammar and event types
// ────────────────────────────────────────────────────────────────────────────

export type ActivationGrammar = 
  | 'human_design' | 'user_response' | 'language_pattern'
  | 'behavioral_pattern' | 'code_pattern' | 'interaction_trace'
  | 'sound_signature' | 'image_signature';

export interface ActivationEvent {
  grammar: ActivationGrammar;
  input: unknown;
  addresses: FullyQualifiedState[];
  confidence: number[];
  source: string;
  timestamp: number;
}

export interface FullyQualifiedState {
  planetary?: PlanetaryQualification;
  dimension?: Dimension;
  center?: Center;
  centerMode?: CenterActivationMode;
  gate?: GateAddress;
  line?: LineQualification;
  color?: ColorQualification;
  tone?: ToneQualification;
  base?: BaseQualification;
  modulation?: ContinuousModulation;
  timestamp: number;
  source: string;
}

export interface ContinuousModulation {
  arc?: {
    position: number;
    modulation: number;
    split?: '12' | '8' | '4';
  };
  degrees: number;
  minutes: number;
  seconds: number;
  spectral?: { range: [number, number]; current: number };
  tonal?: { range: [number, number]; current: number };
  intensity: number;
  phase: number;
  interpolation: { from: number; to: number; progress: number };
}

// ────────────────────────────────────────────────────────────────────────────
// PROJECTION: Domain and expression types
// ────────────────────────────────────────────────────────────────────────────

export type ProjectionDomain = 
  | 'language' | 'code' | 'image' | 'sound' 
  | 'interface' | 'graph' | 'behavior';

export interface Projection {
  source: FullyQualifiedState;
  domain: ProjectionDomain;
  expression: unknown;
  fidelity: number;
  timestamp: number;
}

// ────────────────────────────────────────────────────────────────────────────
// IDENTITY CENTER: User-alignment hub types
// ────────────────────────────────────────────────────────────────────────────

export interface IdentityCenter {
  center: 'G';
  mode: CenterActivationMode;
  intensity: number;
  modulations: Record<string, boolean>;
  activeChannels: Channel[];
  activeGates: GateAddress[];
  llmBridges: LLMBridge[];
  mcpBridges: MCPBridge[];
  userProfile: UserProfile;
  orientation: Orientation;
}

export interface LLMBridge {
  model: string;
  contextWindow: string;
  alignmentScore: number;
}

export interface MCPBridge {
  server: string;
  tools: string[];
  routingPriority: number;
}

export interface UserProfile {
  stylePreferences: string[];
  semanticWeights: Record<string, number>;
  interactionHistory: string[];
  trustedPatterns: string[];
}

export interface Orientation {
  currentFocus: string;
  longTermGoal: string;
  values: string[];
}

// ────────────────────────────────────────────────────────────────────────────
// PERSISTENCE: Local-first storage types
// ────────────────────────────────────────────────────────────────────────────

export interface LocalOntology {
  dimensions: DimensionCorrespondence[];
  centers: CenterState[];
  gates: GateAddress[];
  lines: LineQualification[];
  colors: ColorQualification[];
  tones: ToneQualification[];
  bases: BaseQualification[];
  correspondences: Record<string, unknown>;
  identityCenter: IdentityCenter;
  meshQualification: MessageQualification;
}

export interface CenterState {
  center: Center;
  mode: CenterActivationMode;
  intensity: number;
  modulations: Record<string, boolean>;
  activeChannels: Channel[];
  activeGates: GateAddress[];
}

// ────────────────────────────────────────────────────────────────────────────
// INGESTION: Discernment and growth types
// ────────────────────────────────────────────────────────────────────────────

export interface IngestionEvent {
  source: 'file' | 'url' | 'api' | 'huggingface' | 'git' | 'user';
  payload: unknown;
  validation: ValidationResult;
  quality: QualityScore;
  threat: ThreatAssessment;
}

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  schema: string;
}

export interface QualityScore {
  score: number;
  dimensions: Record<string, number>;
  pattern: string;
}

export interface ThreatAssessment {
  safe: boolean;
  level: 'none' | 'low' | 'medium' | 'high';
  details: string[];
}

// ────────────────────────────────────────────────────────────────────────────
// RESONANCE CORE: Attractor and field types
// ────────────────────────────────────────────────────────────────────────────

export interface Attractor {
  position: number[];
  strength: number;
  radius: number;
  type: 'semantic' | 'emotional' | 'behavioral' | 'archetypal';
}

export interface ResonanceField {
  attractors: Attractor[];
  manifold: (x: number[]) => number;
  geodesic: (a: number[], b: number[]) => number;
  interference: (a: Attractor, b: Attractor) => number;
}

// ────────────────────────────────────────────────────────────────────────────
// SELF-SUPERVISED: Learning and evolution types
// ────────────────────────────────────────────────────────────────────────────

export interface LearningEvent {
  source: string;
  pattern: string;
  outcome: 'success' | 'struggle' | 'neutral';
  timestamp: number;
  weight: number;
}

export interface EvolutionRecord {
  generation: number;
  capability: string;
  subsystem: string;
  rule: string;
  timestamp: number;
}

// ────────────────────────────────────────────────────────────────────────────
// HD GRAPH: Gate and channel graph types
// ────────────────────────────────────────────────────────────────────────────

export interface HDGraph {
  nodes: HDNode[];
  edges: HDEdge[];
  centers: CenterState[];
  channels: Channel[];
}

export interface HDNode {
  id: string;
  gate: GateAddress;
  coordinates: Partial<InternalCoordinates>;
  activation: number;
  stability: number;
}

export interface HDEdge {
  from: string;
  to: string;
  channel: Channel;
  weight: number;
  active: boolean;
}

// ────────────────────────────────────────────────────────────────────────────
// ORGANS: Awareness organ types
// ────────────────────────────────────────────────────────────────────────────

export interface AUTOLINGEvent {
  input: string;
  grammar: ActivationGrammar;
  parsed: FullyQualifiedState[];
  confidence: number;
}

export interface DISEMINEREvent {
  query: string;
  narrative: string;
  wDimensions: Record<string, number>;
  influence: number;
}

export interface NovelWriterEvent {
  prompt: string;
  generated: string;
  archetype: string;
  resonance: number;
}

// ────────────────────────────────────────────────────────────────────────────
// SERVICES: External bridge types (optional, bounded)
// ────────────────────────────────────────────────────────────────────────────

export interface MarketAPIConfig {
  endpoint: string;
  apiKey?: string;
  timeout: number;
  fallback: boolean;
}

export interface OracleConfig {
  type: 'python' | 'chart';
  endpoint: string;
  capabilities: string[];
}

// ────────────────────────────────────────────────────────────────────────────
// ARCHIVE: Superseded work preservation types
// ────────────────────────────────────────────────────────────────────────────

export interface ArchiveEntry {
  name: string;
  reason: 'duplicate' | 'superseded' | 'parallel_truth' | 'prototype_drift' 
          | 'platform_out_of_scope' | 'dead_end_integration';
  extractedLogic: string[];
  canonicalReplacement: string;
  archivedAt: number;
  importable: boolean;  // false — archived files may not be imported by live code
}
