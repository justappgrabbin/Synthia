/**
 * @messy/state-space — How states work internally inside the organism
 * 
 * Derived from: STATE_SPACE_MECHANICS.md
 * 
 * A state is not a single point. A state is a bounded region with
 * internal coordinates, gradients, thresholds, and expressive tendencies.
 */

import {
  Macrostate, InternalCoordinates, ArcPosition, StabilityMap,
  StabilityPosition, Zone, ExpressiveDelivery, AlternativeFace,
  ChannelTendency, TransitionReadiness, NeighborRelation,
  TransitionPath, LineQualification, ColorQualification,
  ToneQualification, BaseQualification, GateAddress
} from '@messy/types';
import {
  LINE_CORRESPONDENCES, COLOR_CORRESPONDENCES, TONE_CORRESPONDENCES,
  BASE_CORRESPONDENCES
} from '@messy/ontology';

// ────────────────────────────────────────────────────────────────────────────
// ARC POSITION — Continuous modulation inside state regions
// ────────────────────────────────────────────────────────────────────────────

export class ArcPositionImpl implements ArcPosition {
  position: number = 0.5;
  modulation: number = 0.5;
  splitContribution = { twelve: 0, eight: 0, four: 0 };
  soundVariation: number = 0.5;
  colorVariation: number = 0.5;
  intensity: number = 0.5;
  phase: number = 0.5;
  interpolation: number = 0.5;
  status: 'provisional' | 'resolved' = 'provisional';

  constructor(partial?: Partial<ArcPosition>) {
    if (partial) Object.assign(this, partial);
  }

  bendExpression(discreteValue: number): number {
    return discreteValue * (1 + this.modulation * Math.sin(this.position * Math.PI * 2));
  }
}

// ────────────────────────────────────────────────────────────────────────────
// INTERNAL COORDINATES — The inner coordinate system
// ────────────────────────────────────────────────────────────────────────────

export class InternalCoordinatesImpl implements InternalCoordinates {
  line?: LineQualification;
  color?: ColorQualification;
  tone?: ToneQualification;
  base?: BaseQualification;
  arcPosition?: ArcPositionImpl;
  degree?: number;
  minute?: number;
  second?: number;

  get coordinateHash(): string {
    const parts = [
      this.line?.line || '_',
      this.color?.color || '_',
      this.tone?.tone || '_',
      this.base?.base || '_',
      this.arcPosition?.position.toFixed(4) || '_',
      this.degree?.toFixed(2) || '_',
      this.minute?.toFixed(2) || '_',
      this.second?.toFixed(2) || '_'
    ];
    return parts.join(':');
  }

  equals(other: InternalCoordinates): boolean {
    return this.coordinateHash === other.coordinateHash;
  }
}

// ────────────────────────────────────────────────────────────────────────────
// STABILITY MAP — Locally distributed, not uniform
// ────────────────────────────────────────────────────────────────────────────

export class StabilityMapImpl implements StabilityMap {
  stableZones: Zone[] = [];
  transitionBands: Zone[] = [];
  metastablePockets: Zone[] = [];
  instabilityRidges: Zone[] = [];
  boundarySurfaces: Zone[] = [];
  currentPosition: StabilityPosition = {
    zone: 'interior',
    stability: 0.8,
    pressure: 0.0,
    changing: false,
    metastable: false
  };

  constructor() {
    this.initializeDefaultZones();
  }

  private initializeDefaultZones(): void {
    this.stableZones.push(
      { name: 'inner_depth', coordinates: { line: LINE_CORRESPONDENCES[1] }, stability: 0.9, resilience: 0.8, description: 'Deep stable interior' },
      { name: 'inner_withdrawal', coordinates: { line: LINE_CORRESPONDENCES[2] }, stability: 0.85, resilience: 0.7, description: 'Stable contemplative zone' },
      { name: 'outer_universal', coordinates: { line: LINE_CORRESPONDENCES[5] }, stability: 0.8, resilience: 0.6, description: 'Stable universal expression' }
    );

    this.transitionBands.push(
      { name: 'experimental_edge', coordinates: { line: LINE_CORRESPONDENCES[3] }, stability: 0.4, resilience: 0.3, description: 'Trial-and-error boundary' },
      { name: 'social_boundary', coordinates: { line: LINE_CORRESPONDENCES[4] }, stability: 0.5, resilience: 0.4, description: 'Social interaction surface' }
    );

    this.instabilityRidges.push(
      { name: 'transcendent_ridge', coordinates: { line: LINE_CORRESPONDENCES[6] }, stability: 0.2, resilience: 0.1, description: 'High transcendence tension' }
    );

    this.metastablePockets.push(
      { name: 'change_pocket', coordinates: { line: LINE_CORRESPONDENCES[3], degree: 180 }, stability: 0.3, resilience: 0.2, description: 'Ready to resolve' }
    );
  }

  updatePosition(coords: InternalCoordinates): void {
    const allZones = [
      ...this.stableZones,
      ...this.transitionBands,
      ...this.metastablePockets,
      ...this.instabilityRidges,
      ...this.boundarySurfaces
    ];

    let nearest = allZones[0];
    let minDistance = Infinity;

    for (const zone of allZones) {
      const dist = this.calculateZoneDistance(coords, zone);
      if (dist < minDistance) {
        minDistance = dist;
        nearest = zone;
      }
    }

    this.currentPosition = {
      zone: nearest.name,
      stability: nearest.stability,
      pressure: this.currentPosition.pressure,
      changing: nearest.stability < 0.4,
      metastable: nearest.stability > 0.2 && nearest.stability < 0.5
    };
  }

  private calculateZoneDistance(coords: InternalCoordinates, zone: Zone): number {
    let distance = 0;
    if (zone.coordinates.line && coords.line) {
      distance += Math.abs((zone.coordinates.line.line || 0) - (coords.line.line || 0)) * 10;
    }
    if (zone.coordinates.degree !== undefined && coords.degree !== undefined) {
      distance += Math.abs(zone.coordinates.degree - coords.degree) / 36;
    }
    return distance;
  }

  applyPressure(amount: number): void {
    this.currentPosition.pressure = Math.min(1, this.currentPosition.pressure + amount);
    if (this.currentPosition.pressure > this.currentPosition.stability) {
      this.currentPosition.changing = true;
    }
    if (this.currentPosition.stability < 0.5 && this.currentPosition.pressure > 0.3) {
      this.currentPosition.metastable = true;
    }
  }

  releasePressure(amount: number): void {
    this.currentPosition.pressure = Math.max(0, this.currentPosition.pressure - amount);
    if (this.currentPosition.pressure < this.currentPosition.stability * 0.5) {
      this.currentPosition.changing = false;
      this.currentPosition.metastable = false;
    }
  }
}

// ────────────────────────────────────────────────────────────────────────────
// EXPRESSIVE DELIVERY — Different faces, same macrostate
// ────────────────────────────────────────────────────────────────────────────

export class ExpressiveDeliveryImpl implements ExpressiveDelivery {
  forwardFace: string = '';
  alternativeFaces: AlternativeFace[] = [];
  currentFace: string = '';
  projectionBias: Record<string, number> = {};
  channelTendencies: ChannelTendency[] = [];

  constructor(archetype: string) {
    this.forwardFace = archetype;
    this.currentFace = archetype;
  }

  selectFace(coords: InternalCoordinates): string {
    let bestFace = this.forwardFace;
    let bestMatch = 0;

    for (const face of this.alternativeFaces) {
      const match = this.calculateFaceMatch(coords, face);
      if (match > bestMatch) {
        bestMatch = match;
        bestFace = face.expression;
      }
    }

    this.currentFace = bestFace;
    return bestFace;
  }

  private calculateFaceMatch(coords: InternalCoordinates, face: AlternativeFace): number {
    let match = 0;
    if (face.coordinates.line && coords.line && face.coordinates.line.line === coords.line.line) {
      match += 0.5;
    }
    if (face.coordinates.color && coords.color && face.coordinates.color.color === coords.color.color) {
      match += 0.3;
    }
    if (face.coordinates.tone && coords.tone && face.coordinates.tone.tone === coords.tone.tone) {
      match += 0.2;
    }
    return match;
  }

  calculateProjectionBias(coords: InternalCoordinates): Record<string, number> {
    const bias: Record<string, number> = {};

    if (coords.color) {
      bias['image'] = 0.3 + (coords.color.color / 6) * 0.7;
    }
    if (coords.tone) {
      bias['sound'] = 0.3 + (coords.tone.tone / 6) * 0.7;
      bias['language'] = 0.3 + (coords.tone.tone / 6) * 0.4;
    }
    if (coords.line) {
      bias['behavior'] = 0.3 + (coords.line.line / 6) * 0.7;
    }
    if (coords.arcPosition) {
      const arcInfluence = (coords.arcPosition as ArcPositionImpl).position;
      Object.keys(bias).forEach(k => bias[k] *= (1 + arcInfluence * 0.2));
    }

    return bias;
  }
}

// ────────────────────────────────────────────────────────────────────────────
// TRANSITION READINESS — Changing is a regime, not instant replacement
// ────────────────────────────────────────────────────────────────────────────

export class TransitionReadinessImpl implements TransitionReadiness {
  phase: 'stable' | 'pressurizing' | 'changing' | 'resolving' | 'resolved' = 'stable';
  tension: number = 0;
  threshold: number = 0.7;
  nearestNeighbor?: NeighborRelation;
  resolutionTarget?: number;
  phaseDuration: number = 0;

  update(stability: StabilityPosition, neighbors: NeighborRelation[]): void {
    this.phaseDuration++;

    switch (this.phase) {
      case 'stable':
        if (stability.pressure > 0.3) {
          this.phase = 'pressurizing';
          this.tension = stability.pressure;
        }
        break;
      case 'pressurizing':
        this.tension = stability.pressure;
        if (this.tension > this.threshold) {
          this.phase = 'changing';
          this.nearestNeighbor = neighbors.reduce((nearest, n) => 
            n.tendency > (nearest?.tendency || 0) ? n : nearest, neighbors[0]
          );
        }
        break;
      case 'changing':
        if (stability.metastable) {
          this.phase = 'resolving';
          this.resolutionTarget = this.nearestNeighbor?.targetGate;
        }
        break;
      case 'resolving':
        if (!stability.changing && !stability.metastable) {
          this.phase = 'resolved';
          this.tension = 0;
        }
        break;
      case 'resolved':
        if (this.phaseDuration > 10) {
          this.phase = 'stable';
          this.phaseDuration = 0;
          this.resolutionTarget = undefined;
        }
        break;
    }
  }

  isMetastable(): boolean {
    return this.phase === 'changing' || this.phase === 'resolving';
  }
}

// ────────────────────────────────────────────────────────────────────────────
// STATE REGION — The bounded region with internal mechanics
// ────────────────────────────────────────────────────────────────────────────

export class StateRegion {
  macrostate: Macrostate;
  coordinates: InternalCoordinatesImpl;
  stabilityMap: StabilityMapImpl;
  delivery: ExpressiveDeliveryImpl;
  transition: TransitionReadinessImpl;

  constructor(identity: Macrostate['identity']) {
    this.coordinates = new InternalCoordinatesImpl();
    this.stabilityMap = new StabilityMapImpl();
    this.delivery = new ExpressiveDeliveryImpl(identity.archetype);
    this.transition = new TransitionReadinessImpl();

    this.macrostate = {
      identity,
      coordinates: this.coordinates,
      stabilityMap: this.stabilityMap,
      expressiveDelivery: this.delivery,
      neighbors: [],
      transitionReadiness: this.transition,
      convergenceReadiness: 0,
      timestamp: Date.now()
    };
  }

  setCoordinates(coords: Partial<InternalCoordinates>): void {
    Object.assign(this.coordinates, coords);
    this.stabilityMap.updatePosition(this.coordinates);
    this.delivery.selectFace(this.coordinates);
    this.macrostate.coordinates = this.coordinates;
  }

  applyPressure(amount: number): void {
    this.stabilityMap.applyPressure(amount);
    this.transition.update(this.stabilityMap.currentPosition, this.macrostate.neighbors);
  }

  releasePressure(amount: number): void {
    this.stabilityMap.releasePressure(amount);
    this.transition.update(this.stabilityMap.currentPosition, this.macrostate.neighbors);
  }

  getCurrentFace(): string {
    return this.delivery.currentFace;
  }

  getProjectionBias(domain: string): number {
    const bias = this.delivery.calculateProjectionBias(this.coordinates);
    return bias[domain] || 0.5;
  }

  isChanging(): boolean {
    return this.stabilityMap.currentPosition.changing;
  }

  isMetastable(): boolean {
    return this.stabilityMap.currentPosition.metastable;
  }

  getTransitionPhase(): string {
    return this.transition.phase;
  }

  sameMacrostate(other: StateRegion): boolean {
    return this.macrostate.identity.archetype === other.macrostate.identity.archetype;
  }

  sameMicrostate(other: StateRegion): boolean {
    return this.coordinates.equals(other.coordinates);
  }

  describe(): string {
    const parts = [
      `Macrostate: ${this.macrostate.identity.archetype}`,
      `Coordinates: ${this.coordinates.coordinateHash}`,
      `Stability: ${this.stabilityMap.currentPosition.stability.toFixed(2)}`,
      `Pressure: ${this.stabilityMap.currentPosition.pressure.toFixed(2)}`,
      `Phase: ${this.transition.phase}`,
      `Current Face: ${this.delivery.currentFace}`,
      `Changing: ${this.isChanging()}`,
      `Metastable: ${this.isMetastable()}`
    ];
    return parts.join('\n');
  }
}

// ────────────────────────────────────────────────────────────────────────────
// STATE SPACE ENGINE — Orchestrator
// ────────────────────────────────────────────────────────────────────────────

export class StateSpaceEngine {
  private regions: Map<string, StateRegion> = new Map();
  private nodes: Map<string, NodeStateImpl> = new Map();
  private channels: Map<string, any> = new Map();

  createRegion(identity: Macrostate['identity']): StateRegion {
    const region = new StateRegion(identity);
    const id = `${identity.archetype}_${Date.now()}`;
    this.regions.set(id, region);
    return region;
  }

  placeNode(nodeId: string, region: StateRegion, coords: Partial<InternalCoordinates>): NodeStateImpl {
    region.setCoordinates(coords);
    const node = new NodeStateImpl(nodeId, region);
    this.nodes.set(nodeId, node);
    return node;
  }

  applyPressure(nodeId: string, amount: number): void {
    const node = this.nodes.get(nodeId);
    if (node) {
      node.region.applyPressure(amount);
      node.modulation.pressure = node.region.stabilityMap.currentPosition.pressure;
      node.stabilityCondition = node.region.isMetastable() ? 'metastable' : 
                                node.region.isChanging() ? 'changing' : 'stable';
    }
  }

  getRegionsByCondition(condition: 'stable' | 'changing' | 'metastable'): StateRegion[] {
    return Array.from(this.regions.values()).filter(r => {
      if (condition === 'stable') return !r.isChanging() && !r.isMetastable();
      if (condition === 'changing') return r.isChanging();
      if (condition === 'metastable') return r.isMetastable();
      return false;
    });
  }

  getSummary(): {
    totalRegions: number;
    totalNodes: number;
    activeChannels: number;
    stableRegions: number;
    changingRegions: number;
    metastableRegions: number;
  } {
    return {
      totalRegions: this.regions.size,
      totalNodes: this.nodes.size,
      activeChannels: Array.from(this.channels.values()).filter((c: any) => c.active).length,
      stableRegions: this.getRegionsByCondition('stable').length,
      changingRegions: this.getRegionsByCondition('changing').length,
      metastableRegions: this.getRegionsByCondition('metastable').length
    };
  }
}

// ────────────────────────────────────────────────────────────────────────────
// NODE STATE — A node participates in a state region
// ────────────────────────────────────────────────────────────────────────────

export class NodeStateImpl {
  nodeId: string;
  region: StateRegion;
  internalPosition: InternalCoordinates;
  stabilityCondition: 'stable' | 'changing' | 'metastable' = 'stable';
  modulation = {
    arc: new ArcPositionImpl(),
    pressure: 0
  };
  channelContribution = {
    strength: 0.5,
    style: 'neutral',
    preferredTargets: [] as number[]
  };

  constructor(nodeId: string, region: StateRegion) {
    this.nodeId = nodeId;
    this.region = region;
    this.internalPosition = region.coordinates;
  }

  calculateChannelContribution(targetNode: NodeStateImpl): {
    strength: number;
    style: string;
    edgeFunction: string;
  } {
    const baseStrength = this.channelContribution.strength;
    const lineMod = this.internalPosition.line ? this.internalPosition.line.line / 6 : 0.5;
    const colorMod = this.internalPosition.color ? this.internalPosition.color.color / 6 : 0.5;
    const toneMod = this.internalPosition.tone ? this.internalPosition.tone.tone / 6 : 0.5;
    const stabilityMod = this.region.stabilityMap.currentPosition.stability;
    const arcMod = this.modulation.arc.position;

    const strength = baseStrength * lineMod * colorMod * toneMod * stabilityMod * (1 + arcMod * 0.2);
    const style = this.determineStyle();
    const edgeFunction = `${this.region.macrostate.identity.archetype}→${targetNode.region.macrostate.identity.archetype}[${style}]`;

    return { strength, style, edgeFunction };
  }

  private determineStyle(): string {
    const parts = [];
    if (this.internalPosition.line) parts.push(`L${this.internalPosition.line.line}`);
    if (this.internalPosition.color) parts.push(`C${this.internalPosition.color.color}`);
    if (this.modulation.arc.position > 0.7) parts.push('high-arc');
    if (this.stabilityCondition === 'changing') parts.push('changing');
    return parts.join('-') || 'neutral';
  }
}

// ────────────────────────────────────────────────────────────────────────────
// PERSPECTIVE ENGINE — Observer-dependent state reading
// ────────────────────────────────────────────────────────────────────────────

export interface Perspective {
  identityCenter: {
    activeGates: number[];
    activeChannels: string[];
    currentFocus: string;
  };
  currentPlacement: Partial<InternalCoordinates>;
  meshPosition: {
    nodeId: string;
    depth: number;
    connectivity: number;
  };
}

export class PerspectiveEngine {
  interpretRegion(region: StateRegion, perspective: Perspective): {
    interpretation: string;
    confidence: number;
    bias: Record<string, number>;
  } {
    const baseInterpretation = region.macrostate.identity.archetype;

    const gateBias = perspective.identityCenter.activeGates.includes(
      region.macrostate.identity.gate?.gate || 0
    ) ? 0.3 : 0;

    const placementSimilarity = this.calculatePlacementSimilarity(
      region.coordinates,
      perspective.currentPlacement
    );

    const meshBias = perspective.meshPosition.connectivity / 10;

    const confidence = 0.5 + gateBias + placementSimilarity * 0.2 + meshBias;

    const interpretation = `${baseInterpretation} [seen from ${perspective.identityCenter.currentFocus}]`;

    return {
      interpretation,
      confidence: Math.min(1, confidence),
      bias: {
        gateAlignment: gateBias,
        placementResonance: placementSimilarity,
        meshConnectivity: meshBias
      }
    };
  }

  private calculatePlacementSimilarity(
    a: InternalCoordinates,
    b: Partial<InternalCoordinates>
  ): number {
    let similarity = 0;
    let count = 0;

    if (a.line && b.line) {
      similarity += a.line.line === b.line.line ? 1 : 0;
      count++;
    }
    if (a.color && b.color) {
      similarity += a.color.color === b.color.color ? 1 : 0.5;
      count++;
    }
    if (a.tone && b.tone) {
      similarity += a.tone.tone === b.tone.tone ? 1 : 0.3;
      count++;
    }

    return count > 0 ? similarity / count : 0;
  }
}

export default StateSpaceEngine;
