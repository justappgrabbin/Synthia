/**
 * @messy/projection — Projection does not define ontology. Projection expresses ontology.
 * 
 * Derived from: ONTOLOGY.md (Projection Domains section)
 * 
 * Once a state is activated, it may be projected into one or more expression domains.
 * Projection is downstream from ontology and activation.
 */

import {
  Projection, ProjectionDomain, FullyQualifiedState,
  LanguageProjection, CodeProjection, ImageProjection,
  SoundProjection, InterfaceProjection, GraphProjection, BehaviorProjection
} from '@messy/types';
import {
  DIMENSION_CORRESPONDENCES, LINE_CORRESPONDENCES, COLOR_CORRESPONDENCES,
  TONE_CORRESPONDENCES, BASE_CORRESPONDENCES
} from '@messy/ontology';
import { StateRegion, InternalCoordinatesImpl } from '@messy/state-space';

// ────────────────────────────────────────────────────────────────────────────
// PROJECTION DOMAINS — All expression domains
// ────────────────────────────────────────────────────────────────────────────

export const PROJECTION_DOMAINS: ProjectionDomain[] = [
  'language', 'code', 'image', 'sound', 'interface', 'graph', 'behavior'
];

// ────────────────────────────────────────────────────────────────────────────
// FIDELITY CALCULATORS — How well expression captures ontology
// ────────────────────────────────────────────────────────────────────────────

export interface FidelityCalculator {
  domain: ProjectionDomain;
  calculate(state: FullyQualifiedState): number;
}

export class LanguageFidelity implements FidelityCalculator {
  domain: ProjectionDomain = 'language';

  calculate(state: FullyQualifiedState): number {
    let score = 0;
    if (state.gate) score += 0.3;
    if (state.line) score += 0.2;
    if (state.dimension) score += 0.2;
    if (state.center) score += 0.15;
    if (state.color) score += 0.1;
    if (state.tone) score += 0.05;
    return Math.min(1, score);
  }
}

export class CodeFidelity implements FidelityCalculator {
  domain: ProjectionDomain = 'code';

  calculate(state: FullyQualifiedState): number {
    // Code projection favors structure and dimension
    let score = 0;
    if (state.gate) score += 0.25;
    if (state.dimension) score += 0.25;
    if (state.center) score += 0.2;
    if (state.line) score += 0.15;
    if (state.base) score += 0.15;
    return Math.min(1, score);
  }
}

export class ImageFidelity implements FidelityCalculator {
  domain: ProjectionDomain = 'image';

  calculate(state: FullyQualifiedState): number {
    // Image projection favors color and modulation
    let score = 0;
    if (state.color) score += 0.4;
    if (state.gate) score += 0.3;
    if (state.modulation) score += 0.2;
    if (state.dimension) score += 0.1;
    return Math.min(1, score);
  }
}

export class SoundFidelity implements FidelityCalculator {
  domain: ProjectionDomain = 'sound';

  calculate(state: FullyQualifiedState): number {
    // Sound projection favors tone and modulation
    let score = 0;
    if (state.tone) score += 0.3;
    if (state.color) score += 0.3;
    if (state.modulation) score += 0.3;
    if (state.dimension) score += 0.1;
    return Math.min(1, score);
  }
}

export class InterfaceFidelity implements FidelityCalculator {
  domain: ProjectionDomain = 'interface';

  calculate(state: FullyQualifiedState): number {
    // Interface projection favors center and modulation
    let score = 0;
    if (state.center) score += 0.3;
    if (state.color) score += 0.2;
    if (state.tone) score += 0.2;
    if (state.modulation) score += 0.2;
    if (state.dimension) score += 0.1;
    return Math.min(1, score);
  }
}

export class GraphFidelity implements FidelityCalculator {
  domain: ProjectionDomain = 'graph';

  calculate(state: FullyQualifiedState): number {
    // Graph projection favors gate and dimension
    let score = 0;
    if (state.gate) score += 0.4;
    if (state.dimension) score += 0.3;
    if (state.modulation) score += 0.2;
    if (state.center) score += 0.1;
    return Math.min(1, score);
  }
}

export class BehaviorFidelity implements FidelityCalculator {
  domain: ProjectionDomain = 'behavior';

  calculate(state: FullyQualifiedState): number {
    // Behavior projection favors color and line
    let score = 0;
    if (state.color) score += 0.4;
    if (state.line) score += 0.3;
    if (state.gate) score += 0.2;
    if (state.dimension) score += 0.1;
    return Math.min(1, score);
  }
}

// ────────────────────────────────────────────────────────────────────────────
// PROJECTION ENGINE — Domain-specific expression
// ────────────────────────────────────────────────────────────────────────────

export class ProjectionEngine {
  private fidelityCalculators: Map<ProjectionDomain, FidelityCalculator> = new Map();

  constructor() {
    this.registerFidelity(new LanguageFidelity());
    this.registerFidelity(new CodeFidelity());
    this.registerFidelity(new ImageFidelity());
    this.registerFidelity(new SoundFidelity());
    this.registerFidelity(new InterfaceFidelity());
    this.registerFidelity(new GraphFidelity());
    this.registerFidelity(new BehaviorFidelity());
  }

  registerFidelity(calculator: FidelityCalculator): void {
    this.fidelityCalculators.set(calculator.domain, calculator);
  }

  /** Project a state into a target domain */
  project(state: FullyQualifiedState, domain: ProjectionDomain): Projection {
    const fidelity = this.calculateFidelity(state, domain);
    const expression = this.generateExpression(state, domain);

    return {
      source: state,
      domain,
      expression,
      fidelity,
      timestamp: Date.now()
    };
  }

  /** Project into multiple domains */
  projectMulti(state: FullyQualifiedState, domains: ProjectionDomain[]): Projection[] {
    return domains.map(domain => this.project(state, domain));
  }

  /** Calculate fidelity for a domain */
  calculateFidelity(state: FullyQualifiedState, domain: ProjectionDomain): number {
    const calculator = this.fidelityCalculators.get(domain);
    return calculator ? calculator.calculate(state) : 0;
  }

  /** Generate domain-specific expression */
  private generateExpression(state: FullyQualifiedState, domain: ProjectionDomain): unknown {
    switch (domain) {
      case 'language':
        return this.generateLanguage(state);
      case 'code':
        return this.generateCode(state);
      case 'image':
        return this.generateImage(state);
      case 'sound':
        return this.generateSound(state);
      case 'interface':
        return this.generateInterface(state);
      case 'graph':
        return this.generateGraph(state);
      case 'behavior':
        return this.generateBehavior(state);
      default:
        return null;
    }
  }

  private generateLanguage(state: FullyQualifiedState): string {
    const parts: string[] = [];

    if (state.gate) {
      parts.push(`Gate ${state.gate.gate}: ${state.gate.archetype}`);
    }
    if (state.line) {
      parts.push(`Line ${state.line.line}: ${state.line.role} — "${state.line.keynote}"`);
    }
    if (state.dimension) {
      const correspondence = DIMENSION_CORRESPONDENCES[state.dimension];
      parts.push(`Dimension: ${state.dimension} — ${correspondence.macrocosmic.keynote}`);
    }
    if (state.center) {
      parts.push(`Center: ${state.center}`);
    }
    if (state.color) {
      parts.push(`Color: ${state.color.color} — ${state.color.motivation} → ${state.color.expression}`);
    }
    if (state.tone) {
      parts.push(`Tone: ${state.tone.tone} — ${state.tone.filter} → ${state.tone.perception}`);
    }
    if (state.planetary) {
      parts.push(`Planetary: ${state.planetary.planet}`);
    }

    return parts.join(' | ');
  }

  private generateCode(state: FullyQualifiedState): Record<string, unknown> {
    return {
      type: 'state_projection',
      gate: state.gate?.gate,
      line: state.line?.line,
      dimension: state.dimension,
      center: state.center,
      color: state.color?.color,
      tone: state.tone?.tone,
      base: state.base?.base,
      planetary: state.planetary?.planet,
      modulation: {
        intensity: state.modulation?.intensity,
        phase: state.modulation?.phase
      },
      timestamp: state.timestamp
    };
  }

  private generateImage(state: FullyQualifiedState): Record<string, unknown> {
    return {
      type: 'image_projection',
      color: state.color ? {
        wavelength: state.color.spectral.wavelength,
        frequency: state.color.spectral.frequency,
        quality: state.color.spectral.quality
      } : undefined,
      archetype: state.gate?.archetype,
      dimension: state.dimension,
      intensity: state.modulation?.intensity,
      phase: state.modulation?.phase
    };
  }

  private generateSound(state: FullyQualifiedState): Record<string, unknown> {
    return {
      type: 'sound_projection',
      tone: state.tone?.attunement,
      frequency: state.color?.spectral.frequency,
      phase: state.modulation?.phase,
      intensity: state.modulation?.intensity,
      filter: state.tone?.filter
    };
  }

  private generateInterface(state: FullyQualifiedState): Record<string, unknown> {
    return {
      type: 'interface_projection',
      center: state.center,
      mode: state.centerMode,
      intensity: state.modulation?.intensity,
      color: state.color?.spectral.quality,
      tone: state.tone?.filter,
      dimension: state.dimension
    };
  }

  private generateGraph(state: FullyQualifiedState): Record<string, unknown> {
    return {
      type: 'graph_projection',
      node: state.gate?.gate,
      edges: [],
      weight: state.modulation?.intensity,
      dimension: state.dimension,
      center: state.center
    };
  }

  private generateBehavior(state: FullyQualifiedState): Record<string, unknown> {
    return {
      type: 'behavior_projection',
      drive: state.color?.driveResponse,
      motivation: state.color?.motivation,
      mode: state.line?.mode,
      approach: state.line?.approach,
      archetype: state.gate?.archetype
    };
  }

  /** Get best projection domain for a state */
  getBestDomain(state: FullyQualifiedState): ProjectionDomain {
    let bestDomain: ProjectionDomain = 'language';
    let bestFidelity = 0;

    for (const domain of PROJECTION_DOMAINS) {
      const fidelity = this.calculateFidelity(state, domain);
      if (fidelity > bestFidelity) {
        bestFidelity = fidelity;
        bestDomain = domain;
      }
    }

    return bestDomain;
  }

  /** Get all domains ranked by fidelity */
  getRankedDomains(state: FullyQualifiedState): { domain: ProjectionDomain; fidelity: number }[] {
    return PROJECTION_DOMAINS
      .map(domain => ({ domain, fidelity: this.calculateFidelity(state, domain) }))
      .sort((a, b) => b.fidelity - a.fidelity);
  }
}

export default ProjectionEngine;
