/**
 * @messy/identity-center — User-alignment hub
 * 
 * Derived from: ONTOLOGY.md (Identity Center section) + FOUNDATION.md
 * 
 * The Identity Center is the user-alignment hub where:
 * - the user's LLMs sit
 * - MCP connections are bridged
 * - tool routing is aligned
 * - user-specific style and meaning are preserved
 * 
 * The Identity Center is canonical and central. It is not an optional afterthought.
 */

import {
  IdentityCenter, LLMBridge, MCPBridge, UserProfile, Orientation,
  Center, CenterActivationMode, Channel, GateAddress, MeshMessage
} from '@messy/types';
import { createDefaultIdentityCenter, ONTOLOGICAL_CONSTITUTION } from '@messy/ontology';
import { MeshMessageImpl, MeshQualifier } from '@messy/mesh';

// ────────────────────────────────────────────────────────────────────────────
// IDENTITY CENTER ENGINE — The canonical user-alignment hub
// ────────────────────────────────────────────────────────────────────────────

export class IdentityCenterEngine {
  private center: IdentityCenter;
  private qualifier: MeshQualifier;
  private messageHistory: MeshMessageImpl[] = [];

  constructor(initial?: Partial<IdentityCenter>) {
    this.center = {
      ...createDefaultIdentityCenter(),
      ...initial,
      center: 'G' // Cannot change — canonical
    };
    this.qualifier = new MeshQualifier();
  }

  // ────────────────────────────────────────────────────────────────────────────
  // LLM BRIDGE MANAGEMENT
  // ────────────────────────────────────────────────────────────────────────────

  /** Add LLM bridge to Identity Center */
  addLLMBridge(bridge: LLMBridge): void {
    // Check for duplicate
    const existing = this.center.llmBridges.find(b => b.model === bridge.model);
    if (existing) {
      // Update alignment score
      existing.alignmentScore = Math.max(existing.alignmentScore, bridge.alignmentScore);
      return;
    }

    this.center.llmBridges.push(bridge);

    // Sort by alignment score (highest first)
    this.center.llmBridges.sort((a, b) => b.alignmentScore - a.alignmentScore);
  }

  /** Remove LLM bridge */
  removeLLMBridge(model: string): void {
    this.center.llmBridges = this.center.llmBridges.filter(b => b.model !== model);
  }

  /** Get best LLM bridge for a task */
  getBestLLMBridge(contextWindow: string): LLMBridge | undefined {
    return this.center.llmBridges
      .filter(b => b.contextWindow === contextWindow || contextWindow === 'any')
      .sort((a, b) => b.alignmentScore - a.alignmentScore)[0];
  }

  /** Get all LLM bridges */
  getLLMBridges(): LLMBridge[] {
    return [...this.center.llmBridges];
  }

  // ────────────────────────────────────────────────────────────────────────────
  // MCP BRIDGE MANAGEMENT
  // ────────────────────────────────────────────────────────────────────────────

  /** Add MCP bridge */
  addMCPBridge(bridge: MCPBridge): void {
    const existing = this.center.mcpBridges.find(b => b.server === bridge.server);
    if (existing) {
      // Merge tools
      existing.tools = [...new Set([...existing.tools, ...bridge.tools])];
      existing.routingPriority = Math.max(existing.routingPriority, bridge.routingPriority);
      return;
    }

    this.center.mcpBridges.push(bridge);

    // Sort by routing priority (highest first)
    this.center.mcpBridges.sort((a, b) => b.routingPriority - a.routingPriority);
  }

  /** Remove MCP bridge */
  removeMCPBridge(server: string): void {
    this.center.mcpBridges = this.center.mcpBridges.filter(b => b.server !== server);
  }

  /** Get MCP bridge for a tool */
  getMCPBridgeForTool(tool: string): MCPBridge | undefined {
    return this.center.mcpBridges
      .filter(b => b.tools.includes(tool))
      .sort((a, b) => b.routingPriority - a.routingPriority)[0];
  }

  /** Get all MCP bridges */
  getMCPBridges(): MCPBridge[] {
    return [...this.center.mcpBridges];
  }

  // ────────────────────────────────────────────────────────────────────────────
  // USER PROFILE MANAGEMENT
  // ────────────────────────────────────────────────────────────────────────────

  /** Update user profile */
  updateProfile(profile: Partial<UserProfile>): void {
    this.center.userProfile = {
      ...this.center.userProfile,
      ...profile,
      stylePreferences: profile.stylePreferences || this.center.userProfile.stylePreferences,
      semanticWeights: profile.semanticWeights || this.center.userProfile.semanticWeights,
      interactionHistory: profile.interactionHistory || this.center.userProfile.interactionHistory,
      trustedPatterns: profile.trustedPatterns || this.center.userProfile.trustedPatterns
    };
  }

  /** Add style preference */
  addStylePreference(preference: string): void {
    if (!this.center.userProfile.stylePreferences.includes(preference)) {
      this.center.userProfile.stylePreferences.push(preference);
    }
  }

  /** Add semantic weight */
  setSemanticWeight(key: string, weight: number): void {
    this.center.userProfile.semanticWeights[key] = Math.max(0, Math.min(1, weight));
  }

  /** Record interaction */
  recordInteraction(interaction: string): void {
    this.center.userProfile.interactionHistory.push(interaction);
    // Keep last 100 interactions
    if (this.center.userProfile.interactionHistory.length > 100) {
      this.center.userProfile.interactionHistory = 
        this.center.userProfile.interactionHistory.slice(-100);
    }
  }

  /** Add trusted pattern */
  addTrustedPattern(pattern: string): void {
    if (!this.center.userProfile.trustedPatterns.includes(pattern)) {
      this.center.userProfile.trustedPatterns.push(pattern);
    }
  }

  /** Get user profile */
  getProfile(): UserProfile {
    return { ...this.center.userProfile };
  }

  // ────────────────────────────────────────────────────────────────────────────
  // ORIENTATION MANAGEMENT
  // ────────────────────────────────────────────────────────────────────────────

  /** Update orientation */
  updateOrientation(orientation: Partial<Orientation>): void {
    this.center.orientation = {
      ...this.center.orientation,
      ...orientation
    };
  }

  /** Set current focus */
  setFocus(focus: string): void {
    this.center.orientation.currentFocus = focus;
  }

  /** Set long-term goal */
  setGoal(goal: string): void {
    this.center.orientation.longTermGoal = goal;
  }

  /** Add value */
  addValue(value: string): void {
    if (!this.center.orientation.values.includes(value)) {
      this.center.orientation.values.push(value);
    }
  }

  /** Get orientation */
  getOrientation(): Orientation {
    return { ...this.center.orientation };
  }

  // ────────────────────────────────────────────────────────────────────────────
  // CENTER ACTIVATION
  // ────────────────────────────────────────────────────────────────────────────

  /** Activate Identity Center */
  activate(mode: CenterActivationMode = 'expressed', intensity: number = 0.8): void {
    this.center.mode = mode;
    this.center.intensity = Math.max(0, Math.min(1, intensity));
  }

  /** Deactivate Identity Center */
  deactivate(): void {
    this.center.mode = 'latent';
    this.center.intensity = 0;
  }

  /** Get activation state */
  getActivation(): { mode: CenterActivationMode; intensity: number } {
    return { mode: this.center.mode, intensity: this.center.intensity };
  }

  // ────────────────────────────────────────────────────────────────────────────
  // TOOL ROUTING
  // ────────────────────────────────────────────────────────────────────────────

  /** Route a tool request to the appropriate bridge */
  routeTool(tool: string, args: unknown): {
    bridge: 'llm' | 'mcp' | 'local';
    target: string;
    priority: number;
  } | null {
    // Check MCP bridges first (highest priority for tools)
    const mcpBridge = this.getMCPBridgeForTool(tool);
    if (mcpBridge) {
      return {
        bridge: 'mcp',
        target: mcpBridge.server,
        priority: mcpBridge.routingPriority
      };
    }

    // Check LLM bridges for reasoning tasks
    const llmBridge = this.getBestLLMBridge('any');
    if (llmBridge) {
      return {
        bridge: 'llm',
        target: llmBridge.model,
        priority: llmBridge.alignmentScore
      };
    }

    // Fallback to local
    return {
      bridge: 'local',
      target: 'local',
      priority: 0.5
    };
  }

  // ────────────────────────────────────────────────────────────────────────────
  // MESH INTEGRATION
  // ────────────────────────────────────────────────────────────────────────────

  /** Qualify message with identity center context */
  qualifyMessage(message: MeshMessageImpl): MeshMessageImpl {
    // Add identity center qualification to message
    message.qualification.userAlignmentContext = JSON.stringify({
      focus: this.center.orientation.currentFocus,
      values: this.center.orientation.values,
      style: this.center.userProfile.stylePreferences
    });

    return message;
  }

  /** Record message in history */
  recordMessage(message: MeshMessageImpl): void {
    this.messageHistory.push(message);
    // Keep last 50 messages
    if (this.messageHistory.length > 50) {
      this.messageHistory = this.messageHistory.slice(-50);
    }
  }

  /** Get message history */
  getMessageHistory(): MeshMessageImpl[] {
    return [...this.messageHistory];
  }

  // ────────────────────────────────────────────────────────────────────────────
  // STATE EXPORT/IMPORT
  // ────────────────────────────────────────────────────────────────────────────

  /** Export identity center state */
  export(): IdentityCenter {
    return { ...this.center };
  }

  /** Import identity center state */
  import(state: IdentityCenter): void {
    this.center = {
      ...state,
      center: 'G' // Enforce canonical center
    };
  }

  /** Get full description */
  describe(): string {
    return `Identity Center (G):
  Mode: ${this.center.mode}
  Intensity: ${this.center.intensity.toFixed(2)}
  LLM Bridges: ${this.center.llmBridges.length}
  MCP Bridges: ${this.center.mcpBridges.length}
  Style Preferences: ${this.center.userProfile.stylePreferences.length}
  Semantic Weights: ${Object.keys(this.center.userProfile.semanticWeights).length}
  Interaction History: ${this.center.userProfile.interactionHistory.length}
  Trusted Patterns: ${this.center.userProfile.trustedPatterns.length}
  Current Focus: ${this.center.orientation.currentFocus}
  Long-term Goal: ${this.center.orientation.longTermGoal}
  Values: ${this.center.orientation.values.join(', ')}`;
  }
}

export default IdentityCenterEngine;
