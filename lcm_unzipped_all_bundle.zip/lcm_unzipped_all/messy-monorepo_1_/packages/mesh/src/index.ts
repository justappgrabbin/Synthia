/**
 * @messy/mesh — Canonical communication and morphing substrate
 * 
 * Derived from: MESH.md
 * 
 * The mesh is not pub/sub alone. It is message-qualified state morphing
 * across an ontological graph.
 * 
 * Mesh Law: gate -> message -> mesh -> channel traversal -> edge formation 
 * -> morph -> convergence -> expression -> center behavior
 */

import {
  MeshMessage, MessageQualification, TraversalMetadata,
  Channel, Edge, Center, GateNumber, Dimension, ArcPosition,
  PlanetaryQualification, Stratum, FullyQualifiedState,
  NodeFunction, NodeContribution, NodePolarity, RelationalAffordance
} from '@messy/types';
import {
  PLANETS, DIMENSIONS, CENTERS, GATES, GATE_ADDRESSES,
  LINE_CORRESPONDENCES, COLOR_CORRESPONDENCES, TONE_CORRESPONDENCES,
  BASE_CORRESPONDENCES
} from '@messy/ontology';
import { StateRegion, InternalCoordinatesImpl, ArcPositionImpl } from '@messy/state-space';

// ────────────────────────────────────────────────────────────────────────────
// MESH MESSAGE — All messages are qualified, not raw
// ────────────────────────────────────────────────────────────────────────────

export class MeshMessageImpl implements MeshMessage {
  content: unknown;
  qualification: MessageQualification;
  traversal: TraversalMetadata;
  timestamp: number;

  constructor(
    content: unknown,
    qualification: Partial<MessageQualification>,
    source: string
  ) {
    this.content = content;
    this.qualification = {
      activeGates: [],
      activeChannels: [],
      sourceCenter: 'G',
      targetCenter: 'G',
      dimensionContext: 'Being',
      recursionDepth: 0,
      ...qualification
    };
    this.traversal = {
      path: [source],
      hops: 0,
      latency: 0,
      morphCount: 0
    };
    this.timestamp = Date.now();
  }

  /** Qualify a message with ontological context */
  qualify(state: FullyQualifiedState): MeshMessageImpl {
    this.qualification = {
      ...this.qualification,
      activeGates: state.gate ? [state.gate.gate] : this.qualification.activeGates,
      sourceCenter: state.center || this.qualification.sourceCenter,
      dimensionContext: state.dimension || this.qualification.dimensionContext,
      lineContext: state.line?.line,
      colorContext: state.color?.color,
      toneContext: state.tone?.tone,
      baseContext: state.base?.base,
      planetaryInfluence: state.planetary,
      arcModulation: state.modulation?.arc ? {
        position: state.modulation.arc.position || 0.5,
        modulation: 0.5,
        soundVariation: 0.5,
        colorVariation: 0.5,
        intensity: state.modulation.intensity || 0.5,
        phase: state.modulation.phase || 0.5,
        interpolation: state.modulation.interpolation?.progress || 0.5,
        status: 'provisional'
      } : undefined
    };
    return this;
  }

  /** Record traversal hop */
  hop(nodeId: string): void {
    this.traversal.path.push(nodeId);
    this.traversal.hops++;
    this.traversal.latency = Date.now() - this.timestamp;
  }

  /** Record morph event */
  morph(): void {
    this.traversal.morphCount++;
  }

  /** Check if message has been through recursion */
  isRecursive(): boolean {
    return this.qualification.recursionDepth > 0;
  }

  /** Get traversal path as string */
  getPath(): string {
    return this.traversal.path.join(' -> ');
  }
}

// ────────────────────────────────────────────────────────────────────────────
// MESH TRAVERSAL — Path changes meaning
// ────────────────────────────────────────────────────────────────────────────

export class MeshTraversal {
  private edges: Map<string, Edge> = new Map();
  private channels: Map<string, Channel> = new Map();
  private activeNodes: Set<string> = new Set();

  /** Traverse from source to target through qualified channels */
  traverse(
    message: MeshMessageImpl,
    source: string,
    target: string,
    qualification: MessageQualification
  ): MeshMessageImpl {
    // Find qualified path
    const path = this.findQualifiedPath(source, target, qualification);

    // Traverse path, morphing at each hop
    for (const nodeId of path) {
      message.hop(nodeId);

      // Check if node morphs the message
      if (this.shouldMorph(message, nodeId)) {
        message.morph();
        this.applyMorph(message, nodeId);
      }

      // Record edge traversal
      this.recordEdge(message, nodeId);
    }

    return message;
  }

  private findQualifiedPath(
    source: string,
    target: string,
    qualification: MessageQualification
  ): string[] {
    // Simplified pathfinding — in production, this would use
    // qualified graph traversal with channel constraints
    const path = [source];

    // Add intermediate nodes based on active gates
    if (qualification.activeGates.length > 0) {
      for (const gate of qualification.activeGates) {
        path.push(`gate_${gate}`);
      }
    }

    path.push(target);
    return path;
  }

  private shouldMorph(message: MeshMessageImpl, nodeId: string): boolean {
    // Receiving a message may morph the receiver
    // Morph occurs when message qualification matches node function
    return message.qualification.dimensionContext !== undefined;
  }

  private applyMorph(message: MeshMessageImpl, nodeId: string): void {
    // Morph: message content is transformed by node function
    // This is where the mesh becomes message-morphic
    const morphFactor = message.qualification.recursionDepth * 0.1;
    message.qualification.recursionDepth++;

    // Apply dimensional modulation
    if (message.qualification.dimensionContext) {
      // Message takes on qualities of the dimension it passes through
    }
  }

  private recordEdge(message: MeshMessageImpl, nodeId: string): void {
    const edgeId = `${message.traversal.path[message.traversal.path.length - 2]}_${nodeId}`;
    const existing = this.edges.get(edgeId);

    if (existing) {
      existing.traversalCount++;
      existing.lastTraversal = Date.now();
      existing.weight = Math.min(1, existing.weight + 0.05);
      existing.stability = Math.min(1, existing.stability + 0.02);
    } else {
      this.edges.set(edgeId, {
        from: message.traversal.path[message.traversal.path.length - 2],
        to: nodeId,
        traversalCount: 1,
        lastTraversal: Date.now(),
        weight: 0.1,
        stability: 0.1
      });
    }
  }

  /** Get all edges with stability above threshold */
  getStableEdges(threshold: number = 0.5): Edge[] {
    return Array.from(this.edges.values()).filter(e => e.stability >= threshold);
  }

  /** Get edges for a specific channel */
  getChannelEdges(channelId: string): Edge[] {
    return Array.from(this.edges.values()).filter(e => 
      e.channel && `${e.channel.from}-${e.channel.to}` === channelId
    );
  }
}

// ────────────────────────────────────────────────────────────────────────────
// MESH QUALIFIER — Ontological message qualification
// ────────────────────────────────────────────────────────────────────────────

export class MeshQualifier {
  /** Create a fully qualified message from a state */
  qualifyMessage(
    content: unknown,
    state: FullyQualifiedState,
    source: string
  ): MeshMessageImpl {
    const message = new MeshMessageImpl(content, {}, source);
    return message.qualify(state);
  }

  /** Extract state from message qualification */
  extractState(message: MeshMessageImpl): Partial<FullyQualifiedState> {
    const q = message.qualification;
    return {
      gate: q.activeGates.length > 0 ? undefined : undefined, // Would need gate lookup
      center: q.sourceCenter,
      dimension: q.dimensionContext,
      line: q.lineContext ? LINE_CORRESPONDENCES[q.lineContext] : undefined,
      color: q.colorContext ? COLOR_CORRESPONDENCES[q.colorContext] : undefined,
      tone: q.toneContext ? TONE_CORRESPONDENCES[q.toneContext] : undefined,
      base: q.baseContext ? BASE_CORRESPONDENCES[q.baseContext] : undefined,
      planetary: q.planetaryInfluence,
      timestamp: message.timestamp,
      source: 'mesh'
    };
  }

  /** Check if message is qualified for a specific center */
  isQualifiedForCenter(message: MeshMessageImpl, center: Center): boolean {
    return message.qualification.targetCenter === center ||
           message.qualification.sourceCenter === center;
  }

  /** Check if message carries specific gate activation */
  hasGateActivation(message: MeshMessageImpl, gate: GateNumber): boolean {
    return message.qualification.activeGates.includes(gate);
  }

  /** Check if message is in specific dimension context */
  isInDimension(message: MeshMessageImpl, dimension: Dimension): boolean {
    return message.qualification.dimensionContext === dimension;
  }
}

// ────────────────────────────────────────────────────────────────────────────
// MESH MORPH — Message-morphic transformation
// ────────────────────────────────────────────────────────────────────────────

export class MeshMorph {
  /** Morph message based on channel traversal */
  morph(message: MeshMessageImpl, channel: Channel): MeshMessageImpl {
    // Channel type affects morph style
    switch (channel.type) {
      case 'definition':
        message = this.morphDefinition(message, channel);
        break;
      case 'conditioning':
        message = this.morphConditioning(message, channel);
        break;
      case 'transit':
        message = this.morphTransit(message, channel);
        break;
      case 'resonance':
        message = this.morphResonance(message, channel);
        break;
    }

    message.morph();
    return message;
  }

  private morphDefinition(message: MeshMessageImpl, channel: Channel): MeshMessageImpl {
    // Definition channels stabilize and clarify
    message.qualification.activeChannels.push(`${channel.from}-${channel.to}`);
    return message;
  }

  private morphConditioning(message: MeshMessageImpl, channel: Channel): MeshMessageImpl {
    // Conditioning channels modulate and qualify
    if (channel.qualification.planetary) {
      message.qualification.planetaryInfluence = channel.qualification.planetary;
    }
    return message;
  }

  private morphTransit(message: MeshMessageImpl, channel: Channel): MeshMessageImpl {
    // Transit channels pass through with minimal modification
    message.qualification.activeGates.push(channel.to);
    return message;
  }

  private morphResonance(message: MeshMessageImpl, channel: Channel): MeshMessageImpl {
    // Resonance channels amplify and synchronize
    message.qualification.recursionDepth++;
    return message;
  }
}

// ────────────────────────────────────────────────────────────────────────────
// MESH CONVERGENCE — Partial convergence is allowed
// ────────────────────────────────────────────────────────────────────────────

export class MeshConvergence {
  private convergingMessages: Map<string, MeshMessageImpl[]> = new Map();

  /** Add message to convergence pool */
  converge(message: MeshMessageImpl, convergenceId: string): {
    converged: boolean;
    result?: MeshMessageImpl;
    partial: boolean;
  } {
    const pool = this.convergingMessages.get(convergenceId) || [];
    pool.push(message);
    this.convergingMessages.set(convergenceId, pool);

    // Check if convergence criteria met
    const requiredMessages = 3; // Configurable

    if (pool.length >= requiredMessages) {
      // Full convergence
      const result = this.mergeMessages(pool);
      this.convergingMessages.delete(convergenceId);
      return { converged: true, result, partial: false };
    }

    // Partial convergence
    if (pool.length >= 2) {
      const result = this.mergeMessages(pool);
      return { converged: false, result, partial: true };
    }

    return { converged: false, partial: false };
  }

  private mergeMessages(messages: MeshMessageImpl[]): MeshMessageImpl {
    // Merge qualifications
    const allGates = messages.flatMap(m => m.qualification.activeGates);
    const allChannels = messages.flatMap(m => m.qualification.activeChannels);

    const merged = new MeshMessageImpl(
      messages[0].content,
      {
        ...messages[0].qualification,
        activeGates: [...new Set(allGates)],
        activeChannels: [...new Set(allChannels)],
        recursionDepth: Math.max(...messages.map(m => m.qualification.recursionDepth))
      },
      'convergence'
    );

    merged.traversal = {
      path: messages.flatMap(m => m.traversal.path),
      hops: messages.reduce((sum, m) => sum + m.traversal.hops, 0),
      latency: Math.max(...messages.map(m => m.traversal.latency)),
      morphCount: messages.reduce((sum, m) => sum + m.traversal.morphCount, 0)
    };

    return merged;
  }
}

// ────────────────────────────────────────────────────────────────────────────
// MESH CENTER STABILIZATION — Centers dynamically stabilized through traversal
// ────────────────────────────────────────────────────────────────────────────

export class CenterStabilizer {
  private centerStates: Map<Center, { intensity: number; lastTraversal: number }> = new Map();

  /** Stabilize a center through message traversal */
  stabilize(center: Center, message: MeshMessageImpl): void {
    const state = this.centerStates.get(center) || { intensity: 0, lastTraversal: 0 };

    // Increase intensity based on message qualification
    const intensityBoost = message.qualification.activeGates.length * 0.1;
    state.intensity = Math.min(1, state.intensity + intensityBoost);
    state.lastTraversal = Date.now();

    this.centerStates.set(center, state);
  }

  /** Decay center intensity over time */
  decay(center: Center, rate: number = 0.01): void {
    const state = this.centerStates.get(center);
    if (state) {
      state.intensity = Math.max(0, state.intensity - rate);
      if (state.intensity === 0) {
        this.centerStates.delete(center);
      }
    }
  }

  /** Get center stabilization level */
  getStabilization(center: Center): number {
    return this.centerStates.get(center)?.intensity || 0;
  }

  /** Get all stabilized centers */
  getStabilizedCenters(): Center[] {
    return Array.from(this.centerStates.entries())
      .filter(([, state]) => state.intensity > 0.3)
      .map(([center]) => center);
  }
}

// ────────────────────────────────────────────────────────────────────────────
// MESH ENGINE — Main orchestrator
// ────────────────────────────────────────────────────────────────────────────

export class MeshEngine {
  traversal: MeshTraversal;
  qualifier: MeshQualifier;
  morph: MeshMorph;
  convergence: MeshConvergence;
  stabilizer: CenterStabilizer;

  constructor() {
    this.traversal = new MeshTraversal();
    this.qualifier = new MeshQualifier();
    this.morph = new MeshMorph();
    this.convergence = new MeshConvergence();
    this.stabilizer = new CenterStabilizer();
  }

  /** Send a message through the mesh */
  send(
    content: unknown,
    state: FullyQualifiedState,
    source: string,
    target: string
  ): MeshMessageImpl {
    // Qualify message
    const message = this.qualifier.qualifyMessage(content, state, source);

    // Traverse through mesh
    const traversed = this.traversal.traverse(message, source, target, message.qualification);

    // Stabilize centers
    if (state.center) {
      this.stabilizer.stabilize(state.center, traversed);
    }

    return traversed;
  }

  /** Converge multiple messages */
  converge(messages: MeshMessageImpl[], convergenceId: string): {
    converged: boolean;
    result?: MeshMessageImpl;
    partial: boolean;
  } {
    let result = { converged: false, partial: false };

    for (const message of messages) {
      result = this.convergence.converge(message, convergenceId);
    }

    return result;
  }

  /** Get mesh statistics */
  getStats(): {
    activeEdges: number;
    stableEdges: number;
    stabilizedCenters: number;
    totalMorphs: number;
    convergencePools: number;
  } {
    return {
      activeEdges: 0, // Would count from traversal
      stableEdges: this.traversal.getStableEdges().length,
      stabilizedCenters: this.stabilizer.getStabilizedCenters().length,
      totalMorphs: 0, // Would track globally
      convergencePools: this.convergence['convergingMessages'].size
    };
  }
}

export default MeshEngine;
