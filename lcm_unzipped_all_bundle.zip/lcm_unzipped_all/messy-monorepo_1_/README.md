# MESSY — Message-Morphic, State-Latticed Organism

> "All possible forms already exist in the state space as latent structure."
> — Foundation Principle

## What MESSY Is

MESSY is a **local-first digital organism** for alignment, activation, and expression. It is not a framework. It is not a library. It is a living system that addresses, activates, and expresses latent structure.

## Core Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    MESSY ORGANISM                        │
├─────────────────────────────────────────────────────────┤
│  Apps Layer          │  Runtime | Browser Shell         │
├─────────────────────────────────────────────────────────┤
│  Organs Layer        │  AUTOLING | DISEMINER | Novel   │
├─────────────────────────────────────────────────────────┤
│  Core Packages       │  Ontology | State Space | Mesh   │
│                      │  Activation | Projection | Node    │
│                      │  Identity Center | Resonance    │
├─────────────────────────────────────────────────────────┤
│  Support Packages    │  Types | Persistence | HD Graph │
│                      │  Ingestion | Self-Supervised    │
├─────────────────────────────────────────────────────────┤
│  Services (Optional) │  Market API | Oracle | Chart    │
└─────────────────────────────────────────────────────────┘
```

## Canonical Documents

The organism is governed by seven canonical documents:

1. **FOUNDATION** — What MESSY is and why it exists
2. **ONTOLOGY** — What exists and how it is ordered
3. **STATE SPACE MECHANICS** — How states work internally
4. **MESH** — How subsystems communicate and morph
5. **NODE FUNCTIONS** — What nodes contribute before channels emerge
6. **MIGRATION MAP** — How prototypes consolidate into canonical monorepo
7. **ARCHIVE POLICY** — How superseded work is preserved without confusion

## Quick Start

```bash
# Install dependencies
pnpm install

# Boot the organism
pnpm organism:boot

# Start the browser shell
pnpm organism:shell

# Validate ontology conformance
pnpm organism:ontology:validate

# Inspect state space
pnpm organism:state:inspect
```

## Local-First Doctrine

The following must remain **local** (no remote dependencies):
- Ontology
- State space
- Mesh
- Gates, channels, centers
- Identity center
- Morph logic
- Persistence
- Browser shell and runtime spine

The following may be **external** (optional bridges):
- User LLMs
- MCP servers
- Oracle services
- Training pipelines
- Market services
- Heavy numerical or research modules

## License

See LICENSE file.
