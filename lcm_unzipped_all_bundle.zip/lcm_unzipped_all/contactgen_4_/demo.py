"""Demo script to generate grasps for a given object."""
import torch
import argparse
import os
import numpy as np

try:
    import trimesh
    HAS_TRIMESH = True
except ImportError:
    HAS_TRIMESH = False

from models.contactgen_cvae import ContactGenCVAE
from utils.data_loader import ObjectPreprocessor
from utils.mano_utils import MANOHand, PiecewiseSDF
from models.grasp_solver import GraspSolver
from utils.vis_utils import save_grasp_obj, visualize_contact_map, visualize_part_map, create_sphere_mesh


def generate_grasps(model, obj_points, n_samples=10, device="cuda"):
    """Generate grasp contact maps for an object."""
    model.eval()
    obj_points = obj_points.to(device).unsqueeze(0)  # [1, N, 3]

    with torch.no_grad():
        predictions = model.sample(obj_points, n_samples=n_samples)

    return predictions


def optimize_grasps(predictions, obj_points, mano_model, n_iterations=100):
    """Optimize grasps from predicted contact maps."""
    solver = GraspSolver(mano_model, n_iterations=n_iterations)

    obj_points_batch = obj_points.unsqueeze(0).expand(len(predictions), -1, -1)

    results = []
    for i, (contact, part, direction) in enumerate(predictions):
        print(f"Optimizing grasp {i+1}/{len(predictions)}...")
        pose, shape, trans = solver.solve(
            obj_points_batch[i:i+1],
            contact,
            part,
            direction
        )
        results.append((pose, shape, trans))

    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--obj_path", type=str, required=True, help="Path to object mesh (.ply, .obj)")
    parser.add_argument("--checkpoint", type=str, default="checkpoint/checkpoint.pt")
    parser.add_argument("--n_samples", type=int, default=10, help="Number of grasp samples")
    parser.add_argument("--save_root", type=str, default="exp/demo_results")
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--n_iterations", type=int, default=100, help="Optimization iterations")
    args = parser.parse_args()

    os.makedirs(args.save_root, exist_ok=True)
    device = torch.device(args.device)

    # Load object
    preprocessor = ObjectPreprocessor(n_points=2048)
    obj_points = preprocessor.process(args.obj_path)

    # Load model
    if os.path.exists(args.checkpoint):
        checkpoint = torch.load(args.checkpoint, map_location=device)
        model_args = checkpoint.get("args", {})

        model = ContactGenCVAE(
            latent_dim=model_args.get("latent_dim", 64),
            n_parts=model_args.get("n_parts", 16),
            n_directions=model_args.get("n_directions", 8)
        ).to(device)

        model.load_state_dict(checkpoint["model_state_dict"])
        print(f"Loaded model from {args.checkpoint}")
    else:
        print("No checkpoint found. Using randomly initialized model for demo.")
        model = ContactGenCVAE(latent_dim=64, n_parts=16, n_directions=8).to(device)

    # Generate contact maps
    print(f"Generating {args.n_samples} grasp samples...")
    predictions = generate_grasps(model, obj_points, n_samples=args.n_samples, device=device)

    # Save contact map visualizations
    for i, (contact, part, direction) in enumerate(predictions):
        contact_vis_path = os.path.join(args.save_root, f"contact_map_{i}.png")
        visualize_contact_map(obj_points, contact.squeeze(0), save_path=contact_vis_path)

        part_vis_path = os.path.join(args.save_root, f"part_map_{i}.png")
        visualize_part_map(obj_points, part.squeeze(0), save_path=part_vis_path)

        # Save raw predictions
        torch.save({
            "contact_map": contact.cpu(),
            "part_map": part.cpu(),
            "direction_map": direction.cpu()
        }, os.path.join(args.save_root, f"prediction_{i}.pt"))

    print(f"Saved contact maps to {args.save_root}")

    # Optimize grasps (optional, requires MANO)
    mano = MANOHand()
    print("
Optimizing grasps...")
    grasps = optimize_grasps(predictions, obj_points, mano, n_iterations=args.n_iterations)

    # Save optimized grasps
    for i, (pose, shape, trans) in enumerate(grasps):
        hand_verts, hand_joints = mano.forward(pose.unsqueeze(0), shape.unsqueeze(0), trans.unsqueeze(0))
        hand_verts = hand_verts.squeeze(0).cpu().numpy()

        # Create simple hand mesh (placeholder)
        hand_faces = np.array([[0, 1, 2], [0, 2, 3]])  # Placeholder

        # Load object mesh for visualization
        if os.path.exists(args.obj_path) and HAS_TRIMESH:
            obj_mesh = trimesh.load(args.obj_path)
            if isinstance(obj_mesh, trimesh.Scene):
                obj_mesh = obj_mesh.dump(concatenate=True)
            obj_verts = obj_mesh.vertices
            obj_faces = obj_mesh.faces
        else:
            obj_verts, obj_faces = create_sphere_mesh(radius=0.1)

        save_path = os.path.join(args.save_root, f"grasp_{i}.obj")
        save_grasp_obj(hand_verts, hand_faces, obj_verts, obj_faces, save_path)

    print(f"
Saved {len(grasps)} grasps to {args.save_root}")


if __name__ == "__main__":
    main()
