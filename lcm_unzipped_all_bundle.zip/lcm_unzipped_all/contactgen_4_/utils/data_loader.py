"""Dataset loader for GRAB dataset and object preprocessing."""
import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import os
import json

try:
    import trimesh
    HAS_TRIMESH = True
except ImportError:
    HAS_TRIMESH = False
    print("Warning: trimesh not available. Using fallback mesh loading.")


class GRABDataset(Dataset):
    """GRAB dataset for hand-object grasping."""

    def __init__(self, data_root, split="train", n_obj_points=2048, n_hand_points=778):
        self.data_root = data_root
        self.split = split
        self.n_obj_points = n_obj_points
        self.n_hand_points = n_hand_points

        # Load dataset index
        self.index_file = os.path.join(data_root, f"{split}_index.json")
        if os.path.exists(self.index_file):
            with open(self.index_file, "r") as f:
                self.data_list = json.load(f)
        else:
            # Create dummy index if not available
            self.data_list = self._create_dummy_index()

    def _create_dummy_index(self):
        """Create dummy data index for demonstration."""
        return [
            {"obj_mesh": "dummy_object.ply", "hand_pose": "dummy_pose.npy"}
            for _ in range(100)
        ]

    def __len__(self):
        return len(self.data_list)

    def _sample_object_points(self, mesh_path):
        """Sample points from object mesh surface."""
        if not os.path.exists(mesh_path):
            # Generate dummy object
            points = torch.randn(self.n_obj_points, 3) * 0.1
            return points

        if not HAS_TRIMESH:
            # Fallback: load PLY manually
            return self._load_ply_points(mesh_path)

        mesh = trimesh.load(mesh_path)
        if isinstance(mesh, trimesh.Scene):
            mesh = mesh.dump(concatenate=True)

        # Sample points on surface
        points, _ = trimesh.sample.sample_surface(mesh, self.n_obj_points)
        points = torch.tensor(points, dtype=torch.float32)

        # Normalize
        center = points.mean(dim=0)
        points = points - center
        scale = points.abs().max()
        points = points / (scale + 1e-8)

        return points

    def _load_ply_points(self, ply_path):
        """Load points from PLY file without trimesh."""
        with open(ply_path, "r") as f:
            lines = f.readlines()

        # Skip header
        vertex_count = 0
        header_end = 0
        for i, line in enumerate(lines):
            if line.startswith("element vertex"):
                vertex_count = int(line.split()[-1])
            if line.strip() == "end_header":
                header_end = i + 1
                break

        points = []
        for line in lines[header_end:header_end + vertex_count]:
            parts = line.strip().split()
            points.append([float(parts[0]), float(parts[1]), float(parts[2])])

        points = torch.tensor(points, dtype=torch.float32)

        # Subsample to n_obj_points
        if len(points) > self.n_obj_points:
            indices = torch.randperm(len(points))[:self.n_obj_points]
            points = points[indices]
        elif len(points) < self.n_obj_points:
            # Repeat points
            repeat = (self.n_obj_points + len(points) - 1) // len(points)
            points = points.repeat(repeat, 1)[:self.n_obj_points]

        # Normalize
        center = points.mean(dim=0)
        points = points - center
        scale = points.abs().max()
        points = points / (scale + 1e-8)

        return points

    def __getitem__(self, idx):
        """
        Returns:
            obj_points: [N, 3]
            contact_map: [N]
            part_map: [N, n_parts]
            direction_map: [N, n_directions]
        """
        item = self.data_list[idx]

        # Load object
        obj_path = os.path.join(self.data_root, item["obj_mesh"])
        obj_points = self._sample_object_points(obj_path)

        # Dummy contact maps (replace with actual data)
        contact_map = torch.rand(self.n_obj_points)
        part_map = torch.rand(self.n_obj_points, 16)
        part_map = part_map / part_map.sum(dim=-1, keepdim=True)
        direction_map = torch.rand(self.n_obj_points, 8)
        direction_map = direction_map / direction_map.sum(dim=-1, keepdim=True)

        return {
            "obj_points": obj_points,
            "contact_map": contact_map,
            "part_map": part_map,
            "direction_map": direction_map
        }


class ObjectPreprocessor:
    """Preprocess 3D objects for contact generation."""

    def __init__(self, n_points=2048):
        self.n_points = n_points

    def process(self, mesh_path):
        """Process a mesh file into normalized point cloud."""
        if not os.path.exists(mesh_path):
            # Generate dummy object (sphere)
            theta = np.random.uniform(0, 2 * np.pi, self.n_points)
            phi = np.random.uniform(0, np.pi, self.n_points)
            x = 0.1 * np.sin(phi) * np.cos(theta)
            y = 0.1 * np.sin(phi) * np.sin(theta)
            z = 0.1 * np.cos(phi)
            points = np.stack([x, y, z], axis=1)
            return torch.tensor(points, dtype=torch.float32)

        if HAS_TRIMESH:
            mesh = trimesh.load(mesh_path)
            if isinstance(mesh, trimesh.Scene):
                mesh = mesh.dump(concatenate=True)

            # Sample points
            points, _ = trimesh.sample.sample_surface(mesh, self.n_points)
            points = torch.tensor(points, dtype=torch.float32)
        else:
            # Fallback: load PLY
            points = self._load_ply_points(mesh_path)

        # Normalize to unit sphere
        center = points.mean(dim=0)
        points = points - center
        scale = points.abs().max()
        points = points / (scale + 1e-8)

        return points

    def _load_ply_points(self, ply_path):
        """Load points from PLY file."""
        with open(ply_path, "r") as f:
            lines = f.readlines()

        vertex_count = 0
        header_end = 0
        for i, line in enumerate(lines):
            if line.startswith("element vertex"):
                vertex_count = int(line.split()[-1])
            if line.strip() == "end_header":
                header_end = i + 1
                break

        points = []
        for line in lines[header_end:header_end + vertex_count]:
            parts = line.strip().split()
            points.append([float(parts[0]), float(parts[1]), float(parts[2])])

        points = torch.tensor(points, dtype=torch.float32)

        # Subsample
        if len(points) > self.n_points:
            indices = torch.randperm(len(points))[:self.n_points]
            points = points[indices]
        elif len(points) < self.n_points:
            repeat = (self.n_points + len(points) - 1) // len(points)
            points = points.repeat(repeat, 1)[:self.n_points]

        return points

    def compute_normals(self, mesh_path):
        """Compute vertex normals for mesh."""
        if not os.path.exists(mesh_path):
            return torch.randn(self.n_points, 3)

        if HAS_TRIMESH:
            mesh = trimesh.load(mesh_path)
            if isinstance(mesh, trimesh.Scene):
                mesh = mesh.dump(concatenate=True)

            # Sample points with normals
            points, face_indices = trimesh.sample.sample_surface(mesh, self.n_points)
            normals = mesh.face_normals[face_indices]
            return torch.tensor(normals, dtype=torch.float32)
        else:
            return torch.randn(self.n_points, 3)
