"""Visualization utilities for grasps and contact maps."""
import numpy as np
import torch
import os

try:
    import trimesh
    HAS_TRIMESH = True
except ImportError:
    HAS_TRIMESH = False


def save_grasp_obj(hand_verts, hand_faces, obj_verts, obj_faces, save_path):
    """Save hand and object as combined OBJ file."""
    with open(save_path, "w") as f:
        # Write object vertices
        for v in obj_verts:
            line = "v " + " ".join(["%.6f" % x for x in v]) + " 0.8 0.8 0.8"
            f.write(line + "\n")
        
        # Write hand vertices (with color)
        for v in hand_verts:
            line = "v " + " ".join(["%.6f" % x for x in v]) + " 1.0 0.4 0.2"
            f.write(line + "\n")
        
        # Write object faces
        for face in obj_faces:
            line = "f " + " ".join([str(x+1) for x in face])
            f.write(line + "\n")
        
        # Write hand faces (offset by object vertex count)
        offset = len(obj_verts)
        for face in hand_faces:
            line = "f " + " ".join([str(x+1+offset) for x in face])
            f.write(line + "\n")


def visualize_contact_map(obj_points, contact_map, save_path=None):
    """Visualize contact map on object points."""
    try:
        import matplotlib.pyplot as plt
        from mpl_toolkits.mplot3d import Axes3D
    except ImportError:
        print("matplotlib not available for visualization")
        return
    
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection="3d")
    
    points = obj_points.cpu().numpy() if torch.is_tensor(obj_points) else obj_points
    contact = contact_map.cpu().numpy() if torch.is_tensor(contact_map) else contact_map
    
    scatter = ax.scatter(points[:, 0], points[:, 1], points[:, 2],
                        c=contact, cmap="hot", s=20, alpha=0.8)
    plt.colorbar(scatter, label="Contact Probability")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    ax.set_title("Contact Map Visualization")
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()


def visualize_part_map(obj_points, part_map, save_path=None):
    """Visualize part map on object points."""
    try:
        import matplotlib.pyplot as plt
        from mpl_toolkits.mplot3d import Axes3D
    except ImportError:
        print("matplotlib not available for visualization")
        return
    
    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(111, projection="3d")
    
    points = obj_points.cpu().numpy() if torch.is_tensor(obj_points) else obj_points
    parts = part_map.argmax(dim=-1).cpu().numpy() if torch.is_tensor(part_map) else part_map.argmax(axis=-1)
    
    colors = plt.cm.tab20(parts / parts.max())
    scatter = ax.scatter(points[:, 0], points[:, 1], points[:, 2],
                        c=colors, s=20, alpha=0.8)
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    ax.set_title("Part Map Visualization")
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()


def create_sphere_mesh(radius=0.1, center=(0, 0, 0), subdivisions=2):
    """Create a simple sphere mesh for demo objects."""
    if HAS_TRIMESH:
        sphere = trimesh.creation.icosphere(subdivisions=subdivisions, radius=radius)
        sphere.vertices += center
        return sphere.vertices, sphere.faces
    else:
        return _create_icosphere_manual(radius, center)


def _create_icosphere_manual(radius, center):
    """Create icosphere without trimesh."""
    verts = [
        [0, 0, radius], [0, 0, -radius],
        [radius, 0, 0], [-radius, 0, 0],
        [0, radius, 0], [0, -radius, 0]
    ]
    
    faces = [
        [0, 2, 4], [0, 4, 3], [0, 3, 5], [0, 5, 2],
        [1, 4, 2], [1, 3, 4], [1, 5, 3], [1, 2, 5]
    ]
    
    new_verts = list(verts)
    new_faces = []
    
    for face in faces:
        v0 = np.array(verts[face[0]])
        v1 = np.array(verts[face[1]])
        v2 = np.array(verts[face[2]])
        
        m01 = (v0 + v1) / 2
        m12 = (v1 + v2) / 2
        m20 = (v2 + v0) / 2
        
        m01 = m01 / np.linalg.norm(m01) * radius
        m12 = m12 / np.linalg.norm(m12) * radius
        m20 = m20 / np.linalg.norm(m20) * radius
        
        idx0 = face[0]
        idx1 = face[1]
        idx2 = face[2]
        idx01 = len(new_verts)
        new_verts.append(m01.tolist())
        idx12 = len(new_verts)
        new_verts.append(m12.tolist())
        idx20 = len(new_verts)
        new_verts.append(m20.tolist())
        
        new_faces.extend([
            [idx0, idx01, idx20],
            [idx01, idx1, idx12],
            [idx20, idx12, idx2],
            [idx01, idx12, idx20]
        ])
    
    verts = np.array(new_verts) + np.array(center)
    faces = np.array(new_faces)
    
    return verts, faces


def create_cube_mesh(size=0.1, center=(0, 0, 0)):
    """Create a cube mesh."""
    if HAS_TRIMESH:
        box = trimesh.creation.box(extents=[size, size, size])
        box.vertices += center
        return box.vertices, box.faces
    else:
        s = size / 2
        verts = np.array([
            [-s, -s, -s], [s, -s, -s], [s, s, -s], [-s, s, -s],
            [-s, -s, s], [s, -s, s], [s, s, s], [-s, s, s]
        ]) + center
        faces = np.array([
            [0, 1, 2], [0, 2, 3],
            [4, 7, 6], [4, 6, 5],
            [0, 4, 5], [0, 5, 1],
            [2, 6, 7], [2, 7, 3],
            [0, 3, 7], [0, 7, 4],
            [1, 5, 6], [1, 6, 2]
        ])
        return verts, faces


def create_cylinder_mesh(radius=0.05, height=0.2, center=(0, 0, 0)):
    """Create a cylinder mesh."""
    if HAS_TRIMESH:
        cylinder = trimesh.creation.cylinder(radius=radius, height=height)
        cylinder.vertices += center
        return cylinder.vertices, cylinder.faces
    else:
        n_segments = 16
        n_rings = 4
        verts = []
        faces = []
        
        for i in range(n_rings):
            z = -height/2 + (height / (n_rings - 1)) * i
            for j in range(n_segments):
                theta = 2 * np.pi * j / n_segments
                x = radius * np.cos(theta)
                y = radius * np.sin(theta)
                verts.append([x, y, z])
        
        verts = np.array(verts) + center
        
        for ring in range(n_rings - 1):
            for seg in range(n_segments):
                v0 = ring * n_segments + seg
                v1 = ring * n_segments + (seg + 1) % n_segments
                v2 = (ring + 1) * n_segments + seg
                v3 = (ring + 1) * n_segments + (seg + 1) % n_segments
                faces.append([v0, v2, v1])
                faces.append([v1, v2, v3])
        
        return verts, np.array(faces)