"""MANO hand model utilities and piecewise SDF representation."""
import torch
import torch.nn as nn
import numpy as np
import pickle
import os


class MANOHand:
    """MANO hand model wrapper."""

    # Hand part definitions (16 parts: 15 joints + palm)
    N_PARTS = 16

    # Joint to part mapping
    JOINT_TO_PART = {
        0: 0,   # wrist -> palm
        1: 1,   # index MCP
        2: 1,   # index PIP
        3: 1,   # index DIP
        4: 1,   # index tip
        5: 2,   # middle MCP
        6: 2,   # middle PIP
        7: 2,   # middle DIP
        8: 2,   # middle tip
        9: 3,   # ring MCP
        10: 3,  # ring PIP
        11: 3,  # ring DIP
        12: 3,  # ring tip
        13: 4,  # pinky MCP
        14: 4,  # pinky PIP
        15: 4,  # pinky DIP
        16: 4,  # pinky tip
        17: 5,  # thumb CMC
        18: 5,  # thumb MCP
        19: 5,  # thumb IP
        20: 5,  # thumb tip
    }

    # Part names
    PART_NAMES = [
        "palm", "index", "middle", "ring", "pinky", "thumb",
        "palm_base", "index_base", "middle_base", "ring_base", 
        "pinky_base", "thumb_base", "palm_tip", "index_tip",
        "middle_tip", "ring_tip"
    ]

    def __init__(self, mano_path=None, use_pca=True, ncomps=6):
        self.use_pca = use_pca
        self.ncomps = ncomps

        # MANO parameters (simplified for standalone)
        self.n_joints = 21
        self.n_verts = 778
        self.n_pca = ncomps

        # Initialize with default template if no MANO file
        if mano_path and os.path.exists(mano_path):
            with open(mano_path, 'rb') as f:
                mano_data = pickle.load(f, encoding='latin1')
            self._load_mano_data(mano_data)
        else:
            self._init_default_template()

    def _init_default_template(self):
        """Initialize with default hand template."""
        # Default hand template vertices (778, 3)
        self.verts_template = torch.zeros(778, 3)
        # Initialize with a simple hand shape
        # Palm
        self.verts_template[:100] = torch.tensor([
            [0.0, 0.0, 0.0], [0.02, 0.0, 0.0], [-0.02, 0.0, 0.0],
            [0.0, 0.02, 0.0], [0.0, -0.02, 0.0]
        ]).repeat(20, 1)[:100]

        # Joint regressor (simplified)
        self.J_regressor = torch.eye(21, 778)

        # Skinning weights (778 verts x 16 parts)
        self.skinning_weights = torch.zeros(778, 16)

        # Assign weights based on vertex regions
        for i in range(778):
            # Simple heuristic assignment
            if i < 100:
                self.skinning_weights[i, 0] = 1.0  # palm
            elif i < 200:
                self.skinning_weights[i, 1] = 1.0  # index
            elif i < 300:
                self.skinning_weights[i, 2] = 1.0  # middle
            elif i < 400:
                self.skinning_weights[i, 3] = 1.0  # ring
            elif i < 500:
                self.skinning_weights[i, 4] = 1.0  # pinky
            elif i < 600:
                self.skinning_weights[i, 5] = 1.0  # thumb
            else:
                self.skinning_weights[i, 0] = 1.0

    def _load_mano_data(self, mano_data):
        """Load MANO model data from pickle."""
        self.verts_template = torch.tensor(mano_data['v_template'], dtype=torch.float32)
        self.faces = mano_data['f']
        self.J_regressor = torch.tensor(mano_data['J_regressor'].toarray(), dtype=torch.float32)
        self.skinning_weights = torch.tensor(mano_data['weights'], dtype=torch.float32)
        self.shapedirs = torch.tensor(mano_data['shapedirs'], dtype=torch.float32)
        self.posedirs = torch.tensor(mano_data['posedirs'], dtype=torch.float32)

        if self.use_pca and 'hands_components' in mano_data:
            self.hands_components = torch.tensor(mano_data['hands_components'][:self.ncomps], dtype=torch.float32)
        else:
            self.use_pca = False

    def forward(self, pose, shape, trans=None):
        """
        Forward pass to get hand vertices and joints.

        Args:
            pose: [B, n_pca] or [B, n_joints*3] hand pose
            shape: [B, 10] shape parameters
            trans: [B, 3] translation

        Returns:
            verts: [B, 778, 3] hand vertices
            joints: [B, 21, 3] hand joints
        """
        batch_size = pose.shape[0]

        # Apply shape blend shapes
        v_shaped = self.verts_template.unsqueeze(0) + torch.einsum('vij,bj->bvi', self.shapedirs, shape)

        # Get joints from regressor
        J = torch.einsum('jv,bvi->bji', self.J_regressor, v_shaped)

        # Convert PCA pose to full pose if needed
        if self.use_pca:
            full_pose = torch.einsum('ij,bj->bi', self.hands_components, pose)
            full_pose = full_pose.view(batch_size, self.ncomps, 3)
        else:
            full_pose = pose.view(batch_size, -1, 3)

        # Add global rotation (first 3 dims) + finger poses
        # Simplified: just return shaped vertices for now
        verts = v_shaped

        if trans is not None:
            verts = verts + trans.unsqueeze(1)
            J = J + trans.unsqueeze(1)

        return verts, J


class PiecewiseSDF(nn.Module):
    """Piecewise SDF model for hand parts."""

    def __init__(self, n_parts=16, hidden_dim=32, n_layers=4):
        super().__init__()
        self.n_parts = n_parts

        # One MLP per hand part
        self.part_decoders = nn.ModuleList()
        for _ in range(n_parts):
            layers = []
            in_dim = 3
            for _ in range(n_layers):
                layers.append(nn.Linear(in_dim, hidden_dim))
                layers.append(nn.LeakyReLU(0.1))
                in_dim = hidden_dim
            layers.append(nn.Linear(hidden_dim, 1))
            self.part_decoders.append(nn.Sequential(*layers))

    def forward(self, points, part_ids):
        """
        Compute SDF values for points belonging to specific hand parts.

        Args:
            points: [B, N, 3] query points
            part_ids: [B, N] part indices (0-15)

        Returns:
            sdf: [B, N] signed distance values
        """
        B, N, _ = points.shape
        sdf = torch.zeros(B, N, device=points.device)

        for part_id in range(self.n_parts):
            mask = (part_ids == part_id).float()
            if mask.sum() > 0:
                part_sdf = self.part_decoders[part_id](points).squeeze(-1)
                sdf = sdf + part_sdf * mask

        return sdf

    def get_skinning_weights(self, points, joints, faces=None):
        """
        Compute skinning weights for query points based on distance to joints.

        Args:
            points: [B, N, 3] query points
            joints: [B, J, 3] hand joints

        Returns:
            weights: [B, N, J] skinning weights
        """
        dists = torch.cdist(points, joints)  # [B, N, J]
        weights = F.softmax(-dists * 10, dim=-1)  # Sharp falloff
        return weights


import torch.nn.functional as F
