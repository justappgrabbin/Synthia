"""Contact map, part map, and direction map utilities."""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class ContactRepresentation:
    """Object-centric contact representation."""

    def __init__(self, n_parts=16, n_directions=8):
        self.n_parts = n_parts
        self.n_directions = n_directions

        # Direction bins (8 directions on unit circle)
        angles = torch.linspace(0, 2 * np.pi, n_directions + 1)[:-1]
        self.direction_bins = torch.stack([
            torch.cos(angles),
            torch.sin(angles)
        ], dim=1)  # [n_directions, 2]

    def compute_contact_map(self, obj_points, hand_verts, hand_faces, threshold=0.005):
        """
        Compute contact probability map on object points.

        Args:
            obj_points: [B, N, 3] object surface points
            hand_verts: [B, V, 3] hand vertices
            hand_faces: [F, 3] hand faces (shared across batch)
            threshold: distance threshold for contact

        Returns:
            contact_map: [B, N] contact probability (0-1)
        """
        # Compute distance from each object point to hand surface
        dists = torch.cdist(obj_points, hand_verts)  # [B, N, V]
        min_dists = dists.min(dim=-1)[0]  # [B, N]

        # Convert distance to contact probability
        contact_map = torch.exp(-min_dists / threshold)
        contact_map = torch.clamp(contact_map, 0, 1)

        return contact_map

    def compute_part_map(self, obj_points, hand_verts, hand_joints, skinning_weights):
        """
        Compute part map on object points.

        Args:
            obj_points: [B, N, 3] object surface points
            hand_verts: [B, V, 3] hand vertices
            hand_joints: [B, J, 3] hand joints
            skinning_weights: [B, V, J] skinning weights

        Returns:
            part_map: [B, N, n_parts] one-hot part assignment
        """
        # Find nearest hand vertex for each object point
        dists = torch.cdist(obj_points, hand_verts)  # [B, N, V]
        nearest_idx = dists.argmin(dim=-1)  # [B, N]

        # Get skinning weights of nearest vertices
        B, N = nearest_idx.shape
        nearest_weights = torch.gather(
            skinning_weights, 1, 
            nearest_idx.unsqueeze(-1).expand(-1, -1, skinning_weights.shape[-1])
        )  # [B, N, J]

        # Map joints to parts (simplified: each joint maps to a part)
        n_joints = hand_joints.shape[1]
        n_parts = self.n_parts

        # Joint-to-part mapping matrix
        joint_to_part = torch.zeros(n_joints, n_parts, device=obj_points.device)
        # Map 21 joints to 16 parts
        joint_to_part[0, 0] = 1.0   # wrist -> palm
        for i in range(1, 5):
            joint_to_part[i, 1] = 1.0   # index
        for i in range(5, 9):
            joint_to_part[i, 2] = 1.0   # middle
        for i in range(9, 13):
            joint_to_part[i, 3] = 1.0   # ring
        for i in range(13, 17):
            joint_to_part[i, 4] = 1.0   # pinky
        for i in range(17, 21):
            joint_to_part[i, 5] = 1.0   # thumb

        # Distribute remaining parts
        for i in range(6, n_parts):
            joint_to_part[i % n_joints, i] = 1.0

        # Compute part weights
        part_map = torch.einsum('bnj,jp->bnp', nearest_weights, joint_to_part)
        part_map = F.softmax(part_map, dim=-1)

        return part_map

    def compute_direction_map(self, obj_points, hand_verts, hand_normals):
        """
        Compute direction map on object points.

        Args:
            obj_points: [B, N, 3] object surface points
            hand_verts: [B, V, 3] hand vertices
            hand_normals: [B, V, 3] hand vertex normals

        Returns:
            direction_map: [B, N, n_directions] direction probabilities
        """
        # Find nearest hand vertex
        dists = torch.cdist(obj_points, hand_verts)  # [B, N, V]
        nearest_idx = dists.argmin(dim=-1)  # [B, N]

        # Get normals of nearest vertices
        B, N = nearest_idx.shape
        nearest_normals = torch.gather(
            hand_normals, 1,
            nearest_idx.unsqueeze(-1).expand(-1, -1, 3)
        )  # [B, N, 3]

        # Project normals to XY plane and compute direction
        normals_xy = nearest_normals[:, :, :2]  # [B, N, 2]
        normals_xy = F.normalize(normals_xy, dim=-1)

        # Compute dot product with direction bins
        direction_bins = self.direction_bins.to(obj_points.device)  # [D, 2]
        direction_logits = torch.einsum('bni,di->bnd', normals_xy, direction_bins)
        direction_map = F.softmax(direction_logits * 5, dim=-1)  # Sharpen

        return direction_map

    def encode(self, obj_points, hand_verts, hand_faces, hand_joints, skinning_weights, hand_normals):
        """Encode full contact representation."""
        contact_map = self.compute_contact_map(obj_points, hand_verts, hand_faces)
        part_map = self.compute_part_map(obj_points, hand_verts, hand_joints, skinning_weights)
        direction_map = self.compute_direction_map(obj_points, hand_verts, hand_normals)

        return {
            'contact': contact_map,
            'part': part_map,
            'direction': direction_map
        }

    def decode(self, obj_points, contact_map, part_map, direction_map, mano_model=None):
        """
        Decode contact representation into hand grasp.
        This is a simplified version - full optimization in solver.
        """
        # Find contact points
        contact_mask = contact_map > 0.5

        # Get dominant part and direction for each contact point
        dominant_parts = part_map.argmax(dim=-1)  # [B, N]
        dominant_dirs = direction_map.argmax(dim=-1)  # [B, N]

        return {
            'contact_mask': contact_mask,
            'dominant_parts': dominant_parts,
            'dominant_directions': dominant_dirs,
            'contact_points': obj_points[contact_mask] if contact_mask.any() else obj_points[:, :10]
        }
