"""Evaluation script for ContactGen."""
import torch
import torch.nn as nn
import argparse
import os
from tqdm import tqdm
import numpy as np

from models.contactgen_cvae import ContactGenCVAE
from utils.data_loader import GRABDataset, ObjectPreprocessor
from utils.mano_utils import MANOHand
from utils.contact_utils import ContactRepresentation
from models.grasp_solver import GraspSolver


def evaluate_model(model, dataloader, device, save_root):
    """Evaluate model and save predictions."""
    model.eval()
    os.makedirs(save_root, exist_ok=True)

    contact_reps = ContactRepresentation()
    mano = MANOHand()
    solver = GraspSolver(mano)

    all_metrics = {
        'contact_iou': [],
        'part_accuracy': [],
        'direction_accuracy': []
    }

    with torch.no_grad():
        for idx, batch in enumerate(tqdm(dataloader, desc="Evaluating")):
            obj_points = batch['obj_points'].to(device)
            gt_contact = batch['contact_map'].to(device)
            gt_part = batch['part_map'].to(device)
            gt_direction = batch['direction_map'].to(device)

            # Sample predictions
            predictions = model.sample(obj_points, n_samples=1)

            for sample_idx, (pred_contact, pred_part, pred_direction) in enumerate(predictions):
                # Metrics
                contact_iou = compute_contact_iou(pred_contact, gt_contact)
                part_acc = compute_part_accuracy(pred_part, gt_part)
                direction_acc = compute_direction_accuracy(pred_direction, gt_direction)

                all_metrics['contact_iou'].append(contact_iou)
                all_metrics['part_accuracy'].append(part_acc)
                all_metrics['direction_accuracy'].append(direction_acc)

                # Save prediction
                save_path = os.path.join(save_root, f'sample_{idx}_{sample_idx}.pt')
                torch.save({
                    'obj_points': obj_points.cpu(),
                    'contact_map': pred_contact.cpu(),
                    'part_map': pred_part.cpu(),
                    'direction_map': pred_direction.cpu()
                }, save_path)

    # Print metrics
    print("\nEvaluation Results:")
    print(f"  Contact IoU: {np.mean(all_metrics['contact_iou']):.4f} ± {np.std(all_metrics['contact_iou']):.4f}")
    print(f"  Part Accuracy: {np.mean(all_metrics['part_accuracy']):.4f} ± {np.std(all_metrics['part_accuracy']):.4f}")
    print(f"  Direction Accuracy: {np.mean(all_metrics['direction_accuracy']):.4f} ± {np.std(all_metrics['direction_accuracy']):.4f}")

    return all_metrics


def compute_contact_iou(pred, gt, threshold=0.5):
    """Compute IoU for contact maps."""
    pred_mask = pred > threshold
    gt_mask = gt > threshold
    intersection = (pred_mask & gt_mask).float().sum()
    union = (pred_mask | gt_mask).float().sum()
    return (intersection / (union + 1e-8)).item()


def compute_part_accuracy(pred, gt):
    """Compute part classification accuracy."""
    pred_labels = pred.argmax(dim=-1)
    gt_labels = gt.argmax(dim=-1)
    correct = (pred_labels == gt_labels).float().mean()
    return correct.item()


def compute_direction_accuracy(pred, gt):
    """Compute direction classification accuracy."""
    pred_labels = pred.argmax(dim=-1)
    gt_labels = gt.argmax(dim=-1)
    correct = (pred_labels == gt_labels).float().mean()
    return correct.item()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=str, required=True)
    parser.add_argument('--data_root', type=str, default='data')
    parser.add_argument('--save_root', type=str, default='exp/results')
    parser.add_argument('--batch_size', type=int, default=8)
    parser.add_argument('--device', type=str, default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()

    device = torch.device(args.device)

    # Load model
    checkpoint = torch.load(args.checkpoint, map_location=device)
    model_args = checkpoint.get('args', {})

    model = ContactGenCVAE(
        latent_dim=model_args.get('latent_dim', 64),
        n_parts=model_args.get('n_parts', 16),
        n_directions=model_args.get('n_directions', 8)
    ).to(device)

    model.load_state_dict(checkpoint['model_state_dict'])

    # Data
    val_dataset = GRABDataset(args.data_root, split='val')
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False)

    # Evaluate
    evaluate_model(model, val_loader, device, args.save_root)


if __name__ == '__main__':
    main()
