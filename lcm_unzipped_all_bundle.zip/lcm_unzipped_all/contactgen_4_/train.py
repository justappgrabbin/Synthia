"""Training script for ContactGen."""
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import argparse
import os
from tqdm import tqdm

from models.contactgen_cvae import ContactGenCVAE
from utils.data_loader import GRABDataset
from utils.mano_utils import MANOHand


def train_epoch(model, dataloader, optimizer, device, epoch):
    """Train for one epoch."""
    model.train()
    total_loss = 0
    contact_loss_total = 0
    part_loss_total = 0
    direction_loss_total = 0
    kl_loss_total = 0

    pbar = tqdm(dataloader, desc=f"Epoch {epoch}")
    for batch in pbar:
        obj_points = batch['obj_points'].to(device)
        contact_map = batch['contact_map'].to(device)
        part_map = batch['part_map'].to(device)
        direction_map = batch['direction_map'].to(device)

        optimizer.zero_grad()

        # Forward pass
        recon_contact, recon_part, recon_direction, mu, logvar = model(
            obj_points, contact_map, part_map, direction_map
        )

        # Compute loss
        loss_dict = model.compute_loss(
            recon_contact, recon_part, recon_direction,
            contact_map, part_map, direction_map,
            mu, logvar, kl_weight=0.1
        )

        loss = loss_dict['total']
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        contact_loss_total += loss_dict['contact'].item()
        part_loss_total += loss_dict['part'].item()
        direction_loss_total += loss_dict['direction'].item()
        kl_loss_total += loss_dict['kl'].item()

        pbar.set_postfix({
            'loss': f"{loss.item():.4f}",
            'contact': f"{loss_dict['contact'].item():.4f}",
            'kl': f"{loss_dict['kl'].item():.4f}"
        })

    n = len(dataloader)
    return {
        'total': total_loss / n,
        'contact': contact_loss_total / n,
        'part': part_loss_total / n,
        'direction': direction_loss_total / n,
        'kl': kl_loss_total / n
    }


def validate(model, dataloader, device):
    """Validate model."""
    model.eval()
    total_loss = 0

    with torch.no_grad():
        for batch in tqdm(dataloader, desc="Validating"):
            obj_points = batch['obj_points'].to(device)
            contact_map = batch['contact_map'].to(device)
            part_map = batch['part_map'].to(device)
            direction_map = batch['direction_map'].to(device)

            recon_contact, recon_part, recon_direction, mu, logvar = model(
                obj_points, contact_map, part_map, direction_map
            )

            loss_dict = model.compute_loss(
                recon_contact, recon_part, recon_direction,
                contact_map, part_map, direction_map,
                mu, logvar, kl_weight=0.1
            )

            total_loss += loss_dict['total'].item()

    return total_loss / len(dataloader)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_root', type=str, default='data')
    parser.add_argument('--work_dir', type=str, default='exp')
    parser.add_argument('--batch_size', type=int, default=8)
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--latent_dim', type=int, default=64)
    parser.add_argument('--n_parts', type=int, default=16)
    parser.add_argument('--n_directions', type=int, default=8)
    parser.add_argument('--device', type=str, default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()

    os.makedirs(args.work_dir, exist_ok=True)
    device = torch.device(args.device)

    # Model
    model = ContactGenCVAE(
        latent_dim=args.latent_dim,
        n_parts=args.n_parts,
        n_directions=args.n_directions
    ).to(device)

    # Data
    train_dataset = GRABDataset(args.data_root, split='train')
    val_dataset = GRABDataset(args.data_root, split='val')

    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=4)
    val_loader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False, num_workers=4)

    # Optimizer
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=30, gamma=0.5)

    # Training loop
    best_val_loss = float('inf')

    for epoch in range(1, args.epochs + 1):
        train_loss = train_epoch(model, train_loader, optimizer, device, epoch)
        val_loss = validate(model, val_loader, device)

        print(f"\nEpoch {epoch}/{args.epochs}")
        print(f"  Train Loss: {train_loss['total']:.4f} (Contact: {train_loss['contact']:.4f}, "
              f"Part: {train_loss['part']:.4f}, Dir: {train_loss['direction']:.4f}, KL: {train_loss['kl']:.4f})")
        print(f"  Val Loss: {val_loss:.4f}")

        scheduler.step()

        # Save checkpoint
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            checkpoint = {
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_loss': val_loss,
                'args': vars(args)
            }
            torch.save(checkpoint, os.path.join(args.work_dir, 'checkpoint.pt'))
            print(f"  Saved best checkpoint (val_loss: {val_loss:.4f})")


if __name__ == '__main__':
    main()
