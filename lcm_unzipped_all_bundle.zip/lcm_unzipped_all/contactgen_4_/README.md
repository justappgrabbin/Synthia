# ContactGen: Generative Contact Modeling for Grasp Generation

A complete, from-scratch implementation of the ContactGen architecture from the ICCV 2023 paper by Liu et al. This system generates realistic human hand grasps for 3D objects using an object-centric contact representation and a conditional sequential CVAE.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    ContactGen Pipeline                       │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Input: 3D Object Mesh                                      │
│       ↓                                                      │
│  Point Cloud Sampling (2048 points)                          │
│       ↓                                                      │
│  ┌─────────────────────────────────────┐                   │
│  │  Contact Representation Encoder        │                   │
│  │  - Contact Map (probability)           │                   │
│  │  - Part Map (16 hand parts)            │                   │
│  │  - Direction Map (8 directions)        │                   │
│  └─────────────────────────────────────┘                   │
│       ↓                                                      │
│  Conditional Sequential CVAE                                 │
│  ┌─────────┐    ┌─────────┐    ┌─────────┐                │
│  │ Encoder │ →  │ Latent  │ →  │ Decoder │                │
│  │PointNet+│    │  z ~64  │    │PointNet+│                │
│  └─────────┘    └─────────┘    └─────────┘                │
│       ↓                                                      │
│  Predicted Contact Maps                                      │
│       ↓                                                      │
│  Model-Based Optimization Solver                             │
│  ┌─────────────────────────────────────┐                   │
│  │  - Contact Proximity Loss            │                   │
│  │  - Part Alignment Loss               │                   │
│  │  - Direction Alignment Loss          │                   │
│  │  - Penetration Loss                  │                   │
│  │  - Pose Regularization               │                   │
│  └─────────────────────────────────────┘                   │
│       ↓                                                      │
│  Output: MANO Hand Grasp (778 vertices, 21 joints)          │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## Key Components

### 1. Object-Centric Contact Representation
- **Contact Map**: Probability of contact at each object point (0-1)
- **Part Map**: Which of 16 hand parts contacts each point (one-hot over parts)
- **Direction Map**: Contact direction within each hand part (8 angular bins)

### 2. PointNet++ Backbone
- Multi-scale set abstraction layers
- Feature propagation for dense predictions
- Pure Python fallback when CUDA extensions unavailable

### 3. Conditional Sequential CVAE
- Encoder: Object points + contact maps → latent distribution
- Decoder: Object points + sampled latent → predicted contact maps
- Reparameterization trick for differentiable sampling

### 4. Piecewise SDF Hand Model
- 16 independent MLP decoders (one per hand part)
- 4 FC layers with 32 neurons and LeakyReLU (slope 0.1)
- Converts hand vertices to signed distance fields

### 5. Model-Based Optimization Solver
- Iterative pose optimization (default: 100 iterations)
- Multi-objective loss function balancing contact, part, direction, penetration, and pose regularization
- Adam optimizer with learning rate 0.01

## Installation

```bash
# Clone repository
git clone https://github.com/stevenlsw/contactgen.git
cd contactgen

# Create environment
conda create -n contactgen python=3.9
conda activate contactgen

# Install PyTorch
pip3 install torch

# Install PyTorch3D (optional, for advanced rendering)
pip install "git+https://github.com/facebookresearch/pytorch3d.git"

# Install dependencies
pip install -r requirements.txt

# Build PointNet++ CUDA extensions (optional, falls back to pure Python)
cd pointnet_lib && python setup.py install
cd ..
```

## Quick Start

### Demo: Generate Grasp for Toothpaste

```bash
python demo.py --obj_path assets/toothpaste.ply --n_samples=10 --save_root exp/demo_results
```

This will:
1. Load the toothpaste mesh
2. Sample 2048 points on its surface
3. Generate 10 diverse grasp contact maps using the CVAE
4. Save contact map visualizations and predicted hand grasps

### Visualize Results

```bash
python vis_grasp.py --hand_path exp/demo_results/grasp_0.obj --obj_path assets/toothpaste.ply
```

## Training

### Prepare GRAB Dataset

Download the [GRAB dataset](https://grab.is.tue.mpg.de/) and extract to the `data/` directory:

```
data/
  train_index.json
  val_index.json
  test_index.json
  meshes/
    object_001.ply
    object_002.ply
    ...
  poses/
    grasp_001.npy
    grasp_002.npy
    ...
```

### Train Model

```bash
python train.py --data_root data --work_dir exp --batch_size 8 --epochs 100 --lr 1e-4
```

Training configuration:
- 1,000 on-surface points + 7,000 near-surface points (σ=0.01) + 1,400 off-surface points per object
- 100 epochs at learning rate 1e-4 with Adam
- Learning rate halved every 30 epochs
- Best checkpoint saved based on validation loss

### Evaluate

```bash
python eval.py --checkpoint exp/checkpoint.pt --save_root exp/results
```

Metrics computed:
- Contact IoU (threshold=0.5)
- Part classification accuracy
- Direction classification accuracy

## Project Structure

```
contactgen/
├── assets/                    # Demo 3D objects
│   ├── toothpaste.ply
│   └── sphere.ply
├── models/
│   ├── contactgen_cvae.py     # Main CVAE model
│   └── grasp_solver.py        # Optimization solver
├── utils/
│   ├── mano_utils.py          # MANO hand model + piecewise SDF
│   ├── contact_utils.py       # Contact representation
│   ├── data_loader.py         # GRAB dataset + preprocessing
│   └── vis_utils.py           # Visualization utilities
├── pointnet_lib/              # PointNet++ implementation
│   ├── pointnet2_utils.py     # Core operations (FPS, ball query, etc.)
│   ├── pointnet2_modules.py   # Set abstraction + feature propagation
│   ├── __init__.py
│   └── setup.py               # CUDA extension build
├── data/                      # Dataset directory
├── exp/                       # Experiment outputs
├── train.py                   # Training script
├── eval.py                    # Evaluation script
├── demo.py                    # Demo inference script
├── vis_grasp.py               # Grasp visualization
└── requirements.txt
```

## Technical Details

### Hand Model
- **MANO**: 778 vertices, 21 joints, 16 hand parts
- **Skinning weights**: Soft assignment based on distance to joints
- **Part decoders**: Independent MLPs per part for SDF computation

### Training Data
- **On-surface points**: 1,000 points sampled from object mesh
- **Near-surface points**: 7,000 points with Gaussian noise (σ=0.01)
- **Off-surface points**: 1,400 random points for SDF training
- **Normalization**: Objects scaled to unit sphere

### Loss Function
```
L = L_contact + L_part + L_direction + λ_kl * L_kl

L_contact = BCE(predicted_contact, ground_truth_contact)
L_part = CE(predicted_part, ground_truth_part)
L_direction = CE(predicted_direction, ground_truth_direction)
L_kl = -0.5 * Σ(1 + log(σ²) - μ² - σ²)
```

### Optimization Solver Loss
```
L = 100 * L_contact_proximity + 10 * L_part_alignment + 5 * L_direction_alignment
    + 50 * L_penetration + 0.1 * L_pose_regularization
```

## Citation

```bibtex
@inproceedings{liu2023contactgen,
  title={ContactGen: Generative Contact Modeling for Grasp Generation},
  author={Liu, Shaowei and Zhou, Yang and Yang, Jimei and Gupta, Saurabh and Wang, Shenlong},
  booktitle={Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV)},
  year={2023}
}
```

## License

This implementation is provided for research and educational purposes.
