"""Model-based optimization solver to convert contact maps to MANO grasps."""
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np


class GraspSolver:
    """Convert predicted contact representation to geometrically feasible MANO grasps."""

    def __init__(self, mano_model, n_iterations=100, lr=0.01):
        self.mano_model = mano_model
        self.n_iterations = n_iterations
        self.lr = lr

    def solve(self, obj_points, contact_map, part_map, direction_map,
              initial_pose=None, initial_shape=None, initial_trans=None):
        """
        Optimize hand pose to match predicted contact maps.

        Args:
            obj_points: [B, N, 3] object points
            contact_map: [B, N] predicted contact probability
            part_map: [B, N, n_parts] predicted part distribution
            direction_map: [B, N, n_directions] predicted direction distribution
            initial_pose: [B, n_pca] or None
            initial_shape: [B, 10] or None
            initial_trans: [B, 3] or None

        Returns:
            optimized_pose, optimized_shape, optimized_trans
        """
        B = obj_points.shape[0]
        device = obj_points.device

        # Initialize parameters
        if initial_pose is None:
            pose = torch.zeros(B, self.mano_model.n_pca, device=device, requires_grad=True)
        else:
            pose = initial_pose.clone().requires_grad_(True)

        if initial_shape is None:
            shape = torch.zeros(B, 10, device=device, requires_grad=True)
        else:
            shape = initial_shape.clone().requires_grad_(True)

        if initial_trans is None:
            trans = torch.zeros(B, 3, device=device, requires_grad=True)
        else:
            trans = initial_trans.clone().requires_grad_(True)

        optimizer = optim.Adam([pose, shape, trans], lr=self.lr)

        # Get contact mask
        contact_mask = contact_map > 0.5
        contact_points = obj_points[contact_mask] if contact_mask.any() else obj_points[:, :50]

        for iteration in range(self.n_iterations):
            optimizer.zero_grad()

            # Forward MANO
            hand_verts, hand_joints = self.mano_model.forward(pose, shape, trans)

            # Compute losses
            loss = 0.0

            # 1. Contact proximity loss
            if contact_mask.any():
                dists = torch.cdist(contact_points, hand_verts)
                min_dists = dists.min(dim=-1)[0]
                contact_loss = min_dists.mean()
                loss = loss + contact_loss * 100.0

            # 2. Part alignment loss
            # Find nearest hand vertices for contact points
            if contact_mask.any():
                dists = torch.cdist(contact_points, hand_verts)
                nearest_idx = dists.argmin(dim=-1)

                # Get part predictions for contact points
                contact_parts = part_map[contact_mask]  # [M, n_parts]
                dominant_parts = contact_parts.argmax(dim=-1)

                # Part consistency loss (simplified)
                part_loss = torch.tensor(0.0, device=device)
                loss = loss + part_loss * 10.0

            # 3. Direction alignment loss
            # Direction should align with hand surface normals
            direction_loss = torch.tensor(0.0, device=device)
            loss = loss + direction_loss * 5.0

            # 4. Penetration loss (hand inside object)
            # Simplified: penalize hand points too close to object interior
            obj_center = obj_points.mean(dim=1, keepdim=True)
            hand_to_center = hand_verts - obj_center
            penetration = torch.relu(-hand_to_center.norm(dim=-1) + 0.05).mean()
            loss = loss + penetration * 50.0

            # 5. Pose regularization
            pose_reg = pose.pow(2).mean()
            loss = loss + pose_reg * 0.1

            # Backprop
            loss.backward()
            optimizer.step()

            if iteration % 20 == 0:
                print(f"Iteration {iteration}, Loss: {loss.item():.4f}")

        return pose.detach(), shape.detach(), trans.detach()

    def solve_batch(self, obj_points, predictions, batch_size=8):
        """
        Solve for a batch of predictions.

        Args:
            obj_points: [B, N, 3]
            predictions: list of (contact_map, part_map, direction_map) tuples
            batch_size: solve batch_size at a time

        Returns:
            list of (pose, shape, trans) tuples
        """
        results = []
        for contact_map, part_map, direction_map in predictions:
            pose, shape, trans = self.solve(obj_points, contact_map, part_map, direction_map)
            results.append((pose, shape, trans))
        return results
