"""Visualize generated grasps."""
import torch
import argparse
import os
import numpy as np

try:
    import pyrender
    import matplotlib.pyplot as plt
    HAS_PYRENDER = True
except ImportError:
    HAS_PYRENDER = False

try:
    import trimesh
    HAS_TRIMESH = True
except ImportError:
    HAS_TRIMESH = False


def visualize_grasp(hand_path, obj_path):
    """Visualize a hand grasp with object using pyrender."""
    if not HAS_PYRENDER:
        print("pyrender not available. Install with: pip install pyrender")
        print("Alternatively, use meshlab or blender to view the .obj files directly.")
        return

    if not HAS_TRIMESH:
        print("trimesh required for pyrender visualization")
        return

    # Load hand and object
    hand_mesh = trimesh.load(hand_path)
    obj_mesh = trimesh.load(obj_path)

    # Create scene
    scene = pyrender.Scene()

    # Add object
    obj_pyrender = pyrender.Mesh.from_trimesh(obj_mesh)
    scene.add(obj_pyrender)

    # Add hand
    hand_pyrender = pyrender.Mesh.from_trimesh(hand_mesh)
    scene.add(hand_pyrender)

    # Camera
    camera = pyrender.PerspectiveCamera(yfov=np.pi / 3.0)
    camera_pose = np.array([
        [1.0, 0.0, 0.0, 0.0],
        [0.0, 1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0, 0.5],
        [0.0, 0.0, 0.0, 1.0]
    ])
    scene.add(camera, pose=camera_pose)

    # Light
    light = pyrender.DirectionalLight(color=np.ones(3), intensity=2.0)
    scene.add(light, pose=camera_pose)

    # Render
    r = pyrender.OffscreenRenderer(800, 600)
    color, depth = r.render(scene)

    # Save
    plt.figure(figsize=(10, 8))
    plt.imshow(color)
    plt.axis("off")
    plt.title("Grasp Visualization")
    plt.tight_layout()
    plt.savefig("grasp_vis.png", dpi=150)
    plt.show()

    print("Saved visualization to grasp_vis.png")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--hand_path", type=str, required=True)
    parser.add_argument("--obj_path", type=str, required=True)
    args = parser.parse_args()

    visualize_grasp(args.hand_path, args.obj_path)


if __name__ == "__main__":
    main()
