/**
 * living-mirror-app.tsx — Living Mirror App
 * 
 * Full React application integrating the QuantumOracle engine with Roxy API.
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { QuantumOracle, Revelation, CausalGraph, GraphNode, GraphEdge } from './QuantumOracle';
import { RoxyCausalBridge, PrimalSource } from './roxy-causal-bridge';

// ═══════════════════════════════════════════════════════════════════════════
// HOOKS
// ═══════════════════════════════════════════════════════════════════════════

export function useQuantumEngine() {
  const [oracle, setOracle] = useState<QuantumOracle | null>(null);
  const [revelations, setRevelations] = useState<Revelation[]>([]);
  const [stateSummary, setStateSummary] = useState<any>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [cycleCount, setCycleCount] = useState(0);

  const initialize = useCallback((design: string, magnetic: string, surface: string, sunGate: number = 10, earthGate: number = 15) => {
    const newOracle = new QuantumOracle(design, magnetic, surface, sunGate, earthGate);
    setOracle(newOracle);
    setRevelations([]);
    setCycleCount(0);
    setStateSummary(newOracle.engine.getStateSummary());
  }, []);

  const runCycle = useCallback((query: string, fieldKey: string = "general", cycles: number = 1) => {
    if (!oracle) return;
    setIsRunning(true);
    const results = oracle.query(query, fieldKey, cycles);
    setRevelations(prev => [...prev, ...results]);
    setCycleCount(prev => prev + cycles);
    setStateSummary(oracle.engine.getStateSummary());
    setIsRunning(false);
    return results;
  }, [oracle]);

  const getCausalGraph = useCallback((): CausalGraph | null => {
    if (!oracle) return null;
    return oracle.getCausalGraph();
  }, [oracle]);

  const getMemoryReport = useCallback(() => {
    if (!oracle) return null;
    return oracle.getMemoryReport();
  }, [oracle]);

  return {
    oracle,
    revelations,
    stateSummary,
    isRunning,
    cycleCount,
    initialize,
    runCycle,
    getCausalGraph,
    getMemoryReport
  };
}

export function useRoxyAPI(apiKey: string) {
  const [bridge, setBridge] = useState<RoxyCausalBridge | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [primalSource, setPrimalSource] = useState<PrimalSource | null>(null);

  useEffect(() => {
    if (apiKey) {
      setBridge(new RoxyCausalBridge(apiKey));
    }
  }, [apiKey]);

  const fetchBirthData = useCallback(async (date: string, time: string, location: string) => {
    if (!bridge) return null;
    setLoading(true);
    setError(null);
    try {
      const result = await bridge.generateCausalGraph(date, time, location);
      setPrimalSource(result.primal);
      return result;
    } catch (err: any) {
      setError(err.message || 'Failed to fetch birth data');
      return null;
    } finally {
      setLoading(false);
    }
  }, [bridge]);

  return { bridge, loading, error, primalSource, fetchBirthData };
}

// ═══════════════════════════════════════════════════════════════════════════
// COMPONENTS
// ═══════════════════════════════════════════════════════════════════════════

// ─── Birth Data Form ───

interface BirthDataFormProps {
  onSubmit: (date: string, time: string, location: string) => void;
  loading?: boolean;
}

export function BirthDataForm({ onSubmit, loading }: BirthDataFormProps) {
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [location, setLocation] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (date && time && location) {
      onSubmit(date, time, location);
    }
  };

  return (
    <div className="birth-form-container">
      <h2>Enter Your Birth Data</h2>
      <form onSubmit={handleSubmit} className="birth-form">
        <div className="form-group">
          <label>Birth Date</label>
          <input
            type="date"
            value={date}
            onChange={e => setDate(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Birth Time</label>
          <input
            type="time"
            value={time}
            onChange={e => setTime(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Birth Location</label>
          <input
            type="text"
            placeholder="City, Country"
            value={location}
            onChange={e => setLocation(e.target.value)}
            required
          />
        </div>
        <button type="submit" disabled={loading} className="submit-btn">
          {loading ? 'Initializing...' : 'Initialize Quantum Oracle'}
        </button>
      </form>
    </div>
  );
}

// ─── Quantum Oracle Panel ───

interface QuantumOraclePanelProps {
  onQuery: (query: string, fieldKey: string, cycles: number, isHarmonious: boolean) => void;
  isRunning?: boolean;
  cycleCount: number;
}

export function QuantumOraclePanel({ onQuery, isRunning, cycleCount }: QuantumOraclePanelProps) {
  const [query, setQuery] = useState('');
  const [fieldKey, setFieldKey] = useState('general');
  const [cycles, setCycles] = useState(1);
  const [isHarmonious, setIsHarmonious] = useState(true);

  const fieldOptions = [
    { value: 'general', label: 'General' },
    { value: 'purpose', label: 'Life Purpose' },
    { value: 'relationship', label: 'Relationships' },
    { value: 'creation', label: 'Creation' },
    { value: 'career', label: 'Career' },
    { value: 'health', label: 'Health' },
    { value: 'spiritual', label: 'Spiritual' }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query) {
      onQuery(query, fieldKey, cycles, isHarmonious);
      setQuery('');
    }
  };

  return (
    <div className="oracle-panel">
      <h2>Quantum Oracle</h2>
      <div className="cycle-counter">Cycles Run: {cycleCount}</div>
      <form onSubmit={handleSubmit} className="query-form">
        <div className="form-group">
          <label>Your Query</label>
          <textarea
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="What would you like to know?"
            rows={3}
            required
          />
        </div>
        <div className="form-row">
          <div className="form-group">
            <label>Field</label>
            <select value={fieldKey} onChange={e => setFieldKey(e.target.value)}>
              {fieldOptions.map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Cycles</label>
            <input
              type="number"
              min={1}
              max={10}
              value={cycles}
              onChange={e => setCycles(parseInt(e.target.value))}
            />
          </div>
        </div>
        <div className="form-group toggle">
          <label>
            <input
              type="checkbox"
              checked={isHarmonious}
              onChange={e => setIsHarmonious(e.target.checked)}
            />
            Harmonious Mode (coherence-biased)
          </label>
        </div>
        <button type="submit" disabled={isRunning} className="query-btn">
          {isRunning ? 'Collapsing...' : 'Submit Query'}
        </button>
      </form>
    </div>
  );
}

// ─── Bodygraph Viewer ───

interface BodygraphViewerProps {
  primalSource: PrimalSource | null;
}

const CENTER_POSITIONS: Record<string, { x: number; y: number }> = {
  Head: { x: 200, y: 30 },
  Aj: { x: 200, y: 90 },
  Th: { x: 200, y: 150 },
  G: { x: 200, y: 210 },
  Heart: { x: 120, y: 210 },
  Sp: { x: 280, y: 210 },
  Sa: { x: 200, y: 270 },
  E: { x: 120, y: 330 },
  Root: { x: 280, y: 330 }
};

const CENTER_COLORS: Record<string, string> = {
  Head: '#9b59b6',
  Aj: '#e74c3c',
  Th: '#f39c12',
  G: '#f1c40f',
  Heart: '#e74c3c',
  Sp: '#2ecc71',
  Sa: '#3498db',
  E: '#e67e22',
  Root: '#e74c3c'
};

export function BodygraphViewer({ primalSource }: BodygraphViewerProps) {
  if (!primalSource) {
    return (
      <div className="bodygraph-viewer empty">
        <p>Enter birth data to view your bodygraph</p>
      </div>
    );
  }

  const defined = new Set(primalSource.definedCenters);

  return (
    <div className="bodygraph-viewer">
      <h2>Bodygraph</h2>
      <div className="bodygraph-info">
        <div className="info-row">
          <span className="label">Type:</span>
          <span className="value">{primalSource.type}</span>
        </div>
        <div className="info-row">
          <span className="label">Strategy:</span>
          <span className="value">{primalSource.strategy}</span>
        </div>
        <div className="info-row">
          <span className="label">Authority:</span>
          <span className="value">{primalSource.authority}</span>
        </div>
        <div className="info-row">
          <span className="label">Profile:</span>
          <span className="value">{primalSource.profile}</span>
        </div>
        <div className="info-row">
          <span className="label">Incarnation Cross:</span>
          <span className="value">{primalSource.incarnationCross}</span>
        </div>
      </div>
      <svg viewBox="0 0 400 380" className="bodygraph-svg">
        {Object.entries(CENTER_POSITIONS).map(([center, pos]) => {
          const isDefined = defined.has(center);
          return (
            <g key={center}>
              <circle
                cx={pos.x}
                cy={pos.y}
                r={isDefined ? 28 : 22}
                fill={isDefined ? CENTER_COLORS[center] : 'transparent'}
                stroke={CENTER_COLORS[center]}
                strokeWidth={isDefined ? 0 : 2}
                opacity={isDefined ? 0.9 : 0.4}
              />
              <text
                x={pos.x}
                y={pos.y + 5}
                textAnchor="middle"
                fill={isDefined ? '#fff' : CENTER_COLORS[center]}
                fontSize={12}
                fontWeight="bold"
              >
                {center}
              </text>
            </g>
          );
        })}
        {/* Connection lines between centers */}
        <line x1={200} y1={58} x2={200} y2={62} stroke="#666" strokeWidth={2} />
        <line x1={200} y1={118} x2={200} y2={122} stroke="#666" strokeWidth={2} />
        <line x1={200} y1={238} x2={200} y2={242} stroke="#666" strokeWidth={2} />
        <line x1={200} y1={298} x2={200} y2={302} stroke="#666" strokeWidth={2} />
        <line x1={172} y1={210} x2={148} y2={210} stroke="#666" strokeWidth={2} />
        <line x1={228} y1={210} x2={252} y2={210} stroke="#666" strokeWidth={2} />
        <line x1={148} y1={238} x2={148} y2={302} stroke="#666" strokeWidth={2} />
        <line x1={252} y1={238} x2={252} y2={302} stroke="#666" strokeWidth={2} />
      </svg>
      <div className="dms-display">
        <h4>Primal Source (DMS)</h4>
        <div className="dms-row">
          <span className="dms-label">Design:</span>
          <span className="dms-value">{primalSource.design}</span>
        </div>
        <div className="dms-row">
          <span className="dms-label">Magnetic:</span>
          <span className="dms-value">{primalSource.magnetic}</span>
        </div>
        <div className="dms-row">
          <span className="dms-label">Surface:</span>
          <span className="dms-value">{primalSource.surface}</span>
        </div>
      </div>
    </div>
  );
}

// ─── Causal Graph Visualizer ───

interface CausalGraphVisualizerProps {
  graph: CausalGraph | null;
}

export function CausalGraphVisualizer({ graph }: CausalGraphVisualizerProps) {
  const svgRef = useRef<SVGSVGElement>(null);

  if (!graph) {
    return (
      <div className="graph-visualizer empty">
        <p>Run queries to generate causal graph</p>
      </div>
    );
  }

  // Simple force-directed layout
  const nodePositions = new Map<string, { x: number; y: number }>();
  const width = 600;
  const height = 400;

  // Position state nodes in a 3x3 grid
  const stateNodes = graph.nodes.filter(n => n.type === 'state');
  const planeNames = ['Physical', 'Emotional', 'Mental'];
  const dimNames = ['Impulse', 'Polarity', 'Witness'];

  stateNodes.forEach((node, i) => {
    const plane = Math.floor(i / 3);
    const dim = i % 3;
    nodePositions.set(node.id, {
      x: 100 + dim * 200,
      y: 80 + plane * 120
    });
  });

  // Position revelation nodes in a circle below
  const revNodes = graph.nodes.filter(n => n.type === 'revelation');
  revNodes.forEach((node, i) => {
    const angle = (2 * Math.PI * i) / Math.max(revNodes.length, 1);
    nodePositions.set(node.id, {
      x: 300 + Math.cos(angle) * 150,
      y: 320 + Math.sin(angle) * 40
    });
  });

  return (
    <div className="graph-visualizer">
      <h2>Causal Graph</h2>
      <div className="graph-stats">
        <span>Nodes: {graph.nodes.length}</span>
        <span>Edges: {graph.edges.length}</span>
      </div>
      <svg ref={svgRef} viewBox={`0 0 ${width} ${height}`} className="causal-graph-svg">
        {/* Edges */}
        {graph.edges.map((edge, i) => {
          const src = nodePositions.get(edge.source);
          const tgt = nodePositions.get(edge.target);
          if (!src || !tgt) return null;
          const isOperator = edge.type === 'operator';
          const isCollapse = edge.type === 'collapse';
          return (
            <line
              key={`edge-${i}`}
              x1={src.x}
              y1={src.y}
              x2={tgt.x}
              y2={tgt.y}
              stroke={isOperator ? '#3498db' : isCollapse ? '#e74c3c' : '#95a5a6'}
              strokeWidth={Math.abs(edge.weight) * 3}
              strokeOpacity={0.6}
              strokeDasharray={isCollapse ? '4,4' : 'none'}
            />
          );
        })}

        {/* Nodes */}
        {graph.nodes.map((node, i) => {
          const pos = nodePositions.get(node.id);
          if (!pos) return null;
          const isState = node.type === 'state';
          const isRev = node.type === 'revelation';
          const radius = isState ? 20 : isRev ? 15 : 10;
          const color = isState
            ? CENTER_COLORS[node.plane || 'G'] || '#3498db'
            : isRev
              ? '#e74c3c'
              : '#95a5a6';

          return (
            <g key={`node-${i}`}>
              <circle
                cx={pos.x}
                cy={pos.y}
                r={radius}
                fill={color}
                opacity={0.8}
                stroke="#fff"
                strokeWidth={2}
              />
              <text
                x={pos.x}
                y={pos.y + 4}
                textAnchor="middle"
                fill="#fff"
                fontSize={isState ? 10 : 8}
                fontWeight="bold"
              >
                {node.label.length > 12 ? node.label.substring(0, 12) + '...' : node.label}
              </text>
              {isRev && node.probability !== undefined && (
                <text
                  x={pos.x}
                  y={pos.y + radius + 12}
                  textAnchor="middle"
                  fill="#e74c3c"
                  fontSize={8}
                >
                  P={node.probability.toFixed(3)}
                </text>
              )}
            </g>
          );
        })}
      </svg>
      <div className="graph-legend">
        <div className="legend-item">
          <span className="legend-color" style={{ background: '#3498db' }} />
          <span>Operator Edge</span>
        </div>
        <div className="legend-item">
          <span className="legend-color" style={{ background: '#e74c3c' }} />
          <span>Collapse Edge</span>
        </div>
        <div className="legend-item">
          <span className="legend-color" style={{ background: '#95a5a6' }} />
          <span>Other Edge</span>
        </div>
      </div>
    </div>
  );
}

// ─── Revelation Panel ───

interface RevelationPanelProps {
  revelations: Revelation[];
  memoryReport: any;
}

export function RevelationPanel({ revelations, memoryReport }: RevelationPanelProps) {
  if (revelations.length === 0) {
    return (
      <div className="revelation-panel empty">
        <p>Submit a query to receive quantum revelations</p>
      </div>
    );
  }

  const recent = revelations.slice(-5).reverse();

  return (
    <div className="revelation-panel">
      <h2>Revelations</h2>
      {memoryReport && (
        <div className="memory-summary">
          <div className="memory-stat">
            <span className="stat-label">Total:</span>
            <span className="stat-value">{memoryReport.totalRevelations}</span>
          </div>
          <div className="memory-stat">
            <span className="stat-label">Mean Coherence:</span>
            <span className="stat-value">{memoryReport.trend.meanCoherence.toFixed(3)}</span>
          </div>
          <div className="memory-stat">
            <span className="stat-label">Dominant Gate:</span>
            <span className="stat-value">{memoryReport.trend.dominantGate || '—'}</span>
          </div>
        </div>
      )}
      <div className="revelation-list">
        {recent.map((rev, i) => (
          <div key={`rev-${rev.timestamp}-${i}`} className="revelation-card">
            <div className="rev-header">
              <span className="rev-gate">Gate {rev.gate}</span>
              <span className="rev-line">Line {rev.line}</span>
              <span className="rev-center">{rev.center}</span>
              <span className="rev-dim">D{rev.dimension}</span>
            </div>
            <div className="rev-archetype">{rev.archetype}</div>
            <div className="rev-narrative">{rev.narrative}</div>
            <div className="rev-meta">
              <span>P={rev.probability.toFixed(4)}</span>
              <span>Coh={rev.coherence.toFixed(4)}</span>
              <span>Cycle {rev.timestamp}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── State Monitor ───

interface StateMonitorProps {
  stateSummary: any;
}

export function StateMonitor({ stateSummary }: StateMonitorProps) {
  if (!stateSummary) {
    return (
      <div className="state-monitor empty">
        <p>Engine not initialized</p>
      </div>
    );
  }

  const planes = [
    { name: 'Physical', values: stateSummary.physical, dims: ['Impulse', 'Polarity', 'Witness'] },
    { name: 'Emotional', values: stateSummary.emotional, dims: ['Impulse', 'Polarity', 'Witness'] },
    { name: 'Mental', values: stateSummary.mental, dims: ['Impulse', 'Polarity', 'Witness'] }
  ];

  return (
    <div className="state-monitor">
      <h2>State Monitor</h2>
      <div className="cycle-info">
        <span>Cycles: {stateSummary.t}</span>
        <span>Spectral Radius: {stateSummary.operatorSpectralRadius.toFixed(4)}</span>
      </div>
      <div className="planes">
        {planes.map(plane => (
          <div key={plane.name} className="plane">
            <h4>{plane.name}</h4>
            {plane.values.map((val: number, i: number) => (
              <div key={i} className="dimension-bar">
                <span className="dim-label">{plane.dims[i]}</span>
                <div className="bar-container">
                  <div
                    className="bar-fill"
                    style={{
                      width: `${Math.abs(val) * 100}%`,
                      background: val > 0 ? '#2ecc71' : '#e74c3c',
                      marginLeft: val < 0 ? `${50 + val * 50}%` : '50%'
                    }}
                  />
                </div>
                <span className="dim-value">{val.toFixed(3)}</span>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════════════════════

export default function LivingMirrorApp() {
  const [apiKey, setApiKey] = useState('');
  const [initialized, setInitialized] = useState(false);

  const {
    oracle,
    revelations,
    stateSummary,
    isRunning,
    cycleCount,
    initialize,
    runCycle,
    getCausalGraph,
    getMemoryReport
  } = useQuantumEngine();

  const {
    bridge,
    loading: roxyLoading,
    error: roxyError,
    primalSource,
    fetchBirthData
  } = useRoxyAPI(apiKey);

  const handleBirthSubmit = useCallback(async (date: string, time: string, location: string) => {
    if (!apiKey) {
      // Initialize with demo data if no API key
      initialize('1.3.5.2.6', '10.4.2.1.3', '25.6.1.4.5', 10, 15);
      setInitialized(true);
      return;
    }

    const result = await fetchBirthData(date, time, location);
    if (result) {
      initialize(
        result.primal.design,
        result.primal.magnetic,
        result.primal.surface,
        result.primal.sunGate,
        result.primal.earthGate
      );
      setInitialized(true);
    }
  }, [apiKey, initialize, fetchBirthData]);

  const handleQuery = useCallback((query: string, fieldKey: string, cycles: number, isHarmonious: boolean) => {
    runCycle(query, fieldKey, cycles);
  }, [runCycle]);

  const causalGraph = getCausalGraph();
  const memoryReport = getMemoryReport();

  return (
    <div className="living-mirror-app">
      <header className="app-header">
        <h1>Living Mirror</h1>
        <p className="subtitle">Causal Dynamical System — Quantum-Semantic Engine</p>
      </header>

      {!initialized && (
        <section className="setup-section">
          <div className="api-key-input">
            <label>Roxy API Key (optional — demo mode works without it)</label>
            <input
              type="password"
              value={apiKey}
              onChange={e => setApiKey(e.target.value)}
              placeholder="Enter your Roxy API key"
            />
          </div>
          <BirthDataForm onSubmit={handleBirthSubmit} loading={roxyLoading} />
          {roxyError && <div className="error-message">{roxyError}</div>}
        </section>
      )}

      {initialized && (
        <div className="dashboard">
          <div className="dashboard-left">
            <BodygraphViewer primalSource={primalSource} />
            <StateMonitor stateSummary={stateSummary} />
          </div>
          <div className="dashboard-center">
            <QuantumOraclePanel
              onQuery={handleQuery}
              isRunning={isRunning}
              cycleCount={cycleCount}
            />
            <RevelationPanel revelations={revelations} memoryReport={memoryReport} />
          </div>
          <div className="dashboard-right">
            <CausalGraphVisualizer graph={causalGraph} />
          </div>
        </div>
      )}
    </div>
  );
}
