# LCM Unzip + Dedupe Report

## What I did
- Unzipped all uploaded `.zip` files into `lcm_unzipped_all/`
- Kept each source bundle in its own extracted folder
- Scanned for exact duplicate files by SHA-256
- Grouped obvious duplicate bundle versions by normalized names

## Summary
- Zip files extracted: 34
- Exact duplicate file groups: 124
- Redundant duplicate file copies: 159

## Duplicate bundle families
- `autopoeticresonanceenginev7`: `AutopoeticResonanceEngine_v7(2).zip`, `AutopoeticResonanceEngine_v7-1.zip`
- `messymonorepo`: `messy-monorepo(1).zip`, `messy-monorepo.zip`
- `synthiakiosk`: `synthia-kiosk(7).zip`, `synthia-kiosk-2(1).zip`
- `synthiakleinmeshpoc`: `synthia-klein-mesh-poc-6.zip`, `synthia-klein-mesh-poc-7.zip`
- `synthiaos`: `SynthiaOS(2).zip`, `SynthiaOS(3).zip`, `SynthiaOS.zip`
- `synthiav9.1`: `synthia-v9.1(2).zip`, `synthia-v9.1(3).zip`

## Recommended canonical families
- Keep `synthia-runtime.zip` as the strongest typed runtime/state-space base.
- Keep `synthia_os_runtime.zip` as the strongest JS organism/runtime logic base.
- Keep `synthia-klein-mesh-poc-7.zip` as Klein-tool / mesh runtime donor.
- Keep `session_build-1.zip` as state-space / edge / attractor donor.
- Keep `synthia-core.zip` as state-space core donor if you want the newer coordinate/AutoLing lane.
- Treat repeated variants like `SynthiaOS*`, `messy-monorepo*`, `synthia-v9.1*`, and docs export zips as duplicates/donors, not separate truths.

## Exact duplicate files
Below are exact duplicate file groups (same file contents, different extracted locations).

- `AutopoeticResonanceEngine_v7_2_/1_SuccessDrivenPurposeCore.js` | `AutopoeticResonanceEngine_v7-1/1_SuccessDrivenPurposeCore.js`
- `AutopoeticResonanceEngine_v7_2_/2_ScientificPaperGenerator.js` | `AutopoeticResonanceEngine_v7-1/2_ScientificPaperGenerator.js`
- `AutopoeticResonanceEngine_v7_2_/3_PersistenceEngine.js` | `AutopoeticResonanceEngine_v7-1/3_PersistenceEngine.js`
- `AutopoeticResonanceEngine_v7_2_/4_ComplementaryCognitiveExtension.js` | `AutopoeticResonanceEngine_v7-1/4_ComplementaryCognitiveExtension.js`
- `AutopoeticResonanceEngine_v7_2_/5_AutopoeticResonanceEngine.js` | `AutopoeticResonanceEngine_v7-1/5_AutopoeticResonanceEngine.js`
- `AutopoeticResonanceEngine_v7_2_/App.jsx` | `AutopoeticResonanceEngine_v7-1/App.jsx`
- `AutopoeticResonanceEngine_v7_2_/App.css` | `AutopoeticResonanceEngine_v7-1/App.css`
- `AutopoeticResonanceEngine_v7_2_/README.md` | `AutopoeticResonanceEngine_v7-1/README.md`
- `SynthiaOS_2_/SynthiaSubstrate.ts` | `SynthiaOS_3_/SynthiaSubstrate.ts` | `SynthiaOS/SynthiaSubstrate.ts`
- `SynthiaOS_2_/SurfaceTransformEngine.ts` | `SynthiaOS_3_/SurfaceTransformEngine.ts` | `SynthiaOS/SurfaceTransformEngine.ts`
- `SynthiaOS_2_/SurfaceTransformEngine.test.ts` | `SynthiaOS_3_/SurfaceTransformEngine.test.ts` | `SynthiaOS/SurfaceTransformEngine.test.ts`
- `SynthiaOS_2_/StyleControlEngine.ts` | `SynthiaOS_3_/StyleControlEngine.ts` | `SynthiaOS/StyleControlEngine.ts`
- `SynthiaOS_2_/StyleControlEngine.test.ts` | `SynthiaOS_3_/StyleControlEngine.test.ts` | `SynthiaOS/StyleControlEngine.test.ts`
- `SynthiaOS_2_/DeepStructureLearner.ts` | `SynthiaOS_3_/DeepStructureLearner.ts` | `SynthiaOS/DeepStructureLearner.ts`
- `SynthiaOS_2_/DeepStructureLearner.test.ts` | `SynthiaOS_3_/DeepStructureLearner.test.ts` | `SynthiaOS/DeepStructureLearner.test.ts`
- `SynthiaOS_2_/InteractiveLearner.ts` | `SynthiaOS_3_/InteractiveLearner.ts` | `SynthiaOS/InteractiveLearner.ts`
- `SynthiaOS_2_/InteractiveLearner.test.ts` | `SynthiaOS_3_/InteractiveLearner.test.ts` | `SynthiaOS/InteractiveLearner.test.ts`
- `SynthiaOS_2_/SacralAnalogyEngine.ts` | `SynthiaOS_3_/SacralAnalogyEngine.ts` | `SynthiaOS/SacralAnalogyEngine.ts`
- `SynthiaOS_2_/SacralAnalogyEngine.test.ts` | `SynthiaOS_3_/SacralAnalogyEngine.test.ts` | `SynthiaOS/SacralAnalogyEngine.test.ts`
- `SynthiaOS_2_/meshServer.js` | `SynthiaOS_3_/meshServer.js` | `SynthiaOS/meshServer.js`
- `SynthiaOS_2_/index.html` | `SynthiaOS_3_/index.html` | `SynthiaOS/index.html`
- `SynthiaOS_2_/README-SynthiaOS.md` | `SynthiaOS_3_/README-SynthiaOS.md` | `SynthiaOS/README-SynthiaOS.md`
- `klcne_complete_package/klein_language_contact_neural_engine.js` | `synthia_orchestrator_complete/klein_language_contact_neural_engine.js`
- `klcne_complete_package/klcne_architecture_guide.md` | `synthia_orchestrator_complete/klcne_architecture_guide.md`
- `klcne_complete_package/klcne_deliverable_summary.md` | `synthia_orchestrator_complete/klcne_deliverable_summary.md`
- `klcne_complete_package/language_contact_model_analysis.png` | `synthia_orchestrator_complete/language_contact_model_analysis.png`
- `klcne_complete_package/klcne_architecture_diagram.png` | `synthia_orchestrator_complete/klcne_architecture_diagram.png`
- `messy-monorepo/apps/browser-shell/tsconfig.json` | `messy-monorepo/apps/runtime/tsconfig.json` | `messy-monorepo/packages/activation/tsconfig.json` | `messy-monorepo/packages/bus/tsconfig.json` | `messy-monorepo/packages/hd-graph/tsconfig.json` | `messy-monorepo/packages/identity-center/tsconfig.json` | `messy-monorepo/packages/ingestion/tsconfig.json` | `messy-monorepo/packages/mesh/tsconfig.json` | `messy-monorepo/packages/ontology/tsconfig.json` | `messy-monorepo/packages/organs-autoling/tsconfig.json` | `messy-monorepo/packages/organs-diseminer/tsconfig.json` | `messy-monorepo/packages/organs-novel-writer/tsconfig.json` | `messy-monorepo/packages/persistence/tsconfig.json` | `messy-monorepo/packages/projection/tsconfig.json` | `messy-monorepo/packages/resonance-core/tsconfig.json` | `messy-monorepo/packages/self-supervised/tsconfig.json` | `messy-monorepo/packages/state-space/tsconfig.json` | `messy-monorepo/packages/types/tsconfig.json` | `messy-monorepo/packages/ui/tsconfig.json` | `messy-monorepo/services/chart-oracle/tsconfig.json` | `messy-monorepo/services/oracle-py/tsconfig.json` | `messy-monorepo/services/resonance-market-api/tsconfig.json`
- `messy_all_docs_bundle/ARCHIVE_POLICY.md` | `messy_docs_full_export/ARCHIVE_POLICY.md`
- `messy_all_docs_bundle/FOUNDATION.md` | `messy_docs_full_export/FOUNDATION.md`
- `messy_all_docs_bundle/MESH.md` | `messy_docs_full_export/MESH.md`
- `messy_all_docs_bundle/MIGRATION_MAP.md` | `messy_docs_full_export/MIGRATION_MAP.md`
- `messy_all_docs_bundle/NODE_FUNCTIONS.md` | `messy_docs_export/docs/NODE_FUNCTIONS.md` | `messy_docs_full_export/NODE_FUNCTIONS.md`
- `messy_all_docs_bundle/ONTOLOGY.md` | `messy_docs_full_export/ONTOLOGY.md`
- `messy_all_docs_bundle/STATE_SPACE_MECHANICS.md` | `messy_docs_full_export/STATE_SPACE_MECHANICS.md`
- `synthia-kiosk_7_/install.sh` | `synthia-kiosk-2_1_/install.sh`
- `synthia-kiosk_7_/package.json` | `synthia-kiosk-2_1_/package.json`
- `synthia-kiosk_7_/tsconfig.json` | `synthia-kiosk-2_1_/tsconfig.json`
- `synthia-kiosk_7_/public/index.html` | `synthia-kiosk-2_1_/public/index.html`
- `synthia-kiosk_7_/src/server.ts` | `synthia-kiosk-2_1_/src/server.ts`
- `synthia-kiosk_7_/src/types.ts` | `synthia-kiosk-2_1_/src/types.ts`
- `synthia-kiosk_7_/src/engine/emergent-response.ts` | `synthia-kiosk-2_1_/src/engine/emergent-response.ts`
- `synthia-kiosk_7_/src/engine/executor.ts` | `synthia-kiosk-2_1_/src/engine/executor.ts`
- `synthia-kiosk_7_/src/engine/intent-parser.ts` | `synthia-kiosk-2_1_/src/engine/intent-parser.ts`
- `synthia-kiosk_7_/src/engine/planner.ts` | `synthia-kiosk-2_1_/src/engine/planner.ts`
- `synthia-kiosk_7_/src/rag/arxiv.ts` | `synthia-kiosk-2_1_/src/rag/arxiv.ts`
- `synthia-kiosk_7_/src/rag/base.ts` | `synthia-kiosk-2_1_/src/rag/base.ts`
- `synthia-kiosk_7_/src/rag/github.ts` | `synthia-kiosk-2_1_/src/rag/github.ts`
- `synthia-kiosk_7_/src/rag/index.ts` | `synthia-kiosk-2_1_/src/rag/index.ts`
- `synthia-kiosk_7_/src/rag/pubmed.ts` | `synthia-kiosk-2_1_/src/rag/pubmed.ts`
- `synthia-kiosk_7_/src/rag/router.ts` | `synthia-kiosk-2_1_/src/rag/router.ts`
- `synthia-kiosk_7_/src/substrate/message-bus.ts` | `synthia-kiosk-2_1_/src/substrate/message-bus.ts`
- `synthia-kiosk_7_/src/substrate/nodes.ts` | `synthia-kiosk-2_1_/src/substrate/nodes.ts`
- `synthia-kiosk_7_/src/tools/core-termux.ts` | `synthia-kiosk-2_1_/src/tools/core-termux.ts`
- `synthia-kiosk_7_/src/tools/device-control.ts` | `synthia-kiosk-2_1_/src/tools/device-control.ts`
- `synthia-kiosk_7_/src/utils/memory-substrate.ts` | `synthia-kiosk-2_1_/src/utils/memory-substrate.ts`
- `synthia-kiosk_7_/src/utils/memory.ts` | `synthia-kiosk-2_1_/src/utils/memory.ts`
- `synthia-kiosk_7_/src/utils/shell.ts` | `synthia-kiosk-2_1_/src/utils/shell.ts`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/README.md` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/README.md`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/package.json` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/package.json`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/demoExtended.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/demoExtended.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/index.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/index.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/frontend/index.html` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/frontend/index.html`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/frontend/meshServer.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/frontend/meshServer.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/mcp/mcpHub.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/mcp/mcpHub.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/mesh/EventMesh.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/mesh/EventMesh.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/mesh/SupabaseSync.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/mesh/SupabaseSync.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/sandbox/sandboxRunner.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/sandbox/sandboxRunner.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/tools/ToolBase.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/tools/ToolBase.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/tools/aiHub.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/tools/aiHub.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/tools/analogyEngine.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/tools/analogyEngine.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/tools/autoling.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/tools/autoling.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/tools/diseminer.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/tools/diseminer.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/tools/githubRAG.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/tools/githubRAG.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/tools/head.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/tools/head.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/tools/historicalMonteCarlo.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/tools/historicalMonteCarlo.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/tools/iChingGrammar.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/tools/iChingGrammar.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/tools/languageContact.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/tools/languageContact.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/tools/messy.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/tools/messy.js`
- `synthia-klein-mesh-poc-6/synthia-klein-mesh-poc/src/tools/novelWriter.js` | `synthia-klein-mesh-poc-7/synthia-klein-mesh-poc/src/tools/novelWriter.js`
- `synthia-runtime/coherence_calculator_v4.json` | `you-n-i-verse-corrected_4_/coherence_calculator_v4.json`
- `synthia-runtime/emergent-edge-resolver.ts` | `you-n-i-verse-corrected_4_/emergent-edge-resolver.ts`
- `synthia-runtime/gate_codon_dictionary.json` | `you-n-i-verse-corrected_4_/gate_codon_dictionary.json`
- `synthia-runtime/state-space-engine-v2.ts` | `you-n-i-verse-corrected_4_/state-space-engine-v2.ts`
- `synthia-runtime/synthia-bridge.ts` | `you-n-i-verse-corrected_4_/synthia-bridge.ts`
- `synthia-v9.1_2_/README.md` | `synthia-v9.1_3_/README.md`
- `synthia-v9.1_2_/package.json` | `synthia-v9.1_3_/package.json`
- `synthia-v9.1_2_/runtime.ts` | `synthia-v9.1_3_/runtime.ts`
- `synthia-v9.1_2_/tsconfig.json` | `synthia-v9.1_3_/tsconfig.json`
- `synthia-v9.1_2_/core/resonance-graph.ts` | `synthia-v9.1_3_/core/resonance-graph.ts`
- `synthia-v9.1_2_/cultivation/growth-path.ts` | `synthia-v9.1_3_/cultivation/growth-path.ts`
- `synthia-v9.1_2_/social/feed-engine.ts` | `synthia-v9.1_3_/social/feed-engine.ts`
- `synthia-v9.1_2_/ui/app.html` | `synthia-v9.1_3_/ui/app.html`
- `synthia-v9.1_2_/universe/generator.ts` | `synthia-v9.1_3_/universe/generator.ts`
- `synthia_os_complete_v2_1_/README.md` | `synthia_os_runtime/README.md`
- `synthia_os_complete_v2_1_/coordinate_engine.js` | `synthia_os_runtime/coordinate_engine.js`
- `synthia_os_complete_v2_1_/edge_function_engine.js` | `synthia_os_runtime/edge_function_engine.js`
- `synthia_os_complete_v2_1_/layer1_ato_core.js` | `synthia_os_runtime/layer1_ato_core.js`
- `synthia_os_complete_v2_1_/layer2_feature_space.js` | `synthia_os_runtime/layer2_feature_space.js`
- `synthia_os_complete_v2_1_/layer4_autolink.js` | `synthia_os_runtime/layer4_autolink.js`
- `synthia_os_complete_v2_1_/layer4_autonovel.js` | `synthia_os_runtime/layer4_autonovel.js`
- `synthia_os_complete_v2_1_/layer4_diseminer.js` | `synthia_os_runtime/layer4_diseminer.js`
- `synthia_os_complete_v2_1_/layer4_worldengine.js` | `synthia_os_runtime/layer4_worldengine.js`
- `synthia_os_complete_v2_1_/layer5_ssm.js` | `synthia_os_runtime/layer5_ssm.js`
- `synthia_os_complete_v2_1_/layer6_unity_body_map.cs` | `synthia_os_runtime/layer6_unity_body_map.cs`
- `synthia_os_complete_v2_1_/layer6_unity_city.cs` | `synthia_os_runtime/layer6_unity_city.cs`
- `synthia_os_complete_v2_1_/layer6_webgl.html` | `synthia_os_runtime/layer6_webgl.html`
- `synthia_os_complete_v2_1_/layer7_lcm.js` | `synthia_os_runtime/layer7_lcm.js`
- `synthia_os_complete_v2_1_/phase_space_engine.js` | `synthia_os_runtime/phase_space_engine.js`
- `synthia_os_complete_v2_1_/rich_state_engine.js` | `synthia_os_runtime/rich_state_engine.js`
- `synthia_os_complete_v2_1_/semantic_triple_engine.js` | `synthia_os_runtime/semantic_triple_engine.js`
- `synthia_os_complete_v2_1_/synthia_body.py` | `synthia_os_runtime/synthia_body.py`
- `synthia_os_complete_v2_1_/synthia_body_architecture.json` | `synthia_os_runtime/synthia_body_architecture.json`
- `synthia_os_complete_v2_1_/synthia_body_mobile.html` | `synthia_os_runtime/synthia_body_mobile.html`
- `synthia_os_complete_v2_1_/test_ato_core.js` | `synthia_os_runtime/test_ato_core.js`
- `synthia_os_complete_v2_1_/test_ato_core_verified.js` | `synthia_os_runtime/test_ato_core_verified.js`
- `synthia_os_complete_v2_1_/test_integrated_substrate.js` | `synthia_os_runtime/test_integrated_substrate.js`
- `synthia_os_complete_v2_1_/test_layer2_feature_space.js` | `synthia_os_runtime/test_layer2_feature_space.js`
- `synthia_os_complete_v2_1_/test_layer3_generative_mesh.js` | `synthia_os_runtime/test_layer3_generative_mesh.js`
- `synthia_os_complete_v2_1_/test_layer4_klein_tools.js` | `synthia_os_runtime/test_layer4_klein_tools.js`

## Extracted folders
Each bundle was extracted under `lcm_unzipped_all/<bundle-name>/`.