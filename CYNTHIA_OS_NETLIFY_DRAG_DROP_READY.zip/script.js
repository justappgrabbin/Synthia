function openApp(id){
  document.querySelectorAll('.window').forEach(w => w.classList.remove('active'));
  const el = document.getElementById(id);
  if(el) el.classList.add('active');
}
function closeWindow(id){
  const el = document.getElementById(id);
  if(el) el.classList.remove('active');
}
function go(event){
  event.preventDefault();
  let url = document.getElementById('urlInput').value.trim();
  if(!/^https?:\/\//i.test(url)) url = 'https://' + url;
  document.getElementById('urlInput').value = url;
  document.getElementById('browserScreen').innerHTML = `<h2>Opening</h2><p>${url}</p><button onclick="window.open('${url.replace(/'/g, '%27')}', '_blank')">Launch in New Tab</button>`;
  window.open(url, '_blank');
}
function tick(){
  document.getElementById('clock').textContent = new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
}
setInterval(tick,1000); tick();
