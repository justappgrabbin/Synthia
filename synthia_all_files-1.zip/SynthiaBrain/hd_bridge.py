import datetime
from typing import Dict, Any, Optional

def calculate_chart(birth: Dict[str, Any]) -> Dict[str, Any]:
    """
    Pure-Python deterministic chart generator.
    Input: dict with date, time, lat, lon (optional)
    Output: dict with Body/Heart/Mind gates + profile + summary
    """
    
    # Parse birth data
    date_str = birth.get("date", "1990-01-01")  # Default date
    time_str = birth.get("time", "12:00")       # Default time
    lat = birth.get("lat", 0.0)                 # Default latitude
    lon = birth.get("lon", 0.0)                 # Default longitude
    
    try:
        # Parse date and time
        if "T" in date_str:
            # ISO format
            dt = datetime.datetime.fromisoformat(date_str.replace("Z", ""))
        else:
            # Separate date and time
            date_part = datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
            time_part = datetime.datetime.strptime(time_str, "%H:%M").time()
            dt = datetime.datetime.combine(date_part, time_part)
    except (ValueError, TypeError):
        # Fallback to default
        dt = datetime.datetime(1990, 1, 1, 12, 0)
    
    # Use datetime components to create deterministic seeds
    year_seed = dt.year
    month_seed = dt.month
    day_seed = dt.day
    hour_seed = dt.hour
    minute_seed = dt.minute
    
    # Geographic influence (simplified)
    lat_seed = int(abs(lat * 100)) % 100
    lon_seed = int(abs(lon * 100)) % 100
    
    # Generate deterministic gate.line values
    def generate_gate_line(seed_base: int, offset: int) -> str:
        """Generate a gate.line string (1-64.1-6)"""
        gate_seed = (seed_base + offset) % 64 + 1
        line_seed = (seed_base + offset * 2) % 6 + 1
        return f"{gate_seed}.{line_seed}"
    
    # Calculate gates for each center
    base_seed = year_seed + month_seed * 100 + day_seed * 10000
    
    # Body gates (influenced by year and geographic location)
    body_seed = base_seed + lat_seed
    body_sun = generate_gate_line(body_seed, 1)
    body_earth = generate_gate_line(body_seed, 2)
    body_nodes = [
        generate_gate_line(body_seed, 3),
        generate_gate_line(body_seed, 4)
    ]
    
    # Heart gates (influenced by month and hour)
    heart_seed = month_seed * 1000 + hour_seed * 10 + lon_seed
    heart_sun = generate_gate_line(heart_seed, 1)
    heart_earth = generate_gate_line(heart_seed, 2)
    heart_nodes = [
        generate_gate_line(heart_seed, 3),
        generate_gate_line(heart_seed, 4)
    ]
    
    # Mind gates (influenced by day and minute)
    mind_seed = day_seed * 100 + minute_seed * 10 + (lat_seed + lon_seed) // 2
    mind_sun = generate_gate_line(mind_seed, 1)
    mind_earth = generate_gate_line(mind_seed, 2)
    mind_nodes = [
        generate_gate_line(mind_seed, 3),
        generate_gate_line(mind_seed, 4)
    ]
    
    # Generate profile (1/3, 1/4, 2/4, 2/5, 3/5, 3/6, 4/6, 5/1, 5/2, 6/2, 6/3)
    profiles = ["1/3", "1/4", "2/4", "2/5", "3/5", "3/6", "4/6", "5/1", "5/2", "6/2", "6/3"]
    profile_index = (base_seed + lat_seed + lon_seed) % len(profiles)
    profile = profiles[profile_index]
    
    # Generate summary
    body_primary = int(body_sun.split(".")[0])
    heart_primary = int(heart_sun.split(".")[0])
    mind_primary = int(mind_sun.split(".")[0])
    
    body_energy = "grounded" if body_primary <= 32 else "dynamic"
    heart_energy = "emotional" if heart_primary <= 32 else "intuitive"
    mind_energy = "analytical" if mind_primary <= 32 else "conceptual"
    
    summary = f"Body {body_energy} (Gate {body_primary}) • Heart {heart_energy} (Gate {heart_primary}) • Mind {mind_energy} (Gate {mind_primary})"
    
    return {
        "body": {
            "sun": body_sun,
            "earth": body_earth,
            "nodes": body_nodes
        },
        "heart": {
            "sun": heart_sun,
            "earth": heart_earth,
            "nodes": heart_nodes
        },
        "mind": {
            "sun": mind_sun,
            "earth": mind_earth,
            "nodes": mind_nodes
        },
        "profile": profile,
        "summary": summary
    }
