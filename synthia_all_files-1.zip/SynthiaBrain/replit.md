# Synthia

## Overview

Synthia is a conversational AI system built with FastAPI that integrates multiple language models (OpenAI, Claude, Grok, Ollama) with a unique "Mind/Heart/Body" framework. The system provides personalized responses through style transformations and includes an optional astrological chart generator. It features a sleek dark-themed web interface with animated visual elements representing the three core aspects of human experience.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Components

**Orchestration Layer (brain.py)**
- Central processing engine that coordinates all system components
- Implements field detection to categorize user input into Mind, Heart, or Body domains
- Manages multi-model response generation with graceful fallbacks
- Applies style transformations (Venom, Soft, Echo, Prime) to personalize responses
- Handles conversation memory persistence

**Response Selection Engine (collapse_engine.py)**
- Intelligent candidate selection using multi-factor scoring
- Evaluates responses based on length/structure, field alignment, keyword overlap, and actionable guidance
- Integrates astrological chart summaries when requested

**Memory Management (memory_store.py)**
- Abstract storage interface supporting multiple backends
- JSONL file-based storage for simplicity and portability
- MongoDB support for scalable deployments
- User-specific conversation history tracking

**Astrological Chart Generator (hd_bridge.py)**
- Pure Python deterministic chart calculation
- Generates Body/Heart/Mind gate mappings based on birth data
- No external dependencies for maximum reliability
- Produces consistent results for identical input parameters

**Configuration Management (settings.py)**
- Environment-based configuration using dataclasses
- Supports multiple AI model providers with fallback handling
- Configurable default behaviors and storage options

### API Architecture

**RESTful Design**
- Health check endpoint for system monitoring
- Single conversation endpoint with comprehensive request/response models
- Pydantic schemas for request validation and documentation

**Frontend Integration**
- Direct HTML serving from FastAPI
- Real-time visual feedback with animated elements
- Responsive design for various screen sizes

### Multi-Model Integration Strategy

**Graceful Degradation**
- Primary models: OpenAI GPT, Claude, Grok, Ollama
- Automatic fallback to available models when API keys are missing
- Soft failure handling to maintain system availability

**Response Optimization**
- Parallel model querying where possible
- Intelligent response selection based on quality heuristics
- Context-aware field detection for targeted responses

### Data Flow Architecture

1. **Input Processing**: User message → field detection (Mind/Heart/Body) → keyword extraction
2. **Response Generation**: Multi-model queries → candidate collection → quality scoring
3. **Post-Processing**: Style transformation → optional chart integration → memory persistence
4. **Output Delivery**: Structured JSON response with conversation context

## External Dependencies

### AI Model APIs
- **OpenAI API**: Primary language model for general conversations
- **Anthropic Claude API**: Alternative model for varied response perspectives
- **xAI Grok API**: Additional model option for diverse viewpoints
- **Ollama**: Local model support for privacy-focused deployments

### Storage Options
- **Local JSONL Files**: Default storage for conversation history
- **MongoDB**: Optional scalable database backend
- **File System**: User data directory for persistent storage

### Python Libraries
- **FastAPI**: Web framework and API server
- **Pydantic**: Data validation and serialization
- **httpx**: Async HTTP client for API integrations
- **uvicorn**: ASGI server for FastAPI deployment

### Frontend Technologies
- **Vanilla JavaScript**: Client-side interactivity
- **CSS3**: Animations and responsive design
- **HTML5**: Semantic markup and structure

### Development and Deployment
- **Python 3.8+**: Runtime environment
- **Environment Variables**: Configuration management
- **CORS Support**: Cross-origin resource sharing for web deployment