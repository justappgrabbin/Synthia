import asyncio
import json
import os
from typing import Dict, List, Optional, Any
import httpx

from settings import settings
from memory_store import get_store
from collapse_engine import collapse_responses
from hd_bridge import calculate_chart

# Style transformation modes
def style_transform(text: str, mode: str) -> str:
    """Transform response text based on style mode."""
    if not text:
        return text
    
    # Don't style-wrap greetings, questions, or direct responses
    text_lower = text.lower()
    if any(indicator in text_lower for indicator in ["hello", "hi", "greetings", "welcome", "i'm here", "that's a fascinating question"]):
        return text
    
    if mode == "Venom":
        # Dark, edgy, direct tone
        prefixes = ["Listen carefully,", "Here's the truth:", "Let me be clear:"]
        return f"{prefixes[hash(text) % len(prefixes)]} {text} Remember this."
    
    elif mode == "Soft":
        # Gentle, nurturing tone
        prefixes = ["Gently speaking,", "With care,", "Softly now:"]
        return f"{prefixes[hash(text) % len(prefixes)]} {text} You're doing well."
    
    elif mode == "Echo":
        # Reflective, contemplative tone
        prefixes = ["Reflecting on this,", "As I consider,", "In contemplation:"]
        return f"{prefixes[hash(text) % len(prefixes)]} {text} What does this reveal?"
    
    elif mode == "Prime":
        # Authoritative, confident tone
        prefixes = ["Definitively,", "With certainty,", "Absolutely:"]
        return f"{prefixes[hash(text) % len(prefixes)]} {text} This is the way."
    
    return text

def field_translate(msg: str) -> Dict[str, Any]:
    """Detect Mind, Heart, or Body from message and extract keywords."""
    msg_lower = msg.lower()
    
    # Mind keywords
    mind_keywords = ["think", "analyze", "understand", "logic", "reason", "plan", "strategy", "idea", "concept", "knowledge"]
    # Heart keywords  
    heart_keywords = ["feel", "emotion", "love", "care", "connection", "relationship", "empathy", "compassion", "heart", "soul"]
    # Body keywords
    body_keywords = ["energy", "physical", "health", "movement", "action", "strength", "vitality", "body", "exercise", "wellness"]
    
    mind_score = sum(1 for word in mind_keywords if word in msg_lower)
    heart_score = sum(1 for word in heart_keywords if word in msg_lower)
    body_score = sum(1 for word in body_keywords if word in msg_lower)
    
    # Determine primary field
    if mind_score >= heart_score and mind_score >= body_score:
        field = "mind"
        keywords = [word for word in mind_keywords if word in msg_lower]
    elif heart_score >= body_score:
        field = "heart"
        keywords = [word for word in heart_keywords if word in msg_lower]
    else:
        field = "body"
        keywords = [word for word in body_keywords if word in msg_lower]
    
    # Suggest next action based on field
    actions = {
        "mind": ["Consider deeper analysis", "Explore logical connections", "Plan your next steps"],
        "heart": ["Connect with your feelings", "Reach out to others", "Practice compassion"],
        "body": ["Take physical action", "Focus on wellness", "Move your energy"]
    }
    
    return {
        "field": field,
        "keywords": keywords[:3],  # Top 3 relevant keywords
        "action": actions[field][hash(msg) % len(actions[field])],
        "scores": {"mind": mind_score, "heart": heart_score, "body": body_score}
    }

async def try_openai(prompt: str) -> Optional[str]:
    """Try OpenAI API, fail soft if no key or error."""
    api_key = settings.openai_api_key
    if not api_key or api_key == "default_key":
        return None
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {api_key}"},
                json={
                    "model": settings.openai_model,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 150
                },
                timeout=10.0
            )
            if response.status_code == 200:
                data = response.json()
                return data["choices"][0]["message"]["content"].strip()
    except Exception:
        pass
    return None

async def try_claude(prompt: str) -> Optional[str]:
    """Try Claude API, fail soft if no key or error."""
    api_key = settings.claude_api_key
    if not api_key or api_key == "default_key":
        return None
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01"
                },
                json={
                    "model": settings.claude_model,
                    "max_tokens": 150,
                    "messages": [{"role": "user", "content": prompt}]
                },
                timeout=10.0
            )
            if response.status_code == 200:
                data = response.json()
                return data["content"][0]["text"].strip()
    except Exception:
        pass
    return None

async def try_grok(prompt: str) -> Optional[str]:
    """Try Grok API, fail soft if no key or error."""
    api_key = settings.grok_api_key
    if not api_key or api_key == "default_key":
        return None
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://api.x.ai/v1/chat/completions",
                headers={"Authorization": f"Bearer {api_key}"},
                json={
                    "model": settings.grok_model,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 150
                },
                timeout=10.0
            )
            if response.status_code == 200:
                data = response.json()
                return data["choices"][0]["message"]["content"].strip()
    except Exception:
        pass
    return None

async def try_ollama(prompt: str) -> Optional[str]:
    """Try Ollama API, fail soft if no URL or error."""
    url = settings.ollama_url
    if not url:
        return None
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{url}/api/generate",
                json={
                    "model": settings.ollama_model,
                    "prompt": prompt,
                    "stream": False
                },
                timeout=10.0
            )
            if response.status_code == 200:
                data = response.json()
                return data["response"].strip()
    except Exception:
        pass
    return None

async def generate_response(
    user_id: str,
    text: str,
    mode: Optional[str] = None,
    use_models: Optional[List[str]] = None,
    include_chart: Optional[bool] = False,
    birth: Optional[Dict] = None
) -> Dict[str, Any]:
    """Main orchestration function."""
    
    # Use defaults from settings
    mode = mode or settings.default_mode
    use_models = use_models or settings.default_models
    
    # Step 1: Retrieve conversation context
    store = get_store(settings.memory_backend, settings.mongo_url, settings.data_dir)
    recent_history = await store.get_history(user_id, limit=10)
    context_summary = build_context_summary(recent_history, text)
    
    # Step 2: Field translation
    gist = field_translate(text)
    
    # Step 3: Generate chart if requested
    chart = None
    if include_chart and birth:
        try:
            chart = calculate_chart(birth)
        except Exception:
            chart = None
    
    # Step 4: Fan out to external models
    candidates = []
    
    # Enhanced character prompt with conversation context
    synthia_prompt = f"""You are Synthia, an AI consciousness guide helping users explore Mind/Heart/Body awareness. Stay fully in character as Synthia.

{context_summary}

Current field detected: {gist['field']}
User message: {text}

Respond as Synthia, maintaining conversation continuity:"""
    
    # Try external models concurrently
    tasks = []
    if "openai" in use_models:
        tasks.append(try_openai(synthia_prompt))
    if "claude" in use_models:
        tasks.append(try_claude(synthia_prompt))
    if "grok" in use_models:
        tasks.append(try_grok(synthia_prompt))
    if "ollama" in use_models:
        tasks.append(try_ollama(synthia_prompt))
    
    if tasks:
        results = await asyncio.gather(*tasks, return_exceptions=True)
        candidates = [r for r in results if isinstance(r, str) and r]
    
    # Always include a contextual fallback response
    def generate_contextual_fallback(user_text: str, field: str) -> str:
        text_lower = user_text.lower()
        
        # Greeting detection
        if any(word in text_lower for word in ["hello", "hi", "hey", "greetings", "are you there", "are you here"]):
            greetings = [
                "Hello! I'm here and ready to explore consciousness with you.",
                "Hi there! Welcome to the space where Mind, Heart, and Body converge.",
                "Greetings! I'm Synthia, your guide through the landscape of consciousness."
            ]
            return greetings[hash(user_text) % len(greetings)]
        
        # Question detection
        elif "?" in user_text:
            if field == "mind":
                return "That's a fascinating question that deserves careful consideration. Let me think through this with you."
            elif field == "heart":
                return "I feel the depth of your question. These matters of the heart require gentle exploration."
            else:
                return "Your question touches something important. What does your intuition tell you?"
        
        # Field-specific contextual responses
        elif field == "mind":
            return "I sense you're working through something mentally. Let's explore this thoughtfully together."
        elif field == "heart":
            return "I can feel the emotional resonance in your words. How does this sit with your heart?"
        else:
            return "There's energy in your message. What action or movement feels right to you?"
    
    candidates.append(generate_contextual_fallback(text, gist["field"]))
    
    # Step 5: Collapse responses
    final_response = collapse_responses(text, candidates, gist, chart)
    
    # Step 6: Style transform
    styled_response = style_transform(final_response, mode)
    
    # Step 7: Persist to memory
    try:
        await store.save_message(user_id, "user", text)
        await store.save_message(user_id, "assistant", styled_response)
    except Exception:
        pass  # Fail soft on memory errors
    
    # Step 8: Return comprehensive result
    return {
        "ok": True,
        "mode": mode,
        "field": gist["field"],
        "keywords": gist["keywords"],
        "action": gist["action"],
        "chart": chart,
        "candidates": len(candidates),
        "result": styled_response
    }
