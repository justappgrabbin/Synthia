import os
from dataclasses import dataclass, field
from typing import List

@dataclass
class Settings:
    # Memory configuration
    memory_backend: str = os.getenv("MEMORY_BACKEND", "jsonl")
    mongo_url: str = os.getenv("MONGO_URL", "mongodb://localhost:27017")
    data_dir: str = os.getenv("DATA_DIR", "./data")
    
    # Default behavior
    default_mode: str = os.getenv("DEFAULT_MODE", "Echo")
    default_models: List[str] = field(default_factory=lambda: os.getenv("DEFAULT_MODELS", "ollama,claude").split(",") if os.getenv("DEFAULT_MODELS") else ["ollama", "claude"])
    
    # OpenAI configuration
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "default_key")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-3.5-turbo")
    
    # Claude configuration
    claude_api_key: str = os.getenv("CLAUDE_API_KEY", "default_key")
    claude_model: str = os.getenv("CLAUDE_MODEL", "claude-3-5-sonnet-20241022")
    
    # Grok configuration
    grok_api_key: str = os.getenv("GROK_API_KEY", "default_key")
    grok_model: str = os.getenv("GROK_MODEL", "grok-beta")
    
    # Ollama configuration
    ollama_url: str = os.getenv("OLLAMA_URL", "http://localhost:11434")
    ollama_model: str = os.getenv("OLLAMA_MODEL", "llama3.2:3b")

# Global settings instance
settings = Settings()
