from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import os

import brain

app = FastAPI(title="Synthia API")

class Birth(BaseModel):
    date: Optional[str] = None
    time: Optional[str] = None
    lat: Optional[float] = None
    lon: Optional[float] = None

class Ask(BaseModel):
    user_id: str
    text: str
    mode: Optional[str] = None
    use_models: Optional[List[str]] = None
    include_chart: Optional[bool] = False
    birth: Optional[Birth] = None

@app.get("/health")
def health():
    return {"ok": True, "name": "Synthia API"}

@app.post("/ask")
async def ask(payload: Ask) -> Dict[str, Any]:
    result = await brain.generate_response(
        user_id=payload.user_id,
        text=payload.text,
        mode=payload.mode,
        use_models=payload.use_models,
        include_chart=payload.include_chart,
        birth=(payload.birth.dict() if payload.birth else None)
    )
    return result

# Serve frontend directly from root
@app.get("/")
def index():
    return FileResponse(os.path.join(os.path.dirname(__file__), "index.html"))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
