from typing import List, Dict, Any, Optional

def _cheap_score(text: str, gist: Dict[str, Any]) -> float:
    """Calculate a heuristic score for response quality."""
    if not text:
        return 0.0
    
    score = 0.0
    text_lower = text.lower()
    
    # Length and structure scoring (30% weight)
    length_score = min(len(text) / 200.0, 1.0)  # Optimal around 200 chars
    structure_score = 0.5
    if "." in text or "!" in text or "?" in text:
        structure_score += 0.3
    if len(text.split()) > 5:  # More than 5 words
        structure_score += 0.2
    
    score += (length_score + structure_score) * 0.3
    
    # Field alignment scoring (40% weight)
    field_keywords = gist.get("keywords", [])
    field_matches = sum(1 for keyword in field_keywords if keyword in text_lower)
    field_score = min(field_matches / max(len(field_keywords), 1), 1.0)
    score += field_score * 0.4
    
    # Keyword overlap with original message (20% weight)
    # This would require the original message, using field keywords as proxy
    keyword_overlap = field_matches / max(len(field_keywords), 1) if field_keywords else 0
    score += keyword_overlap * 0.2
    
    # "Next" directive bonus (10% weight)
    next_indicators = ["what", "how", "next", "should", "could", "might", "consider", "try"]
    next_score = sum(1 for indicator in next_indicators if indicator in text_lower)
    score += min(next_score / 3.0, 1.0) * 0.1
    
    return min(score, 1.0)

def collapse_responses(
    user_text: str,
    candidates: List[str],
    gist: Dict[str, Any],
    chart: Optional[Dict[str, Any]] = None
) -> str:
    """
    Select the best response from candidates using scoring heuristics.
    Optionally append chart summary if available.
    """
    if not candidates:
        return "I'm here to help, but I need a moment to gather my thoughts."
    
    # Score all candidates
    scored_candidates = []
    for candidate in candidates:
        if candidate and candidate.strip():
            score = _cheap_score(candidate, gist)
            scored_candidates.append((score, candidate))
    
    if not scored_candidates:
        return "I'm processing your request, but having trouble formulating a response."
    
    # Sort by score (highest first) and pick the best
    scored_candidates.sort(key=lambda x: x[0], reverse=True)
    best_response = scored_candidates[0][1]
    
    # Append chart summary if available
    if chart and chart.get("summary"):
        chart_summary = chart["summary"]
        best_response += f"\n\n✨ Chart Insight: {chart_summary}"
    
    return best_response.strip()
