import os
import json
import asyncio
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from datetime import datetime

class BaseStore(ABC):
    """Abstract base class for memory storage."""
    
    @abstractmethod
    async def save_message(self, user_id: str, role: str, content: str) -> None:
        pass
    
    @abstractmethod
    async def get_history(self, user_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        pass

class JsonlMemoryStore(BaseStore):
    """JSONL file-based memory storage."""
    
    def __init__(self, data_dir: str = "./data"):
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
    
    def _get_user_file(self, user_id: str) -> str:
        """Get the JSONL file path for a user."""
        safe_user_id = "".join(c for c in user_id if c.isalnum() or c in "._-")
        return os.path.join(self.data_dir, f"{safe_user_id}.jsonl")
    
    async def save_message(self, user_id: str, role: str, content: str) -> None:
        """Save a message to the user's JSONL file."""
        message = {
            "timestamp": datetime.utcnow().isoformat(),
            "role": role,
            "content": content
        }
        
        file_path = self._get_user_file(user_id)
        
        # Use asyncio to write file in a thread to avoid blocking
        def write_file():
            with open(file_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(message, ensure_ascii=False) + "\n")
        
        await asyncio.get_event_loop().run_in_executor(None, write_file)
    
    async def get_history(self, user_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Get message history for a user."""
        file_path = self._get_user_file(user_id)
        
        if not os.path.exists(file_path):
            return []
        
        def read_file():
            messages = []
            with open(file_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            messages.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue
            return messages[-limit:] if limit > 0 else messages
        
        return await asyncio.get_event_loop().run_in_executor(None, read_file)

class MongoMemoryStore(BaseStore):
    """MongoDB-based memory storage."""
    
    def __init__(self, mongo_url: str):
        self.mongo_url = mongo_url
        self._client = None
        self._db = None
        self._collection = None
        self._init_mongo()
    
    def _init_mongo(self):
        """Initialize MongoDB connection."""
        try:
            import pymongo
            self._client = pymongo.MongoClient(self.mongo_url)
            self._db = self._client.synthia
            self._collection = self._db.messages
        except ImportError:
            raise RuntimeError("pymongo not available for MongoDB storage")
        except Exception as e:
            raise RuntimeError(f"Failed to connect to MongoDB: {e}")
    
    async def save_message(self, user_id: str, role: str, content: str) -> None:
        """Save a message to MongoDB."""
        message = {
            "user_id": user_id,
            "timestamp": datetime.utcnow(),
            "role": role,
            "content": content
        }
        
        def insert_message():
            self._collection.insert_one(message)
        
        await asyncio.get_event_loop().run_in_executor(None, insert_message)
    
    async def get_history(self, user_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Get message history for a user from MongoDB."""
        def find_messages():
            cursor = self._collection.find(
                {"user_id": user_id}
            ).sort("timestamp", 1).limit(limit)
            
            messages = []
            for doc in cursor:
                doc["timestamp"] = doc["timestamp"].isoformat()
                del doc["_id"]  # Remove MongoDB ObjectId
                messages.append(doc)
            return messages
        
        return await asyncio.get_event_loop().run_in_executor(None, find_messages)

def get_store(backend: str, mongo_url: str = None, data_dir: str = "./data") -> BaseStore:
    """Factory function to get the appropriate storage backend."""
    if backend.lower() == "mongo" and mongo_url:
        try:
            return MongoMemoryStore(mongo_url)
        except Exception:
            # Fall back to JSONL if MongoDB fails
            return JsonlMemoryStore(data_dir)
    else:
        return JsonlMemoryStore(data_dir)
