# Pathways to Purpose - Resonance Network

## Overview

This is a cohort-based collaboration platform called "Resonance" that helps people discover compatible partners for group projects based on Human Design energy types and I Ching hexagrams. The application matches users into groups, tracks their progress through a 6-week program, and facilitates collective income opportunities.

The core concept: People with complementary energy profiles work together on shared interests, with AI-driven matching to optimize group dynamics and minimize friction. The platform includes an I Ching oracle for guidance and tracks financial opportunities for groups.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **UI Components**: shadcn/ui with Radix primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming (light/dark modes)
- **Build Tool**: Vite with custom plugins for Replit integration
- **Design System**: Carbon Design System principles adapted for data-intensive dashboards

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript (ESM modules)
- **API Pattern**: RESTful JSON API under `/api/*` routes
- **Build**: esbuild for production bundling with selective dependency bundling

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` (shared between client and server)
- **Validation**: Zod schemas with drizzle-zod integration
- **Storage Interface**: Abstract `IStorage` interface in `server/storage.ts` (currently in-memory, designed for PostgreSQL)

### Key Domain Models
- **Users**: Include Human Design profiles (energy type, strategy, centers)
- **Groups**: 6-week cohort programs with phases (discovery → sustain)
- **Memberships**: User-to-group relationships with assigned roles
- **Castings**: I Ching hexagram readings with interpretations
- **Matches**: Resonance-scored pairings between users
- **Opportunities**: Financial/project opportunities for groups

### Application Pages
- Dashboard: Overview with stats, groups, and quick actions
- Profile: User HD profile management with energy type configuration
- Matching: Find compatible users based on resonance scores
- Groups: Create and manage cohort groups
- Oracle: I Ching casting interface
- Opportunities: Track and manage group financial goals
- Settings: Theme and preference management

## External Dependencies

### Database
- PostgreSQL (configured via `DATABASE_URL` environment variable)
- Drizzle Kit for migrations (`npm run db:push`)

### UI Libraries
- Full shadcn/ui component library (Radix-based)
- Framer Motion for animations
- Lucide React for icons
- Recharts for data visualization

### Form Handling
- React Hook Form with Zod resolver

### Session Management
- express-session with connect-pg-simple for PostgreSQL session storage

### Fonts (External CDN)
- DM Sans, Fira Code, Geist Mono, Literata, Space Grotesk (Google Fonts)