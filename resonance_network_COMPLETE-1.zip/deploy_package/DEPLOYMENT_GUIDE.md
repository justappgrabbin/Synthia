# YOU-N-I-VERSE Resonance Network - Deployment Guide

## What You Have

This package contains your complete consciousness social network:

1. **Backend API** (`backend/main.py`) - FastAPI server with:
   - Your trained neural network (ONNX model)
   - Supabase integration for user data
   - Resonance calculation endpoints
   - Success feedback loop for ML training

2. **Frontend** (`frontend/index.html`) - React app with:
   - Birth data input & chart calculation
   - User profile creation
   - Resonance matching interface
   - Success reporting

3. **Database Schema** (`backend/supabase_schema.sql`) - PostgreSQL tables for:
   - User profiles
   - Success reports (ML feedback)
   - Resonance cache

## Step 1: Set Up Supabase

1. Go to https://supabase.com and create a free account
2. Create a new project
3. Go to SQL Editor and run the contents of `backend/supabase_schema.sql`
4. Go to Settings > API to get:
   - `SUPABASE_URL` (Project URL)
   - `SUPABASE_KEY` (anon/public key)

## Step 2: Deploy Backend

### Option A: Railway (Recommended - Easiest)

1. Go to https://railway.app and sign up
2. Click "New Project" > "Deploy from GitHub repo"
3. Connect your GitHub and select your repo
4. Railway will auto-detect Python and deploy
5. Add environment variables:
   - `SUPABASE_URL` = your URL from Step 1
   - `SUPABASE_KEY` = your key from Step 1
6. Railway gives you a URL like `https://yourapp.railway.app`

### Option B: Render

1. Go to https://render.com and sign up
2. Click "New +" > "Web Service"
3. Connect your GitHub repo
4. Settings:
   - **Build Command**: `pip install -r backend/requirements.txt`
   - **Start Command**: `cd backend && uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Add environment variables (same as Railway)
6. Deploy

### Option C: Replit (Fastest for Testing)

1. Go to https://replit.com
2. Create new Repl > "Import from GitHub"
3. Paste your repo URL
4. Replit auto-runs - just add env vars in Secrets tab
5. Click "Run" - you get instant URL

## Step 3: Deploy Frontend

### Option A: Netlify (Free & Easy)

1. Go to https://netlify.com
2. Drag-and-drop your `frontend` folder
3. Edit `index.html` line 157 - replace `'https://your-backend-url.com'` with your Railway/Render URL
4. Netlify gives you URL like `https://yourapp.netlify.app`

### Option B: Vercel (Alternative)

1. Go to https://vercel.com
2. Import project > select frontend folder
3. Update API_URL in index.html
4. Deploy

## Step 4: Copy Your Trained Model

Your neural network is in `ml/model.onnx`. You need to:

1. Copy it to `backend/ml/model.onnx` in your deployment
2. OR upload it separately and update the path in `main.py` line 24

**Important**: Railway/Render both support file uploads. After deployment:
- Use their dashboard to upload `model.onnx`
- Place it in the same directory as `main.py`

## Step 5: Test It

1. Open your frontend URL (Netlify)
2. Enter birth data
3. Click "Calculate My Chart"
4. Switch to "Find Matches" tab
5. System calculates resonance with neural network

## Integration with Your Existing Code

To use your actual QHD engine instead of the mock:

1. Copy `ml/qhd/` folder to `backend/ml/qhd/`
2. In `main.py`, replace the `calculate_chart()` function (lines 54-74):

```python
from ml.qhd.engine import VirtualConsciousnessEngine
from ml.qhd.core import Placement, Stream

def calculate_chart(birth_data: BirthData) -> Dict:
    # Convert birth_data to Placement objects
    # Call your actual engine
    placements = convert_birth_to_placements(birth_data)  # You implement this
    engine = VirtualConsciousnessEngine(placements, model_path="../ml/model.onnx")
    response = engine.query("What is my design?")
    
    # Extract gates from response
    gates = [k for k, v in response.codon_activations.items() if v > 0.5]
    
    return {
        "gates": gates,
        "profile": "4/6",  # Extract from your engine
        "authority": response.field_states.get('heart', {}).get('authority', 'Unknown'),
        "type": "Manifestor",  # Extract from your engine
        "centers": {}  # Map from your field_states
    }
```

## Troubleshooting

**"Model not found"**: Upload `model.onnx` to backend directory
**"Supabase not configured"**: Check environment variables are set
**"CORS error"**: Update CORS origins in `main.py` line 18
**"Module not found"**: Run `pip install -r requirements.txt`

## Next Steps

Once deployed:

1. **Connect Real Chart Calculation**: Wire your QHD engine (see above)
2. **Add Authentication**: Use Supabase Auth for user accounts
3. **Train on Success Data**: When users report successes, retrain your model
4. **Add More Fields**: Expose all 9 consciousness fields in the UI
5. **Build Community Features**: Chat, groups, events based on resonance

## You're Done!

You now have:
- ✅ Backend API running with neural network
- ✅ Supabase storing user data
- ✅ Frontend where people can create profiles
- ✅ Resonance matching using your trained model
- ✅ Feedback loop for continuous learning

The network improves as people use it - exactly as you designed it to.

---

**Need Help?**
- Backend not starting? Check logs in Railway/Render dashboard
- Frontend not connecting? Verify API_URL in index.html
- Model not loading? Ensure model.onnx is in correct path
