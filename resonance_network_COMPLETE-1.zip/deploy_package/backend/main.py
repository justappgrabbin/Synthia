"""
YOU-N-I-VERSE Resonance Network API
FastAPI backend with neural network + Supabase integration
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Optional
import onnxruntime as ort
import numpy as np
from datetime import datetime
import os

# Supabase setup
from supabase import create_client, Client
SUPABASE_URL = os.getenv("SUPABASE_URL", "")
SUPABASE_KEY = os.getenv("SUPABASE_KEY", "")
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY) if SUPABASE_URL else None

app = FastAPI(title="YOU-N-I-VERSE API")

# CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load ONNX model
try:
    onnx_session = ort.InferenceSession("../ml/model.onnx")
    MODEL_LOADED = True
except Exception as e:
    print(f"Model load warning: {e}")
    MODEL_LOADED = False


# ============ DATA MODELS ============

class BirthData(BaseModel):
    date: str  # YYYY-MM-DD
    time: str  # HH:MM
    lat: float
    lon: float
    timezone: str

class UserProfile(BaseModel):
    user_id: str
    birth_data: BirthData
    gates: List[int]
    profile: str
    authority: str
    type: str
    
class ResonanceRequest(BaseModel):
    user_id: str
    target_user_ids: List[str]

class SuccessReport(BaseModel):
    user_id: str
    matched_user_id: str
    success_type: str  # "connection", "collaboration", "insight"
    rating: int  # 1-5
    notes: Optional[str] = None


# ============ CHART CALCULATION ============

def calculate_chart(birth_data: BirthData) -> Dict:
    """
    Calculate Human Design chart from birth data
    This is a placeholder - integrate your actual QHD engine
    """
    # TODO: Wire to your ml/qhd/engine.py
    # For now, mock response
    return {
        "gates": [1, 2, 3, 13, 25, 46],
        "profile": "4/6",
        "authority": "Emotional",
        "type": "Manifestor",
        "centers": {
            "head": True,
            "ajna": True,
            "throat": True,
            "g": False,
            "heart": False,
            "sacral": False,
            "solar_plexus": True,
            "root": True,
            "spleen": False
        }
    }


# ============ NEURAL NETWORK INFERENCE ============

def run_resonance_model(user_gates: List[int], target_gates: List[int]) -> float:
    """
    Run trained GNN model to calculate resonance score
    """
    if not MODEL_LOADED:
        # Fallback: simple gate overlap scoring
        overlap = len(set(user_gates) & set(target_gates))
        return min(overlap / 10.0, 1.0)
    
    try:
        # Prepare input for ONNX model
        # Your model expects node features - adapt to your actual input shape
        user_vec = np.zeros(64, dtype=np.float32)
        target_vec = np.zeros(64, dtype=np.float32)
        
        for gate in user_gates:
            if gate <= 64:
                user_vec[gate-1] = 1.0
        for gate in target_gates:
            if gate <= 64:
                target_vec[gate-1] = 1.0
        
        # Run inference
        input_name = onnx_session.get_inputs()[0].name
        combined = np.stack([user_vec, target_vec])
        result = onnx_session.run(None, {input_name: combined})
        
        # Extract resonance score
        score = float(result[0][0])
        return max(0.0, min(1.0, score))
        
    except Exception as e:
        print(f"Model inference error: {e}")
        # Fallback
        overlap = len(set(user_gates) & set(target_gates))
        return min(overlap / 10.0, 1.0)


# ============ API ENDPOINTS ============

@app.get("/")
def root():
    return {
        "app": "YOU-N-I-VERSE Resonance Network",
        "status": "operational",
        "model_loaded": MODEL_LOADED,
        "supabase_connected": supabase is not None
    }


@app.post("/calculate_chart")
def calculate_chart_endpoint(birth_data: BirthData):
    """Calculate Human Design chart from birth data"""
    try:
        chart = calculate_chart(birth_data)
        return {"ok": True, "chart": chart}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/create_profile")
async def create_profile(profile: UserProfile):
    """Create user profile in Supabase"""
    if not supabase:
        raise HTTPException(status_code=503, detail="Supabase not configured")
    
    try:
        data = {
            "user_id": profile.user_id,
            "birth_data": profile.birth_data.dict(),
            "gates": profile.gates,
            "profile": profile.profile,
            "authority": profile.authority,
            "type": profile.type,
            "created_at": datetime.utcnow().isoformat()
        }
        
        result = supabase.table("profiles").insert(data).execute()
        return {"ok": True, "profile": result.data}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/get_profile/{user_id}")
async def get_profile(user_id: str):
    """Retrieve user profile"""
    if not supabase:
        raise HTTPException(status_code=503, detail="Supabase not configured")
    
    try:
        result = supabase.table("profiles").select("*").eq("user_id", user_id).execute()
        if not result.data:
            raise HTTPException(status_code=404, detail="Profile not found")
        return {"ok": True, "profile": result.data[0]}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/calculate_resonance")
async def calculate_resonance(req: ResonanceRequest):
    """Calculate resonance scores with target users"""
    if not supabase:
        raise HTTPException(status_code=503, detail="Supabase not configured")
    
    try:
        # Get user profile
        user_result = supabase.table("profiles").select("gates").eq("user_id", req.user_id).execute()
        if not user_result.data:
            raise HTTPException(status_code=404, detail="User profile not found")
        user_gates = user_result.data[0]["gates"]
        
        # Get target profiles
        targets_result = supabase.table("profiles").select("user_id, gates, profile, type").in_("user_id", req.target_user_ids).execute()
        
        # Calculate resonance for each target
        resonance_scores = []
        for target in targets_result.data:
            score = run_resonance_model(user_gates, target["gates"])
            resonance_scores.append({
                "user_id": target["user_id"],
                "resonance_score": score,
                "profile": target["profile"],
                "type": target["type"]
            })
        
        # Sort by score descending
        resonance_scores.sort(key=lambda x: x["resonance_score"], reverse=True)
        
        return {"ok": True, "matches": resonance_scores}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/report_success")
async def report_success(report: SuccessReport):
    """User reports successful connection - feeds ML training"""
    if not supabase:
        raise HTTPException(status_code=503, detail="Supabase not configured")
    
    try:
        data = {
            "user_id": report.user_id,
            "matched_user_id": report.matched_user_id,
            "success_type": report.success_type,
            "rating": report.rating,
            "notes": report.notes,
            "reported_at": datetime.utcnow().isoformat()
        }
        
        result = supabase.table("success_reports").insert(data).execute()
        
        # TODO: Trigger model retraining pipeline when enough new data accumulates
        
        return {"ok": True, "report_id": result.data[0]["id"]}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/matching_pool")
async def get_matching_pool(limit: int = 50):
    """Get pool of users available for matching"""
    if not supabase:
        raise HTTPException(status_code=503, detail="Supabase not configured")
    
    try:
        result = supabase.table("profiles").select("user_id, gates, profile, type, authority").limit(limit).execute()
        return {"ok": True, "pool": result.data}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
