-- YOU-N-I-VERSE Resonance Network Database Schema
-- Run this in your Supabase SQL editor

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT UNIQUE NOT NULL,
    birth_data JSONB NOT NULL,
    gates INTEGER[] NOT NULL,
    profile TEXT NOT NULL,
    authority TEXT NOT NULL,
    type TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Success reports table (for ML feedback loop)
CREATE TABLE IF NOT EXISTS success_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL REFERENCES profiles(user_id),
    matched_user_id TEXT NOT NULL REFERENCES profiles(user_id),
    success_type TEXT NOT NULL,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    notes TEXT,
    reported_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Resonance cache table (optional - for performance)
CREATE TABLE IF NOT EXISTS resonance_cache (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id_1 TEXT NOT NULL,
    user_id_2 TEXT NOT NULL,
    resonance_score FLOAT NOT NULL,
    calculated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id_1, user_id_2)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_profiles_user_id ON profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_success_reports_user_id ON success_reports(user_id);
CREATE INDEX IF NOT EXISTS idx_success_reports_matched_user ON success_reports(matched_user_id);
CREATE INDEX IF NOT EXISTS idx_resonance_cache_users ON resonance_cache(user_id_1, user_id_2);

-- Row level security (optional but recommended)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE success_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE resonance_cache ENABLE ROW LEVEL SECURITY;

-- Policies (adjust based on your auth strategy)
CREATE POLICY "Users can read all profiles" ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can insert their own profile" ON profiles FOR INSERT WITH CHECK (true);
CREATE POLICY "Users can update their own profile" ON profiles FOR UPDATE USING (true);

CREATE POLICY "Users can read all success reports" ON success_reports FOR SELECT USING (true);
CREATE POLICY "Users can insert their own reports" ON success_reports FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can read resonance cache" ON resonance_cache FOR SELECT USING (true);
