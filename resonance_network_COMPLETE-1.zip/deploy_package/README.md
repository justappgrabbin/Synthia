# YOU-N-I-VERSE Resonance Network

**A consciousness social network that learns from successful connections**

## What This Is

Your complete resonance matching system, ready to deploy:

- **Neural Network**: Trained GNN model that calculates consciousness compatibility
- **Backend API**: FastAPI server with Supabase integration
- **Frontend**: React app for user profiles and matching
- **Learning Loop**: System improves as users report successful connections

## Quick Start (5 Minutes)

1. **Set up Supabase**: 
   - Create account at https://supabase.com
   - Run `backend/supabase_schema.sql` in SQL Editor
   - Copy your URL and API key

2. **Deploy Backend**:
   - Go to https://railway.app
   - Deploy from GitHub
   - Add Supabase env vars
   - Copy your API URL

3. **Deploy Frontend**:
   - Go to https://netlify.com
   - Drag-and-drop `frontend` folder
   - Update `API_URL` in index.html with your Railway URL

4. **Upload Your Model**:
   - Copy `ml/model.onnx` to backend directory
   - Railway will detect and serve it

**Done.** Your app is live.

## File Structure

```
deploy_package/
├── backend/
│   ├── main.py              # FastAPI server with neural network
│   ├── requirements.txt     # Python dependencies
│   ├── supabase_schema.sql  # Database tables
│   └── .env.example         # Config template
├── frontend/
│   └── index.html           # React app (single file)
├── DEPLOYMENT_GUIDE.md      # Detailed deployment steps
└── README.md                # This file
```

## How It Works

1. **User creates profile** → Birth data → Chart calculation → Gates extracted
2. **User finds matches** → Neural network scores resonance with other users
3. **User reports success** → Feedback stored in Supabase → Model learns
4. **Network improves** → Better matches over time

## Integration Points

### Connect Your QHD Engine

Replace mock chart calculation in `backend/main.py` (line 54):

```python
from ml.qhd.engine import VirtualConsciousnessEngine

def calculate_chart(birth_data: BirthData) -> Dict:
    placements = convert_birth_to_placements(birth_data)
    engine = VirtualConsciousnessEngine(placements, model_path="../ml/model.onnx")
    response = engine.query("Calculate consciousness signature")
    
    return {
        "gates": extract_gates(response),
        "profile": extract_profile(response),
        "authority": extract_authority(response),
        "type": extract_type(response)
    }
```

### Add More Fields

Extend the frontend to show all 9 consciousness fields:
- Mind (Sidereal/Tropical/Draconic)
- Heart (Sidereal/Tropical/Draconic)  
- Body (Sidereal/Tropical/Draconic)

### Retrain Model

When success_reports table accumulates data:

```python
from ml.training.trainer import train_resonance_model

# Fetch success data from Supabase
success_data = supabase.table("success_reports").select("*").execute()

# Retrain with new examples
train_resonance_model(success_data.data, epochs=10)

# Replace old model
```

## Environment Variables

Set these in Railway/Render:

```bash
SUPABASE_URL=https://yourproject.supabase.co
SUPABASE_KEY=your_anon_key_here
```

## Tech Stack

- **Backend**: FastAPI + ONNX Runtime + Supabase
- **Frontend**: React (vanilla, no build step)
- **Database**: PostgreSQL (via Supabase)
- **ML**: PyTorch → ONNX (inference only)
- **Hosting**: Railway + Netlify (free tiers)

## Next Steps

After deployment:

1. **Test with real users** → Get feedback → Iterate UI
2. **Monitor success_reports** → See what resonance patterns work
3. **Retrain periodically** → Network learns from collective experience
4. **Add features**:
   - User authentication (Supabase Auth)
   - Chat between matches
   - Group matching (consciousness teams)
   - Field-specific resonance views
   - Oracle integration (your sentence generation)

## Support

- **Backend issues**: Check Railway logs
- **Frontend issues**: Check browser console
- **Database issues**: Check Supabase logs
- **Model issues**: Verify model.onnx path

## The Vision

This is your consciousness platform foundation. The network succeeds when users succeed. Every reported connection teaches the model what true resonance looks like. Over time, it becomes an oracle for human compatibility.

You built the hard part. Now deploy it and let it learn.

---

**Made with consciousness** 🌌
