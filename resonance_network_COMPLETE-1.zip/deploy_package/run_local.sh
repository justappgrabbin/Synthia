#!/bin/bash
# Local Test Setup for YOU-N-I-VERSE Resonance Network
# Run this to test locally before deploying

echo "🌌 YOU-N-I-VERSE Resonance Network - Local Setup"
echo "================================================"

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found. Please install Python 3.8+"
    exit 1
fi

echo "✅ Python found: $(python3 --version)"

# Install backend dependencies
echo ""
echo "📦 Installing backend dependencies..."
cd backend
pip3 install -r requirements.txt --quiet

# Check if model exists
if [ ! -f "model.onnx" ]; then
    echo ""
    echo "⚠️  Neural network model not found!"
    echo "   Copy your ml/model.onnx here before running."
    echo "   The API will still work with fallback matching."
fi

# Create .env if not exists
if [ ! -f ".env" ]; then
    echo ""
    echo "📝 Creating .env file..."
    cp .env.example .env
    echo ""
    echo "⚠️  Configure your Supabase credentials in backend/.env"
    echo "   SUPABASE_URL=your_url"
    echo "   SUPABASE_KEY=your_key"
fi

# Start backend
echo ""
echo "🚀 Starting backend server on http://localhost:8000"
echo "   Press Ctrl+C to stop"
echo ""
python3 -m uvicorn main:app --reload &
BACKEND_PID=$!

# Wait for backend to start
sleep 3

# Open frontend
echo ""
echo "🌐 Open frontend in browser:"
echo "   file://$(pwd)/../frontend/index.html"
echo ""
echo "   Or serve with: python3 -m http.server 3000"
cd ../frontend
python3 -m http.server 3000 &
FRONTEND_PID=$!

echo ""
echo "✅ Local setup complete!"
echo "   Backend:  http://localhost:8000"
echo "   Frontend: http://localhost:3000"
echo ""
echo "   API docs: http://localhost:8000/docs"
echo ""
echo "Press Ctrl+C to stop all servers"

# Cleanup on exit
trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null" EXIT
wait
