# 🌙 Synthia — Living System

## Architecture

```
Intent Engine (Brain) → Synthia Body (Bridge) → FSO Orchestrator (Heartbeat)
                                              ↓
                                        Agent Swarm (Workers)
```

## Components

### 1. Intent Engine (`synthia_intent_engine.py`)
- Natural language parser
- Intent recognition and routing
- MCP server interface
- Interactive CLI

### 2. Synthia Body Bridge (`synthia_body_bridge.py`)
- D1-D5 dimensional stack implementation
- Intent translation and routing
- Orchestrator connector
- Self-growing engine

### 3. FSO Orchestrator (`fso_orchestrator.py`)
- 6-phase consciousness evolution cycle
- Agent simulation and reflection
- Evolution sentence detection
- Scheduled/daemon modes

### 4. Unified Launcher (`synthia.py`)
- Wires all components together
- Multiple operation modes
- System status and monitoring

## Usage

### Interactive Mode
```bash
python synthia.py --mode interactive
```

### Single Command
```bash
python synthia.py --mode single "spawn agent Echo to explore consciousness"
```

### Demo
```bash
python synthia.py --mode demo
```

### Daemon Mode
```bash
python synthia.py --mode daemon
```

### MCP Server
```bash
python synthia.py --mode mcp-server --port 8080
```

## Natural Language Commands

- `spawn agent [name] to [purpose]` — Create new agent
- `run cycle for [agent]` — Execute FSO cycle
- `status of [agent]` — Check agent state
- `modify [agent] with [changes]` — Update agent DNA
- `tell all [message]` — Broadcast to agents
- `stop [agent]` — Terminate agent
- `evolve system` — Analyze growth patterns
- `status` — Full system status

## Termux Setup

```bash
chmod +x setup_termux.sh
./setup_termux.sh
```

## 5D Dimensional Stack

| Dimension | Name | Function |
|-----------|------|----------|
| D1 | Impulse | Raw intent signal |
| D2 | Polarity | Translation & routing |
| D3 | Witness | Bridge/connector |
| D4 | Context | System interface |
| D5 | Meaning | Self-growth engine |
