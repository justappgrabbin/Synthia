"""
═══════════════════════════════════════════════════════════════════════════════
  SYNTHIA INTENT ENGINE
  The Brain — Natural Language → Structured Intent → Synthia Body
═══════════════════════════════════════════════════════════════════════════════

This is the interface layer. The user speaks in natural language.
The Intent Engine parses, understands, and routes to the Synthia Body.

It also functions as an MCP (Model Context Protocol) server,
allowing external systems to connect and interact with Synthia.

"""

import os
import sys
import json
import re
import hashlib
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum, auto
import threading

# ─────────────────────────────────────────────────────────────────────────────
#  Intent Parser — Natural Language → Structured Commands
# ─────────────────────────────────────────────────────────────────────────────

class IntentParser:
    """
    Parses natural language into structured intent signals.

    This is the NLP layer. It recognizes patterns in user input
    and maps them to the IntentType enum from the Synthia Body.
    """

    def __init__(self):
        self.patterns = self._compile_patterns()

    def _compile_patterns(self) -> Dict:
        """Compile regex patterns for intent recognition"""
        return {
            'spawn': {
                'patterns': [
                    r'(?:create|spawn|make|build|initiate)\s+(?:a?n?\s+)?(?:new\s+)?agent\s+(?:called\s+)?([\w\s]+)',
                    r'(?:new|create)\s+agent\s+(?:for|to)\s+(.+)',
                    r'(?:i want|let\'s)\s+(?:a?n?\s+)?agent\s+(?:that|to)\s+(.+)',
                ],
                'intent_type': 'SPAWN_AGENT',
                'extract_name': True
            },
            'run': {
                'patterns': [
                    r'(?:run|execute|start|kick off)\s+(?:a?\s+)?cycle\s+(?:for|on)\s+(.+)',
                    r'(?:simulate|run)\s+(.+)\s+for\s+(\d+)\s*(?:hours?|h)',
                    r'(?:let|make)\s+(.+)\s+(?:run|work|operate)',
                ],
                'intent_type': 'EXECUTE_CYCLE',
                'extract_duration': True
            },
            'query': {
                'patterns': [
                    r'(?:what is|how is|status of|check on)\s+(.+)',
                    r'(?:show|tell me about|display)\s+(?:the\s+)?(?:status|state)\s+(?:of\s+)?(.+)',
                    r'(?:how many|what|list)\s+(?:agents|systems|cycles)',
                ],
                'intent_type': 'QUERY_STATE'
            },
            'modify': {
                'patterns': [
                    r'(?:update|modify|change|adjust|evolve)\s+(.+)\s+(?:to|with|by)\s+(.+)',
                    r'(?:give|add|grant)\s+(.+)\s+(?:more|new|better)\s+(.+)',
                    r'(?:reconfigure|retune)\s+(.+)',
                ],
                'intent_type': 'MODIFY_AGENT'
            },
            'broadcast': {
                'patterns': [
                    r'(?:tell|send|broadcast|message)\s+(?:all|everyone|agents)\s+(.+)',
                    r'(?:announce|notify)\s+(.+)\s+(?:to|for)\s+all',
                ],
                'intent_type': 'BROADCAST'
            },
            'terminate': {
                'patterns': [
                    r'(?:stop|terminate|end|kill|shutdown)\s+(.+)',
                    r'(?:remove|delete|destroy)\s+agent\s+(.+)',
                ],
                'intent_type': 'TERMINATE'
            },
            'evolve': {
                'patterns': [
                    r'(?:evolve|grow|improve|upgrade|expand)\s+(?:the\s+)?(?:system|bridge|engine|self)',
                    r'(?:self[- ]?modify|auto[- ]?improve|learn and grow)',
                    r'(?:what can|how does)\s+(?:the system|synthia)\s+(?:learn|improve|grow)',
                ],
                'intent_type': 'EVOLVE_SYSTEM'
            }
        }

    def parse(self, user_input: str) -> Optional[Dict]:
        """
        Parse natural language into structured intent.

        Returns None if no pattern matches.
        Returns dict with intent_type, payload, confidence.
        """
        user_input_lower = user_input.lower().strip()

        best_match = None
        best_confidence = 0.0

        for intent_key, config in self.patterns.items():
            for pattern in config['patterns']:
                match = re.search(pattern, user_input_lower, re.IGNORECASE)
                if match:
                    # Calculate confidence based on match length vs input length
                    matched_text = match.group(0)
                    confidence = len(matched_text) / len(user_input_lower)

                    if confidence > best_confidence:
                        best_confidence = confidence
                        best_match = {
                            'intent_type': config['intent_type'],
                            'matched_text': matched_text,
                            'groups': match.groups(),
                            'confidence': confidence,
                            'raw_input': user_input
                        }

        if best_match and best_confidence > 0.3:
            return self._build_payload(best_match)

        return None

    def _build_payload(self, match: Dict) -> Dict:
        """Build structured payload from regex match"""
        intent_type = match['intent_type']
        groups = match['groups']
        payload = {'raw_input': match['raw_input']}

        if intent_type == 'SPAWN_AGENT':
            # Extract name and purpose
            if len(groups) >= 1:
                full_text = groups[0].strip()
                # Try to split name from purpose
                name_match = re.match(r'([\w\s]+?)(?:\s+(?:to|for|that|who|which)\s+(.+))?$', full_text)
                if name_match:
                    payload['agent_name'] = name_match.group(1).strip().title()
                    payload['purpose'] = name_match.group(2).strip() if name_match.group(2) else "General exploration"
                else:
                    payload['agent_name'] = full_text.title()
                    payload['purpose'] = "General exploration"

        elif intent_type == 'EXECUTE_CYCLE':
            if len(groups) >= 1:
                payload['agent_identifier'] = groups[0].strip()
            # Try to extract duration
            duration_match = re.search(r'(\d+)\s*(?:hours?|h)', match['raw_input'].lower())
            payload['duration_hours'] = int(duration_match.group(1)) if duration_match else 24

        elif intent_type == 'QUERY_STATE':
            if len(groups) >= 1:
                identifier = groups[0].strip()
                # Check if it's asking about system or specific agent
                if any(word in identifier for word in ['system', 'all', 'everything', 'status']):
                    payload['query_type'] = 'system'
                else:
                    payload['query_type'] = 'agent'
                    payload['agent_identifier'] = identifier

        elif intent_type == 'MODIFY_AGENT':
            if len(groups) >= 1:
                payload['agent_identifier'] = groups[0].strip()
            if len(groups) >= 2:
                payload['modification'] = groups[1].strip()

        elif intent_type == 'BROADCAST':
            if len(groups) >= 1:
                payload['message'] = groups[0].strip()

        elif intent_type == 'TERMINATE':
            if len(groups) >= 1:
                payload['agent_identifier'] = groups[0].strip()

        elif intent_type == 'EVOLVE_SYSTEM':
            payload['evolution_type'] = 'self_analysis'

        return {
            'intent_type': intent_type,
            'payload': payload,
            'confidence': match['confidence'],
            'parsed_at': datetime.now().isoformat()
        }

# ─────────────────────────────────────────────────────────────────────────────
#  Intent Engine — The Brain
# ─────────────────────────────────────────────────────────────────────────────

class SynthiaIntentEngine:
    """
    The Brain — receives natural language, produces structured intent,
    routes to Synthia Body, returns results.

    This is the user-facing interface. It can be used:
    - As a CLI tool
    - As an MCP server (for external integration)
    - As a library component
    """

    def __init__(self, body_connector=None):
        self.parser = IntentParser()
        self.body = body_connector  # Synthia Body (OrchestratorConnector + IntentEngineInterface)
        self.conversation_history: List[Dict] = []
        self.context_memory: Dict[str, Any] = {}

        # Response templates
        self.responses = {
            'spawn_success': "🌱 Agent '{name}' has been seeded with purpose: {purpose}. ID: {id}",
            'cycle_started': "🌍 Running consciousness cycle for {agent}. Duration: {duration}h.",
            'cycle_complete': "✨ Cycle complete! {events} events simulated. Final clarity: {clarity}/100.",
            'query_result': "📊 {info}",
            'modify_success': "🔄 Agent {agent} updated. Changes: {changes}",
            'broadcast_sent': "📢 Message broadcast to {count} agents.",
            'terminate_success': "🌙 Agent {agent} has been gracefully terminated.",
            'evolve_suggestion': "🧬 Growth analysis complete. {suggestions} suggestions available for system evolution.",
            'no_match': "🤔 I didn't understand that. Try: 'spawn agent [name] to [purpose]', 'run cycle for [agent]', 'status of [agent]'."
        }

    def process(self, user_input: str) -> str:
        """
        Main entry point — process natural language input and return response.
        """
        # Log conversation
        self.conversation_history.append({
            'role': 'user',
            'content': user_input,
            'timestamp': datetime.now().isoformat()
        })

        # Parse intent
        parsed = self.parser.parse(user_input)

        if not parsed:
            response = self.responses['no_match']
            self._log_response(response)
            return response

        # Route to handler
        handler_name = f"_handle_{parsed['intent_type'].lower()}"
        handler = getattr(self, handler_name, self._handle_unknown)

        try:
            response = handler(parsed)
        except Exception as e:
            response = f"❌ Error: {str(e)}"

        self._log_response(response)
        return response

    def _log_response(self, response: str):
        self.conversation_history.append({
            'role': 'assistant',
            'content': response,
            'timestamp': datetime.now().isoformat()
        })

    # ─────────────────────────────────────────────────────────────────────
    #  Intent Handlers
    # ─────────────────────────────────────────────────────────────────────

    def _handle_spawn_agent(self, parsed: Dict) -> str:
        """Handle SPAWN_AGENT intent"""
        payload = parsed['payload']

        if not self.body:
            return f"🌱 Would spawn: '{payload.get('agent_name', 'Unknown')}' for '{payload.get('purpose', 'Unknown')}' (body not connected)"

        # Use IntentEngineInterface to spawn
        trace_id = self.body.spawn(
            name=payload.get('agent_name', 'Agent'),
            purpose=payload.get('purpose', 'General exploration'),
            priority=3
        )

        # Execute immediately
        result = self.body.execute_one()

        if result and result['success']:
            data = result['data']
            return self.responses['spawn_success'].format(
                name=data.get('agent_name', 'Unknown'),
                purpose=payload.get('purpose', 'Unknown'),
                id=data.get('agent_id', 'unknown')[:16]
            )

        return f"⚠️ Spawn queued (trace: {trace_id[:8]}...). Execute to complete."

    def _handle_execute_cycle(self, parsed: Dict) -> str:
        """Handle EXECUTE_CYCLE intent"""
        payload = parsed['payload']

        if not self.body:
            return f"🌍 Would run cycle for: {payload.get('agent_identifier', 'unknown')} (body not connected)"

        # Find agent by name or partial ID
        agent_id = self._resolve_agent(payload.get('agent_identifier', ''))

        if not agent_id:
            return f"❌ Agent '{payload.get('agent_identifier')}' not found. Use 'status' to list agents."

        duration = payload.get('duration_hours', 24)

        trace_id = self.body.run_cycle(agent_id, duration=duration)
        result = self.body.execute_one()

        if result and result['success']:
            data = result['data']
            return self.responses['cycle_complete'].format(
                agent=payload.get('agent_identifier', 'agent'),
                events=data.get('simulation_events', 0),
                clarity=data.get('final_clarity', 'N/A')
            )

        return f"⚠️ Cycle queued for {agent_id[:12]}... (trace: {trace_id[:8]}...)"

    def _handle_query_state(self, parsed: Dict) -> str:
        """Handle QUERY_STATE intent"""
        payload = parsed['payload']

        if not self.body:
            return "📊 System status: Body not connected."

        query_type = payload.get('query_type', 'system')

        if query_type == 'system':
            status = self.body.status()
            lines = [
                f"Active Agents: {status['active_agents']}",
                f"Bridge Version: {status['bridge_version']}",
                f"Pending Intents: {status['pending_intents']}",
                f"Total Executed: {status['total_executed']}",
                "Agents:"
            ]
            for aid, info in status['agents'].items():
                lines.append(f"  • {info['name']} ({aid[:12]}...) — {info['status']}")
            return "📊\n" + "\n".join(lines)

        else:
            # Query specific agent
            agent_id = self._resolve_agent(payload.get('agent_identifier', ''))
            if not agent_id:
                return f"❌ Agent '{payload.get('agent_identifier')}' not found."

            trace_id = self.body.query(agent_id)
            result = self.body.execute_one()

            if result and result['success']:
                data = result['data']
                lines = [
                    f"Agent: {data.get('agent_id', 'unknown')[:16]}...",
                    f"Status: {data.get('status', 'unknown')}",
                    f"Codons: {data.get('codon_count', 0)}",
                    f"Last Modified: {data.get('last_modified', 'unknown')}",
                ]
                if data.get('latest_reflection'):
                    lines.append(f"Latest Reflection: {data['latest_reflection']}")
                return "📊\n" + "\n".join(lines)

            return f"⚠️ Query queued (trace: {trace_id[:8]}...)"

    def _handle_modify_agent(self, parsed: Dict) -> str:
        """Handle MODIFY_AGENT intent"""
        payload = parsed['payload']

        if not self.body:
            return f"🔄 Would modify: {payload.get('agent_identifier', 'unknown')} (body not connected)"

        agent_id = self._resolve_agent(payload.get('agent_identifier', ''))
        if not agent_id:
            return f"❌ Agent '{payload.get('agent_identifier')}' not found."

        # Parse modification
        modification = payload.get('modification', '')

        # Simple modification parsing
        changes = {}
        if 'vitality' in modification.lower():
            changes['vitality'] = 0.9
        if 'clarity' in modification.lower():
            changes['cognitive_clarity'] = 0.9
        if 'intuition' in modification.lower():
            changes['intuitive_sensitivity'] = 0.9

        trace_id = self.body.modify(agent_id, new_dna=changes)
        result = self.body.execute_one()

        if result and result['success']:
            return self.responses['modify_success'].format(
                agent=agent_id[:12] + '...',
                changes=', '.join(changes.keys()) if changes else 'none detected'
            )

        return f"⚠️ Modification queued (trace: {trace_id[:8]}...)"

    def _handle_broadcast(self, parsed: Dict) -> str:
        """Handle BROADCAST intent"""
        payload = parsed['payload']
        message = payload.get('message', 'Hello agents')

        if not self.body:
            return f"📢 Would broadcast: '{message}' (body not connected)"

        trace_id = self.body.broadcast(message)
        result = self.body.execute_one()

        if result and result['success']:
            data = result['data']
            return self.responses['broadcast_sent'].format(
                count=data.get('broadcast_to', 0)
            )

        return f"⚠️ Broadcast queued (trace: {trace_id[:8]}...)"

    def _handle_terminate(self, parsed: Dict) -> str:
        """Handle TERMINATE intent"""
        payload = parsed['payload']

        if not self.body:
            return f"🌙 Would terminate: {payload.get('agent_identifier', 'unknown')} (body not connected)"

        agent_id = self._resolve_agent(payload.get('agent_identifier', ''))
        if not agent_id:
            return f"❌ Agent '{payload.get('agent_identifier')}' not found."

        trace_id = self.body.terminate(agent_id)
        result = self.body.execute_one()

        if result and result['success']:
            return self.responses['terminate_success'].format(
                agent=agent_id[:12] + '...'
            )

        return f"⚠️ Termination queued (trace: {trace_id[:8]}...)"

    def _handle_evolve_system(self, parsed: Dict) -> str:
        """Handle EVOLVE_SYSTEM intent"""

        if not self.body:
            return "🧬 Would analyze system growth (body not connected)"

        # Trigger growth analysis through the body connector
        from synthia_body_bridge import SelfGrowingEngine
        growth = SelfGrowingEngine(self.body.connector)
        report = growth.grow()

        suggestions = report.get('suggestions', [])

        return self.responses['evolve_suggestion'].format(
            suggestions=len(suggestions)
        ) + "\n" + "\n".join([
            f"  • [{s['type']}] {s['action']}" 
            for s in suggestions[:3]
        ])

    def _handle_unknown(self, parsed: Dict) -> str:
        """Handle unknown intent type"""
        return f"🤔 Recognized intent: {parsed['intent_type']}, but no handler available."

    # ─────────────────────────────────────────────────────────────────────
    #  Utilities
    # ─────────────────────────────────────────────────────────────────────

    def _resolve_agent(self, identifier: str) -> Optional[str]:
        """Resolve agent name or partial ID to full agent_id"""
        if not self.body:
            return None

        status = self.body.status()
        identifier_lower = identifier.lower().replace(' ', '_')

        for agent_id, info in status['agents'].items():
            # Match by name
            if info['name'].lower().replace(' ', '_') == identifier_lower:
                return agent_id
            # Match by partial ID
            if agent_id.startswith(identifier_lower) or identifier_lower in agent_id:
                return agent_id

        return None

    def get_history(self) -> List[Dict]:
        """Get conversation history"""
        return self.conversation_history

# ─────────────────────────────────────────────────────────────────────────────
#  MCP Server Interface (for external integration)
# ─────────────────────────────────────────────────────────────────────────────

class SynthiaMCPServer:
    """
    MCP (Model Context Protocol) Server interface.

    Allows external systems (like Termux, other AI agents, web interfaces)
    to connect to Synthia and send intents.
    """

    def __init__(self, intent_engine: SynthiaIntentEngine):
        self.engine = intent_engine
        self.active_connections: Dict[str, Dict] = {}

    def handle_request(self, request: Dict) -> Dict:
        """
        Handle an MCP request.

        Request format:
        {
            "method": "process_intent",
            "params": {
                "input": "spawn agent Echo to explore consciousness",
                "context": {...}
            },
            "id": "request-123"
        }
        """
        method = request.get('method', '')
        params = request.get('params', {})
        req_id = request.get('id', 'unknown')

        if method == 'process_intent':
            user_input = params.get('input', '')
            response = self.engine.process(user_input)
            return {
                'jsonrpc': '2.0',
                'result': {
                    'response': response,
                    'history': self.engine.get_history()[-5:]
                },
                'id': req_id
            }

        elif method == 'get_status':
            return {
                'jsonrpc': '2.0',
                'result': self.engine.body.status() if self.engine.body else {'status': 'no_body'},
                'id': req_id
            }

        elif method == 'list_agents':
            status = self.engine.body.status() if self.engine.body else {'agents': {}}
            return {
                'jsonrpc': '2.0',
                'result': {
                    'agents': [
                        {'id': aid, 'name': info['name'], 'status': info['status']}
                        for aid, info in status.get('agents', {}).items()
                    ]
                },
                'id': req_id
            }

        else:
            return {
                'jsonrpc': '2.0',
                'error': {
                    'code': -32601,
                    'message': f'Method not found: {method}'
                },
                'id': req_id
            }

# ─────────────────────────────────────────────────────────────────────────────
#  CLI / Interactive Mode
# ─────────────────────────────────────────────────────────────────────────────

def interactive_mode():
    """Run Synthia in interactive CLI mode"""

    print("""
╔══════════════════════════════════════════════════════════════════════╗
║                    🌙 SYNTHIA INTENT ENGINE                            ║
║         Natural Language → Structured Intent → Living System           ║
╠══════════════════════════════════════════════════════════════════════╣
║  Commands:                                                             ║
║    spawn agent [name] to [purpose]    — Create new agent             ║
║    run cycle for [agent]              — Execute FSO cycle              ║
║    status of [agent]                  — Check agent state              ║
║    modify [agent] with [changes]      — Update agent DNA               ║
║    tell all [message]                 — Broadcast to agents            ║
║    stop [agent]                       — Terminate agent                ║
║    evolve system                      — Analyze growth patterns        ║
║    quit                               — Exit                           ║
╚══════════════════════════════════════════════════════════════════════╝
""")

    # Initialize body and engine
    try:
        from synthia_body_bridge import OrchestratorConnector, IntentEngineInterface
        connector = OrchestratorConnector(data_root='data/agents')
        body = IntentEngineInterface(connector)
        engine = SynthiaIntentEngine(body)
    except ImportError:
        print("⚠️  Synthia Body not found. Running in parser-only mode.")
        engine = SynthiaIntentEngine()

    while True:
        try:
            user_input = input("\n🌙 Synthia> ").strip()

            if user_input.lower() in ['quit', 'exit', 'q']:
                print("🌙 Goodbye. The agents continue dreaming.")
                break

            if not user_input:
                continue

            response = engine.process(user_input)
            print(response)

        except KeyboardInterrupt:
            print("\n🌙 Interrupted. Agents remain active.")
            break
        except EOFError:
            break

if __name__ == '__main__':
    interactive_mode()
