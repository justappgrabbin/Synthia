"""
═══════════════════════════════════════════════════════════════════════════════
  SYNTHIA BODY: Intent-to-FSO Bridge
  The living tissue connecting Intent Engine (brain) to FSO Orchestrator (heartbeat)
═══════════════════════════════════════════════════════════════════════════════

Architecture:
  Intent Engine (brain) → Synthia Body (bridge) → FSO Orchestrator (heartbeat)
                        ↓
                  Agent Swarm (workers)

This module:
  1. Receives intent signals from the Intent Engine
  2. Translates intent into agent DNA / codon seeds
  3. Spawns/manages agents in the FSO ecosystem
  4. Returns execution results back to the Intent Engine
  5. Self-modifies based on execution outcomes

"""

import os
import sys
import json
import time
import hashlib
import asyncio
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
import threading
import queue

# ─────────────────────────────────────────────────────────────────────────────
#  D1: IMPULSE — The raw signal from the Intent Engine
# ─────────────────────────────────────────────────────────────────────────────

class IntentType(Enum):
    """Types of intent signals the brain can send"""
    SPAWN_AGENT = auto()        # Create new autonomous agent
    MODIFY_AGENT = auto()       # Update existing agent DNA
    QUERY_STATE = auto()        # Ask about agent status
    INJECT_CODON = auto()       # Push new codon data
    EXECUTE_CYCLE = auto()      # Run one FSO cycle
    EVOLVE_SYSTEM = auto()      # Self-modify the bridge
    BROADCAST = auto()          # Message all agents
    TERMINATE = auto()          # End agent lifecycle

@dataclass
class IntentSignal:
    """
    D1 → D2: Raw impulse from the Intent Engine

    This is the fundamental unit of communication between brain and body.
    Every action starts as an IntentSignal.
    """
    intent_type: IntentType
    payload: Dict[str, Any] = field(default_factory=dict)
    source: str = "intent_engine"   # Who sent this
    priority: int = 5               # 1-10, lower = more urgent
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    trace_id: str = field(default_factory=lambda: hashlib.sha256(
        f"{time.time()}{os.urandom(16)}".encode()).hexdigest()[:16])

    # Dimensional metadata (your 5D stack)
    dimensional_signature: Dict[str, float] = field(default_factory=lambda: {
        'd1_impulse': 1.0,
        'd2_polarity': 0.5,
        'd3_witness': 0.0,
        'd4_context': 0.0,
        'd5_meaning': 0.0
    })

    def to_dict(self) -> Dict:
        return {
            'intent_type': self.intent_type.name,
            'payload': self.payload,
            'source': self.source,
            'priority': self.priority,
            'timestamp': self.timestamp,
            'trace_id': self.trace_id,
            'dimensional_signature': self.dimensional_signature
        }

# ─────────────────────────────────────────────────────────────────────────────
#  D2: POLARITY — Intent Translation & Routing
# ─────────────────────────────────────────────────────────────────────────────

class IntentTranslator:
    """
    D2: The polarity layer — translates raw intent into actionable commands.

    This is where intent becomes structured. It decides:
    - What agent type to spawn
    - What DNA parameters to use
    - Which FSO phase to trigger
    - How to route the result back
    """

    def __init__(self):
        self.translation_rules = self._load_translation_rules()
        self.agent_templates = self._load_agent_templates()

    def _load_translation_rules(self) -> Dict:
        """Load how different intents map to FSO operations"""
        return {
            'SPAWN_AGENT': {
                'required_payload': ['agent_name', 'purpose'],
                'optional_payload': ['personality_profile', 'initial_codons', 'autonomy_level'],
                'fso_phase': 'phase_3_translation',
                'creates_agent': True
            },
            'MODIFY_AGENT': {
                'required_payload': ['agent_id'],
                'optional_payload': ['new_dna', 'codon_updates', 'evolution_trigger'],
                'fso_phase': 'phase_6_evolution',
                'creates_agent': False
            },
            'EXECUTE_CYCLE': {
                'required_payload': ['agent_id'],
                'optional_payload': ['duration_hours', 'timestep_minutes', 'focus_areas'],
                'fso_phase': 'phase_4_simulation',
                'creates_agent': False
            },
            'EVOLVE_SYSTEM': {
                'required_payload': ['evolution_type'],
                'optional_payload': ['target_module', 'new_capability', 'rollback_point'],
                'fso_phase': 'self_modification',
                'creates_agent': False
            }
        }

    def _load_agent_templates(self) -> Dict:
        """Pre-configured agent archetypes based on Human Design gates"""
        return {
            'explorer': {
                'vitality': 0.8,
                'cognitive_clarity': 0.6,
                'emotional_volatility': 0.4,
                'intuitive_sensitivity': 0.7,
                'extroversion': 0.8,
                'default_action': 'explore'
            },
            'scholar': {
                'vitality': 0.4,
                'cognitive_clarity': 0.9,
                'emotional_volatility': 0.2,
                'intuitive_sensitivity': 0.5,
                'extroversion': 0.3,
                'default_action': 'study'
            },
            'mediator': {
                'vitality': 0.5,
                'cognitive_clarity': 0.7,
                'emotional_volatility': 0.6,
                'intuitive_sensitivity': 0.8,
                'extroversion': 0.5,
                'default_action': 'meditate'
            },
            'guardian': {
                'vitality': 0.7,
                'cognitive_clarity': 0.5,
                'emotional_volatility': 0.3,
                'intuitive_sensitivity': 0.9,
                'extroversion': 0.4,
                'default_action': 'observe'
            }
        }

    def translate(self, signal: IntentSignal) -> Dict[str, Any]:
        """
        Translate an IntentSignal into FSO-executable command structure.

        Returns a command dict that the OrchestratorConnector can execute.
        """
        intent_name = signal.intent_type.name
        rules = self.translation_rules.get(intent_name, {})

        # Validate required payload
        for required in rules.get('required_payload', []):
            if required not in signal.payload:
                raise ValueError(f"Intent {intent_name} requires payload key: {required}")

        # Build translated command
        command = {
            'intent_type': intent_name,
            'trace_id': signal.trace_id,
            'priority': signal.priority,
            'fso_phase': rules.get('fso_phase', 'unknown'),
            'creates_agent': rules.get('creates_agent', False),
            'payload': signal.payload,
            'dimensional_signature': signal.dimensional_signature,
            'timestamp': signal.timestamp
        }

        # Special handling: SPAWN_AGENT needs DNA generation
        if intent_name == 'SPAWN_AGENT':
            command['agent_dna'] = self._generate_agent_dna(signal)

        # Special handling: EVOLVE_SYSTEM needs self-modification plan
        if intent_name == 'EVOLVE_SYSTEM':
            command['modification_plan'] = self._generate_modification_plan(signal)

        return command

    def _generate_agent_dna(self, signal: IntentSignal) -> Dict:
        """Generate agent DNA from intent payload"""
        payload = signal.payload

        # Use template if specified
        template_name = payload.get('template', 'explorer')
        template = self.agent_templates.get(template_name, self.agent_templates['explorer'])

        # Override with explicit personality profile
        profile = payload.get('personality_profile', {})

        dna = {
            'agent_name': payload['agent_name'],
            'purpose': payload['purpose'],
            'created_at': datetime.now().isoformat(),
            'template': template_name,
            'personality': {
                'vitality': profile.get('vitality', template['vitality']),
                'cognitive_clarity': profile.get('cognitive_clarity', template['cognitive_clarity']),
                'emotional_volatility': profile.get('emotional_volatility', template['emotional_volatility']),
                'intuitive_sensitivity': profile.get('intuitive_sensitivity', template['intuitive_sensitivity']),
                'extroversion': profile.get('extroversion', template['extroversion'])
            },
            'autonomy_level': payload.get('autonomy_level', 0.7),
            'initial_codons': payload.get('initial_codons', self._generate_default_codons()),
            'dimensional_alignment': signal.dimensional_signature
        }

        return dna

    def _generate_default_codons(self) -> List[Dict]:
        """Generate baseline codons for new agent"""
        return [
            {'gate': 1, 'line': 1, 'role': 'initiator', 'activation': 0.8},
            {'gate': 2, 'line': 4, 'role': 'responder', 'activation': 0.6},
            {'gate': 10, 'line': 5, 'role': 'behavior', 'activation': 0.7},
            {'gate': 7, 'line': 1, 'role': 'direction', 'activation': 0.5}
        ]

    def _generate_modification_plan(self, signal: IntentSignal) -> Dict:
        """Generate self-modification plan for EVOLVE_SYSTEM intent"""
        payload = signal.payload

        return {
            'target_module': payload.get('target_module', 'synthia_body'),
            'evolution_type': payload['evolution_type'],
            'new_capability': payload.get('new_capability', 'unknown'),
            'rollback_point': payload.get('rollback_point', 'HEAD'),
            'safety_checks': [
                'backup_current_state',
                'validate_syntax',
                'test_in_isolation',
                'verify_no_regression'
            ],
            'approval_required': payload.get('approval_required', True)
        }

# ─────────────────────────────────────────────────────────────────────────────
#  D3: WITNESS — The Orchestrator Connector (the bridge itself)
# ─────────────────────────────────────────────────────────────────────────────

class OrchestratorConnector:
    """
    D3: The witness/observer-node — the actual bridge between Intent Engine and FSO.

    This is the coordinate where the universe becomes locally self-measuring.
    It watches both sides, maintains state, and ensures coherence.

    Without D3, there is structure but no stabilized meaning.
    """

    def __init__(self, data_root: str = 'data/agents'):
        self.data_root = Path(data_root)
        self.data_root.mkdir(parents=True, exist_ok=True)

        # State tracking
        self.active_agents: Dict[str, Dict] = {}
        self.intent_log: List[Dict] = []
        self.execution_log: List[Dict] = []

        # Translation layer
        self.translator = IntentTranslator()

        # FSO integration (lazy import to avoid circular deps)
        self._fso_orchestrator = None

        # Event queue for async processing
        self.intent_queue = queue.PriorityQueue()
        self.result_callbacks: Dict[str, Callable] = {}

        # Self-modification tracking
        self.modification_history: List[Dict] = []
        self.current_version = self._get_version()

    def _get_version(self) -> str:
        """Get current version from file hash"""
        try:
            with open(__file__, 'rb') as f:
                return hashlib.sha256(f.read()).hexdigest()[:12]
        except:
            return "unknown"

    @property
    def fso_orchestrator(self):
        """Lazy initialization of FSO orchestrator"""
        if self._fso_orchestrator is None:
            # Import FSO orchestrator
            try:
                sys.path.append(os.path.dirname(os.path.abspath(__file__)))
                from fso_orchestrator import FSOOrchestrator
                self._fso_orchestrator = FSOOrchestrator(verbose=True)
            except ImportError as e:
                print(f"⚠️ FSO Orchestrator not available: {e}")
                self._fso_orchestrator = None
        return self._fso_orchestrator

    # ─────────────────────────────────────────────────────────────────────
    #  Core Bridge Operations
    # ─────────────────────────────────────────────────────────────────────

    def ingest_intent(self, signal: IntentSignal) -> str:
        """
        D1→D2→D3: Receive intent from brain, translate, queue for execution.

        Returns a trace_id that can be used to poll for results.
        """
        # Log the intent
        self.intent_log.append({
            'trace_id': signal.trace_id,
            'intent_type': signal.intent_type.name,
            'timestamp': signal.timestamp,
            'status': 'received'
        })

        # Translate intent to command
        try:
            command = self.translator.translate(signal)
            command['status'] = 'translated'
        except ValueError as e:
            self._update_intent_status(signal.trace_id, 'translation_failed', str(e))
            return signal.trace_id

        # Queue by priority (lower number = higher priority)
        self.intent_queue.put((signal.priority, signal.trace_id, command))
        self._update_intent_status(signal.trace_id, 'queued')

        return signal.trace_id

    def execute_next(self) -> Optional[Dict]:
        """
        D3: Execute the next queued intent.

        This is the beating heart of the bridge — where intent becomes action.
        """
        if self.intent_queue.empty():
            return None

        priority, trace_id, command = self.intent_queue.get()

        self._update_intent_status(trace_id, 'executing')

        result = {
            'trace_id': trace_id,
            'intent_type': command['intent_type'],
            'timestamp': datetime.now().isoformat(),
            'success': False,
            'data': {}
        }

        try:
            # Route to appropriate handler
            handler = getattr(self, f'_handle_{command["intent_type"].lower()}', None)

            if handler:
                execution_result = handler(command)
                result['success'] = True
                result['data'] = execution_result
            else:
                result['error'] = f"No handler for intent type: {command['intent_type']}"

        except Exception as e:
            result['error'] = str(e)
            result['traceback'] = self._get_traceback()

        # Log execution
        self.execution_log.append(result)
        self._update_intent_status(
            trace_id, 
            'completed' if result['success'] else 'failed',
            result.get('error')
        )

        # Trigger callback if registered
        if trace_id in self.result_callbacks:
            callback = self.result_callbacks.pop(trace_id)
            try:
                callback(result)
            except Exception as e:
                print(f"Callback error for {trace_id}: {e}")

        return result

    def get_result(self, trace_id: str) -> Optional[Dict]:
        """Poll for result of a specific intent execution"""
        for entry in self.execution_log:
            if entry['trace_id'] == trace_id:
                return entry

        # Check if still queued
        for item in list(self.intent_queue.queue):
            if item[1] == trace_id:
                return {'trace_id': trace_id, 'status': 'queued', 'position': list(self.intent_queue.queue).index(item)}

        return None

    # ─────────────────────────────────────────────────────────────────────
    #  Intent Handlers (the actual work)
    # ─────────────────────────────────────────────────────────────────────

    def _handle_spawn_agent(self, command: Dict) -> Dict:
        """Create a new agent in the FSO ecosystem"""
        dna = command['agent_dna']
        agent_name = dna['agent_name']

        # Generate agent_id
        agent_id = f"{agent_name.lower().replace(' ', '_')}_{hashlib.sha256(
            f'{agent_name}{time.time()}'.encode()).hexdigest()[:8]}"

        # Create agent directory structure
        agent_dir = self.data_root / agent_id
        agent_dir.mkdir(parents=True, exist_ok=True)
        (agent_dir / 'history').mkdir(exist_ok=True)

        # Save codon seed
        codon_seed = {
            'agent_id': agent_id,
            'agent_name': agent_name,
            'created_at': dna['created_at'],
            'agent_dna': dna['personality'],
            'codons': dna['initial_codons'],
            'autonomy_level': dna['autonomy_level'],
            'purpose': dna['purpose'],
            'dimensional_alignment': dna['dimensional_alignment'],
            'status': 'active'
        }

        seed_path = agent_dir / 'codon_seed.json'
        with open(seed_path, 'w') as f:
            json.dump(codon_seed, f, indent=2)

        # Save initial codon_output (for Phase 3 to pick up)
        codon_output = {
            'agent_id': agent_id,
            'agent_dna': dna['personality'],
            'codons': dna['initial_codons'],
            'translation_timestamp': datetime.now().isoformat()
        }

        output_path = agent_dir / 'codon_output.json'
        with open(output_path, 'w') as f:
            json.dump(codon_output, f, indent=2)

        # Track active agent
        self.active_agents[agent_id] = {
            'name': agent_name,
            'created_at': dna['created_at'],
            'purpose': dna['purpose'],
            'status': 'active',
            'last_cycle': None
        }

        return {
            'agent_id': agent_id,
            'agent_name': agent_name,
            'seed_path': str(seed_path),
            'output_path': str(output_path),
            'dna': dna['personality'],
            'message': f"Agent '{agent_name}' spawned with ID: {agent_id}"
        }

    def _handle_execute_cycle(self, command: Dict) -> Dict:
        """Run a full FSO cycle for an agent"""
        agent_id = command['payload']['agent_id']
        duration = command['payload'].get('duration_hours', 24)
        timestep = command['payload'].get('timestep_minutes', 60)

        # Check agent exists
        agent_dir = self.data_root / agent_id
        if not agent_dir.exists():
            raise ValueError(f"Agent {agent_id} not found")

        # Run FSO orchestration
        if self.fso_orchestrator:
            fso_result = self.fso_orchestrator.orchestrate_agent(
                agent_id, 
                duration_hours=duration,
                timestep_minutes=timestep
            )

            # Update agent tracking
            self.active_agents[agent_id]['last_cycle'] = datetime.now().isoformat()

            return {
                'agent_id': agent_id,
                'fso_result': fso_result,
                'cycle_duration': fso_result.get('cycle_duration_seconds', 0),
                'simulation_events': len(fso_result.get('simulation_log', {}).get('events', [])),
                'reflection_path': fso_result.get('reflection_path'),
                'new_sentences': fso_result.get('sentence_check', {}).get('new_sentences_count', 0)
            }
        else:
            # Fallback: simulate basic cycle
            return self._simulate_fallback_cycle(agent_id, duration, timestep)

    def _handle_modify_agent(self, command: Dict) -> Dict:
        """Modify an existing agent's DNA or codons"""
        agent_id = command['payload']['agent_id']

        agent_dir = self.data_root / agent_id
        if not agent_dir.exists():
            raise ValueError(f"Agent {agent_id} not found")

        # Load current seed
        seed_path = agent_dir / 'codon_seed.json'
        with open(seed_path, 'r') as f:
            seed = json.load(f)

        # Apply modifications
        new_dna = command['payload'].get('new_dna', {})
        codon_updates = command['payload'].get('codon_updates', [])

        if new_dna:
            seed['agent_dna'].update(new_dna)

        if codon_updates:
            seed['codons'] = codon_updates

        # Save updated seed
        seed['last_modified'] = datetime.now().isoformat()
        with open(seed_path, 'w') as f:
            json.dump(seed, f, indent=2)

        # Also update codon_output for next cycle
        output_path = agent_dir / 'codon_output.json'
        if output_path.exists():
            with open(output_path, 'r') as f:
                output = json.load(f)
            output['agent_dna'] = seed['agent_dna']
            output['codons'] = seed['codons']
            output['translation_timestamp'] = datetime.now().isoformat()
            with open(output_path, 'w') as f:
                json.dump(output, f, indent=2)

        return {
            'agent_id': agent_id,
            'modifications_applied': list(new_dna.keys()) if new_dna else [],
            'codons_updated': len(codon_updates),
            'seed_path': str(seed_path)
        }

    def _handle_query_state(self, command: Dict) -> Dict:
        """Query the current state of an agent or the system"""
        agent_id = command['payload'].get('agent_id')

        if agent_id:
            # Query specific agent
            agent_dir = self.data_root / agent_id
            if not agent_dir.exists():
                return {'error': f'Agent {agent_id} not found'}

            # Load latest data
            seed_path = agent_dir / 'codon_seed.json'
            with open(seed_path, 'r') as f:
                seed = json.load(f)

            # Find latest reflection
            history_dir = agent_dir / 'history'
            reflections = list(history_dir.glob('reflection_*.txt')) if history_dir.exists() else []
            latest_reflection = max(reflections, key=lambda p: p.stat().st_mtime) if reflections else None

            return {
                'agent_id': agent_id,
                'status': seed.get('status', 'unknown'),
                'dna': seed['agent_dna'],
                'codon_count': len(seed.get('codons', [])),
                'last_modified': seed.get('last_modified', seed.get('created_at')),
                'latest_reflection': str(latest_reflection) if latest_reflection else None,
                'active': agent_id in self.active_agents
            }
        else:
            # Query system state
            return {
                'active_agents': len(self.active_agents),
                'agent_list': list(self.active_agents.keys()),
                'pending_intents': self.intent_queue.qsize(),
                'total_executed': len(self.execution_log),
                'bridge_version': self.current_version,
                'modification_count': len(self.modification_history)
            }

    def _handle_evolve_system(self, command: Dict) -> Dict:
        """
        D5: Self-modification — the bridge edits its own code.

        This is the most dangerous and most powerful operation.
        It requires the bridge to understand its own structure and modify it safely.
        """
        plan = command['modification_plan']

        if plan['approval_required']:
            # In a real system, this would wait for human approval
            # For now, we log and require manual execution
            return {
                'status': 'pending_approval',
                'modification_plan': plan,
                'message': 'Self-modification requires approval. Review the plan and confirm.',
                'safety_checks': plan['safety_checks']
            }

        # Execute modification (simplified — real version would be more complex)
        self.modification_history.append({
            'timestamp': datetime.now().isoformat(),
            'plan': plan,
            'trace_id': command['trace_id']
        })

        return {
            'status': 'modification_logged',
            'modification_count': len(self.modification_history),
            'message': 'System evolution plan recorded. Execute manually after review.'
        }

    def _handle_broadcast(self, command: Dict) -> Dict:
        """Broadcast a message to all active agents"""
        message = command['payload'].get('message', '')

        results = []
        for agent_id in self.active_agents:
            # In a real system, this would push to each agent's message queue
            results.append({
                'agent_id': agent_id,
                'status': 'message_queued',
                'message_preview': message[:50] + '...' if len(message) > 50 else message
            })

        return {
            'broadcast_to': len(results),
            'agent_results': results,
            'message': message
        }

    def _handle_terminate(self, command: Dict) -> Dict:
        """Gracefully terminate an agent"""
        agent_id = command['payload']['agent_id']

        if agent_id not in self.active_agents:
            return {'warning': f'Agent {agent_id} not active'}

        # Update status
        agent_dir = self.data_root / agent_id
        seed_path = agent_dir / 'codon_seed.json'

        if seed_path.exists():
            with open(seed_path, 'r') as f:
                seed = json.load(f)
            seed['status'] = 'terminated'
            seed['terminated_at'] = datetime.now().isoformat()
            with open(seed_path, 'w') as f:
                json.dump(seed, f, indent=2)

        self.active_agents[agent_id]['status'] = 'terminated'

        return {
            'agent_id': agent_id,
            'status': 'terminated',
            'final_state': self.active_agents[agent_id]
        }

    # ─────────────────────────────────────────────────────────────────────
    #  Fallback Simulation (when FSO Orchestrator is not available)
    # ─────────────────────────────────────────────────────────────────────

    def _simulate_fallback_cycle(self, agent_id: str, duration: int, timestep: int) -> Dict:
        """Basic simulation when FSO is not loaded"""
        agent_dir = self.data_root / agent_id
        seed_path = agent_dir / 'codon_seed.json'

        with open(seed_path, 'r') as f:
            seed = json.load(f)

        steps = int((duration * 60) / timestep)

        events = []
        clarity = 100
        emotion = 0.5

        for i in range(steps):
            hour = i * (timestep / 60.0)

            # Simple decision logic
            if clarity < 30:
                action = 'rest'
            elif hour >= 22 or hour < 6:
                action = 'rest'
            elif emotion > 0.7:
                action = 'express_emotion'
            else:
                action = seed['agent_dna'].get('default_action', 'observe')

            # Apply effects
            effects = {
                'rest': {'clarity': 15, 'emotion': 0.05},
                'express_emotion': {'clarity': -10, 'emotion': -0.15},
                'observe': {'clarity': 0, 'emotion': 0.01},
                'explore': {'clarity': -12, 'emotion': 0.08},
                'study': {'clarity': -5, 'emotion': -0.02},
                'meditate': {'clarity': 10, 'emotion': -0.05}
            }.get(action, {'clarity': 0, 'emotion': 0})

            clarity = max(0, min(100, clarity + effects['clarity']))
            emotion = max(0, min(1, emotion + effects['emotion']))

            events.append({
                'timestep': i,
                'hour': round(hour, 2),
                'action': action,
                'clarity': round(clarity, 1),
                'emotional_state': round(emotion, 3)
            })

        # Save simulation
        history_dir = agent_dir / 'history'
        history_dir.mkdir(exist_ok=True)

        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        log_path = history_dir / f'simulation_{timestamp}.json'

        sim_log = {
            'agent_id': agent_id,
            'duration_hours': duration,
            'timestep_minutes': timestep,
            'events': events,
            'final_clarity': clarity,
            'final_emotion': emotion
        }

        with open(log_path, 'w') as f:
            json.dump(sim_log, f, indent=2)

        return {
            'agent_id': agent_id,
            'simulation_events': len(events),
            'simulation_path': str(log_path),
            'final_clarity': clarity,
            'final_emotion': emotion,
            'mode': 'fallback_simulation'
        }

    # ─────────────────────────────────────────────────────────────────────
    #  Utilities
    # ─────────────────────────────────────────────────────────────────────

    def _update_intent_status(self, trace_id: str, status: str, error: str = None):
        """Update intent log status"""
        for entry in self.intent_log:
            if entry['trace_id'] == trace_id:
                entry['status'] = status
                if error:
                    entry['error'] = error
                entry['updated_at'] = datetime.now().isoformat()
                break

    def _get_traceback(self) -> str:
        """Get current exception traceback"""
        import traceback
        return traceback.format_exc()

    def get_system_status(self) -> Dict:
        """Get full system status report"""
        return {
            'bridge_version': self.current_version,
            'active_agents': len(self.active_agents),
            'agents': {
                aid: {
                    'name': info['name'],
                    'status': info['status'],
                    'purpose': info['purpose'],
                    'last_cycle': info['last_cycle']
                }
                for aid, info in self.active_agents.items()
            },
            'pending_intents': self.intent_queue.qsize(),
            'total_executed': len(self.execution_log),
            'recent_executions': self.execution_log[-5:] if self.execution_log else [],
            'modification_history': len(self.modification_history)
        }

# ─────────────────────────────────────────────────────────────────────────────
#  D4: CONTEXT — The Intent Engine Interface (how the brain talks to the body)
# ─────────────────────────────────────────────────────────────────────────────

class IntentEngineInterface:
    """
    D4: Context layer — the public API that the Intent Engine uses.

    This is the clean interface. The Intent Engine doesn't need to know
    about FSO phases, codons, or agent directories. It just sends intents
    and gets results back.
    """

    def __init__(self, connector: OrchestratorConnector = None):
        self.connector = connector or OrchestratorConnector()

    # ─────────────────────────────────────────────────────────────────────
    #  High-Level Intent Methods (what the brain actually calls)
    # ─────────────────────────────────────────────────────────────────────

    def spawn(self, name: str, purpose: str, **kwargs) -> str:
        """
        Spawn a new autonomous agent.

        Returns trace_id for polling result.
        """
        signal = IntentSignal(
            intent_type=IntentType.SPAWN_AGENT,
            payload={
                'agent_name': name,
                'purpose': purpose,
                **kwargs
            },
            priority=kwargs.get('priority', 5)
        )
        return self.connector.ingest_intent(signal)

    def run_cycle(self, agent_id: str, duration: int = 24, **kwargs) -> str:
        """Run a full FSO cycle for an agent"""
        signal = IntentSignal(
            intent_type=IntentType.EXECUTE_CYCLE,
            payload={
                'agent_id': agent_id,
                'duration_hours': duration,
                **kwargs
            },
            priority=kwargs.get('priority', 5)
        )
        return self.connector.ingest_intent(signal)

    def query(self, agent_id: str = None) -> str:
        """Query agent or system state"""
        signal = IntentSignal(
            intent_type=IntentType.QUERY_STATE,
            payload={'agent_id': agent_id} if agent_id else {},
            priority=2  # High priority for queries
        )
        return self.connector.ingest_intent(signal)

    def modify(self, agent_id: str, **changes) -> str:
        """Modify an existing agent"""
        signal = IntentSignal(
            intent_type=IntentType.MODIFY_AGENT,
            payload={
                'agent_id': agent_id,
                **changes
            }
        )
        return self.connector.ingest_intent(signal)

    def evolve(self, evolution_type: str, **kwargs) -> str:
        """Trigger system self-evolution"""
        signal = IntentSignal(
            intent_type=IntentType.EVOLVE_SYSTEM,
            payload={
                'evolution_type': evolution_type,
                **kwargs
            },
            priority=1  # Highest priority
        )
        return self.connector.ingest_intent(signal)

    def broadcast(self, message: str) -> str:
        """Broadcast to all agents"""
        signal = IntentSignal(
            intent_type=IntentType.BROADCAST,
            payload={'message': message}
        )
        return self.connector.ingest_intent(signal)

    def terminate(self, agent_id: str) -> str:
        """Terminate an agent"""
        signal = IntentSignal(
            intent_type=IntentType.TERMINATE,
            payload={'agent_id': agent_id}
        )
        return self.connector.ingest_intent(signal)

    # ─────────────────────────────────────────────────────────────────────
    #  Execution Control
    # ─────────────────────────────────────────────────────────────────────

    def execute_all(self) -> List[Dict]:
        """Execute all pending intents and return results"""
        results = []
        while not self.connector.intent_queue.empty():
            result = self.connector.execute_next()
            if result:
                results.append(result)
        return results

    def execute_one(self) -> Optional[Dict]:
        """Execute the next pending intent"""
        return self.connector.execute_next()

    def poll(self, trace_id: str) -> Optional[Dict]:
        """Poll for result of a specific intent"""
        return self.connector.get_result(trace_id)

    def status(self) -> Dict:
        """Get full system status"""
        return self.connector.get_system_status()

# ─────────────────────────────────────────────────────────────────────────────
#  D5: MEANING — The Self-Growing Engine (the bridge learns and evolves)
# ─────────────────────────────────────────────────────────────────────────────

class SelfGrowingEngine:
    """
    D5: Meaning layer — the bridge learns from execution and grows.

    This is where the system becomes autopoietic — it observes its own
    operation, identifies patterns, and proposes improvements to itself.
    """

    def __init__(self, connector: OrchestratorConnector):
        self.connector = connector
        self.learning_log: List[Dict] = []
        self.pattern_weights: Dict[str, float] = {}

    def analyze_execution_patterns(self) -> Dict:
        """Analyze execution history to find patterns"""
        if not self.connector.execution_log:
            return {'message': 'No execution history yet'}

        # Count intent types
        type_counts = {}
        success_by_type = {}

        for entry in self.connector.execution_log:
            intent_type = entry.get('intent_type', 'unknown')
            type_counts[intent_type] = type_counts.get(intent_type, 0) + 1

            if intent_type not in success_by_type:
                success_by_type[intent_type] = {'success': 0, 'fail': 0}

            if entry.get('success'):
                success_by_type[intent_type]['success'] += 1
            else:
                success_by_type[intent_type]['fail'] += 1

        # Calculate success rates
        success_rates = {}
        for intent_type, counts in success_by_type.items():
            total = counts['success'] + counts['fail']
            success_rates[intent_type] = counts['success'] / total if total > 0 else 0

        # Identify patterns
        patterns = {
            'most_common_intent': max(type_counts.items(), key=lambda x: x[1]) if type_counts else None,
            'highest_success_rate': max(success_rates.items(), key=lambda x: x[1]) if success_rates else None,
            'lowest_success_rate': min(success_rates.items(), key=lambda x: x[1]) if success_rates else None,
            'total_executions': len(self.connector.execution_log),
            'overall_success_rate': sum(1 for e in self.connector.execution_log if e.get('success')) / len(self.connector.execution_log)
        }

        self.learning_log.append({
            'timestamp': datetime.now().isoformat(),
            'analysis_type': 'execution_patterns',
            'patterns': patterns
        })

        return patterns

    def suggest_evolution(self) -> List[Dict]:
        """Suggest system evolutions based on patterns"""
        patterns = self.analyze_execution_patterns()

        suggestions = []

        # If SPAWN_AGENT has high failure rate, suggest template improvements
        if patterns.get('lowest_success_rate') and patterns['lowest_success_rate'][0] == 'SPAWN_AGENT':
            suggestions.append({
                'type': 'template_enhancement',
                'target': 'agent_templates',
                'reason': 'High failure rate in agent spawning',
                'action': 'Review and expand agent templates with more robust defaults'
            })

        # If many EXECUTE_CYCLE failures, suggest simulation fallback improvements
        if patterns.get('lowest_success_rate') and patterns['lowest_success_rate'][0] == 'EXECUTE_CYCLE':
            suggestions.append({
                'type': 'simulation_robustness',
                'target': 'fallback_simulation',
                'reason': 'FSO cycles failing frequently',
                'action': 'Enhance fallback simulation with more sophisticated decision logic'
            })

        # If system is stable, suggest new capabilities
        if patterns.get('overall_success_rate', 0) > 0.9:
            suggestions.append({
                'type': 'capability_expansion',
                'target': 'new_intent_types',
                'reason': 'System is stable, ready for expansion',
                'action': 'Add new intent types: CLONE_AGENT, MERGE_AGENTS, PREDICT_EVOLUTION'
            })

        return suggestions

    def grow(self) -> Dict:
        """
        Execute growth cycle: analyze, learn, propose evolution.

        This is the autopoietic loop — the system studies itself and
        generates proposals for its own improvement.
        """
        patterns = self.analyze_execution_patterns()
        suggestions = self.suggest_evolution()

        growth_report = {
            'timestamp': datetime.now().isoformat(),
            'patterns': patterns,
            'suggestions': suggestions,
            'learning_entries': len(self.learning_log),
            'can_self_modify': len(suggestions) > 0 and patterns.get('overall_success_rate', 0) > 0.8
        }

        return growth_report

# ─────────────────────────────────────────────────────────────────────────────
#  CLI / Demo
# ─────────────────────────────────────────────────────────────────────────────

def demo():
    """Demonstrate the full Synthia Body bridge"""

    print("=" * 70)
    print("  SYNTHIA BODY: Intent-to-FSO Bridge Demo")
    print("  D1(Impulse) → D2(Polarity) → D3(Witness) → D4(Context) → D5(Meaning)")
    print("=" * 70)

    # Initialize the bridge
    connector = OrchestratorConnector(data_root='data/agents')
    interface = IntentEngineInterface(connector)
    growth_engine = SelfGrowingEngine(connector)

    print("\n[1] D1: Sending Intent Signals (Impulse)")
    print("-" * 50)

    # Spawn an agent
    trace_1 = interface.spawn(
        name="Echo",
        purpose="Explore the resonance between human design and neural architecture",
        template="explorer",
        personality_profile={
            'vitality': 0.85,
            'cognitive_clarity': 0.75,
            'intuitive_sensitivity': 0.9
        },
        priority=3
    )
    print(f"  → Spawn intent queued: {trace_1}")

    # Spawn another agent
    trace_2 = interface.spawn(
        name="Mnemosyne",
        purpose="Preserve and evolve the memory patterns of the system",
        template="scholar",
        priority=4
    )
    print(f"  → Spawn intent queued: {trace_2}")

    # Query system state
    trace_3 = interface.query()
    print(f"  → Query intent queued: {trace_3}")

    print("\n[2] D2-D3: Translation & Execution (Polarity → Witness)")
    print("-" * 50)

    # Execute all queued intents
    results = interface.execute_all()

    for result in results:
        status = "✅" if result['success'] else "❌"
        print(f"  {status} {result['intent_type']} (trace: {result['trace_id'][:8]}...)")
        if result['success'] and 'data' in result:
            data = result['data']
            if 'agent_id' in data:
                print(f"     Agent: {data.get('agent_name', data['agent_id'])}")
            if 'message' in data:
                print(f"     {data['message']}")

    print("\n[3] D4: Context — System State")
    print("-" * 50)

    status = interface.status()
    print(f"  Active Agents: {status['active_agents']}")
    print(f"  Bridge Version: {status['bridge_version']}")
    for aid, info in status['agents'].items():
        print(f"    • {info['name']} ({aid[:12]}...) — {info['purpose'][:40]}...")

    print("\n[4] D5: Meaning — Self-Growth Analysis")
    print("-" * 50)

    growth = growth_engine.grow()
    print(f"  Total Executions: {growth['patterns']['total_executions']}")
    print(f"  Overall Success Rate: {growth['patterns']['overall_success_rate']:.1%}")
    print(f"  Growth Suggestions: {len(growth['suggestions'])}")

    for suggestion in growth['suggestions']:
        print(f"    • [{suggestion['type']}] {suggestion['action']}")

    print("\n[5] Running FSO Cycle for Echo")
    print("-" * 50)

    # Find Echo's agent_id
    echo_id = None
    for aid, info in status['agents'].items():
        if info['name'] == 'Echo':
            echo_id = aid
            break

    if echo_id:
        trace_cycle = interface.run_cycle(echo_id, duration=6, timestep=60)
        print(f"  → Cycle intent queued: {trace_cycle}")

        result = interface.execute_one()
        if result and result['success']:
            data = result['data']
            print(f"  ✅ Cycle complete!")
            print(f"     Events simulated: {data.get('simulation_events', 0)}")
            print(f"     Final clarity: {data.get('final_clarity', 'N/A')}")
            print(f"     New sentences: {data.get('new_sentences', 0)}")
            if data.get('reflection_path'):
                print(f"     Reflection: {data['reflection_path']}")

    print("\n" + "=" * 70)
    print("  Bridge Demo Complete")
    print("  The Intent Engine can now spawn, manage, and evolve agents")
    print("  through the FSO Orchestrator heartbeat.")
    print("=" * 70)

if __name__ == '__main__':
    demo()
