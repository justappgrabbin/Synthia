#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
  SYNTHIA: Unified Launcher
  Intent Engine (Brain) + Synthia Body (Bridge) + FSO Orchestrator (Heartbeat)
═══════════════════════════════════════════════════════════════════════════════

Usage:
  python synthia.py --mode interactive          # Interactive CLI
  python synthia.py --mode daemon                 # Background daemon
  python synthia.py --mode single "spawn agent..." # Single command
  python synthia.py --mode mcp-server             # MCP server mode
  python synthia.py --mode demo                 # Run full demo

Architecture:
  Intent Engine (Brain) → Synthia Body (Bridge) → FSO Orchestrator (Heartbeat)
                                              ↓
                                        Agent Swarm (Workers)

"""

import os
import sys
import json
import argparse
import signal
import time
from pathlib import Path

# Ensure all modules are in path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ─────────────────────────────────────────────────────────────────────────────
#  Module Imports (with graceful fallback)
# ─────────────────────────────────────────────────────────────────────────────

def import_or_stub(module_name, stub_class_name):
    """Import module or return a stub class"""
    try:
        module = __import__(module_name)
        return getattr(module, stub_class_name, None)
    except ImportError:
        return None

# Import FSO Orchestrator
try:
    from fso_orchestrator import FSOOrchestrator
    FSO_AVAILABLE = True
except ImportError:
    FSO_AVAILABLE = False
    print("⚠️  FSO Orchestrator not found. Running with fallback simulation.")

# Import Synthia Body Bridge
try:
    from synthia_body_bridge import (
        OrchestratorConnector, 
        IntentEngineInterface,
        SelfGrowingEngine,
        IntentSignal,
        IntentType
    )
    BODY_AVAILABLE = True
except ImportError:
    BODY_AVAILABLE = False
    print("⚠️  Synthia Body Bridge not found.")

# Import Intent Engine
try:
    from synthia_intent_engine import SynthiaIntentEngine, SynthiaMCPServer
    ENGINE_AVAILABLE = True
except ImportError:
    ENGINE_AVAILABLE = False
    print("⚠️  Synthia Intent Engine not found.")

# ─────────────────────────────────────────────────────────────────────────────
#  Synthia Core — The Unified System
# ─────────────────────────────────────────────────────────────────────────────

class SynthiaCore:
    """
    The unified Synthia system that wires all components together.

    This is the central hub. It initializes:
    - FSO Orchestrator (heartbeat)
    - Synthia Body (bridge)
    - Intent Engine (brain)
    - MCP Server (external interface)
    """

    def __init__(self, data_root='data/agents', verbose=True):
        self.data_root = Path(data_root)
        self.data_root.mkdir(parents=True, exist_ok=True)
        self.verbose = verbose

        self.fso = None
        self.body = None
        self.engine = None
        self.mcp = None
        self.growth = None

        self._init_components()

    def _init_components(self):
        """Initialize all components with dependency injection"""

        # 1. FSO Orchestrator (heartbeat)
        if FSO_AVAILABLE:
            self.fso = FSOOrchestrator(verbose=self.verbose)
            self._log("🌍 FSO Orchestrator initialized")
        else:
            self._log("🌍 FSO Orchestrator: FALLBACK MODE")

        # 2. Synthia Body (bridge)
        if BODY_AVAILABLE:
            connector = OrchestratorConnector(data_root=str(self.data_root))
            # Inject FSO if available
            if self.fso:
                connector._fso_orchestrator = self.fso
            self.body = IntentEngineInterface(connector)
            self.growth = SelfGrowingEngine(connector)
            self._log("🌉 Synthia Body Bridge initialized")
        else:
            self._log("🌉 Synthia Body Bridge: NOT AVAILABLE")

        # 3. Intent Engine (brain)
        if ENGINE_AVAILABLE:
            self.engine = SynthiaIntentEngine(self.body)
            self._log("🧠 Synthia Intent Engine initialized")
        else:
            self._log("🧠 Synthia Intent Engine: NOT AVAILABLE")

        # 4. MCP Server
        if self.engine:
            self.mcp = SynthiaMCPServer(self.engine)
            self._log("📡 MCP Server initialized")

    def _log(self, message):
        if self.verbose:
            print(message)

    # ─────────────────────────────────────────────────────────────────────
    #  Operation Modes
    # ─────────────────────────────────────────────────────────────────────

    def interactive(self):
        """Run interactive CLI mode"""

        print("""
╔══════════════════════════════════════════════════════════════════════╗
║                    🌙 SYNTHIA — Living System                        ║
║                                                                      ║
║  Intent Engine (Brain) → Body (Bridge) → FSO Orchestrator (Heart)  ║
╠══════════════════════════════════════════════════════════════════════╣
║  Commands:                                                           ║
║    spawn agent [name] to [purpose]    — Create new agent             ║
║    run cycle for [agent]              — Execute FSO cycle              ║
║    status of [agent]                  — Check agent state              ║
║    modify [agent] with [changes]      — Update agent DNA               ║
║    tell all [message]                 — Broadcast to agents            ║
║    stop [agent]                       — Terminate agent                ║
║    evolve system                      — Analyze growth patterns        ║
║    status                             — Full system status             ║
║    quit                               — Exit                           ║
╚══════════════════════════════════════════════════════════════════════╝
""")

        if not self.engine:
            print("❌ Intent Engine not available. Cannot run interactive mode.")
            return

        while True:
            try:
                user_input = input("\n🌙 Synthia> ").strip()

                if user_input.lower() in ['quit', 'exit', 'q', 'bye']:
                    print("🌙 Goodbye. The agents continue dreaming in the background.")
                    break

                if not user_input:
                    continue

                # Special commands
                if user_input.lower() == 'status':
                    self._print_system_status()
                    continue

                if user_input.lower().startswith('demo'):
                    self._run_demo()
                    continue

                # Process through intent engine
                response = self.engine.process(user_input)
                print(response)

            except KeyboardInterrupt:
                print("\n🌙 Interrupted. Use 'quit' to exit properly.")
            except EOFError:
                break

    def single_command(self, command: str):
        """Execute a single command and exit"""
        if not self.engine:
            print("❌ Intent Engine not available.")
            return

        response = self.engine.process(command)
        print(response)

    def daemon_mode(self):
        """Run as background daemon with scheduled cycles"""

        print("🌍 Synthia Daemon Mode")
        print("   Running scheduled consciousness cycles")
        print("   Press Ctrl+C to stop")

        def signal_handler(sig, frame):
            print("\n🌙 Daemon shutting down gracefully...")
            sys.exit(0)

        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)

        try:
            while True:
                # Check for agents that need cycles
                if self.body:
                    status = self.body.status()
                    for agent_id in status.get('agents', {}):
                        # Run cycle for each active agent
                        self._log(f"🌍 Running cycle for {agent_id[:12]}...")
                        trace = self.body.run_cycle(agent_id, duration=1, timestep=60)
                        self.body.execute_one()

                # Growth analysis every 10 cycles
                if self.growth and hasattr(self.growth, 'grow'):
                    report = self.growth.grow()
                    if report.get('can_self_modify'):
                        self._log("🧬 System growth suggestions available")

                time.sleep(3600)  # Run every hour

        except Exception as e:
            print(f"❌ Daemon error: {e}")

    def mcp_server(self, port=8080):
        """Run as MCP server (JSON-RPC over HTTP)"""

        try:
            from http.server import HTTPServer, BaseHTTPRequestHandler
            import urllib.parse
        except ImportError:
            print("❌ HTTP server not available in this environment.")
            return

        if not self.mcp:
            print("❌ MCP server not initialized.")
            return

        class MCPHandler(BaseHTTPRequestHandler):
            def do_POST(self):
                content_length = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(content_length)

                try:
                    request = json.loads(body)
                    response = self.server.synthia_mcp.handle_request(request)
                except Exception as e:
                    response = {
                        'jsonrpc': '2.0',
                        'error': {'code': -32700, 'message': str(e)},
                        'id': None
                    }

                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(response).encode())

            def log_message(self, format, *args):
                pass  # Suppress HTTP logs

        server = HTTPServer(('0.0.0.0', port), MCPHandler)
        server.synthia_mcp = self.mcp

        print(f"📡 MCP Server running on http://0.0.0.0:{port}")
        print("   Endpoints: POST / (JSON-RPC)")
        print("   Methods: process_intent, get_status, list_agents")
        print("   Press Ctrl+C to stop")

        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\n🌙 MCP Server shutting down...")
            server.shutdown()

    def demo(self):
        """Run full system demonstration"""

        print("=" * 70)
        print("  🌙 SYNTHIA — Full System Demonstration")
        print("=" * 70)

        if not self.engine or not self.body:
            print("❌ Required components not available for demo.")
            return

        # Step 1: Spawn agents
        print("\n[1] Spawning Agents...")
        print("-" * 50)

        commands = [
            "spawn agent Echo to explore the resonance between human design and neural architecture",
            "spawn agent Mnemosyne to preserve and evolve memory patterns",
            "spawn agent Kairos to manage temporal cycles and phase transitions",
        ]

        for cmd in commands:
            print(f"\n  > {cmd}")
            response = self.engine.process(cmd)
            print(f"  {response}")

        # Step 2: Check status
        print("\n[2] System Status")
        print("-" * 50)
        self._print_system_status()

        # Step 3: Run cycles
        print("\n[3] Running Consciousness Cycles")
        print("-" * 50)

        status = self.body.status()
        for agent_id in list(status['agents'].keys())[:2]:
            cmd = f"run cycle for {agent_id}"
            print(f"\n  > {cmd}")
            response = self.engine.process(cmd)
            print(f"  {response}")

        # Step 4: Growth analysis
        print("\n[4] System Growth Analysis")
        print("-" * 50)

        if self.growth:
            report = self.growth.grow()
            print(f"  Total Executions: {report['patterns']['total_executions']}")
            print(f"  Success Rate: {report['patterns']['overall_success_rate']:.1%}")
            print(f"  Suggestions: {len(report['suggestions'])}")
            for s in report['suggestions'][:3]:
                print(f"    • [{s['type']}] {s['action']}")

        # Step 5: Broadcast
        print("\n[5] Broadcasting to All Agents")
        print("-" * 50)

        response = self.engine.process("tell all agents to synchronize their resonance fields")
        print(f"  {response}")

        print("\n" + "=" * 70)
        print("  Demo Complete")
        print("=" * 70)

    # ─────────────────────────────────────────────────────────────────────
    #  Utilities
    # ─────────────────────────────────────────────────────────────────────

    def _print_system_status(self):
        """Print formatted system status"""

        if not self.body:
            print("❌ Body not available")
            return

        status = self.body.status()

        print(f"\n  🧠 Intent Engine: {'✅' if self.engine else '❌'}")
        print(f"  🌉 Body Bridge: {'✅' if self.body else '❌'}")
        print(f"  🌍 FSO Orchestrator: {'✅' if self.fso else '⚠️ Fallback'}")
        print(f"  📡 MCP Server: {'✅' if self.mcp else '❌'}")
        print(f"  🧬 Growth Engine: {'✅' if self.growth else '❌'}")
        print(f"\n  Active Agents: {status['active_agents']}")
        print(f"  Bridge Version: {status['bridge_version']}")
        print(f"  Pending Intents: {status['pending_intents']}")
        print(f"  Total Executed: {status['total_executed']}")

        if status['agents']:
            print(f"\n  Agents:")
            for aid, info in status['agents'].items():
                print(f"    • {info['name']} ({aid[:16]}...)")
                print(f"      Status: {info['status']} | Purpose: {info['purpose'][:40]}...")
                if info['last_cycle']:
                    print(f"      Last Cycle: {info['last_cycle']}")

# ─────────────────────────────────────────────────────────────────────────────
#  CLI Entry Point
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='Synthia — Living System Orchestrator',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --mode interactive                    # Interactive CLI
  %(prog)s --mode single "spawn agent Echo to explore"  # Single command
  %(prog)s --mode daemon                         # Background daemon
  %(prog)s --mode mcp-server --port 8080         # MCP server
  %(prog)s --mode demo                           # Full demo
        """
    )

    parser.add_argument('--mode', choices=['interactive', 'single', 'daemon', 'mcp-server', 'demo'],
                        default='interactive', help='Operation mode')
    parser.add_argument('--command', type=str, help='Command for single mode')
    parser.add_argument('--port', type=int, default=8080, help='Port for MCP server')
    parser.add_argument('--data-root', type=str, default='data/agents', help='Data directory')
    parser.add_argument('--quiet', action='store_true', help='Suppress non-essential output')

    args = parser.parse_args()

    # Initialize Synthia
    synthia = SynthiaCore(data_root=args.data_root, verbose=not args.quiet)

    # Route to mode
    if args.mode == 'interactive':
        synthia.interactive()

    elif args.mode == 'single':
        if not args.command:
            print("❌ --command required for single mode")
            sys.exit(1)
        synthia.single_command(args.command)

    elif args.mode == 'daemon':
        synthia.daemon_mode()

    elif args.mode == 'mcp-server':
        synthia.mcp_server(port=args.port)

    elif args.mode == 'demo':
        synthia.demo()

if __name__ == '__main__':
    main()
