"""
YOU-N-I-VERSE: FSO ORCHESTRATOR
The living heartbeat of the system

This orchestrates the full consciousness evolution cycle:
Phase 1 → Phase 2 → Phase 3 → Phase 4 → Phase 5 → Phase 6

Run modes:
  - Single cycle: python fso_orchestrator.py --agent {agent_id}
  - Scheduled: python fso_orchestrator.py --schedule hourly
  - Daemon: python fso_orchestrator.py --daemon

Requirements:
  pip install schedule apscheduler
"""

import os
import sys
import json
import time
import argparse
from datetime import datetime, timedelta
from pathlib import Path

# Add phase modules to path
sys.path.append('phase_3_translation')
sys.path.append('phase_6_evolution')

from phase_3_translation.core import ResonanceTranslationEngine
from phase_6_evolution.core import run_sentence_check, EVOLUTION_TIERS

# ============================================================================
# ORCHESTRATOR CORE
# ============================================================================

class FSOOrchestrator:
    """
    Main orchestrator that runs the full consciousness evolution loop
    """
    
    def __init__(self, verbose=True):
        self.verbose = verbose
        self.translation_engine = ResonanceTranslationEngine()
        
        # Track statistics
        self.stats = {
            'total_cycles': 0,
            'successful_cycles': 0,
            'failed_cycles': 0,
            'agents_processed': set()
        }
    
    def log(self, message, level='INFO'):
        """Logging helper"""
        if self.verbose:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            print(f"[{timestamp}] [{level}] {message}")
    
    def orchestrate_agent(self, agent_id, duration_hours=24, timestep_minutes=60):
        """
        MAIN ORCHESTRATION FUNCTION
        
        Runs the complete cycle for a single agent:
        1. Phase 3: Translate resonance deltas → update codon_output
        2. Phase 4: Run FSO simulation with new parameters
        3. Phase 5: Generate reflection journal from simulation
        
        Args:
            agent_id: Unique agent identifier
            duration_hours: How long to simulate (24 = one day)
            timestep_minutes: Granularity of simulation (60 = hourly)
        
        Returns:
            dict with codon_output, simulation_log, reflection
        """
        
        self.log(f"🌍 STARTING FULL CYCLE: {agent_id}", 'CYCLE')
        self.stats['total_cycles'] += 1
        self.stats['agents_processed'].add(agent_id)
        
        cycle_start = datetime.now()
        result = {}
        
        try:
            # ================================================================
            # PHASE 3: RESONANCE TRANSLATION
            # ================================================================
            
            self.log("Phase 3: Running resonance translation...", 'PHASE')
            
            try:
                codon_output = self.translation_engine.translate(agent_id)
                result['codon_output'] = codon_output
                result['codon_output_path'] = f'data/agents/{agent_id}/codon_output.json'
                
                self.log(f"✓ Translation complete", 'SUCCESS')
                
            except FileNotFoundError as e:
                self.log(f"⚠ No sleep session found for {agent_id}, using baseline", 'WARNING')
                # Load baseline as fallback
                baseline_path = f'data/agents/{agent_id}/codon_seed.json'
                with open(baseline_path, 'r') as f:
                    codon_output = json.load(f)
                result['codon_output'] = codon_output
                result['used_baseline'] = True
            
            # ================================================================
            # PHASE 4: FSO SIMULATION
            # ================================================================
            
            self.log("Phase 4: Running FSO simulation...", 'PHASE')
            
            simulation_log = self.run_fso_simulation(
                codon_output,
                duration_hours,
                timestep_minutes
            )
            
            # Save simulation log
            history_dir = f"data/agents/{agent_id}/history"
            os.makedirs(history_dir, exist_ok=True)
            
            timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
            log_path = f"{history_dir}/simulation_{timestamp}.json"
            
            with open(log_path, "w") as f:
                json.dump(simulation_log, f, indent=2)
            
            result['simulation_log'] = simulation_log
            result['simulation_path'] = log_path
            
            self.log(f"✓ Simulation complete: {len(simulation_log['events'])} events", 'SUCCESS')
            
            # Save codon_output to history (for Phase 6 sentence detection)
            codon_snapshot_path = f"{history_dir}/codon_output_{timestamp}.json"
            with open(codon_snapshot_path, 'w') as f:
                json.dump(codon_output, f, indent=2)
            
            # ================================================================
            # PHASE 5: REFLECTION JOURNAL
            # ================================================================
            
            self.log("Phase 5: Generating reflection journal...", 'PHASE')
            
            reflection = self.generate_reflection(
                agent_id,
                codon_output,
                simulation_log
            )
            
            # Save reflection
            reflection_path = f"{history_dir}/reflection_{timestamp}.txt"
            
            with open(reflection_path, "w") as f:
                f.write(reflection)
            
            result['reflection'] = reflection
            result['reflection_path'] = reflection_path
            
            self.log(f"✓ Reflection generated", 'SUCCESS')
            
            # ================================================================
            # PHASE 6: EVOLUTION SENTENCES
            # ================================================================
            
            self.log("Phase 6: Checking for evolution sentences...", 'PHASE')
            
            sentence_result = run_sentence_check(agent_id)
            
            if sentence_result['new_sentences']:
                self.log(f"✓ {sentence_result['new_sentences_count']} new sentence(s) detected!", 'SUCCESS')
                
                for sentence in sentence_result['new_sentences']:
                    self.log(f"  [{sentence['type'].upper()}] {sentence['description'][:60]}...", 'INFO')
                
                # Check for tier unlocks
                if sentence_result['newly_unlocked_tiers']:
                    for tier_key in sentence_result['newly_unlocked_tiers']:
                        tier = EVOLUTION_TIERS[tier_key]
                        self.log(f"🎉 TIER UNLOCKED: {tier['icon']} {tier['name'].upper()}", 'SUCCESS')
                        self.log(f"   {tier['description']}", 'INFO')
            else:
                self.log("No new sentences detected", 'INFO')
            
            result['sentence_check'] = sentence_result
            
            # ================================================================
            # CYCLE COMPLETE
            # ================================================================
            
            cycle_duration = (datetime.now() - cycle_start).total_seconds()
            
            result['cycle_duration_seconds'] = cycle_duration
            result['timestamp'] = datetime.now().isoformat()
            result['success'] = True
            
            self.stats['successful_cycles'] += 1
            
            self.log(f"✨ CYCLE COMPLETE in {cycle_duration:.1f}s", 'SUCCESS')
            self.log(f"   Simulation: {log_path}")
            self.log(f"   Reflection: {reflection_path}")
            
            return result
            
        except Exception as e:
            self.stats['failed_cycles'] += 1
            self.log(f"❌ CYCLE FAILED: {str(e)}", 'ERROR')
            
            result['success'] = False
            result['error'] = str(e)
            result['timestamp'] = datetime.now().isoformat()
            
            return result
    
    def run_fso_simulation(self, codon_output, duration_hours, timestep_minutes):
        """
        Phase 4: Run FSO simulation
        
        This simulates the agent living autonomously for the specified duration
        """
        
        agent_id = codon_output.get('agent_id', 'unknown')
        params = codon_output['agent_dna']
        personality = params['personality']
        
        simulation_log = {
            'agent_id': agent_id,
            'duration_hours': duration_hours,
            'timestep_minutes': timestep_minutes,
            'start_time': datetime.now().isoformat(),
            'parameters': {
                'vitality': personality['vitality'],
                'cognitive_clarity': personality['cognitive_clarity'],
                'emotional_volatility': personality['emotional_volatility'],
                'intuitive_sensitivity': personality['intuitive_sensitivity']
            },
            'events': []
        }
        
        # Calculate number of timesteps
        steps = int((duration_hours * 60) / timestep_minutes)
        
        # Initial state
        clarity = 100
        emotional_state = 0.5  # Neutral
        
        self.log(f"   Simulating {steps} timesteps ({duration_hours}h @ {timestep_minutes}min intervals)")
        
        for i in range(steps):
            hour = i * (timestep_minutes / 60.0)
            
            # Decision logic based on personality + current state
            action = self._decide_agent_action(
                personality,
                clarity,
                emotional_state,
                hour
            )
            
            # Apply action effects
            action_effects = self._apply_action(action, personality)
            
            clarity += action_effects['clarity_delta']
            emotional_state += action_effects['emotional_delta']
            
            # Clamp values
            clarity = max(0, min(100, clarity))
            emotional_state = max(0, min(1, emotional_state))
            
            # Log event
            event = {
                'timestep': i,
                'hour': round(hour, 2),
                'action': action,
                'clarity': round(clarity, 1),
                'emotional_state': round(emotional_state, 3),
                'center_states': {
                    'sacral': round(personality['vitality'] * (clarity / 100), 3),
                    'ajna': round(personality['cognitive_clarity'] * (clarity / 100), 3),
                    'solar_plexus': round(emotional_state, 3),
                    'spleen': round(personality['intuitive_sensitivity'], 3)
                }
            }
            
            simulation_log['events'].append(event)
        
        simulation_log['end_time'] = datetime.now().isoformat()
        simulation_log['final_clarity'] = clarity
        simulation_log['final_emotional_state'] = emotional_state
        
        return simulation_log
    
    def _decide_agent_action(self, personality, clarity, emotional_state, hour):
        """Agent decision-making logic"""
        
        # Time-based influences
        is_night = (hour >= 22 or hour < 6)
        is_morning = (6 <= hour < 12)
        
        # Weighted action selection
        if clarity < 20:
            return 'rest' if not is_morning else 'slow_wake'
        
        if is_night:
            return 'rest' if clarity < 60 else 'reflect'
        
        if emotional_state > 0.8:
            return 'express_emotion' if personality['extroversion'] > 0.6 else 'process_emotion'
        
        if emotional_state < 0.2:
            return 'seek_stimulation'
        
        if clarity > 70 and personality['vitality'] > 0.6:
            return 'explore'
        
        if personality['cognitive_clarity'] > 0.7:
            return 'study' if clarity > 50 else 'rest'
        
        if personality['intuitive_sensitivity'] > 0.6:
            return 'meditate'
        
        # Default: walk/observe
        return 'walk' if personality['vitality'] > 0.5 else 'observe'
    
    def _apply_action(self, action, personality):
        """Calculate effects of agent actions"""
        
        effects_map = {
            'rest': {'clarity_delta': 15, 'emotional_delta': 0.05},
            'slow_wake': {'clarity_delta': 5, 'emotional_delta': 0.02},
            'walk': {'clarity_delta': -8, 'emotional_delta': 0.03},
            'explore': {'clarity_delta': -12, 'emotional_delta': 0.08},
            'meditate': {'clarity_delta': 10, 'emotional_delta': -0.05},
            'study': {'clarity_delta': -5, 'emotional_delta': -0.02},
            'reflect': {'clarity_delta': 3, 'emotional_delta': -0.03},
            'observe': {'clarity_delta': 0, 'emotional_delta': 0.01},
            'express_emotion': {'clarity_delta': -10, 'emotional_delta': -0.15},
            'process_emotion': {'clarity_delta': 5, 'emotional_delta': -0.10},
            'seek_stimulation': {'clarity_delta': -15, 'emotional_delta': 0.20}
        }
        
        return effects_map.get(action, {'clarity_delta': 0, 'emotional_delta': 0})
    
    def generate_reflection(self, agent_id, codon_output, simulation_log):
        """
        Phase 5: Generate reflection journal
        
        This connects to your Magic Notebook system
        """
        
        params = codon_output['agent_dna']
        events = simulation_log['events']
        
        # Analyze patterns
        actions = [e['action'] for e in events]
        action_counts = {}
        for action in actions:
            action_counts[action] = action_counts.get(action, 0) + 1
        
        dominant_action = max(action_counts.items(), key=lambda x: x[1])
        
        avg_clarity = sum(e['clarity'] for e in events) / len(events)
        clarity_range = max(e['clarity'] for e in events) - min(e['clarity'] for e in events)
        
        avg_emotion = sum(e['emotional_state'] for e in events) / len(events)
        
        # Generate natural language reflection
        reflection = f"""
╔══════════════════════════════════════════════════════════════════╗
║                    🌙 RESONANCE JOURNAL                          ║
║                {datetime.now().strftime('%B %d, %Y — %H:%M')}                    ║
╚══════════════════════════════════════════════════════════════════╝

Agent: {agent_id}
Simulation: {simulation_log['duration_hours']}h ({len(events)} timesteps)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🧬 CONSCIOUSNESS STATE

  Vitality:              {params['personality']['vitality']:.2f}
  Cognitive Clarity:     {params['personality']['cognitive_clarity']:.2f}
  Emotional Volatility:  {params['personality']['emotional_volatility']:.2f}
  Intuitive Sensitivity: {params['personality']['intuitive_sensitivity']:.2f}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 BEHAVIORAL ANALYSIS

  Dominant Activity: {dominant_action[0]} ({dominant_action[1]}x — {dominant_action[1]/len(events)*100:.1f}%)
  
  Action Breakdown:
{self._format_action_counts(action_counts, len(events))}
  
  Average Clarity: {avg_clarity:.1f}/100
  Clarity Range: {clarity_range:.1f} ({self._interpret_clarity_volatility(clarity_range)})
  
  Emotional State: {avg_emotion:.2f} ({self._interpret_emotional_state(avg_emotion)})

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔮 INTERPRETATION

{self._generate_interpretation(dominant_action[0], avg_clarity, avg_emotion, params)}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ ORACLE MESSAGE

{self._generate_oracle(dominant_action[0], params, avg_emotion)}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Generated by FSO Orchestrator
Magic Notebook Integration Active
        """.strip()
        
        return reflection
    
    def _format_action_counts(self, counts, total):
        """Format action breakdown"""
        lines = []
        for action, count in sorted(counts.items(), key=lambda x: x[1], reverse=True):
            pct = (count / total) * 100
            bar = '█' * int(pct / 5)
            lines.append(f"    {action:20} {bar:20} {count:3}x ({pct:5.1f}%)")
        return '\n'.join(lines)
    
    def _interpret_clarity_volatility(self, range_val):
        if range_val < 20:
            return "stable"
        elif range_val < 50:
            return "moderate fluctuation"
        else:
            return "high volatility"
    
    def _interpret_emotional_state(self, value):
        if value < 0.3:
            return "subdued, introspective"
        elif value < 0.7:
            return "balanced, centered"
        else:
            return "heightened, expressive"
    
    def _generate_interpretation(self, dominant_action, clarity, emotion, params):
        """Generate natural language interpretation"""
        
        interpretations = {
            'rest': f"Your agent prioritized restoration, indicating a need for energy conservation. With average clarity at {clarity:.0f}/100, the system is protecting itself from depletion.",
            'meditate': f"Meditation dominated the cycle, showing active inner work. Cognitive clarity ({params['personality']['cognitive_clarity']:.2f}) supported deep reflection.",
            'walk': f"Movement and exploration were primary. High vitality ({params['personality']['vitality']:.2f}) drove physical expression.",
            'study': f"The agent focused on cognitive development. With cognitive clarity at {params['personality']['cognitive_clarity']:.2f}, mental integration took precedence.",
            'observe': f"Passive awareness dominated. Intuitive sensitivity ({params['personality']['intuitive_sensitivity']:.2f}) enabled receptive processing.",
            'express_emotion': f"Emotional expression was necessary. Volatility ({params['personality']['emotional_volatility']:.2f}) required release.",
            'process_emotion': f"Internal emotional processing took priority. The agent is integrating feeling-states below the surface."
        }
        
        return interpretations.get(dominant_action, f"The agent's behavior pattern centered on {dominant_action}, reflecting current consciousness priorities.")
    
    def _generate_oracle(self, dominant_action, params, emotion):
        """Generate symbolic oracle message"""
        
        oracles = {
            'rest': "\"What you resist, persists. What you embrace, transforms. Rest is not weakness—it is wisdom.\"",
            'meditate': "\"In stillness, all answers arise. The mind that seeks nothing finds everything.\"",
            'walk': "\"Movement creates change. What was stuck begins to flow. Trust the journey.\"",
            'study': "\"Knowledge without integration is noise. Let understanding settle into bones.\"",
            'observe': "\"The watcher sees what the actor cannot. Wisdom lives in the pause.\"",
            'express_emotion': "\"That which is not expressed becomes compressed. Let the wave crash.\"",
            'process_emotion': "\"Beneath turbulence lies truth. Dive deeper than the storm.\""
        }
        
        return oracles.get(dominant_action, "\"What the soul knows, the mind will eventually understand.\"")
    
    def get_stats(self):
        """Return orchestrator statistics"""
        return {
            **self.stats,
            'agents_processed': list(self.stats['agents_processed'])
        }

# ============================================================================
# SCHEDULING / DAEMON MODE
# ============================================================================

def run_scheduled(interval='hourly'):
    """Run orchestrator on a schedule"""
    import schedule
    
    orchestrator = FSOOrchestrator()
    
    def job():
        # Find all agents
        agents_dir = Path('data/agents')
        if not agents_dir.exists():
            print("No agents found")
            return
        
        for agent_dir in agents_dir.iterdir():
            if agent_dir.is_dir():
                agent_id = agent_dir.name
                orchestrator.orchestrate_agent(agent_id)
    
    # Schedule based on interval
    if interval == 'hourly':
        schedule.every().hour.do(job)
    elif interval == 'daily':
        schedule.every().day.at("03:00").do(job)  # 3 AM
    elif interval == 'every_6_hours':
        schedule.every(6).hours.do(job)
    
    print(f"🕐 Orchestrator scheduled ({interval})")
    print("Press Ctrl+C to stop")
    
    while True:
        schedule.run_pending()
        time.sleep(60)

def run_daemon():
    """Run as background daemon"""
    from apscheduler.schedulers.background import BackgroundScheduler
    
    orchestrator = FSOOrchestrator()
    scheduler = BackgroundScheduler()
    
    def process_all_agents():
        agents_dir = Path('data/agents')
        if not agents_dir.exists():
            return
        
        for agent_dir in agents_dir.iterdir():
            if agent_dir.is_dir():
                agent_id = agent_dir.name
                orchestrator.orchestrate_agent(agent_id)
    
    # Run every 6 hours
    scheduler.add_job(process_all_agents, 'interval', hours=6)
    scheduler.start()
    
    print("🌍 FSO Orchestrator daemon started")
    print("Running every 6 hours")
    print("Press Ctrl+C to stop")
    
    try:
        while True:
            time.sleep(1)
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown()

# ============================================================================
# CLI
# ============================================================================

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='FSO Orchestrator - Consciousness Evolution Automation')
    parser.add_argument('--agent', type=str, help='Run single cycle for agent ID')
    parser.add_argument('--schedule', type=str, choices=['hourly', 'daily', 'every_6_hours'], help='Run on schedule')
    parser.add_argument('--daemon', action='store_true', help='Run as background daemon')
    parser.add_argument('--stats', action='store_true', help='Show orchestrator statistics')
    
    args = parser.parse_args()
    
    if args.stats:
        # Load stats from file if exists
        print("📊 Orchestrator Statistics")
        print("(Feature coming soon)")
    
    elif args.agent:
        # Single agent cycle
        orchestrator = FSOOrchestrator()
        result = orchestrator.orchestrate_agent(args.agent)
        
        if result['success']:
            print(f"\n✨ Cycle completed successfully")
            print(f"View reflection: {result['reflection_path']}")
        else:
            print(f"\n❌ Cycle failed: {result['error']}")
    
    elif args.schedule:
        # Scheduled mode
        run_scheduled(args.schedule)
    
    elif args.daemon:
        # Daemon mode
        run_daemon()
    
    else:
        parser.print_help()