/**
 * Synthia Self-Editor
 * D2 Polarity — Can ADD (positive) or MODIFY (negative) existing pages.
 * This is the "self-editing" capability that makes the app truly alive.
 */

import { DynamicExecutor } from './dynamic-executor';

export interface EditOperation {
  type: 'append' | 'prepend' | 'replace' | 'insert' | 'delete' | 'refactor';
  targetId: string;
  targetSection?: 'imports' | 'state' | 'jsx' | 'styles' | 'full';
  description: string;
  searchPattern?: string;       // for replace/insert/delete
  newCode?: string;           // the code to insert/replace with
  lineNumber?: number;        // for insert at specific line
  aiGenerated?: boolean;
}

export interface EditResult {
  operation: EditOperation;
  success: boolean;
  originalCode: string;
  modifiedCode: string;
  diff: string;
  error?: string;
  timestamp: number;
}

export class SelfEditor {
  private executor: DynamicExecutor;
  private editHistory: EditResult[] = [];

  constructor(executor: DynamicExecutor) {
    this.executor = executor;
  }

  /**
   * Apply an edit operation to a component's source code.
   */
  async applyEdit(operation: EditOperation): Promise<EditResult> {
    const startTime = Date.now();

    try {
      // Get current code
      const currentEntry = this.executor.getAllComponents()
        .find(c => c.id === operation.targetId);

      if (!currentEntry) {
        throw new Error(`Component ${operation.targetId} not found in registry`);
      }

      const originalCode = currentEntry.code;
      let modifiedCode = originalCode;

      switch (operation.type) {
        case 'append':
          modifiedCode = this.appendCode(originalCode, operation.newCode || '', operation.targetSection);
          break;
        case 'prepend':
          modifiedCode = this.prependCode(originalCode, operation.newCode || '', operation.targetSection);
          break;
        case 'replace':
          if (!operation.searchPattern) {
            throw new Error('Replace operation requires searchPattern');
          }
          modifiedCode = originalCode.replace(operation.searchPattern, operation.newCode || '');
          break;
        case 'insert':
          if (operation.lineNumber === undefined) {
            throw new Error('Insert operation requires lineNumber');
          }
          modifiedCode = this.insertAtLine(originalCode, operation.lineNumber, operation.newCode || '');
          break;
        case 'delete':
          if (!operation.searchPattern) {
            throw new Error('Delete operation requires searchPattern');
          }
          modifiedCode = originalCode.replace(operation.searchPattern, '');
          break;
        case 'refactor':
          // Full AI-generated refactor — replaces entire component
          if (!operation.newCode) {
            throw new Error('Refactor operation requires newCode');
          }
          modifiedCode = operation.newCode;
          break;
        default:
          throw new Error(`Unknown edit type: ${operation.type}`);
      }

      // Validate the modified code compiles
      const compileResult = await this.executor.hotReload(operation.targetId, modifiedCode);

      if (!compileResult.compiled) {
        throw new Error(`Modified code failed to compile: ${compileResult.error}`);
      }

      const diff = this.generateDiff(originalCode, modifiedCode);

      const result: EditResult = {
        operation,
        success: true,
        originalCode,
        modifiedCode,
        diff,
        timestamp: Date.now()
      };

      this.editHistory.push(result);
      return result;

    } catch (error) {
      const result: EditResult = {
        operation,
        success: false,
        originalCode: '',
        modifiedCode: '',
        diff: '',
        error: error instanceof Error ? error.message : String(error),
        timestamp: Date.now()
      };
      this.editHistory.push(result);
      return result;
    }
  }

  /**
   * Auto-fix a component that failed to compile.
   */
  async autoRepair(targetId: string, errorMessage: string): Promise<EditResult> {
    const entry = this.executor.getAllComponents().find(c => c.id === targetId);
    if (!entry) {
      throw new Error(`Component ${targetId} not found`);
    }

    // Common repair patterns
    let repairedCode = entry.code;

    // Fix 1: Missing import for React hooks
    if (errorMessage.includes('useState') || errorMessage.includes('useEffect')) {
      if (!repairedCode.includes('useState') && !repairedCode.includes('useEffect')) {
        // The hooks are used but not imported — actually they're injected by executor
        // So this might be a different issue
      }
    }

    // Fix 2: Missing StyleSheet.create
    if (errorMessage.includes('styles') && !repairedCode.includes('StyleSheet.create')) {
      // Add a basic StyleSheet if missing
    }

    // Fix 3: Export statement issues (already sanitized by executor, but double-check)
    repairedCode = repairedCode
      .replace(/export\s+default\s+function/g, 'function')
      .replace(/export\s+default\s+const/g, 'const')
      .replace(/export\s+default\s+class/g, 'class');

    // Try to recompile
    const operation: EditOperation = {
      type: 'refactor',
      targetId,
      description: `Auto-repair: ${errorMessage}`,
      newCode: repairedCode,
      aiGenerated: false
    };

    return this.applyEdit(operation);
  }

  /**
   * Generate a description of what changed between two code versions.
   */
  private generateDiff(original: string, modified: string): string {
    const origLines = original.split('\n');
    const modLines = modified.split('\n');

    let diff = '';
    const maxLen = Math.max(origLines.length, modLines.length);

    for (let i = 0; i < maxLen; i++) {
      const orig = origLines[i] || '';
      const mod = modLines[i] || '';

      if (orig !== mod) {
        if (orig) diff += `- ${orig}\n`;
        if (mod) diff += `+ ${mod}\n`;
      }
    }

    return diff || '(no structural changes detected)';
  }

  /**
   * Append code to a specific section of a component.
   */
  private appendCode(code: string, newCode: string, section?: string): string {
    if (!section || section === 'full') {
      return code + '\n' + newCode;
    }

    switch (section) {
      case 'imports':
        // Insert after last import or at top
        const lastImport = code.lastIndexOf('import ');
        if (lastImport >= 0) {
          const endOfImport = code.indexOf('\n', lastImport);
          return code.slice(0, endOfImport + 1) + newCode + '\n' + code.slice(endOfImport + 1);
        }
        return newCode + '\n' + code;

      case 'state':
        // Insert after useState declarations
        const stateMatch = code.match(/const\s+\[.*?\]\s*=\s*useState\(.*?\);/g);
        if (stateMatch && stateMatch.length > 0) {
          const lastState = stateMatch[stateMatch.length - 1];
          const idx = code.lastIndexOf(lastState);
          const endIdx = idx + lastState.length;
          return code.slice(0, endIdx) + '\n  ' + newCode + code.slice(endIdx);
        }
        return code;

      case 'jsx':
        // Insert before closing return View
        const returnMatch = code.match(/return\s*\(/);
        if (returnMatch) {
          // Find the matching closing parenthesis
          const startIdx = code.indexOf(returnMatch[0]) + returnMatch[0].length;
          // Simple heuristic: insert before last </View> or </ScrollView>
          const lastClose = code.lastIndexOf('</View>');
          if (lastClose > startIdx) {
            return code.slice(0, lastClose) + newCode + '\n' + code.slice(lastClose);
          }
        }
        return code;

      case 'styles':
        // Insert before StyleSheet.create closing
        const styleClose = code.lastIndexOf('});');
        if (styleClose > 0) {
          return code.slice(0, styleClose) + newCode + '\n' + code.slice(styleClose);
        }
        return code;

      default:
        return code + '\n' + newCode;
    }
  }

  /**
   * Prepend code to a specific section.
   */
  private prependCode(code: string, newCode: string, section?: string): string {
    if (!section || section === 'full') {
      return newCode + '\n' + code;
    }

    switch (section) {
      case 'imports':
        return newCode + '\n' + code;
      case 'state':
        // Insert before first useState
        const firstState = code.indexOf('const [');
        if (firstState >= 0) {
          return code.slice(0, firstState) + newCode + '\n  ' + code.slice(firstState);
        }
        return code;
      case 'jsx':
        // Insert right after return (
        const returnIdx = code.indexOf('return (');
        if (returnIdx >= 0) {
          const insertIdx = returnIdx + 'return ('.length;
          return code.slice(0, insertIdx) + '\n' + newCode + code.slice(insertIdx);
        }
        return code;
      case 'styles':
        // Insert after StyleSheet.create({
        const styleOpen = code.indexOf('StyleSheet.create({');
        if (styleOpen >= 0) {
          const insertIdx = styleOpen + 'StyleSheet.create({'.length;
          return code.slice(0, insertIdx) + '\n' + newCode + code.slice(insertIdx);
        }
        return code;
      default:
        return newCode + '\n' + code;
    }
  }

  /**
   * Insert code at a specific line number.
   */
  private insertAtLine(code: string, lineNumber: number, newCode: string): string {
    const lines = code.split('\n');
    lines.splice(lineNumber - 1, 0, newCode);
    return lines.join('\n');
  }

  /**
   * Get edit history for a component.
   */
  getEditHistory(targetId: string): EditResult[] {
    return this.editHistory.filter(e => e.operation.targetId === targetId);
  }

  /**
   * Get all edit history.
   */
  getAllEdits(): EditResult[] {
    return [...this.editHistory];
  }

  /**
   * Rollback the last edit for a component.
   */
  async rollback(targetId: string): Promise<EditResult | null> {
    const history = this.getEditHistory(targetId);
    if (history.length === 0) return null;

    const lastEdit = history[history.length - 1];

    // Apply the inverse: restore original code
    const rollbackOp: EditOperation = {
      type: 'refactor',
      targetId,
      description: `Rollback of: ${lastEdit.operation.description}`,
      newCode: lastEdit.originalCode,
      aiGenerated: false
    };

    return this.applyEdit(rollbackOp);
  }

  /**
   * Serialize edit history.
   */
  serialize(): string {
    return JSON.stringify({
      edits: this.editHistory,
      exportedAt: Date.now()
    });
  }
}

export default SelfEditor;
