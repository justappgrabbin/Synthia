# Synthia Self-Evolving App

A React Native app that **grows itself** — adds pages, modifies existing ones, and learns from outcomes. Integrated into the Synthia Intent Engine → Body → Agent Swarm architecture.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    D5: MEANING                              │
│              Semantic Analysis Engine                       │
│         (names pages, assigns basins, finds purpose)        │
├─────────────────────────────────────────────────────────────┤
│                    D4: CONTEXT                              │
│              App Registry (file-based)                      │
│         (what pages exist, what code they have)              │
├─────────────────────────────────────────────────────────────┤
│                    D3: WITNESS                              │
│              Evolution Observer                             │
│    (tracks every mutation, learns coherence patterns)       │
├─────────────────────────────────────────────────────────────┤
│                    D2: POLARITY                             │
│              Self-Editor (add OR modify)                    │
│         (can create new pages or edit existing ones)         │
├─────────────────────────────────────────────────────────────┤
│                    D1: IMPULSE                              │
│              Intent Bridge                                │
│    (receives signals from user, MCP, Termux, or self)       │
└─────────────────────────────────────────────────────────────┘
```

## Files

| File | Purpose | D-Layer |
|------|---------|---------|
| `intent-bridge.ts` | Receives and routes evolution signals | D1 |
| `self-editor.ts` | Modifies existing page code | D2 |
| `evolution-observer.ts` | Tracks all mutations, learns coherence | D3 |
| `dynamic-executor.ts` | Compiles and runs generated code at runtime | D4 |
| `synthia-evolving-app.tsx` | Main orchestrator + Meaning Engine + AI client | D5 |
| `index.ts` | Barrel exports | — |

## Integration Points

### 1. Intent Engine (Brain)
The `IntentBridge` receives signals from your Intent Engine:

```typescript
const bridge = new IntentBridge({ mcpEndpoint: 'http://localhost:3000' });
await bridge.connectMCP('http://your-mcp-server');

// Your Intent Engine sends:
await bridge.receive({
  id: 'intent_123',
  type: 'evolve',
  source: 'intent_engine',
  priority: 'high',
  timestamp: Date.now(),
  trace: ['intent_engine:generated']
});
```

### 2. Termux (Mobile Daemon)
Connect to your Termux daemon for server-side intelligence:

```typescript
await bridge.connectTermux('localhost', 8765);
// Now the app can evolve based on server-side analysis
```

### 3. MCP (External Tools)
The bridge forwards to MCP for complex operations:

```typescript
const result = await bridge.forwardToMCP({
  id: 'intent_456',
  type: 'evolve',
  source: 'user',
  priority: 'normal',
  timestamp: Date.now(),
  trace: []
});
```

## How Evolution Works

1. **D1 Impulse**: User taps "Evolve" or Intent Engine sends signal
2. **D4 Context**: App analyzes existing pages via `AppState`
3. **D5 Meaning**: `MeaningEngine.suggestName()` picks what to create next based on semantic gaps
4. **D2 Polarity**: AI generates complete React Native component code
5. **D4 Execution**: `DynamicExecutor.compileComponent()` turns string into runnable component
6. **D3 Witness**: `EvolutionObserver` records the mutation with coherence score
7. **D4 Persistence**: New page saved to `RNFS` + registry updated
8. **Navigation**: New tab appears automatically in the nav bar

## Page Templates

The `LocalAIClient` generates contextually appropriate templates:

- **Profile** → Editable user card with stats
- **Settings** → Toggle switches + app info
- **Insights** → Metrics grid + timeline
- **Journal** → FlatList entries with add/delete
- **Goals** → Checklist with progress bar
- **Discover** → Search bar + tag suggestions
- **Connect** → Chat-style message list
- **Generic** → Fallback with activation toggle

## Self-Editing

The `SelfEditor` can:
- Append/prepend/insert/replace/delete code sections
- Full refactor (replace entire component)
- Auto-repair compilation errors
- Rollback to previous version
- Track edit history

## Observer Dashboard

Tap "Observer" to see:
- **Attractor Basins**: Visual map of page clusters (identity, insight, control, etc.)
- **Evolution Trajectories**: History of each evolution with coherence scores
- **Suggestions**: AI-recommended next pages based on missing essentials

## Health System

The app monitors its own health:
- Compilation success rate
- Orphaned pages (in registry but no code)
- Failed evolution streaks
- Visual indicator: 🟢 healthy / 🟡 warning / 🔴 critical

## Usage

```typescript
import { SynthiaEvolvingApp } from './synthia';

// In your App.tsx:
export default function App() {
  return <SynthiaEvolvingApp />;
}
```

## Requirements

```bash
npm install react-native-fs @react-native-async-storage/async-storage
# or
yarn add react-native-fs @react-native-async-storage/async-storage
```

## Roadmap

- [ ] Connect to real AI API (replace `LocalAIClient`)
- [ ] WebView fallback for complex generated components
- [ ] Peer-to-peer page sharing between Synthia instances
- [ ] Automatic evolution based on usage patterns
- [ ] Voice-controlled evolution ("Synthia, add a meditation page")
