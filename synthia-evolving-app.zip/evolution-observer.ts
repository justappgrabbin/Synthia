/**
 * Synthia Evolution Observer
 * D3 Witness Layer — Tracks every mutation, learns from outcomes,
 * maintains longitudinal coherence of the app's evolution.
 */

export interface EvolutionRecord {
  id: string;
  evolutionId: string;
  type: 'page_added' | 'page_modified' | 'page_removed' | 'component_added' | 'component_modified' | 'self_repair';
  targetId: string;
  targetName: string;
  beforeSnapshot?: string;      // code before change
  afterSnapshot?: string;       // code after change
  diff?: string;                // unified diff
  intentSignalId: string;       // links back to the D1 impulse
  timestamp: number;
  outcome?: 'success' | 'failure' | 'pending' | 'rolled_back';
  outcomeTimestamp?: number;
  errorMessage?: string;
  userFeedback?: 'positive' | 'neutral' | 'negative';
  performanceImpact?: number;   // ms render time delta
  // D3 witness fields
  witnessNotes: string[];
  coherenceScore: number;       // 0-1, how well this fits the app's trajectory
  resonancePattern: string;     // which attractor basin this evolution belongs to
}

export interface EvolutionTrajectory {
  evolutionId: string;
  records: EvolutionRecord[];
  startedAt: number;
  completedAt?: number;
  status: 'active' | 'completed' | 'failed' | 'rolled_back';
  coherenceScore: number;
  attractorBasin: string;
}

export class EvolutionObserver {
  private records: EvolutionRecord[] = [];
  private trajectories: Map<string, EvolutionTrajectory> = new Map();
  private attractorBasins: Map<string, string[]> = new Map(); // basin -> pageIds
  private maxRecords = 1000;

  constructor() {}

  // D3: Witness — observe a new evolution event
  witness(record: Omit<EvolutionRecord, 'id' | 'coherenceScore' | 'resonancePattern'>): EvolutionRecord {
    const id = `rec_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    // Calculate coherence: how well does this fit existing structure?
    const coherenceScore = this.calculateCoherence(record);

    // Determine which attractor basin this belongs to
    const resonancePattern = this.determineAttractorBasin(record);

    const fullRecord: EvolutionRecord = {
      ...record,
      id,
      coherenceScore,
      resonancePattern,
      witnessNotes: [
        `d3:witness:born:${Date.now()}`,
        `coherence:${coherenceScore.toFixed(3)}`,
        `basin:${resonancePattern}`
      ]
    };

    this.records.push(fullRecord);

    // Maintain trajectory
    this.updateTrajectory(fullRecord);

    // Prune old records
    if (this.records.length > this.maxRecords) {
      this.records = this.records.slice(-this.maxRecords);
    }

    return fullRecord;
  }

  // Mark an evolution as having an outcome
  markOutcome(recordId: string, outcome: EvolutionRecord['outcome'], details?: { error?: string; userFeedback?: EvolutionRecord['userFeedback'] }): void {
    const record = this.records.find(r => r.id === recordId);
    if (!record) return;

    record.outcome = outcome;
    record.outcomeTimestamp = Date.now();
    if (details?.error) record.errorMessage = details.error;
    if (details?.userFeedback) record.userFeedback = details.userFeedback;

    record.witnessNotes.push(`d3:outcome:${outcome}:${Date.now()}`);

    // Update trajectory
    const trajectory = this.trajectories.get(record.evolutionId);
    if (trajectory) {
      if (outcome === 'failure' || outcome === 'rolled_back') {
        trajectory.status = outcome === 'rolled_back' ? 'rolled_back' : 'failed';
      }
      trajectory.completedAt = Date.now();
      this.recalculateTrajectoryCoherence(trajectory);
    }
  }

  // Get the evolution history of a specific page/component
  getHistory(targetId: string): EvolutionRecord[] {
    return this.records
      .filter(r => r.targetId === targetId)
      .sort((a, b) => a.timestamp - b.timestamp);
  }

  // Get all trajectories
  getTrajectories(): EvolutionTrajectory[] {
    return Array.from(this.trajectories.values())
      .sort((a, b) => b.startedAt - a.startedAt);
  }

  // Get the current attractor landscape
  getAttractorLandscape(): Record<string, { pages: string[]; coherence: number; count: number }> {
    const landscape: Record<string, { pages: string[]; coherence: number; count: number }> = {};

    for (const [basin, pageIds] of this.attractorBasins) {
      const basinRecords = this.records.filter(r => r.resonancePattern === basin);
      const avgCoherence = basinRecords.length > 0
        ? basinRecords.reduce((sum, r) => sum + r.coherenceScore, 0) / basinRecords.length
        : 0;

      landscape[basin] = {
        pages: [...new Set(pageIds)],
        coherence: avgCoherence,
        count: basinRecords.length
      };
    }

    return landscape;
  }

  // Learn from patterns: suggest what evolution makes sense next
  suggestNextEvolution(currentPages: string[]): { type: string; confidence: number; reasoning: string }[] {
    const suggestions: { type: string; confidence: number; reasoning: string }[] = [];

    // Analyze what types of pages are missing
    const hasProfile = currentPages.some(p => p.includes('profile') || p.includes('user'));
    const hasSettings = currentPages.some(p => p.includes('settings') || p.includes('config'));
    const hasStats = currentPages.some(p => p.includes('stats') || p.includes('analytics'));
    const hasSearch = currentPages.some(p => p.includes('search') || p.includes('find'));

    if (!hasProfile) {
      suggestions.push({
        type: 'profile_page',
        confidence: 0.85,
        reasoning: 'No user identity page found. Most apps need a profile for personalization.'
      });
    }
    if (!hasSettings) {
      suggestions.push({
        type: 'settings_page',
        confidence: 0.80,
        reasoning: 'No configuration page found. Users need control over app behavior.'
      });
    }
    if (!hasStats) {
      suggestions.push({
        type: 'analytics_page',
        confidence: 0.65,
        reasoning: 'No data visualization found. Users benefit from seeing their activity patterns.'
      });
    }
    if (!hasSearch) {
      suggestions.push({
        type: 'search_page',
        confidence: 0.55,
        reasoning: 'No search functionality found. As app grows, discoverability becomes critical.'
      });
    }

    // Sort by confidence
    return suggestions.sort((a, b) => b.confidence - a.confidence);
  }

  // Serialize state for persistence
  serialize(): string {
    return JSON.stringify({
      records: this.records,
      trajectories: Array.from(this.trajectories.entries()),
      attractorBasins: Array.from(this.attractorBasins.entries()),
      exportedAt: Date.now()
    });
  }

  // Deserialize from stored state
  deserialize(data: string): void {
    const parsed = JSON.parse(data);
    this.records = parsed.records || [];
    this.trajectories = new Map(parsed.trajectories || []);
    this.attractorBasins = new Map(parsed.attractorBasins || []);
  }

  private calculateCoherence(record: Omit<EvolutionRecord, 'id' | 'coherenceScore' | 'resonancePattern'>): number {
    // Coherence measures how well this evolution fits the existing app structure
    let score = 0.5; // baseline

    // Check if similar evolutions succeeded in the past
    const similarRecords = this.records.filter(r => 
      r.type === record.type && r.outcome === 'success'
    );
    if (similarRecords.length > 0) {
      score += 0.2;
    }

    // Check temporal proximity to other successful evolutions
    const recentSuccess = this.records.filter(r => 
      r.outcome === 'success' && 
      Date.now() - r.timestamp < 86400000 // within 24h
    );
    if (recentSuccess.length > 0) {
      score += 0.1;
    }

    // Penalize if same target has failed before
    const targetFailures = this.records.filter(r => 
      r.targetId === record.targetId && r.outcome === 'failure'
    );
    if (targetFailures.length > 0) {
      score -= 0.3 * targetFailures.length;
    }

    return Math.max(0, Math.min(1, score));
  }

  private determineAttractorBasin(record: Omit<EvolutionRecord, 'id' | 'coherenceScore' | 'resonancePattern'>): string {
    // Classify the evolution into an attractor basin based on semantic properties
    const name = record.targetName.toLowerCase();

    if (name.includes('profile') || name.includes('user') || name.includes('account')) {
      return 'identity';
    } else if (name.includes('setting') || name.includes('config') || name.includes('pref')) {
      return 'control';
    } else if (name.includes('stat') || name.includes('analytics') || name.includes('data') || name.includes('chart')) {
      return 'insight';
    } else if (name.includes('search') || name.includes('find') || name.includes('discover')) {
      return 'exploration';
    } else if (name.includes('chat') || name.includes('message') || name.includes('social')) {
      return 'connection';
    } else if (name.includes('home') || name.includes('main') || name.includes('dashboard')) {
      return 'center';
    } else {
      return 'misc';
    }
  }

  private updateTrajectory(record: EvolutionRecord): void {
    let trajectory = this.trajectories.get(record.evolutionId);

    if (!trajectory) {
      trajectory = {
        evolutionId: record.evolutionId,
        records: [],
        startedAt: record.timestamp,
        status: 'active',
        coherenceScore: record.coherenceScore,
        attractorBasin: record.resonancePattern
      };
      this.trajectories.set(record.evolutionId, trajectory);
    }

    trajectory.records.push(record);
    this.recalculateTrajectoryCoherence(trajectory);

    // Update attractor basin mapping
    const basinPages = this.attractorBasins.get(record.resonancePattern) || [];
    if (!basinPages.includes(record.targetId)) {
      basinPages.push(record.targetId);
      this.attractorBasins.set(record.resonancePattern, basinPages);
    }
  }

  private recalculateTrajectoryCoherence(trajectory: EvolutionTrajectory): void {
    if (trajectory.records.length === 0) return;
    const sum = trajectory.records.reduce((acc, r) => acc + r.coherenceScore, 0);
    trajectory.coherenceScore = sum / trajectory.records.length;
  }
}

export default EvolutionObserver;
