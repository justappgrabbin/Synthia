/**
 * Synthia Self-Evolving App — Module Exports
 * 
 * Import everything from here:
 *   import { SynthiaEvolvingApp, IntentBridge, EvolutionObserver } from './synthia';
 */

export { default as SynthiaEvolvingApp } from './synthia-evolving-app';
export { IntentBridge } from './intent-bridge';
export type { IntentSignal, IntentResponse } from './intent-bridge';
export { EvolutionObserver } from './evolution-observer';
export type { EvolutionRecord, EvolutionTrajectory } from './evolution-observer';
export { DynamicExecutor } from './dynamic-executor';
export { SelfEditor } from './self-editor';
export type { EditOperation, EditResult } from './self-editor';
export { LocalAIClient } from './synthia-evolving-app';
export type { AIClient } from './synthia-evolving-app';
