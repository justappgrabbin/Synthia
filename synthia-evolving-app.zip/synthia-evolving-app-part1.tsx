/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  Synthia Self-Evolving App — Main Orchestrator                   ║
 * ║  Intent Engine (Brain) → Synthia Body (Bridge) → Agent Swarm   ║
 * ║  Mapped to 5D Cognitive Stack:                                   ║
 * ║    D1 = Impulse (evolution triggers)                               ║
 * ║    D2 = Polarity (add vs modify — creation vs editing)           ║
 * ║    D3 = Witness (evolution observer — longitudinal coherence)    ║
 * ║    D4 = Context (app state analysis — what exists, what needs)    ║
 * ║    D5 = Meaning (semantic naming — why this evolution matters)   ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, TouchableOpacity, ScrollView, StyleSheet,
  Alert, ActivityIndicator, Modal, TextInput, SafeAreaView,
  StatusBar, FlatList, Switch
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import RNFS from 'react-native-fs';

// Synthia subsystems
import { IntentBridge, IntentSignal } from './intent-bridge';
import { EvolutionObserver, EvolutionRecord } from './evolution-observer';
import { DynamicExecutor } from './dynamic-executor';
import { SelfEditor, EditOperation } from './self-editor';

// ═══════════════════════════════════════════════════════════════
// D4: Context — App Registry (what exists, what the app knows)
// ═══════════════════════════════════════════════════════════════

interface PageDef {
  id: string;
  name: string;
  type: 'screen' | 'component';
  icon: string;
  enabled: boolean;
  createdAt: string;
  evolutionId?: string;
  coherenceScore?: number;
  basin?: string;
}

interface AppState {
  version: string;
  pages: PageDef[];
  navigation: { initialRoute: string; routes: string[] };
  evolutionCount: number;
  lastEvolutionAt: number | null;
  healthScore: number;  // 0-100
}

const SEED_STATE: AppState = {
  version: '1.0.0',
  pages: [
    {
      id: 'home',
      name: 'Home',
      type: 'screen',
      icon: '🏠',
      enabled: true,
      createdAt: new Date().toISOString(),
      basin: 'center'
    }
  ],
  navigation: { initialRoute: 'home', routes: ['home'] },
  evolutionCount: 0,
  lastEvolutionAt: null,
  healthScore: 100
};

const REGISTRY_FILE = `${RNFS.DocumentDirectoryPath}/synthia_registry.json`;
const COMPONENTS_DIR = `${RNFS.DocumentDirectoryPath}/synthia_components`;
const STATE_FILE = `${RNFS.DocumentDirectoryPath}/synthia_state.json`;
const OBSERVER_FILE = `${RNFS.DocumentDirectoryPath}/synthia_observer.json`;

// ═══════════════════════════════════════════════════════════════
// D5: Meaning — Semantic Analysis Engine
// ═══════════════════════════════════════════════════════════════

class MeaningEngine {
  /**
   * Analyze what a page "means" in the context of the app.
   * Returns semantic tags that describe the page's role.
   */
  static analyzePage(name: string, description?: string): {
    tags: string[];
    basin: string;
    purpose: string;
    userValue: string;
  } {
    const lower = (name + ' ' + (description || '')).toLowerCase();
    const tags: string[] = [];
    let basin = 'misc';
    let purpose = 'General functionality';
    let userValue = 'Provides app features';

    if (lower.includes('home') || lower.includes('dash') || lower.includes('main')) {
      tags.push('hub', 'navigation', 'overview');
      basin = 'center';
      purpose = 'Central hub for app navigation and overview';
      userValue = 'Quick access to all app features';
    }
    if (lower.includes('profile') || lower.includes('user') || lower.includes('account') || lower.includes('me')) {
      tags.push('identity', 'personal', 'settings');
      basin = 'identity';
      purpose = 'User identity and personalization management';
      userValue = 'Express who you are and customize your experience';
    }
    if (lower.includes('setting') || lower.includes('config') || lower.includes('pref') || lower.includes('option')) {
      tags.push('control', 'customization', 'preferences');
      basin = 'control';
      purpose = 'App configuration and behavior control';
      userValue = 'Make the app work exactly how you want';
    }
    if (lower.includes('stat') || lower.includes('analytics') || lower.includes('data') || lower.includes('chart') || lower.includes('report')) {
      tags.push('insight', 'visualization', 'tracking');
      basin = 'insight';
      purpose = 'Data visualization and activity tracking';
      userValue = 'Understand your patterns and progress';
    }
    if (lower.includes('search') || lower.includes('find') || lower.includes('discover') || lower.includes('explore') || lower.includes('browse')) {
      tags.push('exploration', 'discovery', 'navigation');
      basin = 'exploration';
      purpose = 'Content discovery and search functionality';
      userValue = 'Find exactly what you need, when you need it';
    }
    if (lower.includes('chat') || lower.includes('message') || lower.includes('social') || lower.includes('community') || lower.includes('connect')) {
      tags.push('connection', 'communication', 'social');
      basin = 'connection';
      purpose = 'Communication and social interaction';
      userValue = 'Stay connected with others';
    }
    if (lower.includes('note') || lower.includes('journal') || lower.includes('log') || lower.includes('diary') || lower.includes('memo')) {
      tags.push('memory', 'expression', 'reflection');
      basin = 'memory';
      purpose = 'Personal recording and reflection space';
      userValue = 'Capture your thoughts and experiences';
    }
    if (lower.includes('task') || lower.includes('todo') || lower.includes('goal') || lower.includes('plan') || lower.includes('schedule')) {
      tags.push('action', 'organization', 'productivity');
      basin = 'action';
      purpose = 'Task management and goal tracking';
      userValue = 'Get things done and achieve your goals';
    }

    if (tags.length === 0) {
      tags.push('feature', 'utility');
      purpose = 'App feature providing specific functionality';
      userValue = 'Extends app capabilities';
    }

    return { tags, basin, purpose, userValue };
  }

  /**
   * Generate a meaningful name for a new page based on context.
   */
  static suggestName(context: { existingPages: string[]; lastAction?: string; userHint?: string }): {
    name: string;
    id: string;
    icon: string;
    description: string;
  } {
    const existing = context.existingPages.map(p => p.toLowerCase());
    const hasProfile = existing.some(p => p.includes('profile') || p.includes('user'));
    const hasSettings = existing.some(p => p.includes('setting') || p.includes('config'));
    const hasStats = existing.some(p => p.includes('stat') || p.includes('analytics'));
    const hasSearch = existing.some(p => p.includes('search') || p.includes('find'));
    const hasNotes = existing.some(p => p.includes('note') || p.includes('journal'));
    const hasTasks = existing.some(p => p.includes('task') || p.includes('todo'));
    const hasChat = existing.some(p => p.includes('chat') || p.includes('message'));

    // Priority order of missing essentials
    if (!hasProfile) {
      return {
        name: 'Profile',
        id: 'profile',
        icon: '👤',
        description: 'Your personal space within the app'
      };
    }
    if (!hasSettings) {
      return {
        name: 'Settings',
        id: 'settings',
        icon: '⚙️',
        description: 'Configure and personalize your experience'
      };
    }
    if (!hasStats) {
      return {
        name: 'Insights',
        id: 'insights',
        icon: '📊',
        description: 'Track your activity and discover patterns'
      };
    }
    if (!hasNotes) {
      return {
        name: 'Journal',
        id: 'journal',
        icon: '📝',
        description: 'Capture thoughts, ideas, and reflections'
      };
    }
    if (!hasTasks) {
      return {
        name: 'Goals',
        id: 'goals',
        icon: '🎯',
        description: 'Set and track your personal objectives'
      };
    }
    if (!hasSearch) {
      return {
        name: 'Discover',
        id: 'discover',
        icon: '🔍',
        description: 'Find and explore content across the app'
      };
    }
    if (!hasChat) {
      return {
        name: 'Connect',
        id: 'connect',
        icon: '💬',
        description: 'Communicate and share with others'
      };
    }

    // If user provided a hint, use it
    if (context.userHint) {
      const hint = context.userHint.toLowerCase().replace(/\s+/g, '_');
      return {
        name: context.userHint,
        id: hint,
        icon: '✨',
        description: `Custom feature: ${context.userHint}`
      };
    }

    // Fallback: generic evolution
    return {
      name: 'Evolve',
      id: `evolve_${Date.now()}`,
      icon: '🧬',
      description: 'A new capability born from the app itself'
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// AI Client Interface (pluggable — can be local, MCP, or cloud)
// ═══════════════════════════════════════════════════════════════

interface AIClient {
  generatePage(params: {
    id: string;
    name: string;
    description: string;
    icon: string;
    existingPages: PageDef[];
    appContext: string;
  }): Promise<string>;

  suggestModification(params: {
    targetId: string;
    currentCode: string;
    request: string;
  }): Promise<string>;
}

// Local/Mock AI client for demo and offline use
class LocalAIClient implements AIClient {
  async generatePage(params: {
    id: string; name: string; description: string; icon: string;
    existingPages: PageDef[]; appContext: string;
  }): Promise<string> {
    // In production, this calls your MCP server, Termux daemon, or cloud API
    // For now, generate a rich template based on the page type
    return this.generateRichTemplate(params);
  }

  async suggestModification(params: {
    targetId: string; currentCode: string; request: string;
  }): Promise<string> {
    // In production, this sends code + request to AI for refactoring
    // For now, return a comment indicating what would change
    return params.currentCode + `\n\n/* TODO: AI would apply: ${params.request} */`;
  }

  private generateRichTemplate(params: {
    id: string; name: string; description: string; icon: string;
    existingPages: PageDef[]; appContext: string;
  }): string {
    const { id, name, icon, description } = params;
    const lowerName = name.toLowerCase();

    // Generate contextually appropriate templates
    if (lowerName.includes('profile') || lowerName.includes('user')) {
      return this.profileTemplate(id, name, icon, description);
    }
    if (lowerName.includes('setting') || lowerName.includes('config')) {
      return this.settingsTemplate(id, name, icon, description);
    }
    if (lowerName.includes('stat') || lowerName.includes('insight') || lowerName.includes('analytics')) {
      return this.statsTemplate(id, name, icon, description);
    }
    if (lowerName.includes('note') || lowerName.includes('journal')) {
      return this.journalTemplate(id, name, icon, description);
    }
    if (lowerName.includes('task') || lowerName.includes('goal') || lowerName.includes('todo')) {
      return this.goalsTemplate(id, name, icon, description);
    }
    if (lowerName.includes('search') || lowerName.includes('discover')) {
      return this.discoverTemplate(id, name, icon, description);
    }
    if (lowerName.includes('chat') || lowerName.includes('connect') || lowerName.includes('message')) {
      return this.connectTemplate(id, name, icon, description);
    }

    return this.genericTemplate(id, name, icon, description);
  }

  private profileTemplate(id: string, name: string, icon: string, description: string): string {
    return `function ${id}Screen({ navigation }) {
  const [user, setUser] = useState({ name: 'Synthia User', bio: '', theme: 'light' });
  const [editing, setEditing] = useState(false);
  const [tempName, setTempName] = useState(user.name);
  const [tempBio, setTempBio] = useState(user.bio);

  const saveProfile = () => {
    setUser({ ...user, name: tempName, bio: tempBio });
    setEditing(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>${icon} ${name}</Text>
      <Text style={styles.subtitle}>${description}</Text>

      <View style={styles.card}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{user.name.split(' ').map(n => n[0]).join('')}</Text>
        </View>

        {editing ? (
          <View style={styles.editForm}>
            <TextInput style={styles.input} value={tempName} onChangeText={setTempName} placeholder="Name" />
            <TextInput style={[styles.input, styles.bioInput]} value={tempBio} onChangeText={setTempBio} placeholder="Bio" multiline />
            <TouchableOpacity style={styles.saveButton} onPress={saveProfile}>
              <Text style={styles.buttonText}>Save</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.infoSection}>
            <Text style={styles.name}>{user.name}</Text>
            <Text style={styles.bio}>{user.bio || 'No bio yet'}</Text>
            <TouchableOpacity style={styles.editButton} onPress={() => { setTempName(user.name); setTempBio(user.bio); setEditing(true); }}>
              <Text style={styles.editButtonText}>Edit Profile</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      <View style={styles.statsRow}>
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>0</Text>
          <Text style={styles.statLabel}>Entries</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>0</Text>
          <Text style={styles.statLabel}>Connections</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>0</Text>
          <Text style={styles.statLabel}>Goals</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f8f9fa' },
  title: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginTop: 20, marginBottom: 4 },
  subtitle: { fontSize: 14, color: '#666', textAlign: 'center', marginBottom: 24 },
  card: { backgroundColor: 'white', borderRadius: 16, padding: 24, alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 4 },
  avatar: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#6366f1', justifyContent: 'center', alignItems: 'center', marginBottom: 16 },
  avatarText: { color: 'white', fontSize: 28, fontWeight: 'bold' },
  name: { fontSize: 22, fontWeight: 'bold', color: '#1a1a1a', marginBottom: 4 },
  bio: { fontSize: 14, color: '#666', textAlign: 'center', marginBottom: 12 },
  editForm: { width: '100%', alignItems: 'center' },
  input: { width: '100%', borderWidth: 1, borderColor: '#e5e7eb', borderRadius: 8, padding: 12, marginBottom: 12, fontSize: 16 },
  bioInput: { height: 80, textAlignVertical: 'top' },
  saveButton: { backgroundColor: '#10b981', paddingHorizontal: 32, paddingVertical: 12, borderRadius: 8 },
  buttonText: { color: 'white', fontSize: 16, fontWeight: '600' },
  editButton: { paddingHorizontal: 20, paddingVertical: 8, borderRadius: 8, borderWidth: 1, borderColor: '#6366f1' },
  editButtonText: { color: '#6366f1', fontSize: 14, fontWeight: '500' },
  infoSection: { alignItems: 'center', width: '100%' },
  statsRow: { flexDirection: 'row', justifyContent: 'space-around', marginTop: 20, backgroundColor: 'white', borderRadius: 12, padding: 16 },
  statItem: { alignItems: 'center' },
  statNumber: { fontSize: 24, fontWeight: 'bold', color: '#6366f1' },
  statLabel: { fontSize: 12, color: '#666', marginTop: 4 }
});`;
  }

  private settingsTemplate(id: string, name: string, icon: string, description: string): string {
    return `function ${id}Screen({ navigation }) {
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [autoEvolve, setAutoEvolve] = useState(false);
  const [fontSize, setFontSize] = useState('medium');

  const settings = [
    { id: 'darkMode', label: 'Dark Mode', icon: '🌙', value: darkMode, setter: setDarkMode },
    { id: 'notifications', label: 'Notifications', icon: '🔔', value: notifications, setter: setNotifications },
    { id: 'autoEvolve', label: 'Auto-Evolve', icon: '🧬', value: autoEvolve, setter: setAutoEvolve, description: 'Let the app grow on its own' },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>${icon} ${name}</Text>
      <Text style={styles.subtitle}>${description}</Text>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>⚡ Preferences</Text>
        {settings.map(item => (
          <View key={item.id} style={styles.settingRow}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>{item.icon}</Text>
              <View>
                <Text style={styles.settingLabel}>{item.label}</Text>
                {item.description && <Text style={styles.settingDesc}>{item.description}</Text>}
              </View>
            </View>
            <Switch value={item.value} onValueChange={item.setter} trackColor={{ false: '#e5e7eb', true: '#6366f1' }} />
          </View>
        ))}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>📱 App Info</Text>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Version</Text>
          <Text style={styles.infoValue}>1.0.0</Text>
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Evolutions</Text>
          <Text style={styles.infoValue}>0</Text>
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Health</Text>
          <Text style={styles.infoValue}>100%</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f8f9fa' },
  title: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginTop: 20, marginBottom: 4 },
  subtitle: { fontSize: 14, color: '#666', textAlign: 'center', marginBottom: 24 },
  section: { backgroundColor: 'white', borderRadius: 16, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 4 },
  sectionTitle: { fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 12 },
  settingRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#f3f4f6' },
  settingLeft: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  settingIcon: { fontSize: 20, marginRight: 12 },
  settingLabel: { fontSize: 16, color: '#1a1a1a' },
  settingDesc: { fontSize: 12, color: '#9ca3af', marginTop: 2 },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#f3f4f6' },
  infoLabel: { fontSize: 15, color: '#374151' },
  infoValue: { fontSize: 15, color: '#6366f1', fontWeight: '500' }
});`;
  }

  private statsTemplate(id: string, name: string, icon: string, description: string): string {
    return `function ${id}Screen({ navigation }) {
  const [stats] = useState({
    evolutions: 0, uptime: '100%', health: 100, pages: 1,
    lastUpdate: new Date().toLocaleDateString()
  });

  const metrics = [
    { label: 'Evolutions', value: stats.evolutions, icon: '🧬', color: '#6366f1' },
    { label: 'Pages', value: stats.pages, icon: '📄', color: '#10b981' },
    { label: 'Health', value: stats.health + '%', icon: '❤️', color: '#ef4444' },
    { label: 'Uptime', value: stats.uptime, icon: '⏱️', color: '#f59e0b' },
  ];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>${icon} ${name}</Text>
      <Text style={styles.subtitle}>${description}</Text>

      <View style={styles.grid}>
        {metrics.map((m, i) => (
          <View key={i} style={[styles.metricCard, { borderLeftColor: m.color }]}>
            <Text style={styles.metricIcon}>{m.icon}</Text>
            <Text style={[styles.metricValue, { color: m.color }]}>{m.value}</Text>
            <Text style={styles.metricLabel}>{m.label}</Text>
          </View>
        ))}
      </View>

      <View style={styles.timeline}>
        <Text style={styles.timelineTitle}>📈 Evolution Timeline</Text>
        <Text style={styles.timelineText}>Your app is just getting started. Each evolution adds new capabilities.</Text>
        <View style={styles.timelineBar}>
          <View style={[styles.timelineProgress, { width: '5%' }]} />
        </View>
        <Text style={styles.timelineStatus}>Seed stage — 1 page active</Text>
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>Last updated: {stats.lastUpdate}</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f8f9fa' },
  title: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginTop: 20, marginBottom: 4 },
  subtitle: { fontSize: 14, color: '#666', textAlign: 'center', marginBottom: 24 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginBottom: 20 },
  metricCard: { width: '48%', backgroundColor: 'white', borderRadius: 12, padding: 20, marginBottom: 12, alignItems: 'center', borderLeftWidth: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  metricIcon: { fontSize: 28, marginBottom: 8 },
  metricValue: { fontSize: 28, fontWeight: 'bold', marginBottom: 4 },
  metricLabel: { fontSize: 12, color: '#666' },
  timeline: { backgroundColor: 'white', borderRadius: 16, padding: 20, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 4 },
  timelineTitle: { fontSize: 18, fontWeight: '600', marginBottom: 8 },
  timelineText: { fontSize: 14, color: '#666', marginBottom: 16, lineHeight: 20 },
  timelineBar: { height: 8, backgroundColor: '#e5e7eb', borderRadius: 4, marginBottom: 8 },
  timelineProgress: { height: 8, backgroundColor: '#6366f1', borderRadius: 4 },
  timelineStatus: { fontSize: 13, color: '#6366f1', fontWeight: '500' },
  footer: { alignItems: 'center', paddingVertical: 20 },
  footerText: { fontSize: 12, color: '#9ca3af' }
});`;
  }

  private journalTemplate(id: string, name: string, icon: string, description: string): string {
    return `function ${id}Screen({ navigation }) {
  const [entries, setEntries] = useState([]);
  const [newEntry, setNewEntry] = useState('');
  const [showInput, setShowInput] = useState(false);

  const addEntry = () => {
    if (newEntry.trim()) {
      setEntries([{ id: Date.now(), text: newEntry, date: new Date().toLocaleString() }, ...entries]);
      setNewEntry('');
      setShowInput(false);
    }
  };

  const deleteEntry = (id) => {
    setEntries(entries.filter(e => e.id !== id));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>${icon} ${name}</Text>
      <Text style={styles.subtitle}>${description}</Text>

      {!showInput ? (
        <TouchableOpacity style={styles.addButton} onPress={() => setShowInput(true)}>
          <Text style={styles.addButtonText}>+ New Entry</Text>
        </TouchableOpacity>
      ) : (
        <View style={styles.inputCard}>
          <TextInput style={styles.input} multiline placeholder="What's on your mind?" value={newEntry} onChangeText={setNewEntry} autoFocus />
          <View style={styles.inputActions}>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => { setShowInput(false); setNewEntry(''); }}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.saveBtn} onPress={addEntry}>
              <Text style={styles.saveText}>Save</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      <FlatList
        data={entries}
        keyExtractor={item => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.entryCard}>
            <Text style={styles.entryText}>{item.text}</Text>
            <View style={styles.entryFooter}>
              <Text style={styles.entryDate}>{item.date}</Text>
              <TouchableOpacity onPress={() => deleteEntry(item.id)}>
                <Text style={styles.deleteText}>🗑️</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>📖</Text>
            <Text style={styles.emptyText}>No entries yet. Start writing!</Text>
          </View>
        }
        contentContainerStyle={entries.length === 0 && styles.emptyList}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f8f9fa' },
  title: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginTop: 20, marginBottom: 4 },
  subtitle: { fontSize: 14, color: '#666', textAlign: 'center', marginBottom: 20 },
  addButton: { backgroundColor: '#6366f1', padding: 16, borderRadius: 12, alignItems: 'center', marginBottom: 16 },
  addButtonText: { color: 'white', fontSize: 16, fontWeight: '600' },
  inputCard: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  input: { height: 100, textAlignVertical: 'top', fontSize: 16, color: '#1a1a1a', lineHeight: 22 },
  inputActions: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 12, gap: 12 },
  cancelBtn: { paddingHorizontal: 16, paddingVertical: 8 },
  cancelText: { color: '#6b7280', fontSize: 14 },
  saveBtn: { backgroundColor: '#6366f1', paddingHorizontal: 20, paddingVertical: 8, borderRadius: 8 },
  saveText: { color: 'white', fontSize: 14, fontWeight: '600' },
  entryCard: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 2, elevation: 2 },
  entryText: { fontSize: 15, color: '#1a1a1a', lineHeight: 22, marginBottom: 8 },
  entryFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  entryDate: { fontSize: 12, color: '#9ca3af' },
  deleteText: { fontSize: 16 },
  emptyState: { alignItems: 'center', paddingVertical: 60 },
  emptyIcon: { fontSize: 48, marginBottom: 12 },
  emptyText: { fontSize: 16, color: '#9ca3af' },
  emptyList: { flex: 1, justifyContent: 'center' }
});`;
  }

  private goalsTemplate(id: string, name: string, icon: string, description: string): string {
    return `function ${id}Screen({ navigation }) {
  const [goals, setGoals] = useState([]);
  const [newGoal, setNewGoal] = useState('');
  const [showInput, setShowInput] = useState(false);

  const addGoal = () => {
    if (newGoal.trim()) {
      setGoals([...goals, { id: Date.now(), text: newGoal, completed: false, createdAt: new Date().toLocaleDateString() }]);
      setNewGoal('');
      setShowInput(false);
    }
  };

  const toggleGoal = (id) => {
    setGoals(goals.map(g => g.id === id ? { ...g, completed: !g.completed } : g));
  };

  const deleteGoal = (id) => {
    setGoals(goals.filter(g => g.id !== id));
  };

  const completed = goals.filter(g => g.completed).length;
  const progress = goals.length > 0 ? (completed / goals.length) * 100 : 0;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>${icon} ${name}</Text>
      <Text style={styles.subtitle}>${description}</Text>

      <View style={styles.progressCard}>
        <Text style={styles.progressTitle}>Progress</Text>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: progress + '%' }]} />
        </View>
        <Text style={styles.progressText}>{completed} of {goals.length} completed</Text>
      </View>

      {!showInput ? (
        <TouchableOpacity style={styles.addButton} onPress={() => setShowInput(true)}>
          <Text style={styles.addButtonText}>+ Add Goal</Text>
        </TouchableOpacity>
      ) : (
        <View style={styles.inputRow}>
          <TextInput style={styles.input} placeholder="What do you want to achieve?" value={newGoal} onChangeText={setNewGoal} autoFocus />
          <TouchableOpacity style={styles.saveBtn} onPress={addGoal}>
            <Text style={styles.saveText}>✓</Text>
          </TouchableOpacity>
        </View>
      )}

      <FlatList
        data={goals}
        keyExtractor={item => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity style={[styles.goalCard, item.completed && styles.goalCompleted]} onPress={() => toggleGoal(item.id)}>
            <Text style={[styles.goalCheck, item.completed && styles.goalCheckDone]}>{item.completed ? '✓' : '○'}</Text>
            <Text style={[styles.goalText, item.completed && styles.goalTextDone]}>{item.text}</Text>
            <TouchableOpacity onPress={() => deleteGoal(item.id)}>
              <Text style={styles.deleteText}>🗑️</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>🎯</Text>
            <Text style={styles.emptyText}>No goals yet. Dream big!</Text>
          </View>
        }
        contentContainerStyle={goals.length === 0 && styles.emptyList}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f8f9fa' },
  title: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginTop: 20, marginBottom: 4 },
  subtitle: { fontSize: 14, color: '#666', textAlign: 'center', marginBottom: 20 },
  progressCard: { backgroundColor: 'white', borderRadius: 16, padding: 20, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 4 },
  progressTitle: { fontSize: 16, fontWeight: '600', marginBottom: 12 },
  progressBar: { height: 10, backgroundColor: '#e5e7eb', borderRadius: 5, marginBottom: 8 },
  progressFill: { height: 10, backgroundColor: '#10b981', borderRadius: 5 },
  progressText: { fontSize: 13, color: '#6b7280' },
  addButton: { backgroundColor: '#6366f1', padding: 16, borderRadius: 12, alignItems: 'center', marginBottom: 16 },
  addButtonText: { color: 'white', fontSize: 16, fontWeight: '600' },
  inputRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, gap: 8 },
  input: { flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 14, fontSize: 16, borderWidth: 1, borderColor: '#e5e7eb' },
  saveBtn: { backgroundColor: '#10b981', width: 48, height: 48, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  saveText: { color: 'white', fontSize: 20, fontWeight: 'bold' },
  goalCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 2, elevation: 2 },
  goalCompleted: { opacity: 0.7 },
  goalCheck: { fontSize: 20, marginRight: 12, color: '#9ca3af' },
  goalCheckDone: { color: '#10b981' },
  goalText: { flex: 1, fontSize: 15, color: '#1a1a1a' },
  goalTextDone: { textDecorationLine: 'line-through', color: '#9ca3af' },
  deleteText: { fontSize: 16, marginLeft: 8 },
  emptyState: { alignItems: 'center', paddingVertical: 60 },
  emptyIcon: { fontSize: 48, marginBottom: 12 },
  emptyText: { fontSize: 16, color: '#9ca3af' },
  emptyList: { flex: 1, justifyContent: 'center' }
});`;
  }

  private discoverTemplate(id: string, name: string, icon: string, description: string): string {
    return `function ${id}Screen({ navigation }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [recentSearches] = useState(['journal', 'goals', 'settings']);

  const search = () => {
    if (query.trim()) {
      // Simulate search across app pages
      setResults([
        { id: 1, title: 'Result for "' + query + '"', subtitle: 'Found in app content', type: 'content' },
        { id: 2, title: 'Related: ' + query, subtitle: 'Suggested based on your activity', type: 'suggestion' }
      ]);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>${icon} ${name}</Text>
      <Text style={styles.subtitle}>${description}</Text>

      <View style={styles.searchBar}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput style={styles.searchInput} placeholder="Search anything..." value={query} onChangeText={setQuery} onSubmitEditing={search} returnKeyType="search" />
        {query.length > 0 && (
          <TouchableOpacity onPress={() => { setQuery(''); setResults([]); }}>
            <Text style={styles.clearIcon}>✕</Text>
          </TouchableOpacity>
        )}
      </View>

      {results.length === 0 ? (
        <View style={styles.recentSection}>
          <Text style={styles.recentTitle}>Recent Searches</Text>
          <View style={styles.tags}>
            {recentSearches.map((tag, i) => (
              <TouchableOpacity key={i} style={styles.tag} onPress={() => { setQuery(tag); search(); }}>
                <Text style={styles.tagText}>{tag}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      ) : (
        <FlatList
          data={results}
          keyExtractor={item => item.id.toString()}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.resultCard}>
              <Text style={styles.resultTitle}>{item.title}</Text>
              <Text style={styles.resultSubtitle}>{item.subtitle}</Text>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f8f9fa' },
  title: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginTop: 20, marginBottom: 4 },
  subtitle: { fontSize: 14, color: '#666', textAlign: 'center', marginBottom: 24 },
  searchBar: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'white', borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 20, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  searchIcon: { fontSize: 18, marginRight: 10 },
  searchInput: { flex: 1, fontSize: 16, color: '#1a1a1a' },
  clearIcon: { fontSize: 16, color: '#9ca3af', padding: 4 },
  recentSection: { marginTop: 10 },
  recentTitle: { fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 12 },
  tags: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tag: { backgroundColor: 'white', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, borderWidth: 1, borderColor: '#e5e7eb' },
  tagText: { fontSize: 14, color: '#6366f1' },
  resultCard: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 2, elevation: 2 },
  resultTitle: { fontSize: 16, fontWeight: '600', color: '#1a1a1a', marginBottom: 4 },
  resultSubtitle: { fontSize: 13, color: '#6b7280' }
});`;
  }

  private connectTemplate(id: string, name: string, icon: string, description: string): string {
    return `function ${id}Screen({ navigation }) {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');

  const sendMessage = () => {
    if (newMessage.trim()) {
      setMessages([...messages, { id: Date.now(), text: newMessage, sender: 'me', time: new Date().toLocaleTimeString() }]);
      setNewMessage('');
      // Simulate response
      setTimeout(() => {
        setMessages(prev => [...prev, { id: Date.now() + 1, text: 'This is a placeholder response. In a real app, this would connect to a chat service.', sender: 'system', time: new Date().toLocaleTimeString() }]);
      }, 1000);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>${icon} ${name}</Text>
      <Text style={styles.subtitle}>${description}</Text>

      <FlatList
        data={messages}
        keyExtractor={item => item.id.toString()}
        renderItem={({ item }) => (
          <View style={[styles.messageBubble, item.sender === 'me' ? styles.myMessage : styles.theirMessage]}>
            <Text style={styles.messageText}>{item.text}</Text>
            <Text style={styles.messageTime}>{item.time}</Text>
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>💬</Text>
            <Text style={styles.emptyText}>Start a conversation!</Text>
          </View>
        }
        contentContainerStyle={messages.length === 0 && styles.emptyList}
        style={styles.messageList}
      />

      <View style={styles.inputBar}>
        <TextInput style={styles.input} placeholder="Type a message..." value={newMessage} onChangeText={setNewMessage} onSubmitEditing={sendMessage} />
        <TouchableOpacity style={styles.sendBtn} onPress={sendMessage}>
          <Text style={styles.sendText}>➤</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f8f9fa' },
  title: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginTop: 20, marginBottom: 4 },
  subtitle: { fontSize: 14, color: '#666', textAlign: 'center', marginBottom: 16 },
  messageList: { flex: 1 },
  messageBubble: { maxWidth: '80%', padding: 12, borderRadius: 16, marginBottom: 8 },
  myMessage: { alignSelf: 'flex-end', backgroundColor: '#6366f1', borderBottomRightRadius: 4 },
  theirMessage: { alignSelf: 'flex-start', backgroundColor: 'white', borderBottomLeftRadius: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 2, elevation: 2 },
  messageText: { fontSize: 15, color: '#1a1a1a', lineHeight: 20 },
  myMessageText: { color: 'white' },
  messageTime: { fontSize: 11, color: '#9ca3af', marginTop: 4, alignSelf: 'flex-end' },
  emptyState: { alignItems: 'center', paddingVertical: 60 },
  emptyIcon: { fontSize: 48, marginBottom: 12 },
  emptyText: { fontSize: 16, color: '#9ca3af' },
  emptyList: { flex: 1, justifyContent: 'center' },
  inputBar: { flexDirection: 'row', alignItems: 'center', paddingTop: 12, borderTopWidth: 1, borderTopColor: '#e5e7eb' },
  input: { flex: 1, backgroundColor: 'white', borderRadius: 24, paddingHorizontal: 16, paddingVertical: 10, fontSize: 15, borderWidth: 1, borderColor: '#e5e7eb', maxHeight: 100 },
  sendBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#6366f1', justifyContent: 'center', alignItems: 'center', marginLeft: 8 },
  sendText: { color: 'white', fontSize: 18 }
});`;
  }

  private genericTemplate(id: string, name: string, icon: string, description: string): string {
    return `function ${id}Screen({ navigation }) {
  const [active, setActive] = useState(false);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>${icon} ${name}</Text>
      <Text style={styles.subtitle}>${description}</Text>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Welcome to ${name}</Text>
        <Text style={styles.cardText}>This page was generated by the Synthia evolution engine. It will grow and adapt as the app learns what you need.</Text>

        <TouchableOpacity style={[styles.actionButton, active && styles.activeButton]} onPress={() => setActive(!active)}>
          <Text style={styles.actionText}>{active ? 'Active ✓' : 'Activate'}</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.infoBox}>
        <Text style={styles.infoTitle}>🧬 About This Page</Text>
        <Text style={styles.infoText}>Type: Screen</Text>
        <Text style={styles.infoText}>ID: ${id}</Text>
        <Text style={styles.infoText}>Generated: {new Date().toLocaleDateString()}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f8f9fa' },
  title: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginTop: 20, marginBottom: 4 },
  subtitle: { fontSize: 14, color: '#666', textAlign: 'center', marginBottom: 24 },
  card: { backgroundColor: 'white', borderRadius: 16, padding: 24, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 4 },
  cardTitle: { fontSize: 20, fontWeight: '600', color: '#1a1a1a', marginBottom: 8 },
  cardText: { fontSize: 14, color: '#666', lineHeight: 20, marginBottom: 16 },
  actionButton: { backgroundColor: '#6366f1', paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
  activeButton: { backgroundColor: '#10b981' },
  actionText: { color: 'white', fontSize: 16, fontWeight: '600' },
  infoBox: { backgroundColor: '#EEF2FF', borderRadius: 12, padding: 16, borderLeftWidth: 4, borderLeftColor: '#6366f1' },
  infoTitle: { fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 8 },
  infoText: { fontSize: 13, color: '#6b7280', marginBottom: 4 }
});`;
  }
}

export { LocalAIClient };
export type { AIClient };
