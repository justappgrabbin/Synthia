/**
 * Synthia Dynamic Executor
 * Compiles and executes generated React Native code at runtime.
 * Uses a component registry + Function constructor approach.
 * 
 * This is the critical bridge between "code as string" and "code as running UI".
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, ScrollView, StyleSheet,
  TextInput, FlatList, Image, ActivityIndicator, Alert,
  Switch, Slider, Modal, SafeAreaView, StatusBar, Platform
} from 'react-native';

// Registry of all dynamically loaded components
interface RegisteredComponent {
  id: string;
  name: string;
  code: string;
  compiled: boolean;
  component: React.ComponentType<any> | null;
  error: string | null;
  loadTime: number;
}

export class DynamicExecutor {
  private registry: Map<string, RegisteredComponent> = new Map();
  private static BUILTINS = {
    React, useState, useEffect, useCallback,
    View, Text, TouchableOpacity, ScrollView, StyleSheet,
    TextInput, FlatList, Image, ActivityIndicator, Alert,
    Switch, Slider, Modal, SafeAreaView, StatusBar, Platform
  };

  constructor() {}

  /**
   * Compile a component from source code string.
   * This is the core magic — we turn a string into a runnable React component.
   */
  async compileComponent(id: string, code: string): Promise<RegisteredComponent> {
    const startTime = Date.now();

    try {
      // Step 1: Sanitize and prepare the code
      const sanitizedCode = this.sanitizeCode(code);

      // Step 2: Wrap the code in a function that returns the component
      // We inject all React Native builtins as parameters
      const builtinNames = Object.keys(DynamicExecutor.BUILTINS).join(', ');
      const builtinValues = Object.values(DynamicExecutor.BUILTINS);

      const wrapperCode = `
        (function(${builtinNames}) {
          "use strict";
          ${sanitizedCode}
          // Try to return the default export or the last defined component
          if (typeof exports !== 'undefined' && exports.default) return exports.default;
          if (typeof module !== 'undefined' && module.exports) return module.exports;
          // Look for a function declaration that matches the component name
          const funcs = Object.keys(this).filter(k => typeof this[k] === 'function');
          if (funcs.length > 0) return this[funcs[funcs.length - 1]];
          return null;
        })
      `;

      // Step 3: Execute the wrapper to get the component factory
      const factory = new Function('return ' + wrapperCode)();
      const Component = factory(...builtinValues);

      if (!Component || typeof Component !== 'function') {
        throw new Error('Compiled code did not produce a valid React component');
      }

      const entry: RegisteredComponent = {
        id,
        name: id,
        code,
        compiled: true,
        component: Component,
        error: null,
        loadTime: Date.now() - startTime
      };

      this.registry.set(id, entry);
      return entry;

    } catch (error) {
      const entry: RegisteredComponent = {
        id,
        name: id,
        code,
        compiled: false,
        component: null,
        error: error instanceof Error ? error.message : String(error),
        loadTime: Date.now() - startTime
      };
      this.registry.set(id, entry);
      return entry;
    }
  }

  /**
   * Get a compiled component by ID. Recompiles if needed.
   */
  async getComponent(id: string, code?: string): Promise<React.ComponentType<any> | null> {
    const existing = this.registry.get(id);

    if (existing && existing.compiled && existing.component) {
      return existing.component;
    }

    if (code) {
      const result = await this.compileComponent(id, code);
      return result.component;
    }

    return null;
  }

  /**
   * Render a component by ID with props.
   * Returns a React element that can be used in JSX.
   */
  async render(id: string, props: any = {}, code?: string): Promise<React.ReactElement | null> {
    const Component = await this.getComponent(id, code);
    if (!Component) return null;
    return React.createElement(Component, props);
  }

  /**
   * Hot-reload a component: recompile without full app restart.
   */
  async hotReload(id: string, newCode: string): Promise<RegisteredComponent> {
    // Remove old registration
    this.registry.delete(id);
    // Recompile
    return this.compileComponent(id, newCode);
  }

  /**
   * Get all registered components.
   */
  getAllComponents(): RegisteredComponent[] {
    return Array.from(this.registry.values());
  }

  /**
   * Get component info (without the full code for performance).
   */
  getComponentInfo(id: string): Pick<RegisteredComponent, 'id' | 'name' | 'compiled' | 'error' | 'loadTime'> | null {
    const entry = this.registry.get(id);
    if (!entry) return null;
    return {
      id: entry.id,
      name: entry.name,
      compiled: entry.compiled,
      error: entry.error,
      loadTime: entry.loadTime
    };
  }

  /**
   * Check if a component is compiled and ready.
   */
  isReady(id: string): boolean {
    const entry = this.registry.get(id);
    return entry?.compiled === true && entry?.component !== null;
  }

  /**
   * Get error for a component if compilation failed.
   */
  getError(id: string): string | null {
    return this.registry.get(id)?.error || null;
  }

  /**
   * Sanitize code before compilation.
   * Removes dangerous patterns while preserving functionality.
   */
  private sanitizeCode(code: string): string {
    // Remove import/export statements (we inject builtins)
    let sanitized = code
      .replace(/import\s+.*?from\s+['"].*?['"];?\s*/g, '')
      .replace(/import\s+\{.*?\}\s+from\s+['"].*?['"];?\s*/g, '')
      .replace(/export\s+default\s+/g, '')
      .replace(/export\s+\{.*?\}\s*;?\s*/g, '')
      .replace(/export\s+/g, '');

    // Remove eval, Function constructor, and other dangerous patterns
    sanitized = sanitized
      .replace(/eval\s*\(/g, '/* eval blocked */(')
      .replace(/new\s+Function\s*\(/g, '/* Function constructor blocked */(')
      .replace(/document\.write/g, '/* document.write blocked */')
      .replace(/window\.location/g, '/* window.location blocked */');

    // Remove XML comments that might break the parser
    sanitized = sanitized.replace(/<!--.*?-->/gs, '');

    return sanitized;
  }

  /**
   * Create a fallback/error component for when compilation fails.
   */
  createErrorComponent(errorMessage: string): React.ComponentType<any> {
    return function ErrorComponent() {
      return React.createElement(View, { style: errorStyles.container },
        React.createElement(Text, { style: errorStyles.icon }, '⚠️'),
        React.createElement(Text, { style: errorStyles.title }, 'Component Error'),
        React.createElement(Text, { style: errorStyles.message }, errorMessage)
      );
    };
  }

  /**
   * Serialize registry state for persistence.
   */
  serialize(): string {
    const data = Array.from(this.registry.entries()).map(([id, entry]) => ({
      id,
      name: entry.name,
      code: entry.code,
      compiled: entry.compiled,
      error: entry.error,
      loadTime: entry.loadTime
    }));
    return JSON.stringify(data);
  }

  /**
   * Deserialize and recompile all components from stored state.
   */
  async deserialize(serialized: string): Promise<void> {
    const data = JSON.parse(serialized);
    for (const entry of data) {
      if (entry.code) {
        await this.compileComponent(entry.id, entry.code);
      }
    }
  }
}

const errorStyles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#FFF5F5',
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#FC8181',
  },
  icon: {
    fontSize: 48,
    marginBottom: 12,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#C53030',
    marginBottom: 8,
  },
  message: {
    fontSize: 14,
    color: '#742A2A',
    textAlign: 'center',
    lineHeight: 20,
  },
});

export default DynamicExecutor;
