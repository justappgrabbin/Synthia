/**
 * Synthia Intent Bridge
 * Connects the Self-Evolving App to the Intent Engine, MCP, and Termux stack.
 * Maps to D1 (Impulse) — the trigger that initiates evolution.
 */

import { EventEmitter } from 'events';

export interface IntentSignal {
  id: string;
  type: 'evolve' | 'modify' | 'repair' | 'prune' | 'observe';
  target?: string;           // page id or component id
  payload?: any;             // additional context
  source: 'user' | 'mcp' | 'termux' | 'self' | 'intent_engine';
  priority: 'critical' | 'high' | 'normal' | 'low';
  timestamp: number;
  trace: string[];           // D3 witness trace
}

export interface IntentResponse {
  signalId: string;
  status: 'accepted' | 'rejected' | 'pending' | 'failed';
  result?: any;
  error?: string;
  trace: string[];
}

export class IntentBridge extends EventEmitter {
  private queue: IntentSignal[] = [];
  private processing = false;
  private mcpEndpoint: string | null = null;
  private termuxSocket: any = null;

  constructor(config?: { mcpEndpoint?: string }) {
    super();
    if (config?.mcpEndpoint) {
      this.mcpEndpoint = config.mcpEndpoint;
    }
  }

  // D1: Impulse — Receive a signal from any source
  async receive(signal: IntentSignal): Promise<IntentResponse> {
    signal.trace = [...signal.trace, `bridge:received:${Date.now()}`];

    // Critical signals bypass queue
    if (signal.priority === 'critical') {
      return this.execute(signal);
    }

    this.queue.push(signal);
    this.emit('signal:queued', signal);
    this.processQueue();

    return {
      signalId: signal.id,
      status: 'pending',
      trace: signal.trace
    };
  }

  // Connect to Termux via WebSocket or HTTP bridge
  async connectTermux(host: string = 'localhost', port: number = 8765): Promise<void> {
    try {
      // In React Native, you'd use a WebSocket or fetch to your Termux daemon
      this.emit('termux:connected', { host, port });
    } catch (error) {
      this.emit('termux:error', error);
    }
  }

  // Connect to MCP server
  async connectMCP(endpoint: string): Promise<void> {
    this.mcpEndpoint = endpoint;
    this.emit('mcp:connected', { endpoint });
  }

  // Forward signal to external systems
  async forwardToMCP(signal: IntentSignal): Promise<any> {
    if (!this.mcpEndpoint) {
      throw new Error('MCP endpoint not configured');
    }
    // HTTP POST to MCP server
    const response = await fetch(`${this.mcpEndpoint}/intent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(signal)
    });
    return response.json();
  }

  private async processQueue(): Promise<void> {
    if (this.processing || this.queue.length === 0) return;
    this.processing = true;

    while (this.queue.length > 0) {
      const signal = this.queue.shift()!;
      await this.execute(signal);
    }

    this.processing = false;
  }

  private async execute(signal: IntentSignal): Promise<IntentResponse> {
    signal.trace.push(`bridge:execute:${Date.now()}`);
    this.emit('signal:executing', signal);

    try {
      const result = await this.routeSignal(signal);

      const response: IntentResponse = {
        signalId: signal.id,
        status: 'accepted',
        result,
        trace: [...signal.trace, `bridge:completed:${Date.now()}`]
      };

      this.emit('signal:completed', response);
      return response;
    } catch (error) {
      const response: IntentResponse = {
        signalId: signal.id,
        status: 'failed',
        error: error instanceof Error ? error.message : String(error),
        trace: [...signal.trace, `bridge:failed:${Date.now()}`]
      };
      this.emit('signal:failed', response);
      return response;
    }
  }

  private async routeSignal(signal: IntentSignal): Promise<any> {
    switch (signal.type) {
      case 'evolve':
        return this.emit('intent:evolve', signal);
      case 'modify':
        return this.emit('intent:modify', signal);
      case 'repair':
        return this.emit('intent:repair', signal);
      case 'prune':
        return this.emit('intent:prune', signal);
      case 'observe':
        return this.emit('intent:observe', signal);
      default:
        throw new Error(`Unknown intent type: ${signal.type}`);
    }
  }

  // Create an impulse from user action
  static createImpulse(
    type: IntentSignal['type'],
    source: IntentSignal['source'] = 'user',
    payload?: any
  ): IntentSignal {
    return {
      id: `intent_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      type,
      source,
      payload,
      priority: 'normal',
      timestamp: Date.now(),
      trace: [`d1:impulse:born:${Date.now()}`]
    };
  }
}

export default IntentBridge;
