
// ═══════════════════════════════════════════════════════════════
// Main App Component
// ═══════════════════════════════════════════════════════════════

export default function SynthiaEvolvingApp() {
  // ── Core State ──
  const [appState, setAppState] = useState<AppState>(SEED_STATE);
  const [currentRoute, setCurrentRoute] = useState('home');
  const [initialized, setInitialized] = useState(false);
  const [isEvolving, setIsEvolving] = useState(false);
  const [showObserver, setShowObserver] = useState(false);
  const [showEditor, setShowEditor] = useState(false);
  const [activePageCode, setActivePageCode] = useState<string | null>(null);
  const [renderError, setRenderError] = useState<string | null>(null);
  const [healthStatus, setHealthStatus] = useState<'healthy' | 'warning' | 'critical'>('healthy');

  // ── Refs to subsystems (persist across renders) ──
  const intentBridgeRef = useRef<IntentBridge | null>(null);
  const observerRef = useRef<EvolutionObserver | null>(null);
  const executorRef = useRef<DynamicExecutor | null>(null);
  const editorRef = useRef<SelfEditor | null>(null);
  const aiClientRef = useRef<AIClient | null>(null);

  // ── Initialize on mount ──
  useEffect(() => {
    initializeSynthia();
  }, []);

  // ── Persist state when it changes ──
  useEffect(() => {
    if (initialized) {
      persistState();
    }
  }, [appState, initialized]);

  const initializeSynthia = async () => {
    try {
      // 1. Create file system structure
      await ensureFileSystem();

      // 2. Load or create app state
      const loadedState = await loadState();
      setAppState(loadedState);

      // 3. Initialize subsystems
      intentBridgeRef.current = new IntentBridge();
      observerRef.current = new EvolutionObserver();
      executorRef.current = new DynamicExecutor();
      editorRef.current = new SelfEditor(executorRef.current);
      aiClientRef.current = new LocalAIClient();

      // 4. Load observer state if exists
      try {
        const observerData = await RNFS.readFile(OBSERVER_FILE, 'utf8');
        observerRef.current.deserialize(observerData);
      } catch { /* no previous observer state */ }

      // 5. Compile all existing pages
      for (const page of loadedState.pages) {
        const code = await loadComponentCode(page.id);
        if (code) {
          await executorRef.current.compileComponent(page.id, code);
        }
      }

      // 6. Set up Intent Bridge listeners
      setupIntentListeners();

      // 7. Health check
      await runHealthCheck();

      setInitialized(true);
      setCurrentRoute(loadedState.navigation.initialRoute);

    } catch (error) {
      console.error('Synthia initialization failed:', error);
      Alert.alert('Initialization Error', error instanceof Error ? error.message : String(error));
    }
  };

  const ensureFileSystem = async () => {
    const dirs = [COMPONENTS_DIR];
    for (const dir of dirs) {
      const exists = await RNFS.exists(dir);
      if (!exists) {
        await RNFS.mkdir(dir);
      }
    }
  };

  const loadState = async (): Promise<AppState> => {
    try {
      const data = await RNFS.readFile(STATE_FILE, 'utf8');
      return JSON.parse(data);
    } catch {
      // First run — save seed state
      await RNFS.writeFile(STATE_FILE, JSON.stringify(SEED_STATE, null, 2), 'utf8');
      // Save initial home screen code
      await saveComponentCode('home', generateHomeScreenCode());
      return SEED_STATE;
    }
  };

  const persistState = async () => {
    try {
      await RNFS.writeFile(STATE_FILE, JSON.stringify(appState, null, 2), 'utf8');
      if (observerRef.current) {
        await RNFS.writeFile(OBSERVER_FILE, observerRef.current.serialize(), 'utf8');
      }
    } catch (error) {
      console.error('Failed to persist state:', error);
    }
  };

  const loadComponentCode = async (id: string): Promise<string | null> => {
    try {
      const path = `${COMPONENTS_DIR}/${id}.js`;
      return await RNFS.readFile(path, 'utf8');
    } catch {
      return null;
    }
  };

  const saveComponentCode = async (id: string, code: string) => {
    const path = `${COMPONENTS_DIR}/${id}.js`;
    await RNFS.writeFile(path, code, 'utf8');
  };

  // ── D1: Impulse — Handle evolution trigger ──
  const handleEvolve = async () => {
    if (isEvolving) return;

    // Create D1 impulse
    const impulse = IntentBridge.createImpulse('evolve', 'user');

    Alert.alert(
      '🧬 Evolve New Page?',
      'The app will analyze its current structure and grow a new page that makes sense.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Evolve!',
          onPress: async () => {
            setIsEvolving(true);
            setRenderError(null);

            try {
              const result = await executeEvolution(impulse);

              if (result.success) {
                Alert.alert(
                  '🎉 New Page Born!',
                  `${result.page.icon} ${result.page.name}\n\n${result.page.description}\n\nBasin: ${result.page.basin}`,
                  [{ text: 'View It', onPress: () => setCurrentRoute(result.page.id) }]
                );
              } else {
                Alert.alert('Evolution Failed', result.error || 'Unknown error');
              }
            } catch (error) {
              Alert.alert('Evolution Error', error instanceof Error ? error.message : String(error));
            } finally {
              setIsEvolving(false);
            }
          }
        }
      ]
    );
  };

  // ── Core Evolution Execution ──
  const executeEvolution = async (impulse: IntentSignal): Promise<{
    success: boolean;
    page?: PageDef;
    error?: string;
  }> => {
    const evolutionId = `evo_${Date.now()}`;
    const observer = observerRef.current!;
    const executor = executorRef.current!;
    const aiClient = aiClientRef.current!;

    // D4: Context — Analyze current app structure
    const existingPages = appState.pages.map(p => p.name);
    const context = { existingPages, lastAction: 'evolve' };

    // D5: Meaning — Suggest what to create based on semantic analysis
    const suggestion = MeaningEngine.suggestName(context);
    const meaning = MeaningEngine.analyzePage(suggestion.name, suggestion.description);

    // D3: Witness — Record the intent
    const witnessRecord = observer.witness({
      evolutionId,
      type: 'page_added',
      targetId: suggestion.id,
      targetName: suggestion.name,
      intentSignalId: impulse.id,
      timestamp: Date.now(),
      witnessNotes: [
        `d1:impulse:evolve:${impulse.id}`,
        `d4:context:pages=${existingPages.length}`,
        `d5:meaning:basin=${meaning.basin}`,
        `d5:meaning:tags=${meaning.tags.join(',')}`,
        `d5:purpose:${meaning.purpose}`,
      ]
    });

    try {
      // Generate code via AI
      const code = await aiClient.generatePage({
        id: suggestion.id,
        name: suggestion.name,
        description: suggestion.description,
        icon: suggestion.icon,
        existingPages: appState.pages,
        appContext: `Synthia self-evolving app with ${existingPages.length} pages. Basin: ${meaning.basin}. Purpose: ${meaning.purpose}.`
      });

      // Compile the generated code
      const compileResult = await executor.compileComponent(suggestion.id, code);

      if (!compileResult.compiled) {
        throw new Error(`Compilation failed: ${compileResult.error}`);
      }

      // Save to file system
      await saveComponentCode(suggestion.id, code);

      // Update app state
      const newPage: PageDef = {
        id: suggestion.id,
        name: suggestion.name,
        type: 'screen',
        icon: suggestion.icon,
        enabled: true,
        createdAt: new Date().toISOString(),
        evolutionId,
        coherenceScore: witnessRecord.coherenceScore,
        basin: meaning.basin
      };

      const newState: AppState = {
        ...appState,
        pages: [...appState.pages, newPage],
        navigation: {
          ...appState.navigation,
          routes: [...appState.navigation.routes, suggestion.id]
        },
        version: incrementVersion(appState.version),
        evolutionCount: appState.evolutionCount + 1,
        lastEvolutionAt: Date.now(),
        healthScore: Math.min(100, appState.healthScore + 2)
      };

      setAppState(newState);

      // Mark success in observer
      observer.markOutcome(witnessRecord.id, 'success');

      return { success: true, page: newPage };

    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      observer.markOutcome(witnessRecord.id, 'failure', { error: msg });

      // Try auto-repair if compilation failed
      if (msg.includes('compile') || msg.includes('syntax')) {
        try {
          const repairResult = await editorRef.current!.autoRepair(suggestion.id, msg);
          if (repairResult.success) {
            // Retry with repaired code
            return executeEvolution(impulse);
          }
        } catch { /* repair failed too */ }
      }

      return { success: false, error: msg };
    }
  };

  // ── D2: Polarity — Modify existing page ──
  const handleModify = async (targetId: string) => {
    const code = await loadComponentCode(targetId);
    if (!code) {
      Alert.alert('Error', 'Could not load page code');
      return;
    }
    setActivePageCode(code);
    setShowEditor(true);
  };

  // ── Intent Bridge Listeners ──
  const setupIntentListeners = () => {
    const bridge = intentBridgeRef.current;
    if (!bridge) return;

    bridge.on('intent:evolve', (signal: IntentSignal) => {
      console.log('Intent: evolve received', signal.id);
    });

    bridge.on('intent:modify', (signal: IntentSignal) => {
      if (signal.target) {
        handleModify(signal.target);
      }
    });

    bridge.on('intent:repair', async (signal: IntentSignal) => {
      if (signal.target && editorRef.current) {
        const code = await loadComponentCode(signal.target);
        if (code) {
          await editorRef.current.autoRepair(signal.target, signal.payload?.error || 'Unknown error');
        }
      }
    });

    bridge.on('intent:observe', () => {
      setShowObserver(true);
    });
  };

  // ── Health Check ──
  const runHealthCheck = async () => {
    let score = 100;
    const issues: string[] = [];

    // Check all compiled components
    const components = executorRef.current?.getAllComponents() || [];
    for (const comp of components) {
      if (!comp.compiled) {
        score -= 10;
        issues.push(`Component ${comp.id} failed to compile`);
      }
    }

    // Check for orphaned pages (in state but no code)
    for (const page of appState.pages) {
      const code = await loadComponentCode(page.id);
      if (!code) {
        score -= 15;
        issues.push(`Page ${page.name} has no code file`);
      }
    }

    // Check observer health
    const trajectories = observerRef.current?.getTrajectories() || [];
    const failedTrajectories = trajectories.filter(t => t.status === 'failed');
    if (failedTrajectories.length > 3) {
      score -= 10;
      issues.push('Multiple failed evolutions detected');
    }

    score = Math.max(0, score);
    setHealthStatus(score > 80 ? 'healthy' : score > 40 ? 'warning' : 'critical');
    setAppState(prev => ({ ...prev, healthScore: score }));

    return { score, issues };
  };

  // ── Render the active page dynamically ──
  const renderActivePage = () => {
    if (!executorRef.current) return null;

    const page = appState.pages.find(p => p.id === currentRoute);
    if (!page) return null;

    const Component = executorRef.current.getComponentInfo(currentRoute);

    if (!Component) {
      return (
        <View style={styles.errorContainer}>
          <Text style={styles.errorIcon}>⚠️</Text>
          <Text style={styles.errorTitle}>Page Not Loaded</Text>
          <Text style={styles.errorText}>{page.name} exists in registry but code is not compiled.</Text>
          <TouchableOpacity style={styles.retryButton} onPress={async () => {
            const code = await loadComponentCode(page.id);
            if (code && executorRef.current) {
              await executorRef.current.compileComponent(page.id, code);
              forceUpdate();
            }
          }}>
            <Text style={styles.retryText}>Reload</Text>
          </TouchableOpacity>
        </View>
      );
    }

    if (!Component.compiled) {
      return (
        <View style={styles.errorContainer}>
          <Text style={styles.errorIcon}>💥</Text>
          <Text style={styles.errorTitle}>Compilation Error</Text>
          <Text style={styles.errorText}>{Component.error}</Text>
        </View>
      );
    }

    // Actually render the compiled component
    const Comp = executorRef.current.getComponent(currentRoute);
    if (!Comp) {
      return (
        <View style={styles.errorContainer}>
          <Text>Component loaded but not retrievable</Text>
        </View>
      );
    }

    return <Comp navigation={{ navigate: setCurrentRoute }} />;
  };

  const [, forceUpdate] = useState(0);

  // ── Loading State ──
  if (!initialized) {
    return (
      <SafeAreaView style={styles.loadingContainer}>
        <StatusBar barStyle="dark-content" />
        <ActivityIndicator size="large" color="#6366f1" />
        <Text style={styles.loadingText}>Initializing Synthia...</Text>
        <Text style={styles.loadingSubtext}>Loading cognitive stack</Text>
      </SafeAreaView>
    );
  }

  // ── Main Render ──
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Text style={styles.headerTitle}>🧬 Synthia</Text>
          <View style={[styles.healthDot, { 
            backgroundColor: healthStatus === 'healthy' ? '#10b981' : healthStatus === 'warning' ? '#f59e0b' : '#ef4444' 
          }]} />
        </View>
        <Text style={styles.headerSubtitle}>
          v{appState.version} • {appState.pages.length} pages • {appState.evolutionCount} evolutions
        </Text>
      </View>

      {/* Navigation */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.navScroll}>
        {appState.pages.map(page => (
          <TouchableOpacity
            key={page.id}
            style={[
              styles.navButton,
              currentRoute === page.id && styles.navButtonActive,
              !page.enabled && styles.navButtonDisabled
            ]}
            onPress={() => setCurrentRoute(page.id)}
          >
            <Text style={styles.navIcon}>{page.icon}</Text>
            <Text style={[
              styles.navText,
              currentRoute === page.id && styles.navTextActive
            ]}>
              {page.name}
            </Text>
            {page.basin && (
              <View style={[styles.basinDot, { 
                backgroundColor: getBasinColor(page.basin) 
              }]} />
            )}
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Content */}
      <View style={styles.content}>
        {renderActivePage()}
      </View>

      {/* Action Bar */}
      <View style={styles.actionBar}>
        <TouchableOpacity style={styles.actionBtn} onPress={() => setShowObserver(true)}>
          <Text style={styles.actionBtnIcon}>👁️</Text>
          <Text style={styles.actionBtnText}>Observer</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.evolveBtn, isEvolving && styles.evolveBtnDisabled]}
          onPress={handleEvolve}
          disabled={isEvolving}
        >
          {isEvolving ? (
            <ActivityIndicator color="white" size="small" />
          ) : (
            <Text style={styles.evolveBtnText}>✨ Evolve</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionBtn} onPress={() => handleModify(currentRoute)}>
          <Text style={styles.actionBtnIcon}>✏️</Text>
          <Text style={styles.actionBtnText}>Edit</Text>
        </TouchableOpacity>
      </View>

      {/* Observer Modal (D3) */}
      <Modal visible={showObserver} animationType="slide" onRequestClose={() => setShowObserver(false)}>
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>👁️ Evolution Observer</Text>
            <TouchableOpacity onPress={() => setShowObserver(false)}>
              <Text style={styles.modalClose}>✕</Text>
            </TouchableOpacity>
          </View>
          <ScrollView style={styles.modalContent}>
            {/* Attractor Landscape */}
            <Text style={styles.sectionTitle}>🌌 Attractor Basins</Text>
            {Object.entries(observerRef.current?.getAttractorLandscape() || {}).map(([basin, data]) => (
              <View key={basin} style={styles.basinCard}>
                <View style={styles.basinHeader}>
                  <Text style={styles.basinName}>{basin}</Text>
                  <View style={[styles.basinBadge, { backgroundColor: getBasinColor(basin) }]}>
                    <Text style={styles.basinBadgeText}>{data.pages.length}</Text>
                  </View>
                </View>
                <Text style={styles.basinMeta}>Coherence: {(data.coherence * 100).toFixed(1)}% • Evolutions: {data.count}</Text>
                <Text style={styles.basinPages}>{data.pages.join(', ')}</Text>
              </View>
            ))}

            {/* Trajectories */}
            <Text style={styles.sectionTitle}>🧬 Evolution Trajectories</Text>
            {observerRef.current?.getTrajectories().slice(0, 10).map(traj => (
              <View key={traj.evolutionId} style={styles.trajectoryCard}>
                <View style={styles.trajectoryHeader}>
                  <Text style={styles.trajectoryId}>{traj.evolutionId.slice(0, 20)}...</Text>
                  <Text style={[
                    styles.trajectoryStatus,
                    { color: traj.status === 'completed' ? '#10b981' : traj.status === 'failed' ? '#ef4444' : '#6366f1' }
                  ]}>
                    {traj.status}
                  </Text>
                </View>
                <Text style={styles.trajectoryBasin}>Basin: {traj.attractorBasin}</Text>
                <Text style={styles.trajectoryCoherence}>Coherence: {(traj.coherenceScore * 100).toFixed(1)}%</Text>
                <Text style={styles.trajectoryRecords}>{traj.records.length} records</Text>
              </View>
            ))}

            {/* Suggestions */}
            <Text style={styles.sectionTitle}>💡 Next Evolution Suggestions</Text>
            {observerRef.current?.suggestNextEvolution(appState.pages.map(p => p.name)).map((sugg, i) => (
              <View key={i} style={styles.suggestionCard}>
                <Text style={styles.suggestionType}>{sugg.type}</Text>
                <Text style={styles.suggestionConf}>{(sugg.confidence * 100).toFixed(0)}% confidence</Text>
                <Text style={styles.suggestionReason}>{sugg.reasoning}</Text>
              </View>
            ))}
          </ScrollView>
        </SafeAreaView>
      </Modal>

      {/* Editor Modal (D2) */}
      <Modal visible={showEditor} animationType="slide" onRequestClose={() => setShowEditor(false)}>
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>✏️ Self-Editor</Text>
            <TouchableOpacity onPress={() => setShowEditor(false)}>
              <Text style={styles.modalClose}>✕</Text>
            </TouchableOpacity>
          </View>
          <ScrollView style={styles.modalContent}>
            <Text style={styles.editorLabel}>Current Page Code:</Text>
            <View style={styles.codeBlock}>
              <Text style={styles.codeText} numberOfLines={50}>
                {activePageCode || 'No code loaded'}
              </Text>
            </View>
            <Text style={styles.editorNote}>
              In production, this editor would allow AI-assisted code modification, 
              hot-reloading, and rollback of changes.
            </Text>
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

// ═══════════════════════════════════════════════════════════════
// Helpers
// ═══════════════════════════════════════════════════════════════

function incrementVersion(version: string): string {
  const [major, minor, patch] = version.split('.').map(Number);
  return `${major}.${minor}.${patch + 1}`;
}

function getBasinColor(basin: string): string {
  const colors: Record<string, string> = {
    center: '#6366f1',
    identity: '#ec4899',
    control: '#6b7280',
    insight: '#10b981',
    exploration: '#f59e0b',
    connection: '#8b5cf6',
    memory: '#06b6d4',
    action: '#ef4444',
    misc: '#9ca3af'
  };
  return colors[basin] || '#9ca3af';
}

function generateHomeScreenCode(): string {
  return `function homeScreen({ navigation }) {
  const [count, setCount] = useState(0);
  const [evolutions, setEvolutions] = useState(0);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🧬 Synthia</Text>
      <Text style={styles.subtitle}>Self-Evolving App</Text>

      <View style={styles.heroCard}>
        <Text style={styles.heroTitle}>Welcome to Your Living App</Text>
        <Text style={styles.heroText}>
          This app grows with you. Each evolution adds new pages, 
          features, and capabilities based on what you need.
        </Text>
      </View>

      <View style={styles.counterCard}>
        <Text style={styles.counterLabel}>Interactions</Text>
        <Text style={styles.counterValue}>{count}</Text>
        <TouchableOpacity style={styles.counterBtn} onPress={() => setCount(c => c + 1)}>
          <Text style={styles.counterBtnText}>Tap Me</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.statusCard}>
        <Text style={styles.statusTitle}>📊 App Status</Text>
        <Text style={styles.statusItem}>🧬 Evolutions: {evolutions}</Text>
        <Text style={styles.statusItem}>📄 Pages: 1</Text>
        <Text style={styles.statusItem}>❤️ Health: 100%</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f8f9fa' },
  title: { fontSize: 36, fontWeight: 'bold', textAlign: 'center', marginTop: 20, color: '#1a1a1a' },
  subtitle: { fontSize: 16, color: '#6366f1', textAlign: 'center', marginBottom: 24, fontWeight: '500' },
  heroCard: { backgroundColor: '#EEF2FF', borderRadius: 16, padding: 20, marginBottom: 16, borderLeftWidth: 4, borderLeftColor: '#6366f1' },
  heroTitle: { fontSize: 18, fontWeight: '600', color: '#374151', marginBottom: 8 },
  heroText: { fontSize: 14, color: '#6b7280', lineHeight: 20 },
  counterCard: { backgroundColor: 'white', borderRadius: 16, padding: 24, alignItems: 'center', marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 4 },
  counterLabel: { fontSize: 14, color: '#6b7280', marginBottom: 8 },
  counterValue: { fontSize: 56, fontWeight: 'bold', color: '#6366f1', marginBottom: 16 },
  counterBtn: { backgroundColor: '#6366f1', paddingHorizontal: 32, paddingVertical: 12, borderRadius: 12 },
  counterBtnText: { color: 'white', fontSize: 16, fontWeight: '600' },
  statusCard: { backgroundColor: 'white', borderRadius: 16, padding: 20, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 4 },
  statusTitle: { fontSize: 16, fontWeight: '600', marginBottom: 12 },
  statusItem: { fontSize: 14, color: '#6b7280', marginBottom: 6 }
});`;
}

// ═══════════════════════════════════════════════════════════════
// Styles
// ═══════════════════════════════════════════════════════════════

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8f9fa' },
  loadingText: { marginTop: 16, fontSize: 18, fontWeight: '600', color: '#1a1a1a' },
  loadingSubtext: { marginTop: 8, fontSize: 14, color: '#9ca3af' },

  header: { backgroundColor: 'white', paddingTop: 12, paddingBottom: 12, paddingHorizontal: 20, borderBottomWidth: 1, borderBottomColor: '#E5E7EB', alignItems: 'center' },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  headerTitle: { fontSize: 22, fontWeight: 'bold', color: '#1a1a1a' },
  healthDot: { width: 8, height: 8, borderRadius: 4 },
  headerSubtitle: { fontSize: 12, color: '#9ca3af', marginTop: 2 },

  navScroll: { backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#E5E7EB', paddingVertical: 8 },
  navButton: { paddingHorizontal: 16, paddingVertical: 10, marginHorizontal: 4, borderRadius: 10, alignItems: 'center', minWidth: 70, position: 'relative' },
  navButtonActive: { backgroundColor: '#6366f1' },
  navButtonDisabled: { opacity: 0.4 },
  navIcon: { fontSize: 22, marginBottom: 2 },
  navText: { fontSize: 11, color: '#6b7280', fontWeight: '500' },
  navTextActive: { color: 'white', fontWeight: '600' },
  basinDot: { position: 'absolute', top: 4, right: 4, width: 6, height: 6, borderRadius: 3 },

  content: { flex: 1 },

  actionBar: { flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 20, backgroundColor: 'white', borderTopWidth: 1, borderTopColor: '#E5E7EB' },
  actionBtn: { alignItems: 'center', paddingHorizontal: 12 },
  actionBtnIcon: { fontSize: 20, marginBottom: 2 },
  actionBtnText: { fontSize: 11, color: '#6b7280' },
  evolveBtn: { backgroundColor: '#10b981', paddingHorizontal: 28, paddingVertical: 12, borderRadius: 12, minWidth: 120, alignItems: 'center' },
  evolveBtnDisabled: { backgroundColor: '#9ca3af' },
  evolveBtnText: { color: 'white', fontSize: 16, fontWeight: 'bold' },

  errorContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  errorIcon: { fontSize: 48, marginBottom: 12 },
  errorTitle: { fontSize: 20, fontWeight: 'bold', color: '#ef4444', marginBottom: 8 },
  errorText: { fontSize: 14, color: '#6b7280', textAlign: 'center', marginBottom: 16 },
  retryButton: { backgroundColor: '#6366f1', paddingHorizontal: 24, paddingVertical: 10, borderRadius: 8 },
  retryText: { color: 'white', fontSize: 14, fontWeight: '600' },

  modalContainer: { flex: 1, backgroundColor: '#f8f9fa' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: '#1a1a1a' },
  modalClose: { fontSize: 20, color: '#6b7280', padding: 4 },
  modalContent: { padding: 20 },

  sectionTitle: { fontSize: 18, fontWeight: '600', color: '#1a1a1a', marginTop: 8, marginBottom: 12 },
  basinCard: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 2, elevation: 2 },
  basinHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  basinName: { fontSize: 16, fontWeight: '600', color: '#374151', textTransform: 'capitalize' },
  basinBadge: { borderRadius: 10, paddingHorizontal: 8, paddingVertical: 2 },
  basinBadgeText: { color: 'white', fontSize: 12, fontWeight: '600' },
  basinMeta: { fontSize: 13, color: '#6b7280', marginBottom: 4 },
  basinPages: { fontSize: 12, color: '#9ca3af' },

  trajectoryCard: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 2, elevation: 2 },
  trajectoryHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  trajectoryId: { fontSize: 12, color: '#9ca3af', fontFamily: 'monospace' },
  trajectoryStatus: { fontSize: 12, fontWeight: '600', textTransform: 'uppercase' },
  trajectoryBasin: { fontSize: 13, color: '#6b7280', marginBottom: 2 },
  trajectoryCoherence: { fontSize: 13, color: '#6b7280', marginBottom: 2 },
  trajectoryRecords: { fontSize: 12, color: '#9ca3af' },

  suggestionCard: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 10, borderLeftWidth: 4, borderLeftColor: '#6366f1' },
  suggestionType: { fontSize: 15, fontWeight: '600', color: '#374151', marginBottom: 4, textTransform: 'capitalize' },
  suggestionConf: { fontSize: 13, color: '#6366f1', fontWeight: '500', marginBottom: 6 },
  suggestionReason: { fontSize: 13, color: '#6b7280', lineHeight: 18 },

  editorLabel: { fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 8 },
  codeBlock: { backgroundColor: '#1a1a1a', borderRadius: 12, padding: 16, marginBottom: 16 },
  codeText: { fontFamily: 'monospace', fontSize: 11, color: '#e5e7eb', lineHeight: 16 },
  editorNote: { fontSize: 13, color: '#9ca3af', textAlign: 'center', lineHeight: 18 }
});
