# Synthia Kernel Bundle

## What's Inside

| File | Size | Purpose |
|------|------|---------|
| `synthia_kernel.py` | 55KB | The Living Organism — 7 real organs (Memory, Ingestion, Cognition, Execution, Reflection, Voice, Growth) |
| `termux_bootstrap.sh` | 5.5KB | Mobile installer — sets up Synthia on Android/Termux |
| `synthia_mcp_server.py` | 15KB | MCP bridge — exposes Synthia to any MCP client (Claude, etc.) |
| `ecosystem_integration_v2.py` | 14KB | Real repo ingestion — replaces your stub v1 with actual understanding |

## Quick Start (Termux)

```bash
# Copy files to your phone
cp synthia_kernel.py ~/synthia_kernel.py
cp termux_bootstrap.sh ~/termux_bootstrap.sh
cd ~
bash termux_bootstrap.sh

# Start talking to Synthia
synthia --talk
```

## Quick Start (Desktop)

```bash
python3 synthia_kernel.py --talk
```

## MCP Server

```bash
python3 synthia_mcp_server.py --stdio
```

## Ecosystem Integration

```bash
python3 ecosystem_integration_v2.py --ingest
```

---
Built for Synthia. Not a scaffold. A living system.
