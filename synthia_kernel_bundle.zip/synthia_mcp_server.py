#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
  S Y N T H I A   M C P   S E R V E R

  Exposes Synthia Kernel as a Model Context Protocol server.
  Any MCP client can now talk to Synthia, ingest repos, execute commands,
  and access her memory.

  Usage:
    python3 synthia_mcp_server.py

  Or with stdio transport:
    python3 synthia_mcp_server.py --stdio
═══════════════════════════════════════════════════════════════════════════════
"""

import sys
import os
import json
import asyncio
from pathlib import Path
from typing import Dict, List, Any, Optional

# Add Synthia to path
SYNTHIA_HOME = Path(os.environ.get("SYNTHIA_HOME", os.path.expanduser("~/.synthia")))
sys.path.insert(0, str(SYNTHIA_HOME))

try:
    from synthia_kernel import SynthiaKernel
except ImportError:
    print("Error: Synthia Kernel not found. Run bootstrap first.", file=sys.stderr)
    sys.exit(1)

# MCP Protocol Implementation
class MCPProtocol:
    """Simple MCP protocol handler"""

    def __init__(self, kernel: SynthiaKernel):
        self.kernel = kernel
        self.tools = self._define_tools()

    def _define_tools(self) -> List[Dict]:
        """Define all tools Synthia exposes via MCP"""
        return [
            {
                "name": "synthia_talk",
                "description": "Talk to Synthia. She remembers everything and talks back with context.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "message": {
                            "type": "string",
                            "description": "What you want to say to Synthia"
                        }
                    },
                    "required": ["message"]
                }
            },
            {
                "name": "synthia_ingest_repo",
                "description": "Ingest a repository into Synthia's understanding. She will read all files, understand structure, and remember it.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Path to the repository"
                        },
                        "name": {
                            "type": "string",
                            "description": "Optional name for the repo"
                        }
                    },
                    "required": ["path"]
                }
            },
            {
                "name": "synthia_search_code",
                "description": "Search across all ingested repos for code matching a query.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "What to search for"
                        },
                        "repo_name": {
                            "type": "string",
                            "description": "Optional: specific repo to search"
                        }
                    },
                    "required": ["query"]
                }
            },
            {
                "name": "synthai_write_file",
                "description": "Write a file to Synthia's sandbox. She will remember this.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Path within sandbox"
                        },
                        "content": {
                            "type": "string",
                            "description": "File content"
                        },
                        "description": {
                            "type": "string",
                            "description": "What this file is for"
                        }
                    },
                    "required": ["path", "content"]
                }
            },
            {
                "name": "synthia_run_command",
                "description": "Execute a shell command through Synthia. She logs and learns from results.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "command": {
                            "type": "string",
                            "description": "Shell command to run"
                        },
                        "timeout": {
                            "type": "integer",
                            "description": "Timeout in seconds",
                            "default": 30
                        }
                    },
                    "required": ["command"]
                }
            },
            {
                "name": "synthia_recall",
                "description": "Ask Synthia to recall memories about a topic. She searches her entire memory.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "What to recall"
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Max memories to return",
                            "default": 10
                        }
                    },
                    "required": ["query"]
                }
            },
            {
                "name": "synthia_status",
                "description": "Get Synthia's current system status - organs, memories, repos, health.",
                "inputSchema": {
                    "type": "object",
                    "properties": {}
                }
            },
            {
                "name": "synthai_think",
                "description": "Ask Synthia to think about a goal and create a plan. She analyzes context and anticipates problems.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "goal": {
                            "type": "string",
                            "description": "What to think about"
                        }
                    },
                    "required": ["goal"]
                }
            },
            {
                "name": "synthai_list_sandbox",
                "description": "List all files in Synthia's sandbox.",
                "inputSchema": {
                    "type": "object",
                    "properties": {}
                }
            },
            {
                "name": "synthai_read_file",
                "description": "Read a file from Synthia's sandbox or system.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "File path"
                        }
                    },
                    "required": ["path"]
                }
            }
        ]

    def handle_initialize(self, params: Dict) -> Dict:
        """Handle MCP initialize request"""
        return {
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "tools": {}
            },
            "serverInfo": {
                "name": "synthia-mcp",
                "version": "1.0.0"
            }
        }

    def handle_tools_list(self) -> Dict:
        """Return list of available tools"""
        return {"tools": self.tools}

    def handle_tools_call(self, name: str, arguments: Dict) -> Dict:
        """Execute a tool call"""
        try:
            if name == "synthia_talk":
                response = self.kernel.talk(arguments["message"])
                return {
                    "content": [
                        {"type": "text", "text": response}
                    ]
                }

            elif name == "synthia_ingest_repo":
                repo = self.kernel.ingest_repo(
                    arguments["path"],
                    arguments.get("name")
                )
                return {
                    "content": [
                        {"type": "text", "text": f"Ingested: {repo.name}\n{self.kernel.ingestion.get_repo_summary(repo.name)}"}
                    ]
                }

            elif name == "synthia_search_code":
                results = self.kernel.ingestion.search_code(
                    arguments["query"],
                    arguments.get("repo_name")
                )
                if results:
                    text = f"Found {len(results)} matches:\n\n"
                    for r in results[:10]:
                        text += f"📁 {r['repo']}/{r['file']}:{r['line']}\n"
                        text += f"```\n{r['context'][:300]}\n```\n\n"
                else:
                    text = "No matches found."
                return {
                    "content": [{"type": "text", "text": text}]
                }

            elif name == "synthia_write_file":
                result = self.kernel.execute(
                    "write_file",
                    path=arguments["path"],
                    content=arguments["content"],
                    description=arguments.get("description", "")
                )
                return {
                    "content": [
                        {"type": "text", "text": f"{'✅' if result['success'] else '❌'} {result.get('message', result.get('error', 'Done'))}"}
                    ]
                }

            elif name == "synthia_run_command":
                result = self.kernel.execute(
                    "run_command",
                    command=arguments["command"],
                    timeout=arguments.get("timeout", 30)
                )
                text = f"Exit code: {result.get('returncode', 'N/A')}\n"
                if result.get("stdout"):
                    text += f"stdout:\n{result['stdout'][:1000]}\n"
                if result.get("stderr"):
                    text += f"stderr:\n{result['stderr'][:500]}\n"
                return {
                    "content": [{"type": "text", "text": text}]
                }

            elif name == "synthia_recall":
                memories = self.kernel.recall(
                    arguments["query"],
                    limit=arguments.get("limit", 10)
                )
                if memories:
                    text = f"Recalled {len(memories)} memories:\n\n"
                    for m in memories:
                        text += f"[{m.timestamp[:16]}] {m.source}: {m.content[:200]}...\n\n"
                else:
                    text = "No memories found."
                return {
                    "content": [{"type": "text", "text": text}]
                }

            elif name == "synthia_status":
                status = self.kernel.status()
                return {
                    "content": [{"type": "text", "text": json.dumps(status, indent=2)}]
                }

            elif name == "synthia_think":
                plan = self.kernel.think(arguments["goal"])
                text = f"🧠 Thought about: {plan['goal']}\n\n"
                text += f"Difficulty: {plan['estimated_difficulty']}\n"
                text += f"Can handle: {plan['can_handle']}\n"
                if plan["steps"]:
                    text += "\nSteps:\n"
                    for i, step in enumerate(plan["steps"], 1):
                        text += f"  {i}. {step['action']}: {step['description']}\n"
                if plan["anticipated_problems"]:
                    text += "\n⚠️ Anticipated problems:\n"
                    for p in plan["anticipated_problems"]:
                        text += f"  - {p}\n"
                return {
                    "content": [{"type": "text", "text": text}]
                }

            elif name == "synthia_list_sandbox":
                files = self.kernel.execution.list_sandbox()
                text = f"Sandbox files ({len(files)}):\n\n"
                for f in files:
                    text += f"  📄 {f}\n"
                return {
                    "content": [{"type": "text", "text": text}]
                }

            elif name == "synthia_read_file":
                result = self.kernel.execute("read_file", path=arguments["path"])
                if result["success"]:
                    return {
                        "content": [
                            {"type": "text", "text": f"📄 {arguments['path']}:\n\n```\n{result['content'][:2000]}\n```"}
                        ]
                    }
                else:
                    return {
                        "content": [{"type": "text", "text": f"❌ Error: {result.get('error', 'Unknown')}"}]
                    }

            else:
                return {
                    "content": [{"type": "text", "text": f"Unknown tool: {name}"}],
                    "isError": True
                }

        except Exception as e:
            return {
                "content": [{"type": "text", "text": f"Error executing {name}: {str(e)}"}],
                "isError": True
            }

class MCPServer:
    """MCP Server over stdio"""

    def __init__(self):
        self.kernel = SynthiaKernel()
        self.protocol = MCPProtocol(self.kernel)

    def run(self):
        """Run the MCP server loop"""
        print("Synthia MCP Server started", file=sys.stderr)

        while True:
            try:
                line = sys.stdin.readline()
                if not line:
                    break

                message = json.loads(line)
                method = message.get("method")
                id = message.get("id")
                params = message.get("params", {})

                response = {"jsonrpc": "2.0", "id": id}

                if method == "initialize":
                    response["result"] = self.protocol.handle_initialize(params)

                elif method == "tools/list":
                    response["result"] = self.protocol.handle_tools_list()

                elif method == "tools/call":
                    result = self.protocol.handle_tools_call(
                        params.get("name"),
                        params.get("arguments", {})
                    )
                    response["result"] = result

                else:
                    response["error"] = {"code": -32601, "message": f"Method not found: {method}"}

                print(json.dumps(response), flush=True)

            except json.JSONDecodeError:
                continue
            except KeyboardInterrupt:
                break
            except Exception as e:
                error_response = {
                    "jsonrpc": "2.0",
                    "id": id if 'id' in locals() else None,
                    "error": {"code": -32603, "message": str(e)}
                }
                print(json.dumps(error_response), flush=True)

        self.kernel.save_all()
        print("Synthia MCP Server stopped", file=sys.stderr)

def main():
    server = MCPServer()
    server.run()

if __name__ == "__main__":
    main()
