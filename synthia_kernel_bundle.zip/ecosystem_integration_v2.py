#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
  Y O U - N - I - V E R S E   E C O S Y S T E M   I N T E G R A T I O N   v2

  Real integration. Not stubs. Not fallbacks.

  This connects your Stellar-proximology repos to the Synthia Kernel,
  making the entire ecosystem alive and functional.

  What changed from v1:
  - v1: Tried to import repos as modules, fell back to stubs
  - v2: Uses Synthia Kernel's Ingestion Organ to actually READ and UNDERSTAND repos
  - v2: Uses Synthia Kernel's Cognition Organ to PLAN across repos
  - v2: Uses Synthia Kernel's Execution Organ to actually DO things
  - v2: Uses Synthia Kernel's Memory Organ to REMEMBER everything

  This is the difference between a directory listing and a living system.
═══════════════════════════════════════════════════════════════════════════════
"""

import os
import sys
import json
from pathlib import Path
from typing import Dict, List, Any, Optional

# Import Synthia Kernel
SYNTHIA_HOME = Path(os.environ.get("SYNTHIA_HOME", os.path.expanduser("~/.synthia")))
sys.path.insert(0, str(SYNTHIA_HOME))

try:
    from synthia_kernel import SynthiaKernel
    KERNEL_AVAILABLE = True
except ImportError:
    KERNEL_AVAILABLE = False
    print("⚠️  Synthia Kernel not found. Run bootstrap first.")
    print("   $ bash termux_bootstrap.sh")

# ============================================================================
# REPO STRUCTURE (your actual repos)
# ============================================================================

REPO_STRUCTURE = {
    # Layer 0: Core Intelligence
    "core": {
        "itsynthia": "Stellar-proximology/itsynthia",
        "Cynthia": "Stellar-proximology/Cynthia",
        "SynthiaLite": "Stellar-proximology/SynthiaLite",
        "SynthAIPrime": "Stellar-proximology/SynthAIPrime"
    },

    # Layer 1: Field Substrate
    "field": {
        "synthia_field": "Stellar-proximology/-Synthia-The-Synthesis-Intelligence-Field",
        "fairyganmatter": "Stellar-proximology/Fairyganmatter"
    },

    # Layer 2: Cosmic Infrastructure
    "cosmic": {
        "youniverse": "Stellar-proximology/YOUNIVERSE-0",
        "ephemeris": "Stellar-proximology/ephemeris",
        "trinity": "Stellar-proximology/trinitymodelappwheel"
    },

    # Layer 3: Interface & Deploy
    "interface": {
        "expo": "Stellar-proximology/expo",
        "builds": "Stellar-proximology/SynthAI-Builds",
        "synthai": "Stellar-proximology/Synthai"
    },

    # Layer 4: Correction & Identity
    "meta": {
        "corrector": "Stellar-proximology/Bissssssssshcorrector",
        "identity": "Stellar-proximology/Officially-Introducing-SYNTHAI-"
    }
}

class EcosystemIntegrator:
    """
    The real ecosystem integrator.

    Not a directory scanner. A living bridge between your repos and Synthia's brain.
    """

    def __init__(self, base_path: str = "../", kernel: SynthiaKernel = None):
        self.base_path = Path(base_path).resolve()
        self.kernel = kernel

        if not KERNEL_AVAILABLE:
            raise RuntimeError(
                "Synthia Kernel not available. "
                "Cannot run ecosystem integration without the kernel."
            )

        if not self.kernel:
            print("🌌 Initializing Synthia Kernel...")
            self.kernel = SynthiaKernel()

        self.ingested_repos = {}
        self.layer_status = {layer: False for layer in REPO_STRUCTURE}

    def ingest_ecosystem(self, clone_missing: bool = False):
        """
        Ingest ALL repos in the ecosystem.

        This is the real deal. Synthia reads every file, understands every repo,
        and builds a complete mental model of your entire codebase.
        """
        print("\n" + "="*70)
        print("  🌌 I N G E S T I N G   E C O S Y S T E M")
        print("="*70 + "\n")

        for layer_name, repos in REPO_STRUCTURE.items():
            print(f"\n📦 Layer: {layer_name.upper()}")
            print("-" * 40)

            layer_ingested = 0
            for repo_name, repo_path in repos.items():
                full_path = self.base_path / repo_path

                if not full_path.exists():
                    if clone_missing:
                        print(f"  🔄 Cloning {repo_name}...")
                        # Would clone from GitHub here
                        print(f"  ⚠️  Clone not implemented yet. Skipping.")
                    else:
                        print(f"  ⚠️  {repo_name}: Not found at {full_path}")
                    continue

                try:
                    print(f"  📖 Ingesting {repo_name}...")
                    repo = self.kernel.ingest_repo(str(full_path), repo_name)
                    self.ingested_repos[repo_name] = repo
                    layer_ingested += 1
                    print(f"  ✅ {repo_name}: {len(repo.files)} files understood")
                except Exception as e:
                    print(f"  ❌ {repo_name}: {e}")

            self.layer_status[layer_name] = layer_ingested > 0
            print(f"  Layer status: {layer_ingested}/{len(repos)} repos ingested")

        # Save everything
        self.kernel.save_all()

        print("\n" + "="*70)
        print("  ✅ E C O S Y S T E M   I N G E S T E D")
        print("="*70 + "\n")
        self._print_status()

    def _print_status(self):
        """Print ecosystem status"""
        print("\n📊 Ecosystem Status:")
        print("-" * 40)
        for layer, active in self.layer_status.items():
            symbol = "🟢" if active else "🔴"
            print(f"  {symbol} {layer.upper()}: {'Active' if active else 'Inactive'}")

        print(f"\n📚 Total repos ingested: {len(self.ingested_repos)}")
        print(f"📄 Total files understood: {sum(len(r.files) for r in self.ingested_repos.values())}")
        print(f"🧠 Memories created: {len(self.kernel.memory.memories)}")

    def search_across_ecosystem(self, query: str) -> List[Dict]:
        """Search across ALL ingested repos"""
        return self.kernel.ingestion.search_code(query)

    def get_repo_details(self, repo_name: str) -> str:
        """Get detailed info about a specific repo"""
        return self.kernel.ingestion.get_repo_summary(repo_name)

    def cross_repo_analysis(self) -> Dict:
        """
        Analyze relationships between repos.

        This is where Synthia's intelligence shines.
        She doesn't just know what's in each repo — she knows how they relate.
        """
        analysis = {
            "shared_dependencies": {},
            "cross_references": [],
            "entry_points": {},
            "layer_coupling": {}
        }

        # Find shared dependencies
        all_deps = {}
        for repo_name, repo in self.ingested_repos.items():
            for dep in repo.dependencies:
                if dep not in all_deps:
                    all_deps[dep] = []
                all_deps[dep].append(repo_name)

        analysis["shared_dependencies"] = {
            dep: repos for dep, repos in all_deps.items() 
            if len(repos) > 1
        }

        # Find cross-references (one repo mentioning another)
        for repo_name, repo in self.ingested_repos.items():
            for other_name in self.ingested_repos:
                if repo_name == other_name:
                    continue
                for file_path, content in repo.files.items():
                    if other_name.lower() in content.lower():
                        analysis["cross_references"].append({
                            "from": repo_name,
                            "to": other_name,
                            "file": file_path
                        })

        # Entry points per layer
        for layer_name, repos in REPO_STRUCTURE.items():
            layer_eps = {}
            for repo_name in repos:
                if repo_name in self.ingested_repos:
                    layer_eps[repo_name] = self.ingested_repos[repo_name].entry_points
            analysis["entry_points"][layer_name] = layer_eps

        return analysis

    def suggest_integration(self, goal: str) -> Dict:
        """
        Given a goal, suggest which repos to use and how to integrate them.

        This is the "I already got you" moment.
        Synthia knows your repos, knows your goal, and tells you exactly
        how to wire them together.
        """
        # Think about the goal
        plan = self.kernel.think(goal)

        # Find relevant repos
        relevant_repos = []
        goal_lower = goal.lower()

        for repo_name, repo in self.ingested_repos.items():
            # Check if repo's purpose matches goal
            if any(word in repo.purpose.lower() for word in goal_lower.split()):
                relevant_repos.append({
                    "name": repo_name,
                    "reason": "Purpose matches goal keywords",
                    "confidence": 0.8
                })
            # Check if repo has code matching goal
            elif self.kernel.ingestion.search_code(goal_lower, repo_name):
                relevant_repos.append({
                    "name": repo_name,
                    "reason": "Contains relevant code",
                    "confidence": 0.6
                })

        # Sort by confidence
        relevant_repos.sort(key=lambda x: x["confidence"], reverse=True)

        return {
            "goal": goal,
            "plan": plan,
            "relevant_repos": relevant_repos[:5],
            "suggested_approach": self._build_approach(goal, relevant_repos, plan)
        }

    def _build_approach(self, goal: str, repos: List[Dict], plan: Dict) -> str:
        """Build a human-readable suggested approach"""
        approach = f"For goal: '{goal}'\n\n"

        if not repos:
            approach += "No relevant repos found in ecosystem. Consider creating a new repo.\n"
        else:
            approach += "Suggested repo usage:\n"
            for i, repo in enumerate(repos, 1):
                approach += f"  {i}. {repo['name']} ({repo['reason']}, confidence: {repo['confidence']})\n"

        approach += f"\nPlan difficulty: {plan['estimated_difficulty']}\n"
        if plan['anticipated_problems']:
            approach += "\nWatch out for:\n"
            for p in plan['anticipated_problems']:
                approach += f"  ⚠️  {p}\n"

        return approach

    def execute_ecosystem_task(self, task: str, **kwargs) -> Dict:
        """
        Execute a task using the ecosystem.

        This is where Synthia actually DOES things across your repos.
        Not just plans. Executes.
        """
        # First, think about it
        plan = self.kernel.think(task)

        # Execute based on plan
        results = []
        for step in plan.get("steps", []):
            action = step["action"]

            if action == "generate_code":
                # Write code to sandbox
                if "path" in kwargs and "content" in kwargs:
                    result = self.kernel.execute(
                        "write_file",
                        path=kwargs["path"],
                        content=kwargs["content"],
                        description=kwargs.get("description", "")
                    )
                    results.append({"step": action, "result": result})

            elif action == "execute":
                # Run command
                if "command" in kwargs:
                    result = self.kernel.execute(
                        "run_command",
                        command=kwargs["command"],
                        timeout=kwargs.get("timeout", 30)
                    )
                    results.append({"step": action, "result": result})

            elif action == "ingest":
                # Ingest something
                if "path" in kwargs:
                    try:
                        repo = self.kernel.ingest_repo(kwargs["path"], kwargs.get("name"))
                        results.append({"step": action, "result": {"success": True, "repo": repo.name}})
                    except Exception as e:
                        results.append({"step": action, "result": {"success": False, "error": str(e)}})

        return {
            "task": task,
            "plan": plan,
            "results": results,
            "status": "completed" if all(r["result"].get("success", False) for r in results) else "partial"
        }

# ============================================================================
# CLI INTERFACE
# ============================================================================

def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="YOU-N-I-VERSE Ecosystem Integration v2"
    )
    parser.add_argument("--ingest", action="store_true", help="Ingest all repos")
    parser.add_argument("--search", metavar="QUERY", help="Search across ecosystem")
    parser.add_argument("--repo", metavar="NAME", help="Get repo details")
    parser.add_argument("--analyze", action="store_true", help="Cross-repo analysis")
    parser.add_argument("--suggest", metavar="GOAL", help="Suggest integration for goal")
    parser.add_argument("--status", action="store_true", help="Show ecosystem status")
    parser.add_argument("--base", default="../", help="Base path for repos")

    args = parser.parse_args()

    if not KERNEL_AVAILABLE:
        print("❌ Cannot run without Synthia Kernel")
        print("   Install: bash termux_bootstrap.sh")
        return

    integrator = EcosystemIntegrator(base_path=args.base)

    if args.ingest:
        integrator.ingest_ecosystem()

    elif args.search:
        results = integrator.search_across_ecosystem(args.search)
        print(f"\n🔍 Search results for '{args.search}':")
        for r in results[:10]:
            print(f"  📁 {r['repo']}/{r['file']}:{r['line']}")
            print(f"     {r['context'][:100]}...")
            print()

    elif args.repo:
        print(integrator.get_repo_details(args.repo))

    elif args.analyze:
        analysis = integrator.cross_repo_analysis()
        print("\n📊 Cross-Repo Analysis:")
        print(json.dumps(analysis, indent=2))

    elif args.suggest:
        suggestion = integrator.suggest_integration(args.suggest)
        print("\n💡 Suggestion:")
        print(suggestion["suggested_approach"])

    elif args.status:
        integrator._print_status()

    else:
        print("Use --help for options")

if __name__ == "__main__":
    main()
