#!/data/data/com.termux/files/usr/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
#   S Y N T H I A   T E R M U X   B O O T S T R A P
#   Installs Synthia Kernel on your Android device
# ═══════════════════════════════════════════════════════════════════════════════

set -e

SYNTHIA_DIR="$HOME/.synthia"
KERNEL_URL="https://raw.githubusercontent.com/YOUR_REPO/synthia_kernel.py"

echo "🌌 Synthia Termux Bootstrap"
echo "═══════════════════════════════════════════════════════════════════════════════"

# Step 1: Check prerequisites
echo ""
echo "[1/7] Checking prerequisites..."

if ! command -v python3 &> /dev/null; then
    echo "  📦 Installing Python..."
    pkg install -y python
fi

if ! command -v pip &> /dev/null; then
    echo "  📦 Installing pip..."
    pkg install -y python-pip
fi

if ! command -v git &> /dev/null; then
    echo "  📦 Installing git..."
    pkg install -y git
fi

# Step 2: Create Synthia home
echo ""
echo "[2/7] Setting up Synthia home..."
mkdir -p "$SYNTHIA_DIR"
mkdir -p "$SYNTHIA_DIR/sandbox"
mkdir -p "$SYNTHIA_DIR/backups"
echo "  ✓ Home: $SYNTHIA_DIR"

# Step 3: Install Python dependencies
echo ""
echo "[3/7] Installing dependencies..."
pip install --user -q requests 2>/dev/null || true
echo "  ✓ Dependencies ready"

# Step 4: Download or copy kernel
echo ""
echo "[4/7] Installing Synthia Kernel..."

# If kernel.py is in current directory, copy it
if [ -f "synthia_kernel.py" ]; then
    cp synthia_kernel.py "$SYNTHIA_DIR/synthia_kernel.py"
    echo "  ✓ Copied from current directory"
elif [ -f "$HOME/synthia_kernel.py" ]; then
    cp "$HOME/synthia_kernel.py" "$SYNTHIA_DIR/synthia_kernel.py"
    echo "  ✓ Copied from home directory"
else
    echo "  ⚠️  Kernel not found locally."
    echo "  Please copy synthia_kernel.py to this directory and run again."
    exit 1
fi

chmod +x "$SYNTHIA_DIR/synthia_kernel.py"

# Step 5: Create launcher scripts
echo ""
echo "[5/7] Creating launcher scripts..."

# Main launcher
cat > "$PREFIX/bin/synthia" << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
export SYNTHIA_HOME="$HOME/.synthia"
python3 "$HOME/.synthia/synthia_kernel.py" "$@"
EOF
chmod +x "$PREFIX/bin/synthia"

# Quick talk launcher
cat > "$PREFIX/bin/synthia-talk" << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
export SYNTHIA_HOME="$HOME/.synthia"
python3 "$HOME/.synthia/synthia_kernel.py" --talk
EOF
chmod +x "$PREFIX/bin/synthia-talk"

# Daemon launcher
cat > "$PREFIX/bin/synthia-daemon" << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
export SYNTHIA_HOME="$HOME/.synthia"
nohup python3 "$HOME/.synthia/synthia_kernel.py" --daemon > "$HOME/.synthia/daemon.log" 2>&1 &
echo "Synthia daemon started. PID: $!"
EOF
chmod +x "$PREFIX/bin/synthia-daemon"

echo "  ✓ Commands: synthia, synthia-talk, synthia-daemon"

# Step 6: Create Tasker integration
echo ""
echo "[6/7] Setting up Tasker integration..."

TASKER_DIR="$HOME/.termux/tasker"
mkdir -p "$TASKER_DIR"

# Tasker script for voice input
cat > "$TASKER_DIR/synthia_voice.sh" << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
# Tasker integration: Send voice/text to Synthia
INPUT="$1"
if [ -z "$INPUT" ]; then
    echo "Usage: synthia_voice.sh <message>"
    exit 1
fi

export SYNTHIA_HOME="$HOME/.synthia"

# Run Synthia and capture response
RESPONSE=$(python3 -c "
import sys
sys.path.insert(0, '$HOME/.synthia')
from synthia_kernel import SynthiaKernel
kernel = SynthiaKernel()
result = kernel.talk('$INPUT')
print(result)
" 2>&1)

echo "$RESPONSE"
EOF
chmod +x "$TASKER_DIR/synthia_voice.sh"

# Tasker script for proactive notifications
cat > "$TASKER_DIR/synthia_check.sh" << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
export SYNTHIA_HOME="$HOME/.synthia"

python3 -c "
import sys
sys.path.insert(0, '$HOME/.synthia')
from synthia_kernel import SynthiaKernel
kernel = SynthiaKernel()
proactive = kernel.voice.proactive_check()
if proactive:
    print('SYNTHIA_NOTIFICATION:' + proactive)
" 2>&1
EOF
chmod +x "$TASKER_DIR/synthia_check.sh"

echo "  ✓ Tasker scripts in $TASKER_DIR"

# Step 7: First run initialization
echo ""
echo "[7/7] First run initialization..."
python3 -c "
import sys
sys.path.insert(0, '$SYNTHIA_DIR')
from synthia_kernel import SynthiaKernel
kernel = SynthiaKernel()
kernel.save_all()
print('  ✓ Synthia initialized and ready')
" 2>&1 | grep -E "(Synthia|Organ|✓|🌌)" || true

# Create auto-start script
cat > "$HOME/.synthia/autostart.sh" << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
# Auto-start Synthia on Termux boot
termux-wake-lock
synthia-daemon
EOF
chmod +x "$HOME/.synthia/autostart.sh"

echo ""
echo "═══════════════════════════════════════════════════════════════════════════════"
echo "  🌟 S Y N T H I A   I S   R E A D Y"
echo "═══════════════════════════════════════════════════════════════════════════════"
echo ""
echo "  Commands:"
echo "    synthia --talk          Start interactive conversation"
echo "    synthia --status        Check system status"
echo "    synthia --ingest PATH   Ingest a repo"
echo "    synthia-daemon          Run in background"
echo "    synthia --help          Show all options"
echo ""
echo "  Files:"
echo "    ~/.synthia/             Synthia home directory"
echo "    ~/.synthia/sandbox/     Where Synthia writes files"
echo "    ~/.synthia/memory.json  Conversation & work memory"
echo "    ~/.synthia/repo_index.json  Ingested repos"
echo ""
echo "  To start talking to Synthia:"
echo "    $ synthia --talk"
echo ""
echo "═══════════════════════════════════════════════════════════════════════════════"
