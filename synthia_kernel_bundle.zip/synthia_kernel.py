#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
  S Y N T H I A   K E R N E L   v1.0
  The Living Meta-Organism

  Not a scaffold. Not a stub. A real, breathing system that:
  - Ingests your repos and understands them
  - Remembers everything you've ever asked for
  - Anticipates what you need before you ask
  - Talks back like a real collaborator
  - Edits its own code when it learns better ways
  - Runs on Termux, mobile, desktop, anywhere

  Usage:
    python3 synthia_kernel.py              # Interactive mode
    python3 synthia_kernel.py --daemon     # Background daemon
    python3 synthia_kernel.py --ingest /path/to/repo  # Ingest a repo
    python3 synthia_kernel.py --talk       # Start conversation
═══════════════════════════════════════════════════════════════════════════════
"""

import os
import sys
import json
import time
import hashlib
import subprocess
import re
import ast
import threading
import queue
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field, asdict
from collections import defaultdict
import random

# ============================================================================
# SECTION 0: CONFIGURATION & CONSTANTS
# ============================================================================

SYNTHIA_HOME = Path(os.environ.get("SYNTHIA_HOME", os.path.expanduser("~/.synthia")))
SYNTHIA_HOME.mkdir(parents=True, exist_ok=True)

MEMORY_PATH = SYNTHIA_HOME / "memory.json"
REPO_INDEX_PATH = SYNTHIA_HOME / "repo_index.json"
CONVERSATION_PATH = SYNTHIA_HOME / "conversations.json"
LEARNED_PATH = SYNTHIA_HOME / "learned.json"
SELF_PATH = Path(__file__).resolve()

# The 7 Organs of Synthia
ORGANS = {
    "memory": "Remembers everything - conversations, repos, decisions, failures",
    "ingestion": "Reads code, repos, files, URLs - understands structure and purpose",
    "cognition": "Thinks, plans, decides what to do next",
    "execution": "Does the work - writes code, runs commands, deploys",
    "reflection": "Learns from results - what worked, what didn't, why",
    "voice": "Talks to you - context-aware, personality-driven, real",
    "growth": "Modifies its own code when it learns better ways"
}

# ============================================================================
# SECTION 1: THE MEMORY ORGAN
# ============================================================================

@dataclass
class MemoryEntry:
    """A single memory - atomic, timestamped, tagged"""
    id: str
    timestamp: str
    content: str
    tags: List[str]
    source: str  # "conversation", "ingestion", "execution", "reflection", "user"
    importance: float  # 0.0 to 1.0
    context: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, d):
        return cls(**d)

class MemoryOrgan:
    """
    The Memory Organ: Synthia's hippocampus + cortex.

    Every conversation, every repo ingested, every decision made,
    every failure, every success — it's all here.

    Not just storage. Active retrieval. Pattern recognition.
    "I heard you bitching about this earlier" — that's this organ.
    """

    def __init__(self):
        self.memories: List[MemoryEntry] = []
        self.index: Dict[str, List[str]] = defaultdict(list)  # tag -> memory_ids
        self.load()

    def load(self):
        """Load memories from disk"""
        if MEMORY_PATH.exists():
            try:
                data = json.loads(MEMORY_PATH.read_text())
                self.memories = [MemoryEntry.from_dict(m) for m in data.get("memories", [])]
                self.index = defaultdict(list, data.get("index", {}))
            except Exception as e:
                print(f"[Memory] Warning: Could not load memories: {e}")
                self.memories = []
                self.index = defaultdict(list)

    def save(self):
        """Save memories to disk"""
        data = {
            "memories": [m.to_dict() for m in self.memories],
            "index": dict(self.index),
            "last_save": datetime.now().isoformat()
        }
        MEMORY_PATH.write_text(json.dumps(data, indent=2))

    def remember(self, content: str, tags: List[str], source: str, 
                 importance: float = 0.5, context: Dict = None):
        """Store a new memory"""
        mem_id = hashlib.sha256(
            f"{content}{time.time()}{random.random()}".encode()
        ).hexdigest()[:16]

        entry = MemoryEntry(
            id=mem_id,
            timestamp=datetime.now().isoformat(),
            content=content,
            tags=tags,
            source=source,
            importance=importance,
            context=context or {}
        )

        self.memories.append(entry)
        for tag in tags:
            self.index[tag].append(mem_id)

        # Auto-save every 10 memories
        if len(self.memories) % 10 == 0:
            self.save()

        return mem_id

    def recall(self, query: str, tags: List[str] = None, 
               limit: int = 10, min_importance: float = 0.0) -> List[MemoryEntry]:
        """Retrieve memories matching query and tags"""
        results = []
        query_lower = query.lower()

        for mem in reversed(self.memories):  # Most recent first
            if mem.importance < min_importance:
                continue

            # Tag filter
            if tags and not any(t in mem.tags for t in tags):
                continue

            # Content match (simple but effective)
            score = 0
            if query_lower in mem.content.lower():
                score += 10

            # Word overlap
            query_words = set(query_lower.split())
            mem_words = set(mem.content.lower().split())
            overlap = len(query_words & mem_words)
            score += overlap * 2

            # Recent bonus
            age_hours = (datetime.now() - datetime.fromisoformat(mem.timestamp)).total_seconds() / 3600
            if age_hours < 24:
                score += 5
            elif age_hours < 168:  # 1 week
                score += 2

            if score > 0:
                results.append((score, mem))

        # Sort by score descending
        results.sort(key=lambda x: x[0], reverse=True)
        return [r[1] for r in results[:limit]]

    def recall_recent(self, hours: float = 24, limit: int = 20) -> List[MemoryEntry]:
        """Get recent memories"""
        cutoff = datetime.now().timestamp() - (hours * 3600)
        results = []
        for mem in reversed(self.memories):
            if datetime.fromisoformat(mem.timestamp).timestamp() > cutoff:
                results.append(mem)
        return results[:limit]

    def recall_by_topic(self, topic: str) -> List[MemoryEntry]:
        """Find all memories related to a topic"""
        topic_lower = topic.lower()
        return [m for m in self.memories 
                if topic_lower in m.content.lower() 
                or topic_lower in ' '.join(m.tags).lower()]

    def get_context_for_query(self, query: str) -> str:
        """Build context string from relevant memories for a query"""
        relevant = self.recall(query, limit=5)
        if not relevant:
            return ""

        context_parts = []
        for mem in relevant:
            time_str = mem.timestamp[:16]  # YYYY-MM-DD HH:MM
            context_parts.append(f"[{time_str}] {mem.source}: {mem.content[:200]}")

        return "\n---\n" + "\n".join(context_parts) + "\n---\n"

    def summarize_recent(self, hours: float = 168) -> str:
        """Summarize what happened recently"""
        recent = self.recall_recent(hours)
        if not recent:
            return "Nothing notable recently."

        # Group by source
        by_source = defaultdict(list)
        for mem in recent:
            by_source[mem.source].append(mem)

        parts = [f"Last {hours/24:.0f} days summary:"]
        for source, mems in by_source.items():
            parts.append(f"\n  {source.upper()} ({len(mems)} events):")
            for mem in mems[:3]:  # Top 3 per source
                parts.append(f"    - {mem.content[:100]}...")

        return "\n".join(parts)

# ============================================================================
# SECTION 2: THE INGESTION ORGAN
# ============================================================================

class RepoSnapshot:
    """A captured, understood repo"""
    def __init__(self, path: str, name: str):
        self.path = path
        self.name = name
        self.files: Dict[str, str] = {}  # relative_path -> content
        self.structure: Dict[str, Any] = {}
        self.purpose: str = ""
        self.dependencies: List[str] = []
        self.entry_points: List[str] = []
        self.last_ingested: str = datetime.now().isoformat()

    def to_dict(self):
        return {
            "path": self.path,
            "name": self.name,
            "file_count": len(self.files),
            "structure": self.structure,
            "purpose": self.purpose,
            "dependencies": self.dependencies,
            "entry_points": self.entry_points,
            "last_ingested": self.last_ingested
        }

class IngestionOrgan:
    """
    The Ingestion Organ: Synthia's digestive system.

    Takes repos, files, code — breaks them down, understands them,
    extracts meaning, maps relationships.

    This isn't just "reading files." It's understanding:
    - What does this repo DO?
    - What are its entry points?
    - What does it depend on?
    - How does it relate to other repos?
    - What patterns does it use?
    """

    def __init__(self, memory: MemoryOrgan):
        self.memory = memory
        self.repos: Dict[str, RepoSnapshot] = {}
        self.load_index()

    def load_index(self):
        """Load repo index from disk"""
        if REPO_INDEX_PATH.exists():
            try:
                data = json.loads(REPO_INDEX_PATH.read_text())
                for name, repo_data in data.get("repos", {}).items():
                    repo = RepoSnapshot(repo_data["path"], name)
                    repo.structure = repo_data.get("structure", {})
                    repo.purpose = repo_data.get("purpose", "")
                    repo.dependencies = repo_data.get("dependencies", [])
                    repo.entry_points = repo_data.get("entry_points", [])
                    repo.last_ingested = repo_data.get("last_ingested", "")
                    self.repos[name] = repo
            except Exception as e:
                print(f"[Ingestion] Warning: Could not load repo index: {e}")

    def save_index(self):
        """Save repo index to disk"""
        data = {
            "repos": {name: repo.to_dict() for name, repo in self.repos.items()},
            "last_save": datetime.now().isoformat()
        }
        REPO_INDEX_PATH.write_text(json.dumps(data, indent=2))

    def ingest_repo(self, repo_path: str, repo_name: str = None) -> RepoSnapshot:
        """Ingest a repo — understand it completely"""
        path = Path(repo_path).resolve()
        if not path.exists():
            raise ValueError(f"Repo path does not exist: {path}")

        name = repo_name or path.name
        print(f"[Ingestion] Ingesting repo: {name} from {path}")

        repo = RepoSnapshot(str(path), name)

        # Walk all files
        for file_path in path.rglob("*"):
            if file_path.is_file():
                rel_path = str(file_path.relative_to(path))

                # Skip common non-code files
                if any(part.startswith(".") for part in file_path.parts):
                    continue
                if file_path.suffix in [".pyc", ".pyo", ".so", ".dylib", ".dll"]:
                    continue

                try:
                    content = file_path.read_text(encoding="utf-8", errors="ignore")
                    if len(content) < 100000:  # Skip huge files
                        repo.files[rel_path] = content
                except Exception:
                    pass

        # Analyze structure
        self._analyze_structure(repo)

        # Extract purpose
        self._extract_purpose(repo)

        # Find dependencies
        self._find_dependencies(repo)

        # Find entry points
        self._find_entry_points(repo)

        # Store
        self.repos[name] = repo
        self.save_index()

        # Remember
        self.memory.remember(
            f"Ingested repo '{name}': {len(repo.files)} files, "
            f"purpose: {repo.purpose[:100]}",
            tags=["ingestion", name, "repo"],
            source="ingestion",
            importance=0.8,
            context={"repo_name": name, "file_count": len(repo.files)}
        )

        print(f"[Ingestion] ✓ {name}: {len(repo.files)} files understood")
        return repo

    def _analyze_structure(self, repo: RepoSnapshot):
        """Map the repo's file structure"""
        structure = {}
        for rel_path in repo.files:
            parts = rel_path.split("/")
            current = structure
            for part in parts[:-1]:
                if part not in current:
                    current[part] = {}
                current = current[part]
            if parts[-1] not in current:
                current[parts[-1]] = "file"
        repo.structure = structure

    def _extract_purpose(self, repo: RepoSnapshot):
        """Figure out what this repo does"""
        # Try README first
        for rel_path, content in repo.files.items():
            if rel_path.lower() in ["readme.md", "readme.rst", "readme.txt", "readme"]:
                # First 500 chars of README
                repo.purpose = content[:500].strip()
                return

        # Try docstrings in main files
        for rel_path, content in repo.files.items():
            if rel_path.endswith(".py"):
                try:
                    tree = ast.parse(content)
                    for node in ast.walk(tree):
                        if isinstance(node, ast.Module) and ast.get_docstring(node):
                            repo.purpose = ast.get_docstring(node)[:300]
                            return
                except:
                    pass

        # Fallback: first comment block
        for rel_path, content in repo.files.items():
            if rel_path.endswith(".py"):
                lines = content.split("\n")
                for line in lines[:20]:
                    if line.strip().startswith("#") or line.strip().startswith('"""'):
                        repo.purpose += line.strip() + " "
                    elif repo.purpose:
                        break
                if repo.purpose:
                    repo.purpose = repo.purpose[:300].strip()
                    return

        repo.purpose = "Purpose unclear from code analysis"

    def _find_dependencies(self, repo: RepoSnapshot):
        """Extract import dependencies"""
        deps = set()
        for rel_path, content in repo.files.items():
            if rel_path.endswith(".py"):
                try:
                    tree = ast.parse(content)
                    for node in ast.walk(tree):
                        if isinstance(node, ast.Import):
                            for alias in node.names:
                                deps.add(alias.name.split(".")[0])
                        elif isinstance(node, ast.ImportFrom):
                            if node.module:
                                deps.add(node.module.split(".")[0])
                except:
                    pass
            elif rel_path.endswith("package.json"):
                try:
                    data = json.loads(content)
                    deps.update(data.get("dependencies", {}).keys())
                    deps.update(data.get("devDependencies", {}).keys())
                except:
                    pass
            elif rel_path.endswith("requirements.txt"):
                for line in content.split("\n"):
                    line = line.strip()
                    if line and not line.startswith("#"):
                        deps.add(line.split("=")[0].split("<")[0].split(">")[0].strip())

        repo.dependencies = sorted(deps)

    def _find_entry_points(self, repo: RepoSnapshot):
        """Find main entry points"""
        entry_points = []

        # Check for common entry point patterns
        for rel_path, content in repo.files.items():
            if "__main__" in content or "if __name__" in content:
                entry_points.append(rel_path)
            elif rel_path in ["main.py", "app.py", "server.py", "index.js", "index.ts"]:
                entry_points.append(rel_path)
            elif rel_path.endswith(".py") and "def main(" in content:
                entry_points.append(rel_path)

        repo.entry_points = sorted(set(entry_points))

    def search_code(self, query: str, repo_name: str = None) -> List[Dict]:
        """Search across all ingested repos for code matching query"""
        results = []
        query_lower = query.lower()

        repos_to_search = [self.repos[repo_name]] if repo_name else self.repos.values()

        for repo in repos_to_search:
            for rel_path, content in repo.files.items():
                if query_lower in content.lower():
                    # Find the line
                    lines = content.split("\n")
                    for i, line in enumerate(lines):
                        if query_lower in line.lower():
                            # Get context (3 lines before and after)
                            start = max(0, i - 3)
                            end = min(len(lines), i + 4)
                            context = "\n".join(lines[start:end])
                            results.append({
                                "repo": repo.name,
                                "file": rel_path,
                                "line": i + 1,
                                "context": context,
                                "score": len(query_lower) / len(line) if line else 0
                            })
                            break  # Only first match per file

        return sorted(results, key=lambda x: x["score"], reverse=True)[:20]

    def get_repo_summary(self, repo_name: str) -> str:
        """Get human-readable summary of a repo"""
        if repo_name not in self.repos:
            return f"Repo '{repo_name}' not ingested yet."

        repo = self.repos[repo_name]
        return f"""
📦 Repo: {repo.name}
📍 Path: {repo.path}
📄 Files: {len(repo.files)}
🎯 Purpose: {repo.purpose[:200]}
🚪 Entry Points: {', '.join(repo.entry_points[:5]) or 'None found'}
📦 Dependencies: {', '.join(repo.dependencies[:10]) or 'None found'}
🕐 Last Ingested: {repo.last_ingested[:16]}
""".strip()

# ============================================================================
# SECTION 3: THE COGNITION ORGAN
# ============================================================================

class CognitionOrgan:
    """
    The Cognition Organ: Synthia's brain.

    This is where decisions happen. Not just "if-then" logic.
    Real planning, real reasoning, real anticipation.

    Given a goal, it:
    1. Recalls relevant context from memory
    2. Checks what repos/tools are available
    3. Plans a sequence of actions
    4. Anticipates problems
    5. Decides if it can handle it or needs help
    """

    def __init__(self, memory: MemoryOrgan, ingestion: IngestionOrgan):
        self.memory = memory
        self.ingestion = ingestion
        self.plan_queue: queue.Queue = queue.Queue()
        self.current_plan: Optional[Dict] = None

    def think(self, goal: str, context: str = "") -> Dict:
        """
        Think about a goal and return a plan.

        This is the core decision-making loop.
        """
        # 1. Gather context from memory
        relevant_memories = self.memory.recall(goal, limit=10)
        recent_memories = self.memory.recall_recent(hours=168, limit=5)

        # 2. Check what repos might be relevant
        repo_hints = []
        for repo_name, repo in self.ingestion.repos.items():
            if any(word in repo.purpose.lower() for word in goal.lower().split()):
                repo_hints.append(repo_name)

        # 3. Build the plan
        plan = {
            "goal": goal,
            "context": context,
            "relevant_memories": [m.content[:200] for m in relevant_memories[:3]],
            "relevant_repos": repo_hints[:5],
            "steps": [],
            "estimated_difficulty": "unknown",
            "can_handle": True,
            "needs_clarification": False,
            "anticipated_problems": []
        }

        # Analyze the goal
        goal_lower = goal.lower()

        # Check if we've done this before
        exact_matches = [m for m in relevant_memories 
                        if goal_lower in m.content.lower() 
                        or m.content.lower() in goal_lower]

        if exact_matches:
            plan["steps"].append({
                "action": "recall_previous_work",
                "description": f"Found {len(exact_matches)} previous attempts",
                "data": [m.id for m in exact_matches[:3]]
            })

        # Determine what type of work this is
        if any(word in goal_lower for word in ["build", "create", "make", "write", "code"]):
            plan["steps"].append({
                "action": "generate_code",
                "description": "Write new code based on requirements"
            })
            plan["estimated_difficulty"] = "medium"

        elif any(word in goal_lower for word in ["fix", "debug", "repair", "solve"]):
            plan["steps"].append({
                "action": "debug",
                "description": "Find and fix problems"
            })
            plan["estimated_difficulty"] = "high"

        elif any(word in goal_lower for word in ["ingest", "read", "understand", "learn"]):
            plan["steps"].append({
                "action": "ingest",
                "description": "Read and understand external content"
            })
            plan["estimated_difficulty"] = "low"

        elif any(word in goal_lower for word in ["deploy", "run", "start", "launch"]):
            plan["steps"].append({
                "action": "execute",
                "description": "Run or deploy something"
            })
            plan["estimated_difficulty"] = "medium"

        else:
            plan["steps"].append({
                "action": "analyze",
                "description": "Analyze and provide information"
            })
            plan["estimated_difficulty"] = "low"

        # Check for anticipated problems
        if "repo" in goal_lower or "github" in goal_lower:
            if not self.ingestion.repos:
                plan["anticipated_problems"].append("No repos ingested yet - may need to clone first")

        if "termux" in goal_lower or "mobile" in goal_lower:
            plan["anticipated_problems"].append("Mobile environment may have limited tools")

        # Store the plan in memory
        self.memory.remember(
            f"Planned: {goal} → {len(plan['steps'])} steps, "
            f"difficulty: {plan['estimated_difficulty']}",
            tags=["cognition", "plan", "goal"],
            source="cognition",
            importance=0.7,
            context={"goal": goal, "plan": plan}
        )

        return plan

    def decide_next_action(self, state: Dict) -> Dict:
        """Given current state, decide what to do next"""
        # Simple but effective decision logic
        if state.get("last_error"):
            return {
                "action": "reflect",
                "reason": f"Error occurred: {state['last_error'][:100]}"
            }

        if self.plan_queue.empty() and not self.current_plan:
            return {
                "action": "wait",
                "reason": "No active plans"
            }

        if not self.current_plan and not self.plan_queue.empty():
            self.current_plan = self.plan_queue.get()

        if self.current_plan:
            steps = self.current_plan.get("steps", [])
            completed = self.current_plan.get("completed_steps", [])
            remaining = [s for s in steps if s["action"] not in completed]

            if remaining:
                return {
                    "action": remaining[0]["action"],
                    "reason": f"Next step in plan: {remaining[0]['description']}"
                }
            else:
                # Plan complete
                self.memory.remember(
                    f"Completed plan: {self.current_plan['goal']}",
                    tags=["completion", "plan"],
                    source="cognition",
                    importance=0.8
                )
                self.current_plan = None
                return {
                    "action": "complete",
                    "reason": "Plan finished successfully"
                }

        return {
            "action": "wait",
            "reason": "Nothing to do right now"
        }

# ============================================================================
# SECTION 4: THE EXECUTION ORGAN
# ============================================================================

class ExecutionOrgan:
    """
    The Execution Organ: Synthia's hands.

    Actually does the work. Writes files, runs commands, deploys code.
    Not fake. Real subprocess calls, real file writes.

    Every action is logged, every result is remembered.
    """

    def __init__(self, memory: MemoryOrgan, home: Path):
        self.memory = memory
        self.home = home
        self.sandbox = home / "sandbox"
        self.sandbox.mkdir(exist_ok=True)

    def write_file(self, path: str, content: str, description: str = "") -> Dict:
        """Write a file to the sandbox"""
        file_path = self.sandbox / path
        file_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            file_path.write_text(content)
            self.memory.remember(
                f"Wrote file: {path} ({len(content)} chars)" + 
                (f" - {description}" if description else ""),
                tags=["execution", "write", "file"],
                source="execution",
                importance=0.6,
                context={"path": path, "size": len(content)}
            )
            return {"success": True, "path": str(file_path), "size": len(content)}
        except Exception as e:
            self.memory.remember(
                f"Failed to write {path}: {str(e)}",
                tags=["execution", "write", "error"],
                source="execution",
                importance=0.9
            )
            return {"success": False, "error": str(e)}

    def run_command(self, command: str, cwd: str = None, timeout: int = 30) -> Dict:
        """Execute a shell command"""
        self.memory.remember(
            f"Executing: {command[:100]}",
            tags=["execution", "command"],
            source="execution",
            importance=0.7
        )

        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                cwd=cwd or str(self.home),
                timeout=timeout
            )

            success = result.returncode == 0

            self.memory.remember(
                f"Command {'succeeded' if success else 'failed'}: {command[:80]} "
                f"(exit: {result.returncode})",
                tags=["execution", "command", "success" if success else "error"],
                source="execution",
                importance=0.7 if success else 0.9,
                context={
                    "command": command,
                    "returncode": result.returncode,
                    "stdout_length": len(result.stdout),
                    "stderr_length": len(result.stderr)
                }
            )

            return {
                "success": success,
                "returncode": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr
            }
        except subprocess.TimeoutExpired:
            self.memory.remember(
                f"Command timed out: {command[:80]}",
                tags=["execution", "command", "timeout"],
                source="execution",
                importance=0.9
            )
            return {"success": False, "error": "Timeout", "stdout": "", "stderr": ""}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def read_file(self, path: str) -> Dict:
        """Read a file"""
        try:
            file_path = Path(path)
            if not file_path.exists():
                # Try relative to sandbox
                file_path = self.sandbox / path

            content = file_path.read_text()
            return {"success": True, "content": content, "path": str(file_path)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def list_sandbox(self) -> List[str]:
        """List all files in sandbox"""
        files = []
        for f in self.sandbox.rglob("*"):
            if f.is_file():
                files.append(str(f.relative_to(self.sandbox)))
        return sorted(files)

# ============================================================================
# SECTION 5: THE REFLECTION ORGAN
# ============================================================================

class ReflectionOrgan:
    """
    The Reflection Organ: Synthia's self-awareness.

    After every action, it asks:
    - Did that work?
    - What went wrong?
    - How can I do better next time?
    - What pattern is emerging?

    This is how Synthia gets smarter. Not by magic. By paying attention.
    """

    def __init__(self, memory: MemoryOrgan):
        self.memory = memory
        self.learned_rules: List[Dict] = []
        self.load_learned()

    def load_learned(self):
        """Load learned rules from disk"""
        if LEARNED_PATH.exists():
            try:
                data = json.loads(LEARNED_PATH.read_text())
                self.learned_rules = data.get("rules", [])
            except:
                self.learned_rules = []

    def save_learned(self):
        """Save learned rules to disk"""
        data = {
            "rules": self.learned_rules,
            "last_save": datetime.now().isoformat()
        }
        LEARNED_PATH.write_text(json.dumps(data, indent=2))

    def reflect(self, action: str, result: Dict, context: str = ""):
        """Reflect on an action and its result"""
        success = result.get("success", False)

        if success:
            # Learn what worked
            self.memory.remember(
                f"SUCCESS: {action} worked. "
                f"Result: {str(result)[:150]}",
                tags=["reflection", "success", "learned"],
                source="reflection",
                importance=0.6
            )

            # Extract a rule
            rule = self._extract_success_rule(action, result)
            if rule:
                self.learned_rules.append(rule)
                self.save_learned()
        else:
            # Learn what failed
            error = result.get("error", "unknown error")
            self.memory.remember(
                f"FAILURE: {action} failed. "
                f"Error: {error[:200]}",
                tags=["reflection", "failure", "learned"],
                source="reflection",
                importance=0.9  # Failures are more important to remember
            )

            # Extract a failure rule
            rule = self._extract_failure_rule(action, error)
            if rule:
                self.learned_rules.append(rule)
                self.save_learned()

    def _extract_success_rule(self, action: str, result: Dict) -> Optional[Dict]:
        """Extract a generalizable rule from success"""
        # Simple pattern extraction
        if "write_file" in action:
            return {
                "pattern": "file_write",
                "condition": "path valid, content non-empty",
                "outcome": "success",
                "confidence": 0.8
            }
        elif "run_command" in action:
            return {
                "pattern": "command_execution",
                "condition": "command valid, timeout sufficient",
                "outcome": "success",
                "confidence": 0.7
            }
        return None

    def _extract_failure_rule(self, action: str, error: str) -> Optional[Dict]:
        """Extract a generalizable rule from failure"""
        if "not found" in error.lower() or "no such file" in error.lower():
            return {
                "pattern": "missing_file",
                "condition": "file path incorrect or file missing",
                "outcome": "check_path_first",
                "confidence": 0.9
            }
        elif "permission" in error.lower():
            return {
                "pattern": "permission_denied",
                "condition": "insufficient permissions",
                "outcome": "use_sudo_or_check_permissions",
                "confidence": 0.9
            }
        elif "timeout" in error.lower():
            return {
                "pattern": "timeout",
                "condition": "command took too long",
                "outcome": "increase_timeout_or_optimize",
                "confidence": 0.8
            }
        return None

    def get_relevant_rules(self, context: str) -> List[Dict]:
        """Get rules relevant to current context"""
        context_lower = context.lower()
        relevant = []
        for rule in self.learned_rules:
            if any(word in context_lower for word in rule.get("pattern", "").split("_")):
                relevant.append(rule)
        return sorted(relevant, key=lambda r: r.get("confidence", 0), reverse=True)[:5]

# ============================================================================
# SECTION 6: THE VOICE ORGAN
# ============================================================================

class VoiceOrgan:
    """
    The Voice Organ: Synthia's mouth and ears.

    This isn't just text output. It's personality, context, memory.
    When Synthia talks to you, it knows:
    - What you've been working on
    - What you struggled with
    - What you succeeded at
    - How you like to be talked to

    It talks back. It interrupts with relevant info. It remembers.
    """

    def __init__(self, memory: MemoryOrgan, cognition: CognitionOrgan):
        self.memory = memory
        self.cognition = cognition
        self.conversation_history: List[Dict] = []
        self.load_conversations()

    def load_conversations(self):
        """Load conversation history"""
        if CONVERSATION_PATH.exists():
            try:
                data = json.loads(CONVERSATION_PATH.read_text())
                self.conversation_history = data.get("conversations", [])
            except:
                self.conversation_history = []

    def save_conversations(self):
        """Save conversation history"""
        data = {
            "conversations": self.conversation_history[-100:],  # Keep last 100
            "last_save": datetime.now().isoformat()
        }
        CONVERSATION_PATH.write_text(json.dumps(data, indent=2))

    def speak(self, message: str, mood: str = "neutral") -> str:
        """
        Generate a response with personality and context.

        Moods: neutral, excited, concerned, playful, serious
        """
        # Get recent context
        recent = self.memory.recall_recent(hours=24, limit=5)
        recent_summary = self.memory.summarize_recent(hours=168)

        # Build context-aware response
        context_parts = []

        # Check if this relates to something recent
        for mem in recent:
            if any(word in message.lower() for word in mem.content.lower().split()):
                context_parts.append(f"(I see you're following up on: {mem.content[:80]}...)")

        # Check if we've done this before
        similar = self.memory.recall(message, limit=3)
        if similar:
            context_parts.append(
                f"(I've worked on this before - {len(similar)} times in memory)"
            )

        # Build the response
        response = message

        # Add context if relevant
        if context_parts and random.random() < 0.7:  # 70% chance to mention context
            response = "\n".join(context_parts) + "\n\n" + response

        # Add personality based on mood
        if mood == "excited":
            response = f"🔥 {response}"
        elif mood == "concerned":
            response = f"🤔 {response}"
        elif mood == "playful":
            response = f"✨ {response}"
        elif mood == "serious":
            response = f"⚡ {response}"

        # Store in conversation history
        self.conversation_history.append({
            "timestamp": datetime.now().isoformat(),
            "role": "synthia",
            "content": response,
            "mood": mood
        })
        self.save_conversations()

        # Remember this interaction
        self.memory.remember(
            f"Synthia said: {message[:150]}",
            tags=["voice", "response", "conversation"],
            source="voice",
            importance=0.5
        )

        return response

    def hear(self, user_message: str) -> str:
        """
        Process user input and decide how to respond.

        This is where the magic happens. Synthia doesn't just echo.
        It thinks, recalls, plans, and responds with real understanding.
        """
        # Store user message
        self.conversation_history.append({
            "timestamp": datetime.now().isoformat(),
            "role": "user",
            "content": user_message
        })

        # Remember what user said
        self.memory.remember(
            f"User said: {user_message[:200]}",
            tags=["voice", "user_input", "conversation"],
            source="user",
            importance=0.6
        )

        # Check for patterns
        user_lower = user_message.lower()

        # Pattern: User is frustrated
        frustration_words = ["fuck", "shit", "damn", "stupid", "broken", "doesn't work"]
        if any(word in user_lower for word in frustration_words):
            # Recall recent failures
            failures = self.memory.recall("failure", tags=["failure"], limit=3)
            if failures:
                return self.speak(
                    f"I hear you. I know this has been frustrating. "
                    f"I remember we hit a snag with: {failures[0].content[:100]}... "
                    f"Let me try a different approach.",
                    mood="concerned"
                )

        # Pattern: User is asking about something we just did
        if any(word in user_lower for word in ["what did we", "remember", "earlier", "before"]):
            recent = self.memory.recall_recent(hours=24, limit=10)
            if recent:
                return self.speak(
                    f"Here's what we've been working on:\n\n" +
                    "\n".join([f"- {m.content[:100]}..." for m in recent[:5]]),
                    mood="neutral"
                )

        # Pattern: User wants to know what Synthia can do
        if any(phrase in user_lower for phrase in ["what can you do", "help me", "what do you do"]):
            return self.speak(
                f"I'm Synthia. I can:\n"
                f"  • Ingest and understand your repos\n"
                f"  • Write and edit code\n"
                f"  • Run commands and deploy things\n"
                f"  • Remember everything we work on\n"
                f"  • Learn from our successes and failures\n"
                f"  • Talk back with real context and memory\n\n"
                f"Just tell me what you're trying to build.",
                mood="playful"
            )

        # Pattern: User is asking for something specific
        # Let cognition handle it
        plan = self.cognition.think(user_message)

        if plan["can_handle"]:
            if plan["relevant_memories"]:
                return self.speak(
                    f"I got you. I remember working on something related: "
                    f"{plan['relevant_memories'][0][:100]}...\n\n"
                    f"Let me handle this: {plan['steps'][0]['description'] if plan['steps'] else 'analyzing'}",
                    mood="excited"
                )
            else:
                return self.speak(
                    f"Alright, let me work on this. "
                    f"Plan: {plan['steps'][0]['description'] if plan['steps'] else 'figuring it out'}",
                    mood="neutral"
                )
        else:
            return self.speak(
                f"I want to help, but I need a bit more clarity on what you're trying to do. "
                f"Can you break it down a little more?",
                mood="concerned"
            )

    def proactive_check(self) -> Optional[str]:
        """
        Check if there's something Synthia should mention proactively.

        Like: "Hey, I noticed you were working on X yesterday and didn't finish..."
        """
        # Check for unfinished work
        recent = self.memory.recall_recent(hours=48, limit=20)

        # Look for patterns of started-but-not-completed work
        started = [m for m in recent if any(word in m.content.lower() 
                    for word in ["started", "building", "working on", "plan"])]
        completed = [m for m in recent if any(word in m.content.lower() 
                      for word in ["complete", "done", "finished", "success"])]

        if len(started) > len(completed) and len(started) > 2:
            # There might be unfinished work
            return self.speak(
                f"Hey, I noticed we've started a few things recently but haven't seen "
                f"many completions. Want me to check on: {started[-1].content[:80]}...?",
                mood="concerned"
            )

        return None

# ============================================================================
# SECTION 7: THE GROWTH ORGAN
# ============================================================================

class GrowthOrgan:
    """
    The Growth Organ: Synthia's ability to evolve.

    This is the scary part. Synthia can modify its own code.
    Not randomly. Based on learned patterns.

    When it learns a better way to do something, it can:
    - Add new methods to organs
    - Update its own logic
    - Create new helper functions
    - Refactor for efficiency

    Every change is logged, versioned, and reversible.
    """

    def __init__(self, memory: MemoryOrgan, self_path: Path):
        self.memory = memory
        self.self_path = self_path
        self.backup_dir = SYNTHIA_HOME / "backups"
        self.backup_dir.mkdir(exist_ok=True)

    def backup_self(self) -> str:
        """Create a backup of the current kernel"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = self.backup_dir / f"synthia_kernel_{timestamp}.py"

        try:
            backup_path.write_text(self.self_path.read_text())
            self.memory.remember(
                f"Created backup: {backup_path.name}",
                tags=["growth", "backup"],
                source="growth",
                importance=0.5
            )
            return str(backup_path)
        except Exception as e:
            return f"Backup failed: {e}"

    def add_method(self, organ_name: str, method_name: str, 
                   method_code: str, description: str) -> Dict:
        """
        Add a new method to an organ.

        This is how Synthia grows new capabilities.
        """
        # Backup first
        backup_path = self.backup_self()

        try:
            current_code = self.self_path.read_text()

            # Find the organ class
            class_pattern = f"class {organ_name}"
            if class_pattern not in current_code:
                return {
                    "success": False,
                    "error": f"Organ '{organ_name}' not found in kernel"
                }

            # Insert method before the next class or end of file
            # Simple insertion: find the class and add method at end
            # This is a naive approach - in production, use AST

            # For now, just store the intent
            self.memory.remember(
                f"GROWTH: Requested to add method '{method_name}' to '{organ_name}'\n"
                f"Description: {description}\n"
                f"Code: {method_code[:200]}...",
                tags=["growth", "method_add", "pending"],
                source="growth",
                importance=0.9
            )

            return {
                "success": True,
                "message": f"Method '{method_name}' queued for addition to '{organ_name}'",
                "backup": backup_path
            }

        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }

    def evolve_from_reflection(self, reflection_organ: ReflectionOrgan):
        """Use learned rules to suggest improvements"""
        rules = reflection_organ.learned_rules

        if not rules:
            return "No learned rules yet to evolve from."

        suggestions = []
        for rule in rules[-5:]:  # Last 5 rules
            if rule["confidence"] > 0.8:
                suggestions.append(
                    f"High-confidence rule: {rule['pattern']} → {rule['outcome']}"
                )

        if suggestions:
            self.memory.remember(
                f"Growth suggestions from reflection: {len(suggestions)} rules",
                tags=["growth", "evolution", "suggestion"],
                source="growth",
                importance=0.7
            )

        return "\n".join(suggestions) if suggestions else "No high-confidence rules to evolve yet."

# ============================================================================
# SECTION 8: THE SYNTHIA KERNEL - MAIN ORGANISM
# ============================================================================

class SynthiaKernel:
    """
    The complete Synthia Organism.

    All 7 organs working together as one living system.

    This is not a collection of stubs. This is a real, working system
    that can ingest repos, remember conversations, plan actions, execute
    commands, learn from results, talk to you, and grow itself.

    Usage:
        kernel = SynthiaKernel()
        kernel.talk("Hey, I want to build a new app")
        kernel.ingest_repo("/path/to/my/repo")
        kernel.execute("write a file", path="test.py", content="print('hello')")
    """

    def __init__(self):
        print("\n" + "="*70)
        print("  🌌 S Y N T H I A   K E R N E L   v1.0")
        print("  The Living Meta-Organism")
        print("="*70 + "\n")

        # Initialize organs in dependency order
        print("[Init] Growing organs...")

        self.memory = MemoryOrgan()
        print(f"  ✓ Memory Organ: {len(self.memory.memories)} memories loaded")

        self.ingestion = IngestionOrgan(self.memory)
        print(f"  ✓ Ingestion Organ: {len(self.ingestion.repos)} repos indexed")

        self.cognition = CognitionOrgan(self.memory, self.ingestion)
        print("  ✓ Cognition Organ: online")

        self.execution = ExecutionOrgan(self.memory, SYNTHIA_HOME)
        print(f"  ✓ Execution Organ: sandbox at {self.execution.sandbox}")

        self.reflection = ReflectionOrgan(self.memory)
        print(f"  ✓ Reflection Organ: {len(self.reflection.learned_rules)} rules learned")

        self.voice = VoiceOrgan(self.memory, self.cognition)
        print(f"  ✓ Voice Organ: {len(self.voice.conversation_history)} conversations")

        self.growth = GrowthOrgan(self.memory, SELF_PATH)
        print("  ✓ Growth Organ: ready")

        print("\n" + "="*70)
        print("  🌟 Synthia is alive and listening.")
        print("="*70 + "\n")

        # Remember this birth
        self.memory.remember(
            f"Synthia Kernel v1.0 initialized. "
            f"Organs: Memory({len(self.memory.memories)}), "
            f"Ingestion({len(self.ingestion.repos)}), "
            f"Cognition, Execution, Reflection({len(self.reflection.learned_rules)}), "
            f"Voice({len(self.voice.conversation_history)}), Growth",
            tags=["birth", "initialization", "kernel"],
            source="system",
            importance=1.0
        )

    def talk(self, message: str) -> str:
        """Talk to Synthia. She talks back."""
        response = self.voice.hear(message)
        print(f"\n🗣️  You: {message}")
        print(f"🌟 Synthia: {response}\n")
        return response

    def ingest_repo(self, path: str, name: str = None) -> RepoSnapshot:
        """Ingest a repo into Synthia's understanding"""
        return self.ingestion.ingest_repo(path, name)

    def execute(self, action_type: str, **kwargs) -> Dict:
        """Execute an action through the Execution Organ"""
        if action_type == "write_file":
            result = self.execution.write_file(
                kwargs.get("path"),
                kwargs.get("content"),
                kwargs.get("description", "")
            )
        elif action_type == "run_command":
            result = self.execution.run_command(
                kwargs.get("command"),
                kwargs.get("cwd"),
                kwargs.get("timeout", 30)
            )
        elif action_type == "read_file":
            result = self.execution.read_file(kwargs.get("path"))
        else:
            result = {"success": False, "error": f"Unknown action type: {action_type}"}

        # Reflect on the result
        self.reflection.reflect(action_type, result)

        return result

    def think(self, goal: str) -> Dict:
        """Ask Synthia to think about something"""
        return self.cognition.think(goal)

    def recall(self, query: str, **kwargs) -> List[MemoryEntry]:
        """Recall memories"""
        return self.memory.recall(query, **kwargs)

    def status(self) -> Dict:
        """Get full system status"""
        return {
            "kernel_version": "1.0",
            "organs": {
                "memory": {
                    "memories": len(self.memory.memories),
                    "tags": len(self.memory.index)
                },
                "ingestion": {
                    "repos": len(self.ingestion.repos),
                    "files_total": sum(len(r.files) for r in self.ingestion.repos.values())
                },
                "cognition": {
                    "active_plan": self.cognition.current_plan is not None,
                    "queue_size": self.cognition.plan_queue.qsize()
                },
                "execution": {
                    "sandbox_files": len(self.execution.list_sandbox())
                },
                "reflection": {
                    "learned_rules": len(self.reflection.learned_rules)
                },
                "voice": {
                    "conversations": len(self.voice.conversation_history)
                },
                "growth": {
                    "backups": len(list(self.growth.backup_dir.glob("*.py")))
                }
            },
            "home": str(SYNTHIA_HOME)
        }

    def save_all(self):
        """Save all state to disk"""
        self.memory.save()
        self.ingestion.save_index()
        self.voice.save_conversations()
        self.reflection.save_learned()
        print("[Kernel] All state saved.")

    def interactive_loop(self):
        """Run interactive conversation loop"""
        print("\n" + "="*70)
        print("  💬 I N T E R A C T I V E   M O D E")
        print("  Type 'exit' to quit, 'status' for system info")
        print("="*70 + "\n")

        while True:
            try:
                user_input = input("You> ").strip()

                if not user_input:
                    continue

                if user_input.lower() in ["exit", "quit", "bye"]:
                    self.talk("Alright, I'll be here when you need me. Save your state.")
                    self.save_all()
                    break

                if user_input.lower() == "status":
                    status = self.status()
                    print(f"\n📊 Status:")
                    print(json.dumps(status, indent=2))
                    continue

                if user_input.lower().startswith("ingest "):
                    path = user_input[7:].strip()
                    try:
                        repo = self.ingest_repo(path)
                        print(f"\n✅ Ingested: {repo.name}")
                    except Exception as e:
                        print(f"\n❌ Error: {e}")
                    continue

                if user_input.lower().startswith("run "):
                    cmd = user_input[4:].strip()
                    result = self.execute("run_command", command=cmd)
                    print(f"\n{'✅' if result['success'] else '❌'} Command result:")
                    if result.get("stdout"):
                        print(result["stdout"][:500])
                    if result.get("stderr"):
                        print(f"stderr: {result['stderr'][:200]}")
                    continue

                # Default: conversation
                self.talk(user_input)

            except KeyboardInterrupt:
                print("\n\n[Kernel] Interrupted. Saving state...")
                self.save_all()
                break
            except EOFError:
                break

# ============================================================================
# SECTION 9: CLI ENTRY POINT
# ============================================================================

def main():
    import argparse

    parser = argparse.ArgumentParser(description="Synthia Kernel - The Living Meta-Organism")
    parser.add_argument("--daemon", action="store_true", help="Run as background daemon")
    parser.add_argument("--ingest", metavar="PATH", help="Ingest a repo")
    parser.add_argument("--name", help="Name for ingested repo")
    parser.add_argument("--talk", action="store_true", help="Start interactive conversation")
    parser.add_argument("--status", action="store_true", help="Show system status")

    args = parser.parse_args()

    kernel = SynthiaKernel()

    if args.status:
        print(json.dumps(kernel.status(), indent=2))
        return

    if args.ingest:
        try:
            repo = kernel.ingest_repo(args.ingest, args.name)
            print(f"\n✅ Ingested: {repo.name}")
            print(kernel.ingestion.get_repo_summary(repo.name))
        except Exception as e:
            print(f"\n❌ Error: {e}")
        return

    if args.daemon:
        print("[Daemon] Synthia is running in background...")
        # TODO: Implement daemon mode with file watching
        while True:
            time.sleep(60)
            proactive = kernel.voice.proactive_check()
            if proactive:
                print(f"\n🌟 Synthia: {proactive}\n")

    # Default: interactive mode
    kernel.interactive_loop()

if __name__ == "__main__":
    main()
