#!/data/data/com.termux/files/usr/bin/bash
# ═══════════════════════════════════════════════════════════════
#  Synthia Kiosk — Self-Installing Bootstrap for Termux
#  One command: Trident Kiosk + Synthia MCP + Chat + WebSocket
# ═══════════════════════════════════════════════════════════════

set -e

SYNTHIA_DIR="${HOME}/synthia-kiosk"
PORT="${SYNTHIA_PORT:-8765}"
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

banner() {
    echo ""
    echo "${CYAN}╔══════════════════════════════════════════════════════╗${NC}"
    echo "${CYAN}║${NC}  🧠  ${GREEN}Synthia Kiosk${NC} — Self-Installing Agent         ${CYAN}║${NC}"
    echo "${CYAN}║${NC}     Trident · MCP · Chat · Device Control · Web     ${CYAN}║${NC}"
    echo "${CYAN}╚══════════════════════════════════════════════════════╝${NC}"
    echo ""
}

step() { echo "${BLUE}▶${NC} $1"; }
ok() { echo "${GREEN}✓${NC} $1"; }
warn() { echo "${YELLOW}⚠${NC} $1"; }
fail() { echo "${RED}✗${NC} $1"; exit 1; }

banner

# ─── Check Termux ───
step "Checking Termux environment..."
if [ -z "$TERMUX_VERSION" ] && [ -z "$PREFIX" ]; then
    fail "This installer only works in Termux on Android."
fi
ok "Termux detected"

# ─── Update packages ───
step "Updating package lists..."
pkg update -y > /dev/null 2>&1 || true
ok "Package lists updated"

# ─── Install Node.js ───
step "Checking Node.js..."
if command -v node &> /dev/null; then
    ok "Node.js $(node --version | sed 's/v//') found"
else
    step "Installing Node.js LTS..."
    pkg install nodejs-lts -y
    ok "Node.js installed"
fi

# ─── Install Git ───
step "Checking Git..."
if ! command -v git &> /dev/null; then
    pkg install git -y
    ok "Git installed"
else
    ok "Git found"
fi

# ─── Install TypeScript ───
step "Checking TypeScript..."
if ! command -v tsc &> /dev/null; then
    npm install -g typescript
    ok "TypeScript installed globally"
else
    ok "TypeScript found"
fi

# ─── Install core-termux ───
step "Checking core-termux..."
if ! command -v core &> /dev/null; then
    warn "core-termux not found — installing..."
    curl -fsSL https://raw.githubusercontent.com/DevCoreXOfficial/core-termux/main/install.sh | bash
    ok "core-termux installed"
else
    ok "core-termux $(core --version 2>/dev/null || echo unknown) found"
fi

# ─── Install Termux:API ───
step "Checking Termux:API..."
if ! command -v termux-media-scan &> /dev/null; then
    warn "Termux:API package not found — installing..."
    pkg install termux-api -y
    ok "Termux:API package installed"
    warn "⚠️  Please also install the Termux:API app from F-Droid for full device control"
else
    ok "Termux:API found"
fi

# ─── Setup Synthia Kiosk ───
step "Setting up Synthia Kiosk..."
if [ -d "$SYNTHIA_DIR" ]; then
    step "Existing installation found — updating..."
    cd "$SYNTHIA_DIR"
    git pull origin main 2>/dev/null || git pull 2>/dev/null || warn "Could not update via git"
else
    mkdir -p "$SYNTHIA_DIR"
fi
ok "Synthia Kiosk directory ready"

# ─── Install npm dependencies ───
step "Installing npm dependencies..."
cd "$SYNTHIA_DIR"
if [ ! -f "package.json" ]; then
    cat > package.json << 'EOF'
{
  "name": "synthia-kiosk",
  "version": "1.0.0",
  "description": "Self-installing Trident Kiosk + Synthia MCP + Chat",
  "type": "module",
  "main": "dist/server.js",
  "bin": { "synthia-kiosk": "dist/server.js" },
  "scripts": {
    "build": "tsc",
    "start": "node dist/server.js",
    "bootstrap": "bash install.sh"
  },
  "dependencies": {
    "@modelcontextprotocol/sdk": "^1.0.4",
    "express": "^4.21.0",
    "ws": "^8.18.0",
    "zod": "^3.23.8"
  },
  "devDependencies": {
    "@types/express": "^4.17.21",
    "@types/node": "^22.0.0",
    "@types/ws": "^8.5.12",
    "typescript": "^5.7.0"
  }
}
EOF
fi

npm install
ok "Dependencies installed"

# ─── Build TypeScript ───
step "Building TypeScript..."
if [ ! -f "tsconfig.json" ]; then
    cat > tsconfig.json << 'EOF'
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "declaration": true,
    "sourceMap": true
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist"]
}
EOF
fi

# Check if source exists, create minimal if not
if [ ! -d "src" ]; then
    warn "Source files not found — creating minimal structure..."
    mkdir -p src/utils src/tools src/engine public
    # The actual source files should be provided separately
    # This is a fallback minimal server
    cat > src/server.ts << 'EOF'
import express from 'express';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const server = createServer(app);
app.use(express.static(join(__dirname, '../public')));
const wss = new WebSocketServer({ server, path: '/ws' });
wss.on('connection', (ws) => {
  ws.send(JSON.stringify({ type: 'connected', payload: { message: 'Synthia Kiosk' } }));
  ws.on('message', (data) => {
    const msg = JSON.parse(data.toString());
    if (msg.type === 'chat') {
      ws.send(JSON.stringify({ type: 'chat', payload: { role: 'agent', content: 'Echo: ' + msg.payload.text } }));
    }
  });
});
server.listen(8765, '0.0.0.0', () => console.log('Synthia Kiosk on http://0.0.0.0:8765'));
EOF
fi

npx tsc
ok "TypeScript compiled"

# ─── Create startup script ───
step "Creating startup script..."
cat > "$SYNTHIA_DIR/start.sh" << EOF
#!/data/data/com.termux/files/usr/bin/bash
cd "${SYNTHIA_DIR}"
echo "🧠 Starting Synthia Kiosk..."
echo "   Web UI: http://localhost:${PORT}"
echo "   WebSocket: ws://localhost:${PORT}/ws"
echo "   MCP: stdio (for Claude/Cursor/Cline)"
node dist/server.js
EOF
chmod +x "$SYNTHIA_DIR/start.sh"
ok "Startup script created"

# ─── Register with Claude Code ───
step "Checking for MCP clients..."
if command -v claude &> /dev/null; then
    step "Registering with Claude Code..."
    claude mcp add synthia-kiosk -- node "$SYNTHIA_DIR/dist/server.js" 2>/dev/null || warn "Could not auto-register with Claude Code"
    ok "Registered with Claude Code"
fi

# ─── Add shell alias ───
step "Adding shell alias..."
SHELL_RC=""
if [ -f "$HOME/.zshrc" ]; then SHELL_RC="$HOME/.zshrc"
elif [ -f "$HOME/.bashrc" ]; then SHELL_RC="$HOME/.bashrc"
fi

if [ -n "$SHELL_RC" ] && ! grep -q "synthia-kiosk" "$SHELL_RC" 2>/dev/null; then
    echo "" >> "$SHELL_RC"
    echo "# Synthia Kiosk alias" >> "$SHELL_RC"
    echo "alias synthia-kiosk='bash ${HOME}/synthia-kiosk/start.sh'" >> "$SHELL_RC"
    echo "alias sk='bash ${HOME}/synthia-kiosk/start.sh'" >> "$SHELL_RC"
    ok "Alias added to ${SHELL_RC}"
    warn "Run 'source ${SHELL_RC}' to use the alias now"
fi

# ─── Final ───
echo ""
echo "${GREEN}╔══════════════════════════════════════════════════════╗${NC}"
echo "${GREEN}║${NC}  🎉 Synthia Kiosk is ready!                         ${GREEN}║${NC}"
echo "${GREEN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
echo "${CYAN}Quick Start:${NC}"
echo "  ${YELLOW}synthia-kiosk${NC}  — Start the server"
echo "  ${YELLOW}sk${NC}             — Short alias"
echo "  ${YELLOW}bash ${HOME}/synthia-kiosk/start.sh${NC} — Direct"
echo ""
echo "${CYAN}Once running, open:${NC}"
echo "  ${YELLOW}http://localhost:${PORT}${NC}  — Trident Kiosk + Chat UI"
echo "  ${YELLOW}ws://localhost:${PORT}/ws${NC}  — WebSocket"
echo ""
echo "${CYAN}MCP Client Config:${NC}"
echo '  { "mcpServers": { "synthia-kiosk": { "command": "node", "args": ["'"${HOME}/synthia-kiosk/dist/server.js"'"] } } }'
echo ""
echo "${GREEN}Done!${NC}"
