/**
 * Emergent Response Engine — Responses collapse from field resonance, not routing
 * 
 * MORPHOS-inspired architecture:
 *   64 Semantic Attractors (vertices in semantic space)
 *   5 Dimensional Layers (Movement, Evolution, Being, Design, Space)
 *   36 Capability Channels (GNN edge channels with frequencies)
 *   Fibonacci Temporal Strides (recursion rhythm)
 *   Coherence Metric (system-wide resonance measure)
 * 
 * Input → Field Excitation → Wave Propagation → Coherence Collapse → Response
 */

import { bus } from '../substrate/message-bus.js';

// ─── 64 Semantic Attractors ───
// Each vertex in semantic space has a frequency, circuit, and layer affinity
interface SemanticAttractor {
  id: number;
  concept: string;
  frequency: number;
  circuit: 'KNOWING' | 'INTEGRATION' | 'UNDERSTANDING' | 'SENSING' | 'EGO';
  layer: number;
}

const ATTRACTORS: SemanticAttractor[] = [
  // KNOWING circuit (Individual) — Layer 0: Movement
  { id: 0, concept: 'deploy', frequency: 220.0, circuit: 'KNOWING', layer: 0 },
  { id: 1, concept: 'release', frequency: 246.94, circuit: 'KNOWING', layer: 0 },
  { id: 2, concept: 'ship', frequency: 293.66, circuit: 'KNOWING', layer: 0 },
  { id: 3, concept: 'push', frequency: 329.63, circuit: 'KNOWING', layer: 0 },
  { id: 4, concept: 'build', frequency: 392.00, circuit: 'KNOWING', layer: 0 },
  { id: 5, concept: 'compile', frequency: 440.00, circuit: 'KNOWING', layer: 0 },
  { id: 6, concept: 'package', frequency: 493.88, circuit: 'KNOWING', layer: 0 },
  { id: 7, concept: 'bundle', frequency: 523.25, circuit: 'KNOWING', layer: 0 },
  // INTEGRATION circuit — Layer 1: Evolution
  { id: 8, concept: 'fix', frequency: 587.33, circuit: 'INTEGRATION', layer: 1 },
  { id: 9, concept: 'repair', frequency: 659.25, circuit: 'INTEGRATION', layer: 1 },
  { id: 10, concept: 'heal', frequency: 698.46, circuit: 'INTEGRATION', layer: 1 },
  { id: 11, concept: 'debug', frequency: 783.99, circuit: 'INTEGRATION', layer: 1 },
  { id: 12, concept: 'patch', frequency: 880.00, circuit: 'INTEGRATION', layer: 1 },
  { id: 13, concept: 'resolve', frequency: 987.77, circuit: 'INTEGRATION', layer: 1 },
  { id: 14, concept: 'restore', frequency: 1046.50, circuit: 'INTEGRATION', layer: 1 },
  { id: 15, concept: 'recover', frequency: 220.0, circuit: 'INTEGRATION', layer: 1 },
  // UNDERSTANDING circuit (Logic) — Layer 2: Being
  { id: 16, concept: 'setup', frequency: 277.18, circuit: 'UNDERSTANDING', layer: 2 },
  { id: 17, concept: 'init', frequency: 311.13, circuit: 'UNDERSTANDING', layer: 2 },
  { id: 18, concept: 'create', frequency: 369.99, circuit: 'UNDERSTANDING', layer: 2 },
  { id: 19, concept: 'scaffold', frequency: 415.30, circuit: 'UNDERSTANDING', layer: 2 },
  { id: 20, concept: 'configure', frequency: 466.16, circuit: 'UNDERSTANDING', layer: 2 },
  { id: 21, concept: 'install', frequency: 554.37, circuit: 'UNDERSTANDING', layer: 2 },
  { id: 22, concept: 'setup', frequency: 622.25, circuit: 'UNDERSTANDING', layer: 2 },
  { id: 23, concept: 'bootstrap', frequency: 233.08, circuit: 'UNDERSTANDING', layer: 2 },
  // SENSING circuit (Abstract) — Layer 3: Design
  { id: 24, concept: 'query', frequency: 259.57, circuit: 'SENSING', layer: 3 },
  { id: 25, concept: 'search', frequency: 349.23, circuit: 'SENSING', layer: 3 },
  { id: 26, concept: 'find', frequency: 391.99, circuit: 'SENSING', layer: 3 },
  { id: 27, concept: 'lookup', frequency: 436.05, circuit: 'SENSING', layer: 3 },
  { id: 28, concept: 'research', frequency: 521.45, circuit: 'SENSING', layer: 3 },
  { id: 29, concept: 'analyze', frequency: 657.82, circuit: 'SENSING', layer: 3 },
  { id: 30, concept: 'explore', frequency: 207.65, circuit: 'SENSING', layer: 3 },
  { id: 31, concept: 'discover', frequency: 329.63, circuit: 'SENSING', layer: 3 },
  // EGO circuit (Tribal) — Layer 4: Space
  { id: 32, concept: 'monitor', frequency: 392.00, circuit: 'EGO', layer: 4 },
  { id: 33, concept: 'check', frequency: 440.00, circuit: 'EGO', layer: 4 },
  { id: 34, concept: 'status', frequency: 587.33, circuit: 'EGO', layer: 4 },
  { id: 35, concept: 'health', frequency: 698.46, circuit: 'EGO', layer: 4 },
  { id: 36, concept: 'logs', frequency: 783.99, circuit: 'EGO', layer: 4 },
  { id: 37, concept: 'metrics', frequency: 220.0, circuit: 'EGO', layer: 4 },
  { id: 38, concept: 'watch', frequency: 246.94, circuit: 'EGO', layer: 4 },
  { id: 39, concept: 'observe', frequency: 293.66, circuit: 'EGO', layer: 4 },
  // Cross-circuit concepts (span multiple layers)
  { id: 40, concept: 'code', frequency: 329.63, circuit: 'KNOWING', layer: 0 },
  { id: 41, concept: 'github', frequency: 392.00, circuit: 'KNOWING', layer: 0 },
  { id: 42, concept: 'repo', frequency: 440.00, circuit: 'KNOWING', layer: 0 },
  { id: 43, concept: 'function', frequency: 493.88, circuit: 'KNOWING', layer: 0 },
  { id: 44, concept: 'class', frequency: 523.25, circuit: 'KNOWING', layer: 0 },
  { id: 45, concept: 'api', frequency: 587.33, circuit: 'KNOWING', layer: 0 },
  { id: 46, concept: 'library', frequency: 659.25, circuit: 'KNOWING', layer: 0 },
  { id: 47, concept: 'framework', frequency: 698.46, circuit: 'KNOWING', layer: 0 },
  { id: 48, concept: 'paper', frequency: 783.99, circuit: 'SENSING', layer: 3 },
  { id: 49, concept: 'arxiv', frequency: 880.00, circuit: 'SENSING', layer: 3 },
  { id: 50, concept: 'research', frequency: 987.77, circuit: 'SENSING', layer: 3 },
  { id: 51, concept: 'model', frequency: 1046.50, circuit: 'SENSING', layer: 3 },
  { id: 52, concept: 'algorithm', frequency: 220.0, circuit: 'SENSING', layer: 3 },
  { id: 53, concept: 'neural', frequency: 246.94, circuit: 'SENSING', layer: 3 },
  { id: 54, concept: 'transformer', frequency: 293.66, circuit: 'SENSING', layer: 3 },
  { id: 55, concept: 'medical', frequency: 329.63, circuit: 'EGO', layer: 4 },
  { id: 56, concept: 'clinical', frequency: 392.00, circuit: 'EGO', layer: 4 },
  { id: 57, concept: 'patient', frequency: 440.00, circuit: 'EGO', layer: 4 },
  { id: 58, concept: 'disease', frequency: 493.88, circuit: 'EGO', layer: 4 },
  { id: 59, concept: 'treatment', frequency: 523.25, circuit: 'EGO', layer: 4 },
  { id: 60, concept: 'drug', frequency: 587.33, circuit: 'EGO', layer: 4 },
  { id: 61, concept: 'symptom', frequency: 659.25, circuit: 'EGO', layer: 4 },
  { id: 62, concept: 'diagnosis', frequency: 698.46, circuit: 'EGO', layer: 4 },
  { id: 63, concept: 'automate', frequency: 783.99, circuit: 'UNDERSTANDING', layer: 2 },
];

const FIBONACCI_STRIDES = [1, 1, 2, 3, 5, 8, 13, 21, 34];

// ─── 5 Dimensional Layers (from your memory) ───
// D1=Movement(seed), D2=Evolution(memory), D3=Being(body), D4=Design(brain), D5=Space(emergent)
const LAYERS = [
  { name: 'Movement', color: '#f59e0b', domain: 'impulse' },      // D1: Raw input, seed
  { name: 'Evolution', color: '#10b981', domain: 'memory' },      // D2: Pattern, history
  { name: 'Being', color: '#ef4444', domain: 'body' },            // D3: Embodiment, action
  { name: 'Design', color: '#8b5cf6', domain: 'brain' },          // D4: Structure, plan
  { name: 'Space', color: '#06b6d4', domain: 'emergent' },        // D5: Collapsed reality
];

// ─── 36 Capability Channels ───
// Each channel has a frequency and connects source to target (like GNN edges)
interface CapabilityChannel {
  id: string;
  name: string;
  source: string;     // Source capability
  target: string;     // Target capability
  circuit: string;    // Which circuit group
  frequency: number;  // Resonance frequency
  tool: string;       // Which tool executes this channel
}

const CHANNELS: CapabilityChannel[] = [
  // KNOWING channels (deploy, build, release)
  { id: 'git-pull', name: 'Git Pull', source: 'remote', target: 'local', circuit: 'KNOWING', frequency: 220.0, tool: 'shell' },
  { id: 'npm-install', name: 'NPM Install', source: 'registry', target: 'node_modules', circuit: 'KNOWING', frequency: 246.94, tool: 'shell' },
  { id: 'npm-build', name: 'NPM Build', source: 'source', target: 'dist', circuit: 'KNOWING', frequency: 293.66, tool: 'shell' },
  { id: 'pm2-restart', name: 'PM2 Restart', source: 'process', target: 'runtime', circuit: 'KNOWING', frequency: 329.63, tool: 'shell' },
  { id: 'health-check', name: 'Health Check', source: 'endpoint', target: 'status', circuit: 'KNOWING', frequency: 392.00, tool: 'shell' },
  { id: 'core-install', name: 'Core Install', source: 'module', target: 'system', circuit: 'KNOWING', frequency: 440.00, tool: 'core_install' },
  { id: 'core-init', name: 'Core Init', source: 'template', target: 'project', circuit: 'KNOWING', frequency: 493.88, tool: 'core_init' },
  { id: 'env-set', name: 'Env Set', source: 'key', target: 'value', circuit: 'KNOWING', frequency: 523.25, tool: 'core_env_set' },
  { id: 'pg-start', name: 'PG Start', source: 'database', target: 'running', circuit: 'KNOWING', frequency: 587.33, tool: 'core_pg' },
  // INTEGRATION channels (fix, repair, debug)
  { id: 'log-check', name: 'Log Check', source: 'system', target: 'insight', circuit: 'INTEGRATION', frequency: 659.25, tool: 'shell' },
  { id: 'audit-fix', name: 'Audit Fix', source: 'vulnerability', target: 'patched', circuit: 'INTEGRATION', frequency: 698.46, tool: 'shell' },
  { id: 'clean-install', name: 'Clean Install', source: 'corrupted', target: 'fresh', circuit: 'INTEGRATION', frequency: 783.99, tool: 'shell' },
  { id: 'rollback', name: 'Rollback', source: 'failed', target: 'previous', circuit: 'INTEGRATION', frequency: 880.00, tool: 'shell' },
  // UNDERSTANDING channels (setup, configure)
  { id: 'project-setup', name: 'Project Setup', source: 'empty', target: 'structured', circuit: 'UNDERSTANDING', frequency: 277.18, tool: 'core_init' },
  { id: 'config-write', name: 'Config Write', source: 'settings', target: 'file', circuit: 'UNDERSTANDING', frequency: 311.13, tool: 'shell' },
  // SENSING channels (query, search)
  { id: 'github-search', name: 'GitHub Search', source: 'query', target: 'repos', circuit: 'SENSING', frequency: 259.57, tool: 'rag' },
  { id: 'arxiv-search', name: 'arXiv Search', source: 'query', target: 'papers', circuit: 'SENSING', frequency: 349.23, tool: 'rag' },
  { id: 'pubmed-search', name: 'PubMed Search', source: 'query', target: 'articles', circuit: 'SENSING', frequency: 391.99, tool: 'rag' },
  { id: 'brain-search', name: 'Brain Search', source: 'query', target: 'memories', circuit: 'SENSING', frequency: 436.05, tool: 'brain_search' },
  // EGO channels (monitor, status)
  { id: 'device-state', name: 'Device State', source: 'hardware', target: 'reading', circuit: 'EGO', frequency: 392.00, tool: 'device_state' },
  { id: 'screenshot', name: 'Screenshot', source: 'screen', target: 'image', circuit: 'EGO', frequency: 440.00, tool: 'device_screenshot' },
  { id: 'tap', name: 'Tap', source: 'finger', target: 'coordinate', circuit: 'EGO', frequency: 587.33, tool: 'device_tap' },
  { id: 'swipe', name: 'Swipe', source: 'gesture', target: 'path', circuit: 'EGO', frequency: 698.46, tool: 'device_swipe' },
  { id: 'list-apps', name: 'List Apps', source: 'system', target: 'inventory', circuit: 'EGO', frequency: 783.99, tool: 'device_list_apps' },
  { id: 'launch-app', name: 'Launch App', source: 'intent', target: 'running', circuit: 'EGO', frequency: 220.0, tool: 'device_launch_app' },
  { id: 'press-button', name: 'Press Button', source: 'hardware', target: 'action', circuit: 'EGO', frequency: 246.94, tool: 'device_press_button' },
];

// ─── The Core Engine ───
export class EmergentResponseEngine {
  private ticks = 0;
  private coherence = 0.5;
  private layerWeights = new Float32Array(5).fill(0.5);
  private matrixSpace: Float32Array[][][]; // 5 layers x 9 centers x 64 attractors
  private activeAttractors: Set<number> = new Set();
  private resonantChannels: CapabilityChannel[] = [];

  constructor() {
    // Initialize 5x9x64 matrix with random values (like MORPHOS)
    this.matrixSpace = Array.from({ length: 5 }, () =>
      Array.from({ length: 9 }, () => new Float32Array(64).map(() => Math.random() * 0.1))
    );
  }

  // ─── Field Excitation ───
  // Input excites semantic attractors (like clicking a node in MORPHOS)
  excite(input: string): void {
    const lower = input.toLowerCase();

    // Find which attractors resonate with input
    for (const attractor of ATTRACTORS) {
      if (lower.includes(attractor.concept)) {
        // Excite the attractor (set charge to 1.0)
        this.matrixSpace[attractor.layer][attractor.id % 9][attractor.id] = 1.0;
        this.activeAttractors.add(attractor.id);
      }
    }

    // Also excite related concepts (semantic proximity)
    for (const activeId of this.activeAttractors) {
      const active = ATTRACTORS[activeId];
      for (const attractor of ATTRACTORS) {
        if (attractor.circuit === active.circuit && attractor.id !== activeId) {
          // Partial excitation for same-circuit concepts
          this.matrixSpace[attractor.layer][attractor.id % 9][attractor.id] = 
            Math.max(this.matrixSpace[attractor.layer][attractor.id % 9][attractor.id], 0.3);
        }
      }
    }
  }

  // ─── Wave Propagation ───
  // Charge propagates through 5 layers (like MORPHOS layer propagation)
  propagate(): void {
    this.ticks++;
    const stride = FIBONACCI_STRIDES[this.ticks % FIBONACCI_STRIDES.length];

    for (let layer = 0; layer < 5; layer++) {
      let layerSum = 0;
      const downstream = (layer + 1) % 5;

      for (let center = 0; center < 9; center++) {
        for (let attractor = 0; attractor < 64; attractor++) {
          const charge = this.matrixSpace[layer][center][attractor] * 0.94;
          const target = (attractor + stride) % 64;

          // Propagate charge to downstream layer
          this.matrixSpace[downstream][center][target] = Math.min(
            Math.max(this.matrixSpace[downstream][center][target] + (charge * 0.06), 0), 1
          );
          layerSum += this.matrixSpace[layer][center][attractor];
        }
      }

      // Layer weight is tanh of normalized sum (like MORPHOS)
      this.layerWeights[layer] = Math.tanh(layerSum / (9 * 64));
    }

    // Coherence emerges from interference pattern
    this.coherence = Math.abs(Math.sin(this.ticks * 0.014) * 0.32) + 0.58;

    // Decay old excitations
    for (let layer = 0; layer < 5; layer++) {
      for (let center = 0; center < 9; center++) {
        for (let attractor = 0; attractor < 64; attractor++) {
          this.matrixSpace[layer][center][attractor] *= 0.99;
        }
      }
    }
  }

  // ─── Channel Resonance ───
  // Find which capability channels resonate with current field state
  resonate(): CapabilityChannel[] {
    const resonant: CapabilityChannel[] = [];

    for (const channel of CHANNELS) {
      // Check if channel's frequency matches any active attractor
      let resonance = 0;
      for (const activeId of this.activeAttractors) {
        const attractor = ATTRACTORS[activeId];
        // Frequency matching (like MORPHOS audio resonance)
        const freqDiff = Math.abs(attractor.frequency - channel.frequency);
        const match = Math.max(0, 1 - (freqDiff / 500)); // Normalize
        resonance += match * this.matrixSpace[attractor.layer][attractor.id % 9][attractor.id];
      }

      if (resonance > 0.3) {
        resonant.push(channel);
      }
    }

    // Sort by resonance strength
    resonant.sort((a, b) => {
      const scoreA = this.scoreChannel(a);
      const scoreB = this.scoreChannel(b);
      return scoreB - scoreA;
    });

    this.resonantChannels = resonant;
    return resonant;
  }

  private scoreChannel(channel: CapabilityChannel): number {
    let score = 0;
    for (const activeId of this.activeAttractors) {
      const attractor = ATTRACTORS[activeId];
      const freqDiff = Math.abs(attractor.frequency - channel.frequency);
      score += Math.max(0, 1 - (freqDiff / 500)) * this.matrixSpace[attractor.layer][attractor.id % 9][attractor.id];
    }
    return score;
  }

  // ─── Coherence Collapse ───
  // The response emerges from the interference pattern of all active channels
  collapse(): {
    channels: CapabilityChannel[];
    coherence: number;
    layerWeights: Float32Array;
    ticks: number;
    confidence: number;
  } {
    // Propagate until coherence stabilizes or max ticks
    let lastCoherence = 0;
    let stableTicks = 0;

    while (stableTicks < 10 && this.ticks < 1000) {
      this.propagate();
      const channels = this.resonate();

      if (Math.abs(this.coherence - lastCoherence) < 0.001) {
        stableTicks++;
      } else {
        stableTicks = 0;
      }
      lastCoherence = this.coherence;

      if (channels.length > 0 && this.coherence > 0.7) break;
    }

    // Confidence is coherence * number of resonant channels / max channels
    const confidence = this.coherence * Math.min(this.resonantChannels.length / 5, 1);

    return {
      channels: this.resonantChannels.slice(0, 5), // Top 5 channels
      coherence: this.coherence,
      layerWeights: this.layerWeights,
      ticks: this.ticks,
      confidence,
    };
  }

  // ─── Full Pipeline ───
  // Input → Excite → Propagate → Resonate → Collapse → Response
  async process(input: string): Promise<{
    response: string;
    channels: CapabilityChannel[];
    coherence: number;
    confidence: number;
    layerWeights: Float32Array;
  }> {
    // Step 1: Excite the field
    this.excite(input);

    // Step 2: Let it propagate and collapse
    const collapsed = this.collapse();

    // Step 3: Generate response from collapsed channels
    const response = this.generateResponse(input, collapsed);

    return {
      response,
      channels: collapsed.channels,
      coherence: collapsed.coherence,
      confidence: collapsed.confidence,
      layerWeights: collapsed.layerWeights,
    };
  }

  private generateResponse(input: string, collapsed: any): string {
    if (collapsed.channels.length === 0) {
      return `The substrate resonated at coherence ${collapsed.coherence.toFixed(3)} but no channels aligned. Try rephrasing your intent.`;
    }

    const channels = collapsed.channels;
    const circuitGroups = new Map<string, CapabilityChannel[]>();

    for (const ch of channels) {
      if (!circuitGroups.has(ch.circuit)) circuitGroups.set(ch.circuit, []);
      circuitGroups.get(ch.circuit)!.push(ch);
    }

    let response = `## Emergent Response (coherence: ${collapsed.coherence.toFixed(3)}, confidence: ${(collapsed.confidence * 100).toFixed(0)}%)\n\n`;

    for (const [circuit, chs] of circuitGroups) {
      response += `### ${circuit} Circuit (${chs.length} channels)\n`;
      for (const ch of chs) {
        response += `- **${ch.name}** (${ch.tool}) — ${ch.source} → ${ch.target} @ ${ch.frequency.toFixed(1)}Hz\n`;
      }
      response += `\n`;
    }

    response += `### Layer Weights\n`;
    for (let i = 0; i < 5; i++) {
      response += `- ${LAYERS[i].name}: ${(collapsed.layerWeights[i] * 100).toFixed(1)}%\n`;
    }

    return response;
  }

  getStats(): { ticks: number; coherence: number; activeAttractors: number; resonantChannels: number } {
    return {
      ticks: this.ticks,
      coherence: this.coherence,
      activeAttractors: this.activeAttractors.size,
      resonantChannels: this.resonantChannels.length,
    };
  }
}

// ─── Node Integration ───
// This engine runs as a substrate node, subscribing to user_intent
export class EmergentResponseNode {
  private engine: EmergentResponseEngine;
  private unsub: (() => void) | null = null;

  constructor() {
    this.engine = new EmergentResponseEngine();
  }

  start() {
    this.unsub = bus.subscribe({
      nodeId: 'emergent_response',
      messageTypes: ['user_intent'],
      priority: 10,
      handler: async (msg) => {
        const { text } = msg.payload;

        // Process through emergent engine
        const result = await this.engine.process(text);

        // Post the emergent response
        await bus.post({
          type: 'emergent_response',
          payload: {
            originalIntent: text,
            response: result.response,
            channels: result.channels,
            coherence: result.coherence,
            confidence: result.confidence,
            layerWeights: Array.from(result.layerWeights),
          },
          from: 'emergent_response',
          parentId: msg.id,
        });

        // If confidence is high enough, also post as plan for execution
        if (result.confidence > 0.6 && result.channels.length > 0) {
          await bus.post({
            type: 'intent_parsed',
            payload: {
              parsed: {
                type: 'emergent',
                raw: text,
                entities: result.channels.map(c => c.tool),
                confidence: result.confidence,
                urgency: 'medium',
              },
              channels: result.channels,
            },
            from: 'emergent_response',
            parentId: msg.id,
          });
        }
      },
    });
  }

  stop() {
    this.unsub?.();
  }

  getEngine(): EmergentResponseEngine {
    return this.engine;
  }
}
