/**
 * Dynamic Planner v2 — Goal Graph Traversal + Capability Registry
 * 
 * The planner is no longer the hub. It becomes a consumer of the substrate.
 * Plans are assembled dynamically from the capability graph instead of hardcoded.
 * 
 * Architecture:
 *   Goal Graph (from intent parser)
 *   ↓
 *   Capability Registry (what tools can do)
 *   ↓
 *   Plan Assembly (dynamic step construction)
 *   ↓
 *   Risk Assessment + Rollback Generation
 */

import type { ParsedIntent, ActionPlan, ActionStep, PlanContext, OutcomeRecord } from '../types.js';
import { MemoryStore } from '../utils/memory.js';
import { SemanticIntentParser } from './intent-parser.js';

interface Capability {
  id: string;
  tools: string[];
  prerequisites: string[];
  risk: 'low' | 'medium' | 'high';
  rollback: string[];
  validation?: (output: string) => boolean;
  timeout: number;
  maxRetries: number;
}

interface ToolRegistry {
  [toolName: string]: {
    capabilities: string[];
    parameters: Record<string, { type: string; required: boolean; default?: any }>;
    description: string;
  };
}

// Capability Registry — the source of truth for what the system can do
const CAPABILITY_REGISTRY: Record<string, Capability> = {
  'git.pull': {
    id: 'git.pull',
    tools: ['shell'],
    prerequisites: [],
    risk: 'low',
    rollback: ['git.reset'],
    validation: (o: string) => !o.includes('error') && !o.includes('fatal'),
    timeout: 30000,
    maxRetries: 1,
  },
  'deps.install': {
    id: 'deps.install',
    tools: ['shell'],
    prerequisites: [],
    risk: 'medium',
    rollback: ['deps.clean'],
    validation: (o: string) => !o.includes('ERR!'),
    timeout: 120000,
    maxRetries: 2,
  },
  'project.build': {
    id: 'project.build',
    tools: ['shell'],
    prerequisites: ['deps.install'],
    risk: 'medium',
    rollback: ['build.clean'],
    validation: (o: string) => !o.includes('error') && !o.includes('failed'),
    timeout: 120000,
    maxRetries: 1,
  },
  'service.restart': {
    id: 'service.restart',
    tools: ['shell'],
    prerequisites: ['project.build'],
    risk: 'medium',
    rollback: ['service.stop'],
    validation: (o: string) => o.includes('restarted') || o.includes('online') || o.includes('started'),
    timeout: 30000,
    maxRetries: 2,
  },
  'service.health': {
    id: 'service.health',
    tools: ['shell'],
    prerequisites: ['service.restart'],
    risk: 'low',
    rollback: [],
    validation: (o: string) => o.includes('OK') || o.includes('ok') || o.includes('healthy') || o.includes('{"'),
    timeout: 15000,
    maxRetries: 3,
  },
  'deps.clean': {
    id: 'deps.clean',
    tools: ['shell'],
    prerequisites: [],
    risk: 'low',
    rollback: [],
    timeout: 30000,
    maxRetries: 0,
  },
  'build.clean': {
    id: 'build.clean',
    tools: ['shell'],
    prerequisites: [],
    risk: 'low',
    rollback: [],
    timeout: 30000,
    maxRetries: 0,
  },
  'service.stop': {
    id: 'service.stop',
    tools: ['shell'],
    prerequisites: [],
    risk: 'low',
    rollback: [],
    timeout: 15000,
    maxRetries: 1,
  },
  'git.reset': {
    id: 'git.reset',
    tools: ['shell'],
    prerequisites: [],
    risk: 'high',
    rollback: [],
    timeout: 15000,
    maxRetries: 0,
  },
  'env.set': {
    id: 'env.set',
    tools: ['core_env_set'],
    prerequisites: [],
    risk: 'low',
    rollback: [],
    timeout: 15000,
    maxRetries: 0,
  },
  'db.start': {
    id: 'db.start',
    tools: ['core_pg'],
    prerequisites: [],
    risk: 'low',
    rollback: ['db.stop'],
    timeout: 30000,
    maxRetries: 1,
  },
  'db.stop': {
    id: 'db.stop',
    tools: ['core_pg'],
    prerequisites: [],
    risk: 'low',
    rollback: [],
    timeout: 15000,
    maxRetries: 0,
  },
  'device.screenshot': {
    id: 'device.screenshot',
    tools: ['device_screenshot'],
    prerequisites: [],
    risk: 'low',
    rollback: [],
    timeout: 15000,
    maxRetries: 1,
  },
  'device.tap': {
    id: 'device.tap',
    tools: ['device_tap'],
    prerequisites: [],
    risk: 'low',
    rollback: [],
    timeout: 10000,
    maxRetries: 0,
  },
  'device.swipe': {
    id: 'device.swipe',
    tools: ['device_swipe'],
    prerequisites: [],
    risk: 'low',
    rollback: [],
    timeout: 10000,
    maxRetries: 0,
  },
  'device.list_apps': {
    id: 'device.list_apps',
    tools: ['device_list_apps'],
    prerequisites: [],
    risk: 'low',
    rollback: [],
    timeout: 15000,
    maxRetries: 0,
  },
  'device.launch': {
    id: 'device.launch',
    tools: ['device_launch_app'],
    prerequisites: [],
    risk: 'low',
    rollback: [],
    timeout: 15000,
    maxRetries: 0,
  },
  'rag.query': {
    id: 'rag.query',
    tools: ['rag'],
    prerequisites: [],
    risk: 'low',
    rollback: [],
    timeout: 30000,
    maxRetries: 1,
  },
  'brain.search': {
    id: 'brain.search',
    tools: ['brain_search'],
    prerequisites: [],
    risk: 'low',
    rollback: [],
    timeout: 15000,
    maxRetries: 0,
  },
};

// Tool parameter registry
const TOOL_REGISTRY: ToolRegistry = {
  'shell': {
    capabilities: ['git.pull', 'deps.install', 'project.build', 'service.restart', 'service.health', 'deps.clean', 'build.clean', 'service.stop', 'git.reset'],
    parameters: {
      cmd: { type: 'string', required: true },
      cwd: { type: 'string', required: false },
      timeout: { type: 'number', required: false, default: 60000 },
    },
    description: 'Execute shell commands',
  },
  'core_install': {
    capabilities: ['deps.install'],
    parameters: {
      module: { type: 'string', required: true },
      tools: { type: 'array', required: false },
    },
    description: 'Install core-termux modules',
  },
  'core_env_set': {
    capabilities: ['env.set'],
    parameters: {
      key: { type: 'string', required: true },
      value: { type: 'string', required: true },
    },
    description: 'Set environment variables',
  },
  'core_pg': {
    capabilities: ['db.start', 'db.stop'],
    parameters: {
      command: { type: 'string', required: true },
      arg: { type: 'string', required: false },
    },
    description: 'PostgreSQL management',
  },
  'device_screenshot': {
    capabilities: ['device.screenshot'],
    parameters: {
      path: { type: 'string', required: false },
    },
    description: 'Take device screenshot',
  },
  'device_tap': {
    capabilities: ['device.tap'],
    parameters: {
      x: { type: 'number', required: true },
      y: { type: 'number', required: true },
    },
    description: 'Tap device screen',
  },
  'device_swipe': {
    capabilities: ['device.swipe'],
    parameters: {
      x1: { type: 'number', required: true },
      y1: { type: 'number', required: true },
      x2: { type: 'number', required: true },
      y2: { type: 'number', required: true },
      duration: { type: 'number', required: false, default: 300 },
    },
    description: 'Swipe device screen',
  },
  'device_list_apps': {
    capabilities: ['device.list_apps'],
    parameters: {},
    description: 'List installed apps',
  },
  'device_launch_app': {
    capabilities: ['device.launch'],
    parameters: {
      packageName: { type: 'string', required: true },
    },
    description: 'Launch app',
  },
  'brain_search': {
    capabilities: ['brain.search'],
    parameters: {
      query: { type: 'string', required: true },
    },
    description: 'Search brain memory',
  },
  'rag': {
    capabilities: ['rag.query'],
    parameters: {
      text: { type: 'string', required: true },
      domain: { type: 'string', required: false },
      topK: { type: 'number', required: false, default: 5 },
    },
    description: 'Query RAG sources',
  },
};

export class DynamicPlanner {
  private memory: MemoryStore;
  private planCounter = 0;
  private parser: SemanticIntentParser;

  constructor(memory: MemoryStore) {
    this.memory = memory;
    this.parser = new SemanticIntentParser();
  }

  async buildPlan(intent: ParsedIntent): Promise<ActionPlan> {
    this.planCounter++;
    const planId = `plan_${Date.now()}_${this.planCounter}`;

    // Get previous outcomes for this intent type
    const previousOutcomes = await this.memory.getRelevantOutcomes(intent.raw);
    const successPatterns = intent.type !== 'unknown' 
      ? await this.memory.getSuccessPatterns(intent.type) 
      : [];

    // D3: Get goals from intent parser
    const goals = this.parser.getGoalsForIntent(intent.type);

    // D4: Traverse capability graph to build plan
    const { steps, rollbackSteps } = this.assemblePlanFromGoals(goals, intent, successPatterns);

    const context = {
      intent: intent.raw,
      parsedType: intent.type,
      confidence: intent.confidence,
      sourceDevice: 'termux-local',
      previousOutcomes,
    };

    return {
      id: planId,
      intent: intent.raw,
      steps,
      rollbackSteps,
      context,
      createdAt: Date.now(),
    };
  }

  private assemblePlanFromGoals(
    goals: any[], 
    intent: ParsedIntent, 
    successPatterns: string[]
  ): { steps: ActionStep[]; rollbackSteps: ActionStep[] } {

    const steps: ActionStep[] = [];
    const rollbackSteps: ActionStep[] = [];

    for (const goal of goals) {
      // Resolve capabilities to tools
      const capabilityChain = this.resolveCapabilityChain(goal.requiredCapabilities);

      for (const capId of capabilityChain) {
        const capability = CAPABILITY_REGISTRY[capId];
        if (!capability) continue;

        // Map capability to tool calls
        for (const toolName of capability.tools) {
          const tool = TOOL_REGISTRY[toolName];
          if (!tool) continue;

          const step = this.buildStepFromCapability(capability, toolName, intent, successPatterns);
          if (step) steps.push(step);
        }

        // Add rollback steps for high-risk capabilities
        if (capability.risk === 'high' || capability.risk === 'medium') {
          for (const rollbackCap of capability.rollback) {
            const rbCap = CAPABILITY_REGISTRY[rollbackCap];
            if (rbCap) {
              rollbackSteps.push({
                tool: rbCap.tools[0],
                params: this.buildRollbackParams(rbCap, intent),
                validate: () => true,
                onFail: 'skip',
                maxRetries: rbCap.maxRetries,
              });
            }
          }
        }
      }
    }

    // Deduplicate steps
    const seen = new Set<string>();
    const uniqueSteps = steps.filter(s => {
      const key = `${s.tool}:${JSON.stringify(s.params)}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    return { steps: uniqueSteps, rollbackSteps };
  }

  private resolveCapabilityChain(requiredCapabilities: string[]): string[] {
    const chain: string[] = [];
    const visited = new Set<string>();

    for (const capId of requiredCapabilities) {
      this.resolvePrerequisites(capId, chain, visited);
    }

    return chain;
  }

  private resolvePrerequisites(capId: string, chain: string[], visited: Set<string>) {
    if (visited.has(capId)) return;
    visited.add(capId);

    const cap = CAPABILITY_REGISTRY[capId];
    if (!cap) return;

    // Add prerequisites first
    for (const prereq of cap.prerequisites) {
      this.resolvePrerequisites(prereq, chain, visited);
    }

    chain.push(capId);
  }

  private buildStepFromCapability(
    capability: Capability, 
    toolName: string, 
    intent: ParsedIntent,
    successPatterns: string[]
  ): ActionStep | null {

    const params = this.buildToolParams(toolName, capability, intent);
    if (!params) return null;

    // Determine failure strategy based on risk and patterns
    let onFail: ActionStep['onFail'] = 'skip';
    if (capability.risk === 'high') onFail = 'rollback';
    else if (capability.risk === 'medium') onFail = 'retry';
    else if (successPatterns.some(p => p.includes(capability.id))) onFail = 'retry';

    return {
      tool: toolName,
      params,
      validate: capability.validation,
      onFail,
      maxRetries: capability.maxRetries,
    };
  }

  private buildToolParams(toolName: string, capability: Capability, intent: ParsedIntent): Record<string, any> | null {
    const tool = TOOL_REGISTRY[toolName];
    if (!tool) return null;

    const params: Record<string, any> = {};

    for (const [paramName, paramDef] of Object.entries(tool.parameters)) {
      if (paramDef.required) {
        params[paramName] = this.inferParamValue(paramName, capability, intent);
      } else if (paramDef.default !== undefined) {
        params[paramName] = paramDef.default;
      }
    }

    return params;
  }

  private inferParamValue(paramName: string, capability: Capability, intent: ParsedIntent): any {
    // Infer parameter values from intent context
    switch (paramName) {
      case 'cmd':
        return this.inferCommand(capability, intent);
      case 'module':
        return intent.entities.find(e => ['lang', 'db', 'ai', 'editor', 'dev', 'npm', 'shell', 'ui', 'auto'].includes(e)) || 'npm';
      case 'template':
        return intent.entities.find(e => ['next', 'react', 'express', 'nest'].includes(e)) || 'next';
      case 'command':
        return 'start'; // Default pg command
      case 'key':
      case 'value':
        return ''; // Will be filled by user or context
      case 'x':
      case 'y':
        return 500; // Default tap coordinates
      case 'x1':
      case 'x2':
        return 500;
      case 'y1':
        return 1500;
      case 'y2':
        return 500;
      case 'duration':
        return 300;
      case 'path':
        return '';
      case 'packageName':
        return intent.entities.find(e => e.includes('.')) || 'com.termux';
      case 'query':
        return intent.raw;
      case 'text':
        return intent.raw;
      case 'domain':
        return this.inferDomainFromIntent(intent);
      case 'topK':
        return 5;
      default:
        return '';
    }
  }

  private inferCommand(capability: Capability, intent: ParsedIntent): string {
    const type = intent.type;

    switch (capability.id) {
      case 'git.pull': return 'git pull --ff-only';
      case 'deps.install': return 'npm install';
      case 'deps.clean': return 'rm -rf node_modules package-lock.json && npm install';
      case 'project.build': return 'npm run build';
      case 'service.restart': return 'pm2 restart all || pm2 start ecosystem.config.js || pm2 start npm --name app -- start';
      case 'service.health': return 'sleep 3 && curl -s http://localhost:3000/health || curl -s http://localhost:3000 || echo "OK"';
      case 'service.stop': return 'pm2 stop all';
      case 'git.reset': return 'git reset --hard HEAD~1';
      case 'build.clean': return 'rm -rf dist build';
      default: return 'echo "No command inferred"';
    }
  }

  private inferDomainFromIntent(intent: ParsedIntent): string {
    const codeKeywords = ['github', 'repo', 'code', 'javascript', 'python', 'typescript', 'rust', 'implementation'];
    const researchKeywords = ['paper', 'arxiv', 'research', 'algorithm', 'model', 'neural'];
    const medicalKeywords = ['medical', 'clinical', 'patient', 'disease', 'treatment', 'pubmed'];

    const lower = intent.raw.toLowerCase();
    if (medicalKeywords.some(k => lower.includes(k))) return 'medical';
    if (researchKeywords.some(k => lower.includes(k))) return 'research';
    if (codeKeywords.some(k => lower.includes(k))) return 'code';
    return 'general';
  }

  private buildRollbackParams(capability: Capability, intent: ParsedIntent): Record<string, any> {
    const params: Record<string, any> = {};

    for (const [paramName, paramDef] of Object.entries(TOOL_REGISTRY[capability.tools[0]]?.parameters || {})) {
      if (paramDef.required) {
        params[paramName] = this.inferParamValue(paramName, capability, intent);
      }
    }

    return params;
  }

  // Public API for tool registration
  registerCapability(id: string, capability: Capability) {
    CAPABILITY_REGISTRY[id] = capability;
  }

  registerTool(name: string, tool: any) {
    TOOL_REGISTRY[name] = tool;
  }

  listCapabilities(): string[] {
    return Object.keys(CAPABILITY_REGISTRY);
  }

  listTools(): string[] {
    return Object.keys(TOOL_REGISTRY);
  }
}
