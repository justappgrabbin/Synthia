/**
 * Memory Substrate — Graph-based persistent knowledge store
 * 
 * Everything is a node. Relationships are edges.
 * Plans, intents, files, artifacts, chat messages — all nodes in the same graph.
 * The planner traverses this graph. Chat traverses it. Code generation traverses it.
 * 
 * Node types:
 *   - intent: what the user wanted
 *   - plan: the generated execution plan
 *   - step: individual execution step
 *   - outcome: result of execution (success/failure)
 *   - artifact: generated files, outputs
 *   - file: ingested files
 *   - semantic: concepts, entities, knowledge
 *   - link: relationships between nodes
 * 
 * Edge types:
 *   - generated: intent → plan
 *   - contains: plan → step
 *   - produced: step → artifact
 *   - learned: outcome → plan (success patterns)
 *   - related: semantic ↔ semantic
 *   - preceded: step → step (temporal)
 *   - caused: step → outcome
 */

import { readFile, writeFile, mkdir, access } from 'fs/promises';
import { join } from 'path';

const SUBSTRATE_DIR = `${process.env.HOME}/.local/share/synthia-kiosk/substrate`;
const NODES_FILE = join(SUBSTRATE_DIR, 'nodes.json');
const EDGES_FILE = join(SUBSTRATE_DIR, 'edges.json');

interface SubstrateNode {
  id: string;
  type: 'intent' | 'plan' | 'step' | 'outcome' | 'artifact' | 'file' | 'semantic' | 'chat' | 'link';
  content: string;
  metadata: Record<string, any>;
  createdAt: number;
  accessCount: number;
  lastAccessed: number;
  vector?: number[]; // Semantic embedding (for future vector search)
}

interface SubstrateEdge {
  id: string;
  from: string;
  to: string;
  type: 'generated' | 'contains' | 'produced' | 'learned' | 'related' | 'preceded' | 'caused' | 'references' | 'context';
  weight: number;
  metadata: Record<string, any>;
  createdAt: number;
}

interface GraphQuery {
  nodeTypes?: string[];
  edgeTypes?: string[];
  fromId?: string;
  toId?: string;
  contentQuery?: string;
  timeRange?: { start: number; end: number };
  limit?: number;
}

interface TraversalResult {
  nodes: SubstrateNode[];
  edges: SubstrateEdge[];
  paths: string[][]; // Node ID paths
}

async function loadJson<T>(path: string, defaultVal: T): Promise<T> {
  try {
    await access(path);
    const data = await readFile(path, 'utf-8');
    return JSON.parse(data);
  } catch {
    return defaultVal;
  }
}

async function saveJson<T>(path: string, data: T): Promise<void> {
  await mkdir(SUBSTRATE_DIR, { recursive: true });
  await writeFile(path, JSON.stringify(data, null, 2));
}

export class MemorySubstrate {
  private nodes: Map<string, SubstrateNode> = new Map();
  private edges: Map<string, SubstrateEdge> = new Map();
  private nodeIndex: Map<string, Set<string>> = new Map(); // type -> node IDs
  private edgeIndex: Map<string, Set<string>> = new Map(); // fromId -> edge IDs
  private loaded = false;

  async init(): Promise<void> {
    if (this.loaded) return;

    const nodesArr = await loadJson<SubstrateNode[]>(NODES_FILE, []);
    const edgesArr = await loadJson<SubstrateEdge[]>(EDGES_FILE, []);

    this.nodes = new Map(nodesArr.map(n => [n.id, n]));
    this.edges = new Map(edgesArr.map(e => [e.id, e]));

    // Build indices
    this.nodeIndex = new Map();
    this.edgeIndex = new Map();

    for (const [id, node] of this.nodes) {
      if (!this.nodeIndex.has(node.type)) this.nodeIndex.set(node.type, new Set());
      this.nodeIndex.get(node.type)!.add(id);
    }

    for (const [id, edge] of this.edges) {
      if (!this.edgeIndex.has(edge.from)) this.edgeIndex.set(edge.from, new Set());
      this.edgeIndex.get(edge.from)!.add(id);
    }

    this.loaded = true;
    console.log(`[Substrate] Loaded ${this.nodes.size} nodes, ${this.edges.size} edges`);
  }

  // ─── Node Operations ───

  async createNode(node: Omit<SubstrateNode, 'createdAt' | 'accessCount' | 'lastAccessed'>): Promise<SubstrateNode> {
    await this.init();

    const fullNode: SubstrateNode = {
      ...node,
      createdAt: Date.now(),
      accessCount: 0,
      lastAccessed: Date.now(),
    };

    this.nodes.set(node.id, fullNode);

    if (!this.nodeIndex.has(node.type)) this.nodeIndex.set(node.type, new Set());
    this.nodeIndex.get(node.type)!.add(node.id);

    await this.persist();
    return fullNode;
  }

  async getNode(id: string): Promise<SubstrateNode | null> {
    await this.init();
    const node = this.nodes.get(id);
    if (node) {
      node.accessCount++;
      node.lastAccessed = Date.now();
    }
    return node || null;
  }

  async findNodesByType(type: string): Promise<SubstrateNode[]> {
    await this.init();
    const ids = this.nodeIndex.get(type) || new Set();
    return Array.from(ids).map(id => this.nodes.get(id)!).filter(Boolean);
  }

  async searchNodes(query: string, types?: string[]): Promise<SubstrateNode[]> {
    await this.init();
    const results: SubstrateNode[] = [];
    const q = query.toLowerCase();

    for (const [id, node] of this.nodes) {
      if (types && !types.includes(node.type)) continue;
      if (node.content.toLowerCase().includes(q) || 
          JSON.stringify(node.metadata).toLowerCase().includes(q)) {
        results.push(node);
      }
    }

    return results.sort((a, b) => b.lastAccessed - a.lastAccessed).slice(0, 50);
  }

  // ─── Edge Operations ───

  async createEdge(edge: Omit<SubstrateEdge, 'createdAt'>): Promise<SubstrateEdge> {
    await this.init();

    const fullEdge: SubstrateEdge = {
      ...edge,
      createdAt: Date.now(),
    };

    this.edges.set(edge.id, fullEdge);

    if (!this.edgeIndex.has(edge.from)) this.edgeIndex.set(edge.from, new Set());
    this.edgeIndex.get(edge.from)!.add(edge.id);

    await this.persist();
    return fullEdge;
  }

  async getEdgesFrom(fromId: string, type?: string): Promise<SubstrateEdge[]> {
    await this.init();
    const edgeIds = this.edgeIndex.get(fromId) || new Set();
    return Array.from(edgeIds)
      .map(id => this.edges.get(id)!)
      .filter(e => !type || e.type === type);
  }

  async getEdgesTo(toId: string, type?: string): Promise<SubstrateEdge[]> {
    await this.init();
    return Array.from(this.edges.values())
      .filter(e => e.to === toId && (!type || e.type === type));
  }

  // ─── Graph Traversal ───

  async traverse(startId: string, options: {
    depth?: number;
    edgeTypes?: string[];
    nodeTypes?: string[];
    direction?: 'forward' | 'backward' | 'both';
  } = {}): Promise<TraversalResult> {
    await this.init();

    const { depth = 3, edgeTypes, nodeTypes, direction = 'forward' } = options;
    const visited = new Set<string>();
    const resultNodes: SubstrateNode[] = [];
    const resultEdges: SubstrateEdge[] = [];
    const paths: string[][] = [];

    const traverseRecursive = (currentId: string, currentDepth: number, currentPath: string[]) => {
      if (currentDepth > depth || visited.has(currentId)) return;
      visited.add(currentId);

      const node = this.nodes.get(currentId);
      if (!node) return;

      if (!nodeTypes || nodeTypes.includes(node.type)) {
        resultNodes.push(node);
        paths.push([...currentPath, currentId]);
      }

      // Forward edges
      if (direction === 'forward' || direction === 'both') {
        const forwardEdges = Array.from(this.edges.values())
          .filter(e => e.from === currentId && (!edgeTypes || edgeTypes.includes(e.type)));
        for (const edge of forwardEdges) {
          resultEdges.push(edge);
          traverseRecursive(edge.to, currentDepth + 1, [...currentPath, currentId]);
        }
      }

      // Backward edges
      if (direction === 'backward' || direction === 'both') {
        const backwardEdges = Array.from(this.edges.values())
          .filter(e => e.to === currentId && (!edgeTypes || edgeTypes.includes(e.type)));
        for (const edge of backwardEdges) {
          resultEdges.push(edge);
          traverseRecursive(edge.from, currentDepth + 1, [...currentPath, currentId]);
        }
      }
    };

    traverseRecursive(startId, 0, []);

    return { nodes: resultNodes, edges: resultEdges, paths };
  }

  // ─── Semantic Linking ───

  async linkSemantically(nodeId: string, relatedIds: string[], weight: number = 0.5): Promise<void> {
    await this.init();

    for (const relatedId of relatedIds) {
      if (relatedId === nodeId) continue;
      await this.createEdge({
        id: `edge_${Date.now()}_${Math.random()}`,
        from: nodeId,
        to: relatedId,
        type: 'related',
        weight,
        metadata: { autoLinked: true },
      });
    }
  }

  // ─── High-Level Operations ───

  async recordIntent(text: string, parsedType: string, confidence: number): Promise<SubstrateNode> {
    const intentId = `intent_${Date.now()}`;
    return this.createNode({
      id: intentId,
      type: 'intent',
      content: text,
      metadata: { parsedType, confidence },
    });
  }

  async recordPlan(intentId: string, plan: any): Promise<SubstrateNode> {
    const planId = `plan_${Date.now()}`;
    const planNode = await this.createNode({
      id: planId,
      type: 'plan',
      content: JSON.stringify(plan),
      metadata: { intentId, stepCount: plan.steps?.length || 0 },
    });

    await this.createEdge({
      id: `edge_${Date.now()}`,
      from: intentId,
      to: planId,
      type: 'generated',
      weight: 1,
      metadata: {},
    });

    // Record steps as nodes
    for (let i = 0; i < (plan.steps?.length || 0); i++) {
      const stepId = `${planId}_step_${i}`;
      await this.createNode({
        id: stepId,
        type: 'step',
        content: JSON.stringify(plan.steps[i]),
        metadata: { planId, index: i, tool: plan.steps[i].tool },
      });

      await this.createEdge({
        id: `edge_${Date.now()}_${i}`,
        from: planId,
        to: stepId,
        type: 'contains',
        weight: 1,
        metadata: { stepIndex: i },
      });

      if (i > 0) {
        await this.createEdge({
          id: `edge_${Date.now()}_prev_${i}`,
          from: `${planId}_step_${i - 1}`,
          to: stepId,
          type: 'preceded',
          weight: 1,
          metadata: {},
        });
      }
    }

    return planNode;
  }

  async recordOutcome(planId: string, success: boolean, output: string, learnings: string[]): Promise<SubstrateNode> {
    const outcomeId = `outcome_${Date.now()}`;
    const outcomeNode = await this.createNode({
      id: outcomeId,
      type: 'outcome',
      content: output,
      metadata: { planId, success, learnings },
    });

    await this.createEdge({
      id: `edge_${Date.now()}`,
      from: planId,
      to: outcomeId,
      type: 'caused',
      weight: success ? 1 : 0.5,
      metadata: { success },
    });

    // Link learnings to plan for future retrieval
    for (const learning of learnings) {
      const learningId = `learning_${Date.now()}_${Math.random()}`;
      await this.createNode({
        id: learningId,
        type: 'semantic',
        content: learning,
        metadata: { planId, outcomeId, success },
      });

      await this.createEdge({
        id: `edge_${Date.now()}_learn`,
        from: planId,
        to: learningId,
        type: 'learned',
        weight: success ? 1 : 0.3,
        metadata: {},
      });
    }

    return outcomeNode;
  }

  async recordChat(role: 'user' | 'agent', content: string, metadata?: any): Promise<SubstrateNode> {
    const chatId = `chat_${Date.now()}`;
    return this.createNode({
      id: chatId,
      type: 'chat',
      content,
      metadata: { role, ...metadata },
    });
  }

  async recordArtifact(planId: string, name: string, content: string, type: string): Promise<SubstrateNode> {
    const artifactId = `artifact_${Date.now()}`;
    const artifactNode = await this.createNode({
      id: artifactId,
      type: 'artifact',
      content,
      metadata: { planId, name, artifactType: type },
    });

    await this.createEdge({
      id: `edge_${Date.now()}`,
      from: planId,
      to: artifactId,
      type: 'produced',
      weight: 1,
      metadata: { artifactType: type },
    });

    return artifactNode;
  }

  // ─── Learning from Substrate ───

  async getSuccessPatterns(intentType: string): Promise<string[]> {
    await this.init();

    // Find successful outcomes for this intent type
    const intents = await this.findNodesByType('intent');
    const relevantIntents = intents.filter(i => i.metadata.parsedType === intentType);

    const learnings: string[] = [];

    for (const intent of relevantIntents) {
      // Traverse to find outcomes
      const result = await this.traverse(intent.id, {
        depth: 3,
        edgeTypes: ['generated', 'caused'],
        nodeTypes: ['outcome'],
      });

      for (const outcome of result.nodes) {
        if (outcome.metadata.success) {
          learnings.push(...(outcome.metadata.learnings || []));
        }
      }
    }

    return [...new Set(learnings)];
  }

  async getRelevantOutcomes(intent: string): Promise<any[]> {
    await this.init();

    const keywords = intent.toLowerCase().split(/\s+/);
    const allOutcomes = await this.findNodesByType('outcome');

    return allOutcomes
      .filter(o => keywords.some(k => o.content.toLowerCase().includes(k)))
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 5);
  }

  async getChatHistory(limit = 50): Promise<SubstrateNode[]> {
    await this.init();
    const chats = await this.findNodesByType('chat');
    return chats.sort((a, b) => b.createdAt - a.createdAt).slice(0, limit);
  }

  async getStats(): Promise<{ nodes: number; edges: number; byType: Record<string, number> }> {
    await this.init();
    const byType: Record<string, number> = {};
    for (const [id, node] of this.nodes) {
      byType[node.type] = (byType[node.type] || 0) + 1;
    }
    return { nodes: this.nodes.size, edges: this.edges.size, byType };
  }

  // ─── Persistence ───

  private async persist(): Promise<void> {
    await saveJson(NODES_FILE, Array.from(this.nodes.values()));
    await saveJson(EDGES_FILE, Array.from(this.edges.values()));
  }
}
