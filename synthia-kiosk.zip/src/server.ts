/**
 * Synthia Kiosk Server — Organism Architecture
 * 
 * The server is NOT the brain. It is the sensory/motor interface.
 * All intelligence lives in the substrate nodes.
 * 
 * HTTP/WebSocket → MessageBus → Nodes → Substrate → Nodes → WebSocket
 */
import express from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { Server as McpServer } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

import { MemorySubstrate } from './utils/memory-substrate.js';
import { bus } from './substrate/message-bus.js';
import {
  IntentParserNode, PlannerNode, ExecutorNode, ShellNode,
  DeviceNode, RAGNode, CoreTermuxNode, MemoryNode, ChatNode,
  NodeOrchestrator,
} from './substrate/nodes.js';
import { RAGRouter } from './rag/router.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = process.env.SYNTHIA_PORT ? parseInt(process.env.SYNTHIA_PORT) : 8765;

// ─── Initialize Substrate ───
const substrate = new MemorySubstrate();
await substrate.init();

console.log(`[Server] Substrate initialized: ${(await substrate.getStats()).nodes} nodes`);

// ─── Initialize RAG Router ───
const ragRouter = new RAGRouter();
await ragRouter.init();

// ─── Initialize Node Orchestrator ───
const orchestrator = new NodeOrchestrator();

// Register all nodes
orchestrator.register('intent_parser', new IntentParserNode());
orchestrator.register('planner', new PlannerNode(substrate));
orchestrator.register('executor', new ExecutorNode(substrate));
orchestrator.register('shell', new ShellNode());
orchestrator.register('device', new DeviceNode());
orchestrator.register('rag', new RAGNode());
orchestrator.register('core_termux', new CoreTermuxNode());
orchestrator.register('memory', new MemoryNode(substrate));

// Start all nodes
orchestrator.startAll();
console.log('[Server] All substrate nodes started');

// ─── Express App ───
const app = express();
const httpServer = createServer(app);

app.use(express.json());
app.use(express.static(join(__dirname, '../public')));

// Health check
app.get('/api/status', async (req, res) => {
  const stats = await substrate.getStats();
  const busStats = bus.getStats();
  res.json({
    running: true,
    port: PORT,
    substrate: stats,
    bus: busStats,
    uptime: process.uptime(),
  });
});

// Intent execution — posts to bus, does NOT execute directly
app.post('/api/intent', async (req, res) => {
  const { intent } = req.body;
  if (!intent) return res.status(400).json({ error: 'intent required' });

  // Post to bus. Nodes will handle it.
  const msg = await bus.post({
    type: 'user_intent',
    payload: { text: intent, context: req.body.context },
    from: 'http_api',
  });

  // Wait for plan completion (with timeout)
  const result = await waitForPlanCompletion(msg.id, 120000);

  res.json(result || { pending: true, messageId: msg.id });
});

// RAG query — posts to bus
app.post('/api/rag/query', async (req, res) => {
  const { text, domain, topK, sources, fusion } = req.body;
  if (!text) return res.status(400).json({ error: 'text required' });

  const msg = await bus.post({
    type: 'rag_query',
    payload: { text, domain, topK, sources, fusion },
    from: 'http_api',
  });

  // Wait for result
  const result = await waitForMessageType(msg.id, 'rag_result', 30000);
  res.json(result?.payload || { pending: true });
});

// RAG sources status
app.get('/api/rag/sources', async (req, res) => {
  const stats = await ragRouter.getAllStats();
  res.json({ sources: ragRouter.listSources(), stats });
});

// GitHub clone
app.post('/api/rag/github/clone', async (req, res) => {
  const { url, name } = req.body;
  if (!url) return res.status(400).json({ error: 'url required' });

  const github = ragRouter.getSource('github') as any;
  if (!github) return res.status(503).json({ error: 'GitHub RAG not available' });

  try {
    await github.cloneRepo(url, name || 'repo');
    res.json({ success: true, message: `Cloned ${url}` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// arXiv download
app.post('/api/rag/arxiv/download', async (req, res) => {
  const { pdfUrl, paperId } = req.body;
  if (!pdfUrl || !paperId) return res.status(400).json({ error: 'pdfUrl and paperId required' });

  const arxiv = ragRouter.getSource('arxiv') as any;
  if (!arxiv) return res.status(503).json({ error: 'arXiv RAG not available' });

  try {
    await arxiv.downloadPaper(pdfUrl, paperId);
    res.json({ success: true, message: `Downloaded ${paperId}` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Chat history from substrate
app.get('/api/chat', async (req, res) => {
  const limit = parseInt(req.query.limit as string) || 50;
  const history = await substrate.getChatHistory(limit);
  res.json(history);
});

// Device control endpoints (safe wrappers, not raw shell)
app.get('/api/device/state', async (req, res) => {
  const device = new (await import('./tools/device-control.js')).DeviceControlTools();
  const state = await device.getDeviceState();
  res.json(state);
});

app.post('/api/device/screenshot', async (req, res) => {
  const device = new (await import('./tools/device-control.js')).DeviceControlTools();
  const path = await device.takeScreenshot(req.body.path);
  res.json({ path });
});

// Trident component data
app.get('/api/trident/components', (req, res) => res.json(COMPONENTS));
app.get('/api/trident/slots', (req, res) => res.json(SLOTS));
app.get('/api/trident/presets', (req, res) => res.json(PRESETS));

// ─── WebSocket Server ───
const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
const wsClients = new Set<WebSocket>();

function broadcastToClients(msg: any) {
  const data = JSON.stringify(msg);
  wsClients.forEach(ws => { if (ws.readyState === WebSocket.OPEN) ws.send(data); });
}

wss.on('connection', (ws) => {
  wsClients.add(ws);
  console.log('[WS] Client connected');

  // Create a ChatNode for this WebSocket connection
  const chatNode = new ChatNode((msg) => {
    if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg));
  });
  chatNode.start();

  ws.on('message', async (data) => {
    try {
      const msg = JSON.parse(data.toString());

      switch (msg.type) {
        case 'chat': {
          // Post to bus as chat_message
          await bus.post({
            type: 'chat_message',
            payload: { role: 'user', content: msg.payload.text },
            from: 'websocket',
          });

          // Also post as user_intent for processing
          await bus.post({
            type: 'user_intent',
            payload: { text: msg.payload.text, context: msg.payload.context },
            from: 'websocket',
          });
          break;
        }

        case 'intent': {
          await bus.post({
            type: 'user_intent',
            payload: { text: msg.payload.intent, context: msg.payload.context },
            from: 'websocket',
          });
          break;
        }

        case 'rag_query': {
          await bus.post({
            type: 'rag_query',
            payload: msg.payload,
            from: 'websocket',
          });
          break;
        }

        case 'build': {
          broadcastToClients({ type: 'build', payload: { status: 'started', assembly: msg.payload.assembly } });
          const steps = ['Fetching', 'Resolving', 'Assembling', 'Configuring', 'Building', 'Packaging'];
          for (let i = 0; i < steps.length; i++) {
            await new Promise(r => setTimeout(r, 800 + Math.random() * 400));
            broadcastToClients({ type: 'build', payload: { status: 'progress', step: steps[i], pct: Math.round(((i + 1) / steps.length) * 100) } });
          }
          broadcastToClients({ type: 'build', payload: { status: 'complete', message: 'Build successful' } });
          break;
        }

        case 'deploy': {
          broadcastToClients({ type: 'deploy', payload: { status: 'started', assembly: msg.payload.assembly } });
          const steps = ['Initializing', 'Packaging', 'Writing configs', 'Preparing network', 'Configuring MCP', 'Building bundle', 'Health checks'];
          for (let i = 0; i < steps.length; i++) {
            await new Promise(r => setTimeout(r, 500 + Math.random() * 300));
            broadcastToClients({ type: 'deploy', payload: { status: 'progress', step: steps[i], pct: Math.round(((i + 1) / steps.length) * 100) } });
          }
          broadcastToClients({ type: 'deploy', payload: { status: 'complete', message: 'Deployment successful' } });
          break;
        }

        case 'ping': {
          ws.send(JSON.stringify({ type: 'pong', payload: { time: Date.now() } }));
          break;
        }
      }
    } catch (err: any) {
      ws.send(JSON.stringify({ type: 'error', payload: { message: err.message } }));
    }
  });

  ws.on('close', () => {
    wsClients.delete(ws);
    chatNode.stop();
    console.log('[WS] Client disconnected');
  });
});

// ─── MCP Server (Stdio) ───
const mcpServer = new McpServer(
  { name: 'synthia-kiosk', version: '2.0.0' },
  { capabilities: { tools: {} } }
);

mcpServer.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    { name: 'synthia_intent', description: 'Execute natural language intent via substrate', inputSchema: { type: 'object', properties: { intent: { type: 'string' }, context: { type: 'object' } }, required: ['intent'] } },
    { name: 'synthia_rag_query', description: 'Query RAG sources', inputSchema: { type: 'object', properties: { text: { type: 'string' }, domain: { type: 'string' }, sources: { type: 'array', items: { type: 'string' } } }, required: ['text'] } },
    { name: 'synthia_rag_sources', description: 'Get RAG source status', inputSchema: { type: 'object', properties: {} } },
    { name: 'synthia_status', description: 'Full system status', inputSchema: { type: 'object', properties: {} } },
  ]
}));

mcpServer.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;
  try {
    switch (name) {
      case 'synthia_intent': {
        const msg = await bus.post({
          type: 'user_intent',
          payload: { text: args.intent, context: args.context },
          from: 'mcp',
        });
        const result = await waitForPlanCompletion(msg.id, 120000);
        return { content: [{ type: 'text', text: result ? JSON.stringify(result) : 'Pending...' }] };
      }
      case 'synthia_rag_query': {
        const msg = await bus.post({
          type: 'rag_query',
          payload: { text: args.text, domain: args.domain, sources: args.sources },
          from: 'mcp',
        });
        const result = await waitForMessageType(msg.id, 'rag_result', 30000);
        return { content: [{ type: 'text', text: result?.payload?.synthesized || 'No results' }] };
      }
      case 'synthia_rag_sources': {
        const stats = await ragRouter.getAllStats();
        return { content: [{ type: 'text', text: JSON.stringify(stats, null, 2) }] };
      }
      case 'synthia_status': {
        const stats = await substrate.getStats();
        const busStats = bus.getStats();
        return { content: [{ type: 'text', text: `Substrate: ${stats.nodes} nodes, ${stats.edges} edges\nBus: ${busStats.totalMessages} messages, ${busStats.subscribers} subscribers\nServer: http://localhost:${PORT}` }] };
      }
      default: throw new Error(`Unknown tool: ${name}`);
    }
  } catch (err: any) {
    return { content: [{ type: 'text', text: `❌ ${err.message}` }], isError: true };
  }
});

// ─── Helpers ───
async function waitForPlanCompletion(parentId: string, timeout: number): Promise<any> {
  return new Promise((resolve) => {
    const start = Date.now();
    const check = () => {
      const completed = bus.getMessagesByType('plan_completed', 10)
        .find(m => m.trace.includes(parentId));
      if (completed) {
        resolve(completed.payload);
      } else if (Date.now() - start > timeout) {
        resolve({ timeout: true, message: 'Plan execution timed out' });
      } else {
        setTimeout(check, 500);
      }
    };
    check();
  });
}

async function waitForMessageType(parentId: string, type: string, timeout: number): Promise<SubstrateMessage | null> {
  return new Promise((resolve) => {
    const start = Date.now();
    const check = () => {
      const found = bus.getMessagesByType(type, 10)
        .find(m => m.parentId === parentId || m.trace.includes(parentId));
      if (found) {
        resolve(found);
      } else if (Date.now() - start > timeout) {
        resolve(null);
      } else {
        setTimeout(check, 500);
      }
    };
    check();
  });
}

// ─── Trident Data ───
const COMPONENTS = [
  { id: 'model', name: 'model.py', badge: 'core', badgeClass: 'badge-core', desc: '1M param transformer with 3 specialist heads: Code, Math, Research.', size: '~45KB', deps: ['torch', 'numpy'], config: { head_mode: { type: 'select', options: ['auto', 'code', 'math', 'research'], default: 'auto', label: 'Head Mode' }, temperature: { type: 'number', default: 0.7, min: 0.1, max: 2.0, step: 0.1, label: 'Temperature' }, max_tokens: { type: 'number', default: 512, min: 64, max: 2048, step: 64, label: 'Max Tokens' }, use_rag: { type: 'checkbox', default: true, label: 'Enable RAG' } } },
  { id: 'rag', name: 'rag.py', badge: 'rag', badgeClass: 'badge-rag', desc: 'Python chunk store + P2P RAG node. Local embedding storage with aiortc WebRTC.', size: '~32KB', deps: ['aiortc', 'numpy', 'sentence-transformers'], config: { chunk_size: { type: 'number', default: 512, min: 128, max: 2048, step: 128, label: 'Chunk Size' }, top_k: { type: 'number', default: 5, min: 1, max: 20, step: 1, label: 'Top-K' }, embedding_model: { type: 'select', options: ['all-MiniLM-L6-v2', 'all-mpnet-base-v2'], default: 'all-MiniLM-L6-v2', label: 'Embed Model' }, p2p_enabled: { type: 'checkbox', default: true, label: 'P2P Mode' } } },
  { id: 'rag_client', name: 'rag_client.js', badge: 'client', badgeClass: 'badge-client', desc: 'Browser P2P RAG client. WebRTC DataChannel for connecting to Trident nodes.', size: '~18KB', deps: ['webrtc-adapter'], config: { signaling_url: { type: 'text', default: 'ws://localhost:8765', label: 'Signaling URL' }, stun_server: { type: 'text', default: 'stun:stun.l.google.com:19302', label: 'STUN Server' }, auto_connect: { type: 'checkbox', default: false, label: 'Auto-Connect' } } },
  { id: 'signal_server', name: 'signal_server.py', badge: 'signal', badgeClass: 'badge-signal', desc: 'Minimal WebSocket signaling server. Handshake-only (~50 lines).', size: '~3KB', deps: ['websockets'], config: { host: { type: 'text', default: '0.0.0.0', label: 'Host' }, port: { type: 'number', default: 8765, min: 1000, max: 65535, step: 1, label: 'Port' }, cors_origins: { type: 'text', default: '*', label: 'CORS Origins' } } },
  { id: 'mcp_server', name: 'mcp_server.py', badge: 'mcp', badgeClass: 'badge-mcp', desc: 'FastMCP server exposing all Trident tools to Claude Desktop / any MCP client.', size: '~28KB', deps: ['fastmcp', 'mcp'], config: { transport: { type: 'select', options: ['stdio', 'sse', 'http'], default: 'stdio', label: 'Transport' }, port: { type: 'number', default: 3000, min: 1000, max: 65535, step: 1, label: 'Port' }, log_level: { type: 'select', options: ['debug', 'info', 'warn', 'error'], default: 'info', label: 'Log Level' } } },
  { id: 'train', name: 'train.py', badge: 'train', badgeClass: 'badge-train', desc: 'Training loop — toy data to real data. CPU-friendly. Fine-tune all 3 heads.', size: '~22KB', deps: ['torch', 'datasets'], config: { epochs: { type: 'number', default: 3, min: 1, max: 100, step: 1, label: 'Epochs' }, batch_size: { type: 'number', default: 4, min: 1, max: 32, step: 1, label: 'Batch Size' }, learning_rate: { type: 'number', default: 0.001, min: 0.0001, max: 0.01, step: 0.0001, label: 'LR' }, dataset: { type: 'select', options: ['toy', 'codeparrot', 'math_qa', 'custom'], default: 'toy', label: 'Dataset' } } },
];

const SLOTS = [
  { id: 'core', label: 'Core Engine', icon: '🧠', accepts: ['model'] },
  { id: 'knowledge', label: 'Knowledge Layer', icon: '📚', accepts: ['rag'] },
  { id: 'client', label: 'Client Interface', icon: '🌐', accepts: ['rag_client'] },
  { id: 'network', label: 'Network Layer', icon: '🔌', accepts: ['signal_server'] },
  { id: 'integration', label: 'Integration', icon: '🔧', accepts: ['mcp_server'] },
  { id: 'training', label: 'Training', icon: '🎓', accepts: ['train'] },
];

const PRESETS = {
  minimal: { name: 'Minimal', icon: '⚡', desc: 'Core model only', comps: ['model'] },
  full: { name: 'Full Stack', icon: '🔱', desc: 'All 6 modules', comps: ['model', 'rag', 'rag_client', 'signal_server', 'mcp_server', 'train'] },
  p2p: { name: 'P2P Node', icon: '🌐', desc: 'Model + RAG + P2P', comps: ['model', 'rag', 'rag_client', 'signal_server'] },
  mcp: { name: 'MCP Server', icon: '🔧', desc: 'Model + RAG + MCP', comps: ['model', 'rag', 'mcp_server'] },
};

// ─── Start ───
httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`🧠 Synthia Kiosk Organism running on http://0.0.0.0:${PORT}`);
  console.log(`   WebSocket: ws://localhost:${PORT}/ws`);
  console.log(`   MCP: stdio (for Claude/Cursor/Cline)`);
  console.log(`   Architecture: MessageBus + Substrate Nodes`);
});

// Start MCP stdio transport
const mcpTransport = new StdioServerTransport();
mcpServer.connect(mcpTransport).then(() => {
  console.log('   MCP stdio transport connected');
});
