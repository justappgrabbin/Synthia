/**
 * System Nodes — Every component is a node that subscribes to the bus
 * 
 * No node imports another. They only import the bus and post/subscribe.
 */

import { bus, SubstrateMessage } from './message-bus.js';
import { MemorySubstrate } from '../utils/memory-substrate.js';
import { SemanticIntentParser } from '../engine/intent-parser.js';
import { DynamicPlanner } from '../engine/planner.js';
import { Executor } from '../engine/executor.js';
import { CoreTermuxTools } from '../tools/core-termux.js';
import { DeviceControlTools } from '../tools/device-control.js';
import { RAGRouter } from '../rag/router.js';
import { runShell } from '../utils/shell.js';

// ─── Intent Parser Node ───
export class IntentParserNode {
  private parser = new SemanticIntentParser();
  private unsub: (() => void) | null = null;

  start() {
    this.unsub = bus.subscribe({
      nodeId: 'intent_parser',
      messageTypes: ['user_intent'],
      priority: 10,
      handler: async (msg) => {
        const { text, context } = msg.payload;
        const parsed = this.parser.parse(text);

        await bus.post({
          type: 'intent_parsed',
          payload: { parsed, originalText: text, context },
          from: 'intent_parser',
          parentId: msg.id,
        });
      },
    });
  }

  stop() { this.unsub?.(); }
}

// ─── Planner Node ───
export class PlannerNode {
  private planner: DynamicPlanner;
  private unsub: (() => void) | null = null;

  constructor(memory: any) {
    this.planner = new DynamicPlanner(memory);
  }

  start() {
    this.unsub = bus.subscribe({
      nodeId: 'planner',
      messageTypes: ['intent_parsed'],
      priority: 9,
      handler: async (msg) => {
        const { parsed } = msg.payload;
        const plan = await this.planner.buildPlan(parsed);

        await bus.post({
          type: 'plan_generated',
          payload: { plan, parsed },
          from: 'planner',
          parentId: msg.id,
        });
      },
    });
  }

  stop() { this.unsub?.(); }
}

// ─── Executor Node ───
export class ExecutorNode {
  private executor: Executor;
  private unsub: (() => void) | null = null;
  private stepResults: Map<string, any> = new Map();

  constructor(memory: any) {
    this.executor = new Executor(memory);
    this.executor.onLog = (msg, type) => {
      bus.post({
        type: 'log',
        payload: { message: msg, level: type },
        from: 'executor',
      });
    };
  }

  start() {
    this.unsub = bus.subscribe({
      nodeId: 'executor',
      messageTypes: ['plan_generated'],
      priority: 8,
      handler: async (msg) => {
        const { plan } = msg.payload;

        for (let i = 0; i < plan.steps.length; i++) {
          const step = plan.steps[i];

          await bus.post({
            type: 'step_execute',
            payload: { step, planId: plan.id, stepIndex: i },
            from: 'executor',
            parentId: msg.id,
          });

          const result = await this.waitForStepCompletion(plan.id, i);

          if (!result.success) {
            if (step.onFail === 'rollback' && plan.rollbackSteps.length > 0) {
              await bus.post({
                type: 'plan_rollback',
                payload: { plan, failedStep: i },
                from: 'executor',
                parentId: msg.id,
              });
            }
            break;
          }
        }

        await bus.post({
          type: 'plan_completed',
          payload: { plan, results: Array.from(this.stepResults.entries()) },
          from: 'executor',
          parentId: msg.id,
        });
      },
    });
  }

  private waitForStepCompletion(planId: string, stepIndex: number): Promise<any> {
    return new Promise((resolve) => {
      const checkResult = () => {
        const key = `${planId}_${stepIndex}`;
        const result = this.stepResults.get(key);
        if (result) { resolve(result); }
        else { setTimeout(checkResult, 100); }
      };
      checkResult();
    });
  }

  recordStepResult(planId: string, stepIndex: number, result: any) {
    this.stepResults.set(`${planId}_${stepIndex}`, result);
  }

  stop() { this.unsub?.(); }
}

// ─── Shell Node ───
export class ShellNode {
  private unsub: (() => void) | null = null;

  start() {
    this.unsub = bus.subscribe({
      nodeId: 'shell',
      messageTypes: ['step_execute'],
      priority: 5,
      handler: async (msg) => {
        const { step } = msg.payload;
        if (step.tool !== 'shell') return;

        const result = await runShell(step.params.cmd, {
          cwd: step.params.cwd,
          timeout: step.params.timeout || 60000,
        });

        await bus.post({
          type: 'step_completed',
          payload: { step, result, tool: 'shell' },
          from: 'shell',
          parentId: msg.id,
        });
      },
    });
  }

  stop() { this.unsub?.(); }
}

// ─── Device Control Node ───
export class DeviceNode {
  private deviceControl = new DeviceControlTools();
  private unsub: (() => void) | null = null;

  start() {
    this.unsub = bus.subscribe({
      nodeId: 'device',
      messageTypes: ['step_execute'],
      priority: 5,
      handler: async (msg) => {
        const { step } = msg.payload;
        const deviceTools = ['device_screenshot', 'device_tap', 'device_swipe', 'device_list_apps', 'device_launch_app', 'device_press_button'];
        if (!deviceTools.includes(step.tool)) return;

        let result: any;
        try {
          switch (step.tool) {
            case 'device_screenshot': result = { success: true, output: await this.deviceControl.takeScreenshot(step.params.path) }; break;
            case 'device_tap': result = { success: true, output: await this.deviceControl.tap(step.params.x, step.params.y) }; break;
            case 'device_swipe': result = { success: true, output: await this.deviceControl.swipe(step.params.x1, step.params.y1, step.params.x2, step.params.y2, step.params.duration) }; break;
            case 'device_list_apps': result = { success: true, output: JSON.stringify(await this.deviceControl.listApps()) }; break;
            case 'device_launch_app': result = { success: true, output: await this.deviceControl.launchApp(step.params.packageName) }; break;
            case 'device_press_button': result = { success: true, output: await this.deviceControl.pressButton(step.params.button) }; break;
            default: result = { success: false, output: `Unknown device tool: ${step.tool}` };
          }
        } catch (err: any) {
          result = { success: false, output: err.message };
        }

        await bus.post({
          type: 'step_completed',
          payload: { step, result, tool: step.tool },
          from: 'device',
          parentId: msg.id,
        });
      },
    });
  }

  stop() { this.unsub?.(); }
}

// ─── RAG Node ───
export class RAGNode {
  private router = new RAGRouter();
  private unsub: (() => void) | null = null;

  start() {
    this.unsub = bus.subscribe({
      nodeId: 'rag',
      messageTypes: ['step_execute', 'rag_query'],
      priority: 5,
      handler: async (msg) => {
        if (msg.type === 'step_execute') {
          const { step } = msg.payload;
          if (step.tool !== 'rag') return;

          const result = await this.router.query(step.params.text, {
            domain: step.params.domain,
            topK: step.params.topK,
          });

          await bus.post({
            type: 'step_completed',
            payload: { step, result: { success: true, output: result.synthesized }, tool: 'rag' },
            from: 'rag',
            parentId: msg.id,
          });
        } else if (msg.type === 'rag_query') {
          const { text, domain, sources, fusion } = msg.payload;
          const result = await this.router.query(text, { domain, sources, fusion });

          await bus.post({
            type: 'rag_result',
            payload: result,
            from: 'rag',
            parentId: msg.id,
          });
        }
      },
    });
  }

  stop() { this.unsub?.(); }
}

// ─── Core Termux Node ───
export class CoreTermuxNode {
  private coreTermux = new CoreTermuxTools();
  private unsub: (() => void) | null = null;

  start() {
    this.unsub = bus.subscribe({
      nodeId: 'core_termux',
      messageTypes: ['step_execute'],
      priority: 5,
      handler: async (msg) => {
        const { step } = msg.payload;
        const coreTools = ['core_install', 'core_init', 'core_env_set', 'core_pg', 'brain_search'];
        if (!coreTools.includes(step.tool)) return;

        let result: any;
        try {
          switch (step.tool) {
            case 'core_install': result = { success: true, output: await this.coreTermux.install(step.params.module, step.params.tools) }; break;
            case 'core_init': result = { success: true, output: await this.coreTermux.initProject(step.params.template, step.params.cwd) }; break;
            case 'core_env_set': result = { success: true, output: await this.coreTermux.envSet(step.params.key, step.params.value) }; break;
            case 'core_pg': result = { success: true, output: await this.coreTermux.pg(step.params.command, step.params.arg) }; break;
            case 'brain_search': result = { success: true, output: await this.coreTermux.brainSearch(step.params.query) }; break;
            default: result = { success: false, output: `Unknown core tool: ${step.tool}` };
          }
        } catch (err: any) {
          result = { success: false, output: err.message };
        }

        await bus.post({
          type: 'step_completed',
          payload: { step, result, tool: step.tool },
          from: 'core_termux',
          parentId: msg.id,
        });
      },
    });
  }

  stop() { this.unsub?.(); }
}

// ─── Memory Node ───
export class MemoryNode {
  private substrate: MemorySubstrate;
  private unsub: (() => void) | null = null;

  constructor(substrate: MemorySubstrate) {
    this.substrate = substrate;
  }

  start() {
    this.unsub = bus.subscribe({
      nodeId: 'memory',
      messageTypes: ['user_intent', 'intent_parsed', 'plan_generated', 'step_execute', 'step_completed', 'plan_completed', 'rag_query', 'rag_result', 'chat_message'],
      priority: 1,
      handler: async (msg) => {
        switch (msg.type) {
          case 'user_intent':
            await this.substrate.recordIntent(msg.payload.text, 'user', 1);
            break;
          case 'intent_parsed':
            await this.substrate.createNode({
              id: `parsed_${msg.id}`,
              type: 'semantic',
              content: JSON.stringify(msg.payload.parsed),
              metadata: { messageId: msg.id, type: 'parsed_intent' },
            });
            break;
          case 'plan_generated':
            await this.substrate.recordPlan(msg.parentId || msg.id, msg.payload.plan);
            break;
          case 'plan_completed':
            const { plan, results } = msg.payload;
            const allSuccess = results.every((r: any) => r[1].success);
            const learnings = results.map((r: any) => `${r[0]}: ${r[1].success ? 'success' : 'failed'}`);
            await this.substrate.recordOutcome(plan.id, allSuccess, JSON.stringify(results), learnings);
            break;
          case 'chat_message':
            await this.substrate.recordChat(msg.payload.role, msg.payload.content, msg.payload.metadata);
            break;
        }
      },
    });
  }

  stop() { this.unsub?.(); }
}

// ─── Chat Node (WebSocket bridge) ───
export class ChatNode {
  private wsSend: (msg: any) => void;
  private unsub: (() => void) | null = null;

  constructor(wsSend: (msg: any) => void) {
    this.wsSend = wsSend;
  }

  start() {
    this.unsub = bus.subscribe({
      nodeId: 'chat',
      messageTypes: ['plan_completed', 'rag_result', 'log', 'handler_error'],
      priority: 2,
      handler: async (msg) => {
        switch (msg.type) {
          case 'plan_completed':
            this.wsSend({
              type: 'intent_result',
              payload: {
                planId: msg.payload.plan.id,
                success: msg.payload.results.every((r: any) => r[1].success),
                output: JSON.stringify(msg.payload.results),
              },
            });
            break;
          case 'rag_result':
            this.wsSend({ type: 'rag_result', payload: msg.payload });
            break;
          case 'log':
            this.wsSend({ type: 'log', payload: msg.payload });
            break;
          case 'handler_error':
            this.wsSend({ type: 'error', payload: { message: msg.payload.error } });
            break;
        }
      },
    });
  }

  stop() { this.unsub?.(); }
}

// ─── Node Orchestrator ───
export class NodeOrchestrator {
  private nodes: Map<string, { start: () => void; stop: () => void }> = new Map();

  register(id: string, node: { start: () => void; stop: () => void }) {
    this.nodes.set(id, node);
  }

  startAll() {
    for (const [id, node] of this.nodes) {
      console.log(`[Orchestrator] Starting node: ${id}`);
      node.start();
    }
  }

  stopAll() {
    for (const [id, node] of this.nodes) {
      console.log(`[Orchestrator] Stopping node: ${id}`);
      node.stop();
    }
  }

  getNode(id: string): any {
    return this.nodes.get(id);
  }
}
