/**
 * Message Bus — The substrate's central nervous system
 * 
 * No component calls another directly. All communication happens through here.
 * Every node subscribes to message types. The bus routes messages to subscribers.
 * 
 * This is the actual inversion:
 *   Before: Executor calls Shell.run()
 *   After:  Executor posts "execute_shell" message. Shell node subscribes to 
 *           "execute_shell" and executes. Result is posted back as "shell_result".
 *           Executor subscribes to "shell_result" and continues.
 */

export interface SubstrateMessage {
  id: string;
  type: string;
  payload: any;
  from: string;      // Node ID that posted this
  to?: string;       // Optional: specific target node
  parentId?: string; // For reply chains
  timestamp: number;
  trace: string[];   // Path through the graph for debugging
}

export interface NodeSubscription {
  nodeId: string;
  messageTypes: string[];
  handler: (msg: SubstrateMessage) => Promise<void> | void;
  priority: number;  // Higher = processed first
}

export class MessageBus {
  private subscribers: Map<string, NodeSubscription[]> = new Map();
  private messageLog: SubstrateMessage[] = [];
  private maxLogSize = 10000;

  // Subscribe a node to message types
  subscribe(sub: NodeSubscription): () => void {
    for (const type of sub.messageTypes) {
      if (!this.subscribers.has(type)) this.subscribers.set(type, []);
      const subs = this.subscribers.get(type)!;
      subs.push(sub);
      subs.sort((a, b) => b.priority - a.priority);
    }

    // Return unsubscribe function
    return () => {
      for (const type of sub.messageTypes) {
        const subs = this.subscribers.get(type);
        if (subs) {
          const idx = subs.findIndex(s => s.nodeId === sub.nodeId);
          if (idx >= 0) subs.splice(idx, 1);
        }
      }
    };
  }

  // Post a message to the substrate
  async post(msg: Omit<SubstrateMessage, 'id' | 'timestamp' | 'trace'>): Promise<SubstrateMessage> {
    const fullMsg: SubstrateMessage = {
      ...msg,
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      timestamp: Date.now(),
      trace: [...(msg.trace || []), msg.from],
    };

    this.messageLog.push(fullMsg);
    if (this.messageLog.length > this.maxLogSize) {
      this.messageLog = this.messageLog.slice(-this.maxLogSize);
    }

    // Route to subscribers
    const subs = this.subscribers.get(fullMsg.type) || [];

    for (const sub of subs) {
      // If message has specific target, only deliver to that node
      if (fullMsg.to && sub.nodeId !== fullMsg.to) continue;

      try {
        await sub.handler(fullMsg);
      } catch (err) {
        console.error(`[Bus] Handler error in ${sub.nodeId} for ${fullMsg.type}:`, err);
        // Post error message so other nodes can handle it
        await this.post({
          type: 'handler_error',
          payload: { originalMsg: fullMsg, error: (err as Error).message },
          from: 'bus',
          to: fullMsg.from,
          parentId: fullMsg.id,
        });
      }
    }

    return fullMsg;
  }

  // Get message history for a trace
  getTrace(messageId: string): SubstrateMessage[] {
    const msg = this.messageLog.find(m => m.id === messageId);
    if (!msg) return [];

    const trace: SubstrateMessage[] = [msg];
    let current = msg;

    while (current.parentId) {
      const parent = this.messageLog.find(m => m.id === current.parentId);
      if (!parent) break;
      trace.unshift(parent);
      current = parent;
    }

    return trace;
  }

  // Get messages by type
  getMessagesByType(type: string, limit = 100): SubstrateMessage[] {
    return this.messageLog
      .filter(m => m.type === type)
      .slice(-limit);
  }

  // Get messages from a node
  getMessagesFrom(nodeId: string, limit = 100): SubstrateMessage[] {
    return this.messageLog
      .filter(m => m.from === nodeId)
      .slice(-limit);
  }

  getStats(): { totalMessages: number; subscribers: number; types: string[] } {
    return {
      totalMessages: this.messageLog.length,
      subscribers: this.subscribers.size,
      types: Array.from(this.subscribers.keys()),
    };
  }
}

// Singleton instance
export const bus = new MessageBus();
