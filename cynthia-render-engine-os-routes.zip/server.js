import express from "express";
import cors from "cors";
import multer from "multer";
import AdmZip from "adm-zip";
import fs from "node:fs/promises";
import fsSync from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { spawn } from "node:child_process";
import vm from "node:vm";
import { nanoid } from "nanoid";
import { createClient } from "@supabase/supabase-js";

const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.CYNTHIA_DATA_DIR || path.join(process.cwd(), "data");
const PROJECTS_DIR = path.join(DATA_DIR, "projects");
const ALLOW_BUILDS = (process.env.ALLOW_BUILDS || "true").toLowerCase() === "true";
const BUILD_TIMEOUT_MS = Number(process.env.BUILD_TIMEOUT_MS || 180000);
const SUPABASE_INTAKE_URL = process.env.SUPABASE_INTAKE_URL || "https://leisphnjslcuepflefri.supabase.co/functions/v1/cynthia-intake";
const SUPABASE_URL = process.env.SUPABASE_URL || "https://leisphnjslcuepflefri.supabase.co";
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || "";
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || "";
const SUPABASE_READ_KEY = SUPABASE_SERVICE_ROLE_KEY || SUPABASE_ANON_KEY;

const supabase = SUPABASE_READ_KEY
  ? createClient(SUPABASE_URL, SUPABASE_READ_KEY, { auth: { persistSession: false, autoRefreshToken: false } })
  : null;

await fs.mkdir(PROJECTS_DIR, { recursive: true });

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 75 * 1024 * 1024 } });

app.use(cors());
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use("/", express.static(path.join(process.cwd(), "public")));

function sha(input) {
  return crypto.createHash("sha256").update(input).digest("hex");
}

function safeRel(raw) {
  const normalized = String(raw || "").replace(/\\/g, "/").replace(/^\/+/, "");
  const clean = path.posix.normalize(normalized);
  if (!clean || clean === "." || clean.startsWith("../") || clean.includes("/../")) return null;
  if (clean.includes("__MACOSX") || clean.endsWith(".DS_Store")) return null;
  return clean;
}

function isTextFile(filename) {
  return /\.(html?|css|js|mjs|cjs|ts|tsx|jsx|json|md|txt|svg|xml|csv|yml|yaml|toml|py|sql|env)$/i.test(filename);
}

async function exists(p) {
  try { await fs.access(p); return true; } catch { return false; }
}

async function readJSON(p, fallback = null) {
  try { return JSON.parse(await fs.readFile(p, "utf8")); } catch { return fallback; }
}

async function writeJSON(p, obj) {
  await fs.writeFile(p, JSON.stringify(obj, null, 2), "utf8");
}

async function walk(dir, base = dir, out = []) {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  for (const e of entries) {
    if (e.name === "node_modules" || e.name === ".git") continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) await walk(full, base, out);
    else {
      const rel = path.relative(base, full).replace(/\\/g, "/");
      const stat = await fs.stat(full);
      out.push({ path: rel, size: stat.size, text: isTextFile(rel) });
    }
  }
  return out;
}

function detectEntrypoints(files) {
  const html = files.filter(f => /\.html?$/i.test(f.path)).map(f => f.path);
  const preferred = [
    /(^|\/)index\.html?$/i,
    /(^|\/)(app|home|main|shell|morph|syntia|synthia|cynthia)[^/]*\.html?$/i
  ];
  const ranked = [];
  for (const rx of preferred) for (const p of html) if (rx.test(p) && !ranked.includes(p)) ranked.push(p);
  for (const p of html) if (!ranked.includes(p)) ranked.push(p);
  return ranked;
}

async function findBuildOutput(sourceDir) {
  const candidates = ["dist", "build", "out", "public"];
  for (const c of candidates) {
    const dir = path.join(sourceDir, c);
    if (await exists(path.join(dir, "index.html"))) return c;
  }
  return null;
}

function loadMorphEngine() {
  const code = fsSync.readFileSync(path.join(process.cwd(), "lib", "morphEngine.js"), "utf8");
  const sandbox = { console, Date, JSON, Map, Set, Array, Object, String, Number, Boolean, RegExp, Math, crypto, setTimeout, clearTimeout };
  sandbox.window = sandbox;
  sandbox.global = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox, { filename: "morphEngine.js" });
  const exported = sandbox.MorphEngine || sandbox.window?.MorphEngine || sandbox.globalThis?.MorphEngine;
  if (!exported?.MorphMemoryEngine) throw new Error("MorphEngine.MorphMemoryEngine was not found");
  return exported;
}

const MorphEngine = loadMorphEngine();

async function projectMeta(id) {
  const meta = await readJSON(path.join(PROJECTS_DIR, id, "project.json"));
  if (!meta) throw new Error("Project not found");
  return meta;
}

async function saveMeta(meta) {
  meta.updatedAt = new Date().toISOString();
  await writeJSON(path.join(PROJECTS_DIR, meta.id, "project.json"), meta);
}

async function ingestToSupabase(filename, content, sourceKind, address) {
  try {
    const res = await fetch(SUPABASE_INTAKE_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename, content, source_kind: sourceKind, address })
    });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok && data.ok !== false, data };
  } catch (error) {
    return { ok: false, error: String(error.message || error) };
  }
}

async function analyzeFile(projectId, filePath, address) {
  const meta = await projectMeta(projectId);
  const sourceDir = path.join(PROJECTS_DIR, projectId, "source");
  const abs = path.join(sourceDir, filePath);
  if (!abs.startsWith(sourceDir)) throw new Error("Bad path");
  if (!isTextFile(filePath)) throw new Error("MIR only analyzes text/code files");

  const content = await fs.readFile(abs, "utf8");
  const engine = new MorphEngine.MorphMemoryEngine();
  const artifact = {
    id: `artifact_${sha(projectId + ":" + filePath).slice(0, 16)}`,
    originalName: path.basename(filePath),
    originalContent: content,
    metadata: { path: filePath, projectId, size: content.length, address: address || meta.address || null, uploadedAt: new Date().toISOString() }
  };
  const analyzed = await engine.analyzeArtifact(artifact);
  if (engine.rememberArtifact) await engine.rememberArtifact(analyzed);
  return { engine, analyzed, content };
}

function runCommand(cmd, args, cwd, timeoutMs) {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, { cwd, shell: true, env: { ...process.env, CI: "true" } });
    let stdout = "", stderr = "";
    let killed = false;
    const timer = setTimeout(() => { killed = true; child.kill("SIGKILL"); }, timeoutMs);
    child.stdout.on("data", d => stdout += d.toString());
    child.stderr.on("data", d => stderr += d.toString());
    child.on("close", code => {
      clearTimeout(timer);
      resolve({ code, stdout: stdout.slice(-20000), stderr: stderr.slice(-20000), killed });
    });
  });
}

async function buildProject(id) {
  if (!ALLOW_BUILDS) throw new Error("Builds are disabled by ALLOW_BUILDS=false");
  const meta = await projectMeta(id);
  const sourceDir = path.join(PROJECTS_DIR, id, "source");
  const pkgPath = path.join(sourceDir, "package.json");
  if (!(await exists(pkgPath))) throw new Error("No package.json found. Static projects do not need build.");

  meta.status = "building";
  meta.buildLog = "";
  await saveMeta(meta);

  const install = await runCommand("npm", ["install", "--omit=optional"], sourceDir, BUILD_TIMEOUT_MS);
  const pkg = await readJSON(pkgPath, {});
  let build = { code: 0, stdout: "", stderr: "", killed: false };
  if (pkg?.scripts?.build) build = await runCommand("npm", ["run", "build"], sourceDir, BUILD_TIMEOUT_MS);
  else build = { code: 0, stdout: "No build script. Skipped build.\n", stderr: "", killed: false };

  const buildOutput = await findBuildOutput(sourceDir);
  const files = await walk(sourceDir);
  const outputFiles = buildOutput ? await walk(path.join(sourceDir, buildOutput)) : [];
  const entrypoints = buildOutput ? detectEntrypoints(outputFiles) : detectEntrypoints(files);

  meta.status = build.code === 0 && install.code === 0 ? "built" : "build_failed";
  meta.buildOutput = buildOutput;
  meta.files = files;
  meta.entrypoints = entrypoints;
  meta.selectedEntrypoint = entrypoints[0] || meta.selectedEntrypoint;
  meta.buildLog = ["## npm install", install.stdout, install.stderr, "## npm run build", build.stdout, build.stderr, build.killed ? "BUILD KILLED BY TIMEOUT" : ""].join("\n").slice(-50000);
  await saveMeta(meta);
  return meta;
}


function requireSupabase() {
  if (!supabase) {
    throw new Error("Supabase client is not configured. Set SUPABASE_SERVICE_ROLE_KEY or SUPABASE_ANON_KEY.");
  }
  return supabase;
}

async function selectAll(table, limit = 100) {
  const sb = requireSupabase();
  const { data, error } = await sb.from(table).select("*").limit(limit);
  if (error) throw error;
  return data || [];
}

async function insertRow(table, payload) {
  const sb = requireSupabase();
  const { data, error } = await sb.from(table).insert(payload).select("*").single();
  if (error) throw error;
  return data;
}

async function getOSState() {
  const [apps, agents, systemNodes, fieldSnapshots, memories, traversals] = await Promise.all([
    selectAll("apps", 100),
    selectAll("agents", 100),
    selectAll("system_nodes", 250),
    selectAll("field_snapshots", 100),
    selectAll("memories", 100),
    selectAll("agent_traversals", 100)
  ]);
  return { apps, agents, systemNodes, fieldSnapshots, memories, traversals };
}

app.get("/api/health", (req, res) => res.json({ ok: true, name: "Cynthia Render Engine", allowBuilds: ALLOW_BUILDS, morphEngine: true }));


app.get("/api/os/state", async (req, res) => {
  try {
    res.json({ ok: true, state: await getOSState() });
  } catch (error) {
    res.status(500).json({ ok: false, error: String(error.message || error) });
  }
});

app.get("/api/apps", async (req, res) => {
  try {
    res.json({ ok: true, apps: await selectAll("apps", Number(req.query.limit || 100)) });
  } catch (error) {
    res.status(500).json({ ok: false, error: String(error.message || error) });
  }
});

app.get("/api/agents", async (req, res) => {
  try {
    res.json({ ok: true, agents: await selectAll("agents", Number(req.query.limit || 100)) });
  } catch (error) {
    res.status(500).json({ ok: false, error: String(error.message || error) });
  }
});

app.post("/api/mcp/tool-call", async (req, res) => {
  try {
    const row = await insertRow("mcp_tool_calls", {
      session_id: req.body.session_id || req.body.sessionId || null,
      tool_name: req.body.tool_name || req.body.toolName || "unknown",
      input: req.body.input || {},
      output: req.body.output || {},
      status: req.body.status || "ok",
      error: req.body.error || null
    });
    res.json({ ok: true, toolCall: row });
  } catch (error) {
    res.status(500).json({ ok: false, error: String(error.message || error) });
  }
});

app.post("/api/sentence-state", async (req, res) => {
  try {
    const row = await insertRow("sentence_states", {
      artifact_id: req.body.artifact_id || req.body.artifactId || null,
      node_id: req.body.node_id || req.body.nodeId || null,
      address_id: req.body.address_id || req.body.addressId || null,
      sentence: req.body.sentence || null,
      state_type: req.body.state_type || req.body.stateType || "observation",
      dimension: req.body.dimension || null,
      payload: req.body.payload || {}
    });
    res.json({ ok: true, sentenceState: row });
  } catch (error) {
    res.status(500).json({ ok: false, error: String(error.message || error) });
  }
});

app.post("/api/morph-event", async (req, res) => {
  try {
    const row = await insertRow("morph_events", {
      repo: req.body.repo || "cynthia-render-engine",
      generation: req.body.generation || null,
      coherence: req.body.coherence || null,
      gates: req.body.gates || {},
      state: req.body.state || req.body.payload || {}
    });
    res.json({ ok: true, morphEvent: row });
  } catch (error) {
    res.status(500).json({ ok: false, error: String(error.message || error) });
  }
});



app.get("/api/projects", async (req, res) => {
  const ids = await fs.readdir(PROJECTS_DIR).catch(() => []);
  const metas = [];
  for (const id of ids) {
    const meta = await readJSON(path.join(PROJECTS_DIR, id, "project.json"));
    if (meta) metas.push(meta);
  }
  metas.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  res.json({ ok: true, projects: metas });
});

app.post("/api/projects", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) throw new Error("Upload a zip or a file");
    const id = nanoid(10);
    const projectDir = path.join(PROJECTS_DIR, id);
    const sourceDir = path.join(projectDir, "source");
    await fs.mkdir(sourceDir, { recursive: true });

    const originalName = req.file.originalname || "upload";
    const isZip = /\.zip$/i.test(originalName) || req.file.mimetype?.includes("zip");

    if (isZip) {
      const zip = new AdmZip(req.file.buffer);
      for (const entry of zip.getEntries()) {
        if (entry.isDirectory) continue;
        const rel = safeRel(entry.entryName);
        if (!rel) continue;
        const dest = path.join(sourceDir, rel);
        if (!dest.startsWith(sourceDir)) continue;
        await fs.mkdir(path.dirname(dest), { recursive: true });
        await fs.writeFile(dest, entry.getData());
      }
    } else {
      const rel = safeRel(originalName) || "upload.txt";
      await fs.writeFile(path.join(sourceDir, rel), req.file.buffer);
    }

    const files = await walk(sourceDir);
    const entrypoints = detectEntrypoints(files);
    const pkg = await readJSON(path.join(sourceDir, "package.json"), null);
    const address = req.body.address ? JSON.parse(req.body.address) : null;

    const meta = {
      id, title: originalName, sourceKind: isZip ? "zip" : "file",
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
      status: pkg ? "needs_build_or_static_check" : "mounted_static",
      address, hasPackageJson: !!pkg, packageManager: pkg ? "npm" : null,
      buildOutput: null, entrypoints, selectedEntrypoint: entrypoints[0] || null,
      files, notes: [], buildLog: "", supabase: []
    };
    await saveMeta(meta);

    let count = 0;
    for (const f of files) {
      if (count >= 40) break;
      if (!f.text || f.size > 1_500_000) continue;
      const content = await fs.readFile(path.join(sourceDir, f.path), "utf8");
      meta.supabase.push(await ingestToSupabase(path.basename(f.path), content, `render-engine:${originalName}`, address));
      count++;
    }
    await saveMeta(meta);

    res.json({ ok: true, project: meta });
  } catch (error) {
    res.status(500).json({ ok: false, error: String(error.message || error) });
  }
});

app.get("/api/projects/:id", async (req, res) => {
  try { res.json({ ok: true, project: await projectMeta(req.params.id) }); }
  catch (e) { res.status(404).json({ ok: false, error: e.message }); }
});

app.post("/api/projects/:id/build", async (req, res) => {
  try { res.json({ ok: true, project: await buildProject(req.params.id) }); }
  catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post("/api/projects/:id/entrypoint", async (req, res) => {
  try {
    const meta = await projectMeta(req.params.id);
    const ep = safeRel(req.body.entrypoint);
    if (!ep) throw new Error("Bad entrypoint");
    meta.selectedEntrypoint = ep;
    await saveMeta(meta);
    res.json({ ok: true, project: meta });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post("/api/projects/:id/morph", async (req, res) => {
  try {
    const mode = req.body.mode || "exact";
    const filePath = safeRel(req.body.path || "");
    if (!filePath) throw new Error("Bad file path");
    const { engine, analyzed } = await analyzeFile(req.params.id, filePath, req.body.address);
    const result = await engine.regenerateArtifact(analyzed, { address: req.body.address }, mode);
    res.json({ ok: true, file: filePath, mode, understanding: analyzed.understanding, regeneration: result.regenerationResult, nodeCount: engine.getNodeCount?.() ?? null });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post("/api/projects/:id/notes", async (req, res) => {
  try {
    const meta = await projectMeta(req.params.id);
    const note = { id: nanoid(8), text: String(req.body.text || ""), target: req.body.target || meta.selectedEntrypoint || null, address: req.body.address || meta.address || null, createdAt: new Date().toISOString() };
    meta.notes.unshift(note);
    await saveMeta(meta);
    await ingestToSupabase(`note-${note.id}.json`, JSON.stringify(note, null, 2), "render-engine-note", note.address);
    res.json({ ok: true, note, project: meta });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.get("/play/:id", async (req, res) => {
  try {
    const meta = await projectMeta(req.params.id);
    let base = path.join(PROJECTS_DIR, req.params.id, "source");
    let entry = meta.selectedEntrypoint || meta.entrypoints?.[0];

    if (meta.buildOutput) {
      base = path.join(base, meta.buildOutput);
      entry = entry || "index.html";
    }

    if (!entry) return res.status(404).send("No playable HTML entrypoint found. Build may be required.");
    const file = path.join(base, entry);
    if (!file.startsWith(base)) return res.status(400).send("Bad entrypoint");
    res.sendFile(file);
  } catch (e) {
    res.status(500).send(e.message);
  }
});

app.use("/project/:id/files", async (req, res, next) => {
  try {
    const meta = await projectMeta(req.params.id);
    let base = path.join(PROJECTS_DIR, req.params.id, "source");
    if (meta.buildOutput && req.query.built === "1") base = path.join(base, meta.buildOutput);
    express.static(base)(req, res, next);
  } catch (e) { next(e); }
});

app.listen(PORT, () => console.log(`Cynthia Render Engine listening on :${PORT}`));
