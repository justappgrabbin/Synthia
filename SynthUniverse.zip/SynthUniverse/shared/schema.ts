import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, jsonb, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Core system schemas
export const coreValues = pgTable("core_values", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  mind: real("mind").notNull(),
  heart: real("heart").notNull(),
  body: real("body").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const nineProjections = pgTable("nine_projections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  coreValuesId: varchar("core_values_id").references(() => coreValues.id),
  mindPersonal: real("mind_personal").notNull(),
  mindInterpersonal: real("mind_interpersonal").notNull(),
  mindTranspersonal: real("mind_transpersonal").notNull(),
  heartPersonal: real("heart_personal").notNull(),
  heartInterpersonal: real("heart_interpersonal").notNull(),
  heartTranspersonal: real("heart_transpersonal").notNull(),
  bodyPersonal: real("body_personal").notNull(),
  bodyInterpersonal: real("body_interpersonal").notNull(),
  bodyTranspersonal: real("body_transpersonal").notNull(),
});

export const skills = pgTable("skills", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  skillId: integer("skill_id").notNull(), // 1-64
  name: text("name").notNull(),
  node: text("node").notNull(), // Mind, Heart, Body
  level: integer("level").default(1).notNull(),
  xp: integer("xp").default(0).notNull(),
  active: boolean("active").default(true).notNull(),
  stats: jsonb("stats").notNull(), // COPNHFE stats
});

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  requiredAxes: jsonb("required_axes").notNull(),
  ringBias: jsonb("ring_bias"),
  gateAffinity: jsonb("gate_affinity"),
  sunGateBoost: boolean("sun_gate_boost").default(false),
  minSprites: integer("min_sprites").default(1),
  maxSprites: integer("max_sprites").default(3),
  minTeamLevel: integer("min_team_level").default(1),
  difficulty: integer("difficulty").default(3),
  tier: text("tier"),
  fit: integer("fit"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const jobs = pgTable("jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // module, city, skill
  priority: real("priority").default(1).notNull(),
  requires: jsonb("requires").notNull(),
  dependencies: jsonb("dependencies").default([]),
  status: text("status").default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const recipes = pgTable("recipes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  recipeId: text("recipe_id").notNull().unique(),
  label: text("label").notNull(),
  gates: jsonb("gates").notNull(), // array of gate numbers
  reward: jsonb("reward").notNull(), // {xp: number, shards: number}
});

export const modules = pgTable("modules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  code: text("code").notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const events = pgTable("events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  kind: text("kind").notNull(),
  data: jsonb("data").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Insert schemas
export const insertCoreValuesSchema = createInsertSchema(coreValues).omit({
  id: true,
  timestamp: true,
});

export const insertNineProjectionsSchema = createInsertSchema(nineProjections).omit({
  id: true,
});

export const insertSkillSchema = createInsertSchema(skills).omit({
  id: true,
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
});

export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  createdAt: true,
});

export const insertRecipeSchema = createInsertSchema(recipes).omit({
  id: true,
});

export const insertModuleSchema = createInsertSchema(modules).omit({
  id: true,
  createdAt: true,
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  timestamp: true,
});

// Types
export type CoreValues = typeof coreValues.$inferSelect;
export type InsertCoreValues = z.infer<typeof insertCoreValuesSchema>;

export type NineProjections = typeof nineProjections.$inferSelect;
export type InsertNineProjections = z.infer<typeof insertNineProjectionsSchema>;

export type Skill = typeof skills.$inferSelect;
export type InsertSkill = z.infer<typeof insertSkillSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;

export type Recipe = typeof recipes.$inferSelect;
export type InsertRecipe = z.infer<typeof insertRecipeSchema>;

export type Module = typeof modules.$inferSelect;
export type InsertModule = z.infer<typeof insertModuleSchema>;

export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;

// Additional types for API responses
export interface SystemStatus {
  websocketConnected: boolean;
  ollamaReady: boolean;
  activeModules: number;
  totalSkills: number;
  pendingJobs: number;
  uptime: string;
}

export interface CollapseSystem {
  core: CoreValues;
  projections: NineProjections;
  mode: {
    tone: string;
    focus: string;
    dominant: string;
  };
}

export interface TaskFitResult {
  fit: number;
  tier: string;
}

export interface SparkleElementCheck {
  element: string | null;
  label?: string;
  reward?: { xp: number; shards: number };
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  model?: string;
  timestamp: Date;
}
