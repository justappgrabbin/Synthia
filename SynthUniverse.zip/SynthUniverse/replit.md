# SYNTHAI - You-N-I-Verse Control Center

## Overview

SYNTHAI is a sophisticated personal development and cognitive enhancement platform built around a multi-dimensional "collapse system" architecture. The application integrates personality analysis, skill development, task management, and AI-powered coaching into a unified dashboard experience. The system models human development through three core nodes (Mind, Heart, Body) with nine projections across personal, interpersonal, and transpersonal dimensions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript running on Vite for development
- **UI Library**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS
- **State Management**: TanStack Query for server state with custom WebSocket integration
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with custom CSS variables for theming, including specialized gradient classes for Mind/Heart/Body visualization

### Backend Architecture
- **Runtime**: Node.js with Express.js serving both API and static assets
- **Database Layer**: Drizzle ORM with PostgreSQL (configured for Neon Database serverless)
- **Real-time Communication**: WebSocket server for live system updates and status broadcasting
- **Service Architecture**: Modular service layer with distinct domains:
  - Collapse System: Core personality analysis and projection calculations
  - Cities Engine: Skill management and availability calculations
  - TaskFit Builder: Task creation and job delegation system
  - Sparkle System: Recipe-based achievement and reward mechanics
  - Builder Service: Module generation and integration
  - Coach Service: AI-powered guidance and feedback

### Data Storage Solutions
- **Primary Database**: PostgreSQL with Drizzle schema definitions
- **Schema Design**: Normalized tables for core values, projections, skills, tasks, jobs, recipes, modules, and events
- **In-Memory Storage**: Mock storage implementation for development with interface-driven design for production database swapping

### Authentication and Authorization
- Session-based authentication using connect-pg-simple for PostgreSQL session storage
- No explicit auth routes visible, suggesting development/demo mode or simplified access control

### Core System Design Patterns

#### Collapse System
Mathematical model that processes personality data through a "collapse" algorithm to generate core values (Mind, Heart, Body) and nine-dimensional projections. Uses weighted aspect analysis and gate-based calculations for personalized insights.

#### Cities Engine
Skill availability system that maps core values to three virtual "cities" (Mind, Heart, Body), each containing 64 skills and up to 10 agents. Skills have levels, XP, and COPNHFE (personality factor) statistics that determine availability and effectiveness.

#### TaskFit Algorithm
Scoring system that evaluates how well teams of "sprites" (skill agents) match task requirements based on COPNHFE compatibility, ring bias, gate affinity, and team composition.

#### Sparkle System
Achievement engine using recipe-based combinations of active "gates" (personality traits) to unlock rewards and progression elements.

## External Dependencies

### Core Frontend Dependencies
- **React Ecosystem**: React 18, TanStack Query v5, React Hook Form with Zod validation
- **UI Components**: Radix UI primitives for accessible component foundation
- **Styling**: Tailwind CSS with PostCSS processing
- **Development**: Vite with TypeScript, ESBuild for production builds

### Backend Dependencies
- **Server Framework**: Express.js with WebSocket support via 'ws' library
- **Database**: Drizzle ORM with @neondatabase/serverless for PostgreSQL connectivity
- **Session Management**: connect-pg-simple for PostgreSQL-backed sessions
- **Utilities**: date-fns for date manipulation, nanoid for ID generation

### Development and Build Tools
- **TypeScript**: Full type safety across frontend and backend with shared schema types
- **Build System**: Vite for frontend, ESBuild for backend bundling
- **Database Management**: Drizzle Kit for schema migrations and database operations

### Optional Integrations
- **AI Services**: Ollama integration for LLM-powered coaching and chat functionality (configurable via OLLAMA_URL environment variable)
- **Replit Platform**: Specific integrations for Replit development environment including dev banner and cartographer plugin

The architecture demonstrates a clear separation of concerns with shared TypeScript interfaces, enabling type-safe communication between frontend and backend while maintaining flexibility for external AI service integration.