import http from "http";
import fs from "fs";
import path from "path";
import url from "url";

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const root = path.join(__dirname, "..");

const state = {
  // simple memory state
  cities: seedCities(),
  jobs: []
};

function seedCities() {
  const mk = node => ({
    node,
    skills: Array.from({length:64}, (_,i)=>({
      id: i+1,
      name: `${node}-Skill-${i+1}`,
      level: 1,
      xp: 0,
      active: (i % 3) !== 0
    }))
  });
  return { Mind: mk("Mind"), Heart: mk("Heart"), Body: mk("Body") };
}

function clamp(v, lo=-1, hi=1){ return Math.max(lo, Math.min(hi, v)); }
function collapseCore(parser) {
  // tiny fake collapse based on optional parser; safe defaults
  const m = clamp((parser?.aspects?.mind ?? 0.2)*2-1);
  const h = clamp((parser?.aspects?.heart ?? 0.4)*2-1);
  const b = clamp((parser?.aspects?.body ?? 0.3)*2-1);
  return { mind:m, heart:h, body:b };
}
function projectNine(core, f=0.9){
  const c = core;
  const bleed=(a,b)=>clamp(a*f+b*(1-f));
  return {
    "Mind-Personal": bleed(c.mind, c.body),
    "Mind-Interpersonal": bleed(c.mind, c.heart),
    "Mind-Transpersonal": bleed(c.mind, (c.heart+c.body)/2),
    "Heart-Personal": bleed(c.heart, c.body),
    "Heart-Interpersonal": bleed(c.heart, c.mind),
    "Heart-Transpersonal": bleed(c.heart, (c.mind+c.body)/2),
    "Body-Personal": bleed(c.body, c.mind),
    "Body-Interpersonal": bleed(c.body, c.heart),
    "Body-Transpersonal": bleed(c.body, (c.mind+c.heart)/2)
  };
}
function modeFrom(core){
  const arr = [["mind",core.mind],["heart",core.heart],["body",core.body]].sort((a,b)=>b[1]-a[1]);
  const dom = arr[0][0];
  if (dom==="heart") return { tone:"empathetic", focus:"connection", dominant:"heart" };
  if (dom==="mind") return { tone:"analytical", focus:"problem-solving", dominant:"mind" };
  return { tone:"practical", focus:"execution", dominant:"body" };
}

function sendJSON(res, code, obj){
  res.writeHead(code, {
    "Content-Type":"application/json",
    "Access-Control-Allow-Origin":"*"
  });
  res.end(JSON.stringify(obj));
}

function readBody(req){
  return new Promise(resolve=>{
    let b=""; req.on("data",d=>b+=d); req.on("end",()=>{
      try{ resolve(JSON.parse(b||"{}")); }catch{ resolve({}); }
    });
  });
}

function listAvailable(core){
  // availability based on node strength
  const clip = v => Math.max(0, Math.min(1, (v+1)/2));
  const avail = { Mind: clip(core.mind), Heart: clip(core.heart), Body: clip(core.body) };
  const out = {};
  for (const node of ["Mind","Heart","Body"]) {
    const mult = avail[node];
    out[node] = state.cities[node].skills
      .filter(s=>s.active)
      .map(s=>({ ...s, availability: Math.round(mult * (50 + s.level*10)) }))
      .sort((a,b)=>b.availability-a.availability)
      .slice(0,10);
  }
  return out;
}

function applySkill({node, skillId, alignment=0.9}){
  const skills = state.cities[node]?.skills || [];
  const s = skills.find(x=>x.id===Number(skillId));
  if (!s || !s.active) return { ok:false, reason:"inactive or missing" };
  // lightweight success score using level & randomness scaled by alignment
  const base = 0.3 + s.level*0.05;
  const score = Math.max(0, Math.min(1, base*alignment + Math.random()*0.4));
  const win = score >= 0.42;
  s.xp += win ? 10 : 2;
  if (s.xp >= 50 + s.level*25){ s.level++; s.xp = 0; }
  if (!win && alignment < 0.4) s.active = Math.random() > 0.5 ? false : s.active;
  return { ok:true, win, score:+score.toFixed(3), level:s.level, active:s.active };
}

const server = http.createServer(async (req, res) => {
  // CORS preflight
  if (req.method==="OPTIONS"){
    res.writeHead(204, {
      "Access-Control-Allow-Origin":"*",
      "Access-Control-Allow-Methods":"GET,POST,OPTIONS",
      "Access-Control-Allow-Headers":"Content-Type"
    });
    return res.end();
  }

  const parsed = new URL(req.url, "http://localhost");

  // API routes
  if (req.method==="GET" && parsed.pathname==="/health"){
    return sendJSON(res, 200, { ok:true });
  }

  if (req.method==="POST" && parsed.pathname==="/chat"){
    const body = await readBody(req);
    const core = collapseCore(body.parser || { aspects: { mind:0.4, heart:0.35, body:0.25 }});
    const nine = projectNine(core);
    const mode = modeFrom(core);
    // simple inline reply; you can swap for Ollama later
    const prompt = (body.prompt||"").trim() || "Hello";
    const reply = (mode.dominant==="heart")
      ? `💜 (${mode.tone}) I hear you: "${prompt}". One kind step you can take today?`
      : (mode.dominant==="mind")
      ? `🧠 (${mode.tone}) For "${prompt}", let's outline next steps.`
      : `🛠️ (${mode.tone}) Let's execute. "${prompt}" → first action queued.`;
    return sendJSON(res, 200, { reply, core, projection:nine, mode });
  }

  if (req.method==="POST" && parsed.pathname==="/builder/jobs"){
    const body = await readBody(req);
    const job = { t: Date.now(), type: body.kind||"module", name: body.detail||"unspecified", requires: ["code","tests"] };
    state.jobs.push(job);
    return sendJSON(res, 200, { ok:true, job });
  }

  if (req.method==="GET" && parsed.pathname==="/builder/jobs"){
    return sendJSON(res, 200, state.jobs.slice(-200));
  }

  if (req.method==="POST" && parsed.pathname==="/builder/integrate"){
    const body = await readBody(req);
    const moduleName = (body.moduleName||"mod").replace(/[^\w\-]+/g,"_");
    const code = body.code || "export default () => ({ok:true});\n";
    const dir = path.join(root, "backend", "modules");
    fs.mkdirSync(dir, { recursive:true });
    fs.writeFileSync(path.join(dir, moduleName+".js"), code, "utf8");
    return sendJSON(res, 200, { ok:true, module: moduleName });
  }

  if (req.method==="GET" && parsed.pathname==="/cities"){
    return sendJSON(res, 200, state.cities);
  }

  if (req.method==="POST" && parsed.pathname==="/cities/available"){
    const body = await readBody(req);
    const core = body.core || { mind:0, heart:0, body:0 };
    return sendJSON(res, 200, { list: listAvailable(core) });
  }

  if (req.method==="POST" && parsed.pathname==="/cities/apply"){
    const body = await readBody(req);
    const node = (body.node||"Mind");
    const result = applySkill({ node, skillId: body.skillId, alignment: body.alignment ?? 0.9 });
    return sendJSON(res, 200, result);
  }

  // Static files (frontend)
  let filePath = path.join(root, "public", parsed.pathname === "/" ? "index.html" : parsed.pathname.replace(/^\/+/,""));
  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()){
    const ext = path.extname(filePath).toLowerCase();
    const type = ext === ".css" ? "text/css" : ext === ".js" ? "application/javascript" : "text/html";
    res.writeHead(200, { "Content-Type": type });
    fs.createReadStream(filePath).pipe(res); return;
  }

  // 404
  return sendJSON(res, 404, { error:"not found" });
});

const PORT = process.env.PORT || 8787;
server.listen(PORT, ()=>console.log("Cynthia DIY server on", PORT));