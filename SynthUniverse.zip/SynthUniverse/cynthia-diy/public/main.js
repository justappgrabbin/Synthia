const $ = s => document.querySelector(s);
const API = p => p.startsWith("/") ? p : ("/"+p);

// tray
$("#openTray").onclick = ()=>$("#tray").classList.add("open");
$("#trayClose").onclick = ()=>$("#tray").classList.remove("open");

// bottom nav
$("#navHome").onclick = ()=>window.scrollTo({top:0,behavior:"smooth"});
$("#navCities").onclick = ()=>document.getElementById("citiesCard").scrollIntoView({behavior:"smooth"});
$("#navBuilder").onclick = ()=>$("#tray").classList.add("open");
$("#navChat").onclick = ()=>$("#chatDock").classList.remove("hidden");

// chat
const dock = $("#chatDock");
$("#openChat").onclick = ()=>dock.classList.remove("hidden");
$("#chatToggle").onclick = ()=>dock.classList.toggle("hidden");
$("#chatClose").onclick = ()=>dock.classList.add("hidden");

function pushChat(who, txt){
  const div = document.createElement("div");
  div.className = "chat-msg"+(who==="me"?" me":"");
  div.textContent = txt;
  $("#chatLog").appendChild(div);
  $("#chatLog").scrollTop = $("#chatLog").scrollHeight;
}

$("#chatSend").onclick = async ()=>{
  const txt = $("#chatText").value.trim();
  if(!txt) return;
  pushChat("me", txt);
  $("#chatText").value = "";
  // keep a simple parser knob; later you can wire real parser
  const parser = { aspects:{ mind:0.45, heart:0.35, body:0.2 } };
  const r = await fetch(API("chat"), { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ prompt: txt, parser }) });
  const j = await r.json();
  pushChat("her", j.reply || "(no reply)");
};

// builder quick actions
$("#addJobBtn").onclick = async ()=>{
  const r = await fetch(API("builder/jobs"), { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ kind:"city", detail:"MindCity" }) });
  const j = await r.json();
  await loadJobs();
};
$("#loadJobsBtn").onclick = ()=>loadJobs();

async function loadJobs(){
  const r = await fetch(API("builder/jobs"));
  const j = await r.json();
  const ul = $("#jobs"); ul.innerHTML = "";
  j.slice(-20).reverse().forEach(job=>{
    const li = document.createElement("li");
    li.textContent = `${new Date(job.t).toLocaleTimeString()} • ${job.type}: ${job.name}`;
    ul.appendChild(li);
  });
}
loadJobs();

// cities
$("#openCities").onclick = ()=>document.getElementById("citiesCard").scrollIntoView({behavior:"smooth"});
$("#refreshAvail").onclick = loadAvail;

async function loadAvail(){
  const core = { mind: 0.4, heart: 0.2, body: 0.1 }; // demo; real core comes from /chat if you want
  const r = await fetch(API("cities/available"), { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ core }) });
  const j = await r.json();
  const box = $("#avail"); box.innerHTML = "";
  Object.entries(j.list).forEach(([node, skills])=>{
    const sec = document.createElement("div");
    sec.className = "skill-group";
    const title = document.createElement("h3"); title.textContent = node; sec.appendChild(title);
    skills.forEach(s=>{
      const row = document.createElement("div"); row.className = "skill-line";
      row.innerHTML = `<div><strong>${s.name}</strong></div>
        <div class="meta">Avail ${s.availability}% • L${s.level} • ${s.active?'active':'inactive'}</div>`;
      row.onclick = ()=>{
        $("#nodeSel").value = node;
        $("#skillId").value = s.id;
      };
      sec.appendChild(row);
    });
    box.appendChild(sec);
  });
}

$("#applySkill").onclick = async ()=>{
  const node = $("#nodeSel").value;
  const skillId = Number($("#skillId").value||"0");
  if (!skillId) { $("#applyOut").textContent = "Enter a Skill ID 1–64"; return; }
  const r = await fetch(API("cities/apply"), { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ node, skillId, alignment:0.9 }) });
  const j = await r.json();
  $("#applyOut").textContent = j.ok ? `Result: ${j.win?'Win':'Loss'} • Score ${j.score} • Level ${j.level} • Active ${j.active}` : j.reason;
  loadAvail();
};

// boot
(async function init(){
  // load initial data
  await loadAvail();
  
  // Add welcome message if no server response
  const testServer = async () => {
    try {
      const response = await fetch(API("health"));
      if (!response.ok) throw new Error('Server not available');
    } catch (error) {
      console.log('Server not available, using offline mode');
      pushChat("system", "⚠️ Server offline - using demo mode. You can still explore the interface!");
    }
  };
  
  await testServer();
})();