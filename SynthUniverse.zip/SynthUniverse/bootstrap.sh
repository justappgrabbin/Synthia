#!/usr/bin/env bash
set -euo pipefail

APP="cynthia-phase0_5"
mkdir -p "$APP"/{backend,backend/cities,backend/modules,frontend,frontend/game,data}
cd "$APP"

# ---------------- package.json ----------------
cat > package.json <<'EOF'
{
  "name": "cynthia-phase0-5",
  "version": "0.5.0",
  "type": "module",
  "scripts": {
    "start": "node backend/server.js"
  },
  "dependencies": {
    "ws": "^8.17.0"
  }
}
EOF

# ---------------- backend/config.json ----------------
cat > backend/config.json <<'EOF'
{
  "port": 8787,
  "ollama": {
    "url": "",
    "models": {
      "Mind": "tinyllama",
      "Heart": "mistral",
      "Body": "phi"
    },
    "options": { "temperature": 0.6, "num_predict": 160, "top_p": 0.9, "repeat_penalty": 1.08 }
  }
}
EOF

# ---------------- backend/ollama.js ----------------
cat > backend/ollama.js <<'EOF'
import http from 'http';
const agent = new http.Agent({ maxSockets: 10 });

export async function callOllama({ url, model, prompt, options }) {
  const endpoint = (process.env.OLLAMA_URL || url || '').trim();
  if (!endpoint) {
    return { ok: false, text: "(LLM offline — set OLLAMA_URL). Fallback: core-only reply." };
  }
  try {
    const res = await fetch(`${endpoint.replace(/\/$/, '')}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, prompt, options: options || { temperature: 0.6, top_p: 0.9 } }),
      agent
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const lines = [];
    for await (const chunk of res.body) lines.push(Buffer.from(chunk).toString('utf8'));
    const last = lines.join('').trim().split('\n').filter(Boolean).pop();
    const obj = JSON.parse(last);
    return { ok: true, text: obj.response || '' };
  } catch (e) {
    return { ok: false, text: `(LLM error: ${e.message}). Fallback reply.` };
  }
}
EOF

# ---------------- backend/collapse.js ----------------
cat > backend/collapse.js <<'EOF'
export function clamp(x, lo=-1, hi=1){ return Math.max(lo, Math.min(hi, x)); }

export function collapseCore(parser) {
  // lightweight, deterministic-ish core from parser hints
  const a = Number(parser?.aspects?.["Sun conjunct Mercury"]?.weight ?? 0);
  const b = Number(parser?.aspects?.["Mars sextile Saturn"]?.weight ?? 0);
  const sun = Number(parser?.gates?.sunGate ?? 16);
  let mind = clamp((a*0.7 + b*0.2) * 2 - 1);
  let heart = clamp((a*0.2 + b*0.5) * 2 - 1);
  let body = clamp((a*0.1 + b*0.3) * 2 - 1);
  const mod = sun % 3;
  if (mod===0) mind = clamp(mind + 0.06);
  if (mod===1) heart = clamp(heart + 0.06);
  if (mod===2) body = clamp(body + 0.06);
  return { mind, heart, body };
}

export function projectNine(core, f=0.9) {
  const {mind,heart,body} = core;
  const bleed = (a,b)=> clamp(a*f + b*(1-f));
  return {
    "Mind-Personal": bleed(mind, body),
    "Mind-Interpersonal": bleed(mind, heart),
    "Mind-Transpersonal": bleed(mind, (heart+body)/2),
    "Heart-Personal": bleed(heart, body),
    "Heart-Interpersonal": bleed(heart, mind),
    "Heart-Transpersonal": bleed(heart, (mind+body)/2),
    "Body-Personal": bleed(body, mind),
    "Body-Interpersonal": bleed(body, heart),
    "Body-Transpersonal": bleed(body, (mind+heart)/2)
  };
}

export function modeFrom(core){
  const ranked = [['mind',core.mind],['heart',core.heart],['body',core.body]].sort((a,b)=>b[1]-a[1]);
  const dom = ranked[0][0];
  if (dom==='heart') return { tone:'empathetic', focus:'connection', dominant:'Heart' };
  if (dom==='mind') return { tone:'analytical', focus:'problem-solving', dominant:'Mind' };
  return { tone:'practical', focus:'execution', dominant:'Body' };
}

export function buildPrompt(input, mode){
  return `You are Cynthia. Tone: ${mode.tone}. Focus: ${mode.focus}.
Reply briefly, helpfully.

User: ${input}
Cynthia:`;
}
EOF

# ---------------- backend/parserStub.js ----------------
cat > backend/parserStub.js <<'EOF'
export function fakeParserSeed() {
  const rnd = (n) => Math.max(0, Math.min(1, (Math.sin(Date.now()/10000 + n) * 0.5 + 0.5)));
  const pickGates = () => { const out = new Set(); while (out.size<3) out.add(1+Math.floor(Math.random()*64)); return [...out]; };
  return {
    aspects: {
      "Sun conjunct Mercury": { weight: rnd(1) },
      "Mars sextile Saturn": { weight: rnd(2) }
    },
    gates: { sunGate: 16, active: pickGates() },
    skills: { Mind: 3, Heart: 2, Body: 2 }
  };
}
EOF

# ---------------- backend/builder.js ----------------
cat > backend/builder.js <<'EOF'
import fs from 'fs';
import path from 'path';

const DATA = path.join(process.cwd(), 'data', 'lab');
const TODO = path.join(DATA, 'todos.jsonl');
const JOBS = path.join(DATA, 'jobs.jsonl');
let todoCache = [], jobCache = [];

function ensure(){ fs.mkdirSync(DATA, { recursive:true }); }
function syncToDisk(){
  if (todoCache.length){ fs.appendFileSync(TODO, todoCache.map(r=>JSON.stringify(r)+'\n').join('')); todoCache=[]; }
  if (jobCache.length){ fs.appendFileSync(JOBS, jobCache.map(r=>JSON.stringify(r)+'\n').join('')); jobCache=[]; }
}
setInterval(syncToDisk, 5*60*1000);
process.on('SIGINT', ()=>{ syncToDisk(); process.exit(); });

export function builderNeed(kind, detail){
  ensure(); const rec = { t: Date.now(), kind, detail }; todoCache.push(rec); return rec;
}
export function generateJobSpec(kind, detail, dependencies=[]){
  ensure();
  const templates = {
    module:{ type:'module', priority:1, requires:['code','tests'] },
    city:{ type:'city', priority:2, requires:['agents','skills','config'] },
    skill:{ type:'skill', priority:1.5, requires:['logic','training'] }
  };
  const spec = { t: Date.now(), name: detail, ...(templates[kind]||templates.module), dependencies };
  jobCache.push(spec); return spec;
}
export function listTodos(limit=200){
  ensure();
  const lines = fs.existsSync(TODO)? fs.readFileSync(TODO,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse):[];
  return [...lines, ...todoCache].slice(-limit);
}
export function listJobs(limit=200){
  ensure();
  const lines = fs.existsSync(JOBS)? fs.readFileSync(JOBS,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse):[];
  return [...lines, ...jobCache].slice(-limit);
}
export async function delegateJob(jobId, agentUrl){
  const job = listJobs().find(j=>j.t===jobId); if(!job || !agentUrl) return { ok:false, error:'Invalid job or agent URL' };
  try{
    const res = await fetch(agentUrl,{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(job) });
    if(!res.ok) throw new Error(`HTTP ${res.status}`);
    const result = await res.json();
    builderNeed('delegation', `Job ${job.name} -> ${agentUrl}: ${JSON.stringify(result)}`);
    return { ok:true, result };
  }catch(e){ builderNeed('error', `Delegation failed for ${job.name}: ${e.message}`); return { ok:false, error:e.message }; }
}
export function integrateModule(moduleName, code){
  const file = path.join(process.cwd(), 'backend', 'modules', `${moduleName}.js`);
  fs.mkdirSync(path.dirname(file), { recursive:true });
  fs.writeFileSync(file, code, 'utf8');
  builderNeed('module', `Integrated ${moduleName}`);
  return { ok:true, module: moduleName };
}
EOF

# ---------------- backend/modules-loader.js ----------------
cat > backend/modules-loader.js <<'EOF'
import fs from 'fs';
import path from 'path';
const MODULES_DIR = path.join(process.cwd(), 'backend', 'modules');
export let loadedModules = {};

export function loadModules(){
  loadedModules = {};
  if(!fs.existsSync(MODULES_DIR)) return [];
  for (const file of fs.readdirSync(MODULES_DIR)){
    if (!file.endsWith('.js')) continue;
    const name = file.replace('.js','');
    try{
      const modPath = path.join(MODULES_DIR, file);
      delete import.meta?.resolve && null; // noop; keep ESM
      loadedModules[name] = (await import(`file://${modPath}`)).default ?? (await import(`file://${modPath}`));
    }catch(e){ console.error('Module load failed', name, e.message); }
  }
  return Object.keys(loadedModules);
}

export function getModule(name){ return loadedModules[name] || null; }
EOF

# ---------------- backend/taskfit.js ----------------
cat > backend/taskfit.js <<'EOF'
export function scoreTask(task, sprites, sunGate=16){
  // very lightweight "fit" score 0..100 based on COPNHFE coverage & ring bias
  const axes = (task.required_axes||[]).map(x=>({axis:x.axis||[], weight:Number(x.weight||0)}));
  const sum = (o)=>Object.values(o).reduce((m,x)=>m+Number(x||0),0);
  let team = { C:0,O:0,P:0,N:0,H:0,F:0,E:0 };
  for (const s of sprites){
    for (const k of Object.keys(team)) team[k]+=Number(s.copnhfe?.[k]||0);
  }
  const axisScore = axes.reduce((m,a)=> m + a.weight*(a.axis.reduce((acc,k)=>acc+team[k],0)/(sprites.length*100*a.axis.length||1)), 0);
  const ringBonus = sprites.some(s=>task.ring_bias?.includes(s.ring))? 0.1:0;
  const gateBonus = sprites.some(s=>task.gate_affinity?.includes(s.gate))? 0.08:0;
  const sunBonus = (task.sun_gate_boost && sprites.some(s=>s.gate===sunGate))? 0.05:0;
  const raw = Math.max(0, Math.min(1, axisScore + ringBonus + gateBonus + sunBonus));
  const fit = Math.round(raw*100);
  const tier = fit>85?'S':fit>70?'A':fit>55?'B':fit>40?'C':'D';
  return { fit, tier };
}
EOF

# ---------------- backend/sparkle.js ----------------
cat > backend/sparkle.js <<'EOF'
import fs from 'fs';
import path from 'path';
const REC = path.join(process.cwd(), 'backend', 'recipes.json');
let recipes = [];
try { recipes = JSON.parse(fs.readFileSync(REC,'utf8')); } catch { recipes = []; }

export function checkElementComplete(activeGates=[], projection={}){
  const set = new Set(activeGates);
  for (const r of recipes){
    if ((r.gates||[]).every(g=>set.has(g))) return { element:r.id, label:r.label, reward:r.reward||{xp:10, shards:1} };
  }
  return { element:null };
}

export function updateRecipes(newRecipes){
  recipes = newRecipes||[];
  fs.writeFileSync(REC, JSON.stringify(recipes,null,2));
  return { ok:true, count: recipes.length };
}
EOF

# ---------------- backend/recipes.json ----------------
cat > backend/recipes.json <<'EOF'
[
  { "id": "TrineSpark", "label": "Trine Spark", "gates": [16, 62, 48], "reward": {"xp": 12, "shards": 1} },
  { "id": "MindBloom", "label": "Mind Bloom", "gates": [24, 4, 61], "reward": {"xp": 10, "shards": 1} }
]
EOF

# ---------------- backend/cities/engine.js ----------------
cat > backend/cities/engine.js <<'EOF'
import fs from 'fs';
import path from 'path';
import { scoreTask } from '../taskfit.js';

const DB = path.join(process.cwd(), 'data', 'cities.json');
const NODES = ['Mind','Heart','Body'];
let cityCache = null;
let writeQueue = [];

function seedSkills(node){
  return Array.from({length:64},(_,i)=>({
    id:i+1, name:`${node}-Skill-${i+1}`,
    stats:{ C:30+((i*7)%70), O:30+((i*11)%70), P:30+((i*13)%70), N:30+((i*17)%70), H:30+((i*19)%70), F:30+((i*23)%70), E:30+((i*29)%70) },
    level:1, xp:0, active:(i%3)!==0
  }));
}

function load(){
  if (cityCache) return cityCache;
  if (!fs.existsSync(DB)){
    const obj = { Mind:{skills:seedSkills('Mind')}, Heart:{skills:seedSkills('Heart')}, Body:{skills:seedSkills('Body')} };
    fs.mkdirSync(path.dirname(DB), { recursive:true });
    fs.writeFileSync(DB, JSON.stringify(obj,null,2));
    cityCache = obj; return obj;
  }
  cityCache = JSON.parse(fs.readFileSync(DB,'utf8')); return cityCache;
}

function queueSave(st){
  writeQueue.push(st);
  if (writeQueue.length>100){ fs.writeFileSync(DB, JSON.stringify(writeQueue.pop(),null,2)); writeQueue=[]; }
}
setInterval(()=>{ if(writeQueue.length){ fs.writeFileSync(DB, JSON.stringify(writeQueue.pop(),null,2)); writeQueue=[]; }}, 10*60*1000);
process.on('SIGINT', ()=>{ if(writeQueue.length) fs.writeFileSync(DB, JSON.stringify(writeQueue.pop(),null,2)); process.exit(); });

export function getCities(){ return load(); }
export function getNode(node){ node=node[0].toUpperCase()+node.slice(1).toLowerCase(); return load()[node]; }
export function projectAvailability(core){ const clip=v=>Math.max(0,Math.min(1,(v+1)/2)); return { Mind:clip(core.mind||0), Heart:clip(core.heart||0), Body:clip(core.body||0) }; }
export function listAvailable(core){
  const st = load(); const avail = projectAvailability(core); const out={};
  for(const node of NODES){
    const mult = avail[node]||0;
    out[node] = st[node].skills
      .filter(s=>s.active)
      .map(s=>({ ...s, availability: Math.round(mult*(50 + s.level*10)) }))
      .sort((a,b)=>b.availability - a.availability)
      .slice(0,10);
  }
  return out;
}

export function applySkill({ node, skillId, taskVec, alignment=1.0 }){
  node=node[0].toUpperCase()+node.slice(1).toLowerCase();
  const st=load(); const s=(st[node]?.skills||[]).find(x=>x.id===Number(skillId));
  if(!s || !s.active) return { ok:false, reason:'inactive or missing' };
  const task={ title:`Apply ${s.name}`, min_sprites:1, max_sprites:1, min_team_level:s.level, difficulty:3,
    required_axes:Object.keys(taskVec||{}).map(k=>({axis:[k],weight:1/((Object.keys(taskVec||{}).length)||1)})),
    ring_bias:[node], gate_affinity:[s.id], sun_gate_boost:false };
  const sprite={ id:s.id, gate:s.id, ring:node, level:s.level, copnhfe:s.stats, positioning:'Personal', modality:'Generic' };
  const taskFit = scoreTask(task,[sprite],s.id);
  const score = (taskFit.fit/100) * alignment;
  const win = score >= 0.42;
  s.xp += win?10:2;
  if (s.xp >= 50 + s.level*25){ s.level++; s.xp = 0; }
  if (!win && alignment<0.4) s.active = Math.random()>0.5 ? false : s.active;
  queueSave(st);
  return { ok:true, win, score:+score.toFixed(3), level:s.level, active:s.active, taskFit:taskFit.fit };
}

export function composeSkills({ node, k, taskVec, alignment=1.0, core }){
  node=node[0].toUpperCase()+node.slice(1).toLowerCase();
  const st=load(); const avail = projectAvailability(core)[node]||0;
  const skills = st[node].skills.filter(s=>s.active).map(s=>({ ...s, availability: Math.round(avail*(50+s.level*10)) }))
    .sort((a,b)=>b.availability-a.availability).slice(0,k);
  if (skills.length<k) return { ok:false, reason:`Not enough active skills for k=${k}` };

  const task={ title:`Compose ${node} Skills`, min_sprites:k, max_sprites:k, min_team_level:Math.min(...skills.map(s=>s.level)), difficulty:3,
    required_axes:Object.keys(taskVec||{}).map(k=>({axis:[k],weight:1/((Object.keys(taskVec||{}).length)||1)})),
    ring_bias:[node], gate_affinity:skills.map(s=>s.id), sun_gate_boost:false };
  const sprites = skills.map(s=>({ id:s.id, gate:s.id, ring:node, level:s.level, copnhfe:s.stats, positioning:'Personal', modality:'Generic' }));
  const taskFit = scoreTask(task, sprites, skills[0].id);
  const score = (taskFit.fit/100) * alignment;
  const win = score >= 0.42;
  for (const s of skills){ s.xp += win?10:2; if (s.xp>=50+s.level*25){ s.level++; s.xp=0; } if (!win && alignment<0.4) s.active = Math.random()>0.5?false:s.active; }
  queueSave(st);
  return { ok:true, win, score:+score.toFixed(3), skills: skills.map(s=>({id:s.id,level:s.level,active:s.active})), taskFit: taskFit.fit };
}

export function bestSkills({ node, k, taskVec, core }){
  node=node[0].toUpperCase()+node.slice(1).toLowerCase();
  const st=load(); const avail = projectAvailability(core)[node]||0;
  const ranked = st[node].skills.filter(s=>s.active).map(s=>{
    const task={ title:`Evaluate ${s.name}`, min_sprites:1, max_sprites:1, min_team_level:s.level, difficulty:3,
      required_axes:Object.keys(taskVec||{}).map(k=>({axis:[k],weight:1/((Object.keys(taskVec||{}).length)||1)})),
      ring_bias:[node], gate_affinity:[s.id], sun_gate_boost:false };
    const sprite={ id:s.id, gate:s.id, ring:node, level:s.level, copnhfe:s.stats };
    const tf = scoreTask(task,[sprite],s.id);
    return { ...s, availability: Math.round(avail*(50+s.level*10)), taskFit: tf.fit };
  }).sort((a,b)=> (b.taskFit + b.availability*0.2) - (a.taskFit + a.availability*0.2)).slice(0,k);
  return { ok:true, skills: ranked };
}
EOF

# ---------------- backend/coach.js ----------------
cat > backend/coach.js <<'EOF'
export function coachStub(input, mode={tone:'empathetic', focus:'connection'}){
  const prompts = [
    `I hear you: "${input}". What's one small step you can take today to feel more aligned?`,
    `Thanks for sharing: "${input}". Can you name one thought that feels heavy? Let's examine it together.`,
    `Understood: "${input}". Try this micro-step: write one gratitude and one boundary you can keep today.`
  ];
  const response = prompts[Math.floor(Math.random()*prompts.length)];
  return { response, tone: mode.tone };
}
EOF

# ---------------- backend/gamegan.js ----------------
cat > backend/gamegan.js <<'EOF'
import fs from 'fs';
import path from 'path';
import { builderNeed } from './builder.js';

export function gameganMock(spec){
  const title = spec.title || 'Untitled Game';
  const color = spec.color || '#24d6a9';
  const speed = Number(spec.speed || 3);
  const message = spec.message || 'Play the game!';
  const fileName = `${title.replace(/[^\w]+/g,'_')}_${Date.now()}.html`;
  const filePath = path.join(process.cwd(), 'frontend', 'game', fileName);
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
  <style>body{margin:0;background:#0b0b12;color:#e9e9ef;font-family:system-ui}canvas{border:1px solid #24244a;display:block;margin:24px auto}</style>
  </head><body><h1 style="text-align:center">${title}</h1><canvas id="game" width="400" height="400"></canvas><p style="text-align:center">${message}</p>
  <script>
  const c = document.getElementById('game').getContext('2d'); c.fillStyle='${color}'; let x=200,y=200,dx=${speed},dy=${speed};
  function loop(){ c.clearRect(0,0,400,400); c.beginPath(); c.arc(x,y,20,0,Math.PI*2); c.fill();
    x+=dx; y+=dy; if(x<20||x>380) dx=-dx; if(y<20||y>380) dy=-dy; requestAnimationFrame(loop); } loop();
  </script></body></html>`;
  fs.mkdirSync(path.dirname(filePath), { recursive:true });
  fs.writeFileSync(filePath, html);
  builderNeed('game', `Generated mock game: ${fileName}`);
  return { ok:true, urlHint:`/game/${fileName}` };
}
EOF

# ---------------- backend/lab-logger.js ----------------
cat > backend/lab-logger.js <<'EOF'
import fs from 'fs';
import path from 'path';
const LOG = path.join(process.cwd(), 'data', 'events.jsonl');
export function logEvent(event){
  fs.mkdirSync(path.dirname(LOG), { recursive:true });
  fs.appendFileSync(LOG, JSON.stringify({ t:Date.now(), ...event }) + '\n');
}
export function listEvents(limit=200){
  if(!fs.existsSync(LOG)) return [];
  const lines = fs.readFileSync(LOG,'utf8').trim().split('\n').filter(Boolean);
  return lines.slice(-limit).map(l=>{ try{return JSON.parse(l)}catch{return null} }).filter(Boolean);
}
EOF

# ---------------- backend/server.js ----------------
cat > backend/server.js <<'EOF'
import http from 'http';
import fs from 'fs';
import path from 'path';
import { WebSocketServer } from 'ws';
import cfgRaw from './config.json' assert { type:'json' };
import { collapseCore, projectNine, modeFrom, buildPrompt } from './collapse.js';
import { fakeParserSeed } from './parserStub.js';
import { callOllama } from './ollama.js';
import { builderNeed, generateJobSpec, listTodos, listJobs, delegateJob, integrateModule } from './builder.js';
import { loadModules, loadedModules } from './modules-loader.js';
import { getCities, listAvailable, applySkill, composeSkills, bestSkills, projectAvailability } from './cities/engine.js';
import { coachStub } from './coach.js';
import { checkElementComplete, updateRecipes } from './sparkle.js';
import { gameganMock } from './gamegan.js';
import { logEvent, listEvents } from './lab-logger.js';

const cfg = cfgRaw;
const server = http.createServer();
const wss = new WebSocketServer({ server });

function send(res, code, obj){ res.writeHead(code, { 'Content-Type':'application/json', 'Access-Control-Allow-Origin':'*' }); res.end(JSON.stringify(obj)); }
function readBody(req){ return new Promise(r=>{ let b=''; req.on('data',d=>b+=d); req.on('end',()=>{ try{ r(JSON.parse(b||'{}')); }catch{ r({}); } }); }); }
function broadcast(msg){ wss.clients.forEach(ws=>ws.readyState===1 && ws.send(JSON.stringify(msg))); }

wss.on('connection', ws=>{
  ws.send(JSON.stringify({ type:'health', data:{ ok:true, ollama: !!(process.env.OLLAMA_URL || cfg.ollama.url) } }));
  ws.send(JSON.stringify({ type:'todos', data:listTodos() }));
  ws.send(JSON.stringify({ type:'jobs', data:listJobs() }));
  ws.send(JSON.stringify({ type:'modules', data:Object.keys(loadedModules) }));
});

await loadModules();

server.on('request', async (req,res)=>{
  const url = new URL(req.url, 'http://localhost');
  if (req.method==='OPTIONS'){
    res.writeHead(204, {
      'Access-Control-Allow-Origin':'*',
      'Access-Control-Allow-Methods':'GET,POST,OPTIONS',
      'Access-Control-Allow-Headers':'Content-Type'
    }); return res.end();
  }

  // Static serve generated games
  if (req.method==='GET' && url.pathname.startsWith('/game/')){
    const filePath = path.join(process.cwd(), 'frontend', url.pathname);
    if (fs.existsSync(filePath)){ res.writeHead(200, {'Content-Type':'text/html'}); fs.createReadStream(filePath).pipe(res); return; }
    return send(res,404,{error:'Game file not found'});
  }

  // Health
  if (req.method==='GET' && url.pathname==='/health'){ return send(res,200,{ ok:true, ollama: !!(process.env.OLLAMA_URL || cfg.ollama.url) }); }

  // Builder & Modules
  if (req.method==='GET' && url.pathname==='/todos'){ return send(res,200, listTodos()); }
  if (req.method==='GET' && url.pathname==='/builder/jobs'){ return send(res,200, listJobs()); }
  if (req.method==='POST' && url.pathname==='/builder/jobs'){ const body=await readBody(req); const job=generateJobSpec(body.kind||'module', body.detail||'unspecified', body.dependencies||[]); broadcast({type:'jobs',data:listJobs()}); return send(res,200,{ok:true, job}); }
  if (req.method==='POST' && url.pathname==='/builder/delegate'){ const body=await readBody(req); const out=await delegateJob(body.jobId, body.agentUrl); broadcast({type:'todos',data:listTodos()}); return send(res,200,out); }
  if (req.method==='POST' && url.pathname==='/builder/integrate'){
    const body=await readBody(req);
    if(!body.moduleName) return send(res,400,{error:'Missing moduleName'});
    const result = integrateModule(body.moduleName, body.code||'export default () => ({ ok:true });');
    await loadModules(); broadcast({type:'modules',data:Object.keys(loadedModules)});
    return send(res,200,result);
  }
  if (req.method==='GET' && url.pathname==='/modules'){ return send(res,200,Object.keys(loadedModules)); }

  // Sparkle
  if (req.method==='POST' && url.pathname==='/sparkle/check'){ const body=await readBody(req); return send(res,200, checkElementComplete(body.activeGates||[], body.projection||{})); }
  if (req.method==='POST' && url.pathname==='/sparkle/update'){ const body=await readBody(req); const out = updateRecipes(body.recipes||[]); return send(res,200,out); }

  // Cities
  if (req.method==='GET' && url.pathname==='/cities'){ return send(res,200, getCities()); }
  if (req.method==='POST' && url.pathname.startsWith('/cities/')){ const node=url.pathname.split('/').pop(); const body=await readBody(req); const core=(body.mind!==undefined)?body:fakeParserSeed(); const cities=getNode(node); return send(res,200, cities); }
  if (req.method==='POST' && url.pathname==='/cities/available'){ const body=await readBody(req); const core=(body.mind!==undefined)?body:fakeParserSeed(); return send(res,200, listAvailable(core)); }
  if (req.method==='POST' && url.pathname==='/cities/apply'){ const body=await readBody(req); const out=applySkill(body); broadcast({type:'apply',data:out}); return send(res,200,out); }
  if (req.method==='POST' && url.pathname==='/cities/compose'){ const body=await readBody(req); const out=composeSkills(body); broadcast({type:'compose',data:out}); return send(res,200,out); }
  if (req.method==='POST' && url.pathname==='/cities/best'){ const body=await readBody(req); return send(res,200, bestSkills(body)); }

  // Collapse
  if (req.method==='POST' && url.pathname==='/collapse'){ const body=await readBody(req); const parser=(body.parser)?body.parser:fakeParserSeed(); const core = collapseCore(parser); const projections = projectNine(core, body.f||0.9); const mode = modeFrom(core); const result={ core, projections, mode, parser }; broadcast({type:'collapse',data:result}); return send(res,200,result); }

  // LLM Chat
  if (req.method==='POST' && url.pathname==='/chat'){ 
    const body=await readBody(req);
    const parser=(body.parser)?body.parser:fakeParserSeed();
    const core = collapseCore(parser); const projections = projectNine(core, 0.9); const mode = modeFrom(core);
    const modelMap = { Mind:'tinyllama', Heart:'mistral', Body:'phi' };
    const model = body.model || modelMap[mode.dominant] || 'tinyllama';
    const prompt = buildPrompt(body.prompt||'Hello', mode);
    const ollama = await callOllama({ url:(process.env.OLLAMA_URL||cfg.ollama.url), model, prompt, options:cfg.ollama.options });
    if (!ollama.ok) builderNeed('module', 'Ollama not reachable — set OLLAMA_URL or config. Using fallback.');
    const reply = ollama.text || `(${mode.tone}/${mode.focus}) Thanks for sharing. Try one small aligned step today.`;
    const result={ reply, core, projections, mode, parser }; broadcast({type:'chat',data:result});
    return send(res,200,result);
  }

  // Coach
  if (req.method==='POST' && url.pathname==='/coach'){ const body=await readBody(req); const parser=(body.parser)?body.parser:fakeParserSeed(); const core=collapseCore(parser); const mode=modeFrom(core); const result=coachStub(body.input||'Hello', mode); logEvent({kind:'coach',input:body.input,result}); return send(res,200,result); }

  // GameGAN
  if (req.method==='POST' && url.pathname==='/gamegan/mock'){ const body=await readBody(req); const result=gameganMock(body.spec||{}); logEvent({kind:'game',spec:body.spec,result}); return send(res,200,result); }

  // Events
  if (req.method==='GET' && url.pathname==='/events'){ const limit=Number(url.searchParams.get('limit')||200); return send(res,200, listEvents(limit)); }

  // Default
  send(res,404,{error:'Not found'});
});

const PORT = process.env.PORT || cfg.port || 8787;
server.listen(PORT, ()=>console.log(`Cynthia Phase 0.5 running on port ${PORT}`));
EOF

# ---------------- frontend/index.html ----------------
cat > frontend/index.html <<'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cynthia Phase 0.5 — You-N-I-Verse Control</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: system-ui, -apple-system, sans-serif; background: linear-gradient(135deg, #0b0b12 0%, #24244a 100%); color: #e9e9ef; min-height: 100vh; overflow-x: auto; }
    .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
    .header { text-align: center; margin-bottom: 30px; }
    .header h1 { font-size: 2.5em; background: linear-gradient(45deg, #ff6b9d, #24d6a9, #ffd93d); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 10px; }
    .header p { opacity: 0.8; font-size: 1.1em; }
    .nav { display: flex; justify-content: center; gap: 15px; margin-bottom: 30px; flex-wrap: wrap; }
    .nav button { padding: 12px 24px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #e9e9ef; border-radius: 8px; cursor: pointer; font-size: 14px; transition: all 0.3s; }
    .nav button:hover, .nav button.active { background: rgba(255,255,255,0.2); transform: translateY(-2px); }
    .section { display: none; }
    .section.active { display: block; }
    .card { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 20px; margin-bottom: 20px; backdrop-filter: blur(10px); }
    .row { display: flex; gap: 10px; margin-bottom: 15px; flex-wrap: wrap; }
    .row button { padding: 8px 16px; background: #24d6a9; color: #0b0b12; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; transition: all 0.2s; }
    .row button:hover { background: #1fb892; transform: scale(1.05); }
    .skill-card { background: rgba(36,214,169,0.1); border: 1px solid rgba(36,214,169,0.3); border-radius: 8px; padding: 15px; margin: 10px; display: inline-block; min-width: 200px; }
    .input-group { display: flex; gap: 10px; align-items: center; margin-bottom: 15px; flex-wrap: wrap; }
    .input-group input, .input-group select { padding: 8px 12px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #e9e9ef; border-radius: 6px; font-size: 14px; }
    .input-group input::placeholder { color: rgba(233,233,239,0.5); }
    .status { position: fixed; top: 20px; right: 20px; background: rgba(0,0,0,0.8); padding: 10px 15px; border-radius: 8px; font-size: 12px; }
    .status.connected { color: #24d6a9; }
    .status.disconnected { color: #ff6b9d; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px; }
    .chat { max-height: 400px; overflow-y: auto; border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; padding: 15px; margin-bottom: 15px; background: rgba(0,0,0,0.2); }
    .msg { margin-bottom: 10px; padding: 8px 12px; border-radius: 8px; }
    .msg.user { background: rgba(36,214,169,0.2); text-align: right; }
    .msg.assistant { background: rgba(255,107,157,0.2); }
    textarea { width: 100%; padding: 10px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #e9e9ef; border-radius: 6px; font-family: inherit; resize: vertical; }
    .gate-grid { display: grid; grid-template-columns: repeat(8, 1fr); gap: 8px; margin-bottom: 15px; }
    .gate { background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #e9e9ef; border-radius: 6px; padding: 8px; text-align: center; cursor: pointer; font-size: 12px; transition: all 0.2s; }
    .gate.active { background: rgba(255,215,61,0.3); border-color: #ffd93d; }
    .gate:hover { background: rgba(255,255,255,0.2); }
    .footer { text-align: center; margin-top: 40px; opacity: 0.6; font-size: 12px; }
    @media (max-width: 768px) { 
      .container { padding: 15px; } 
      .header h1 { font-size: 2em; } 
      .grid { grid-template-columns: 1fr; } 
      .row { flex-direction: column; } 
      .input-group { flex-direction: column; align-items: stretch; }
    }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <div class="header">
      <h1>CYNTHIA PHASE 0.5</h1>
      <p>You-N-I-Verse Control Center</p>
    </div>

    <!-- Navigation -->
    <div class="nav">
      <button onclick="showSection('collapse')" id="nav-collapse" class="active">Collapse System</button>
      <button onclick="showSection('cities')" id="nav-cities">Cities Engine</button>
      <button onclick="showSection('taskfit')" id="nav-taskfit">TaskFit & Builder</button>
      <button onclick="showSection('sparkle')" id="nav-sparkle">Sparkle System</button>
      <button onclick="showSection('llm')" id="nav-llm">LLM Interface</button>
    </div>

    <!-- Status Indicator -->
    <div class="status disconnected" id="status">WebSocket Disconnected</div>

    <!-- Collapse System -->
    <section id="collapse" class="section active">
      <div class="card">
        <h2>Collapse System — Mind • Heart • Body Projection</h2>
        <p style="margin-bottom: 20px; opacity: 0.8;">Generate core values and nine-dimensional projections from personality data.</p>
        
        <div class="row">
          <button onclick="runCollapse()">Generate Analysis</button>
          <button onclick="clearCollapse()">Clear</button>
        </div>
        
        <div id="core-display"></div>
      </div>
    </section>

    <!-- Cities Engine -->
    <section id="cities" class="section">
      <div class="card">
        <h2>Cities Engine (3×64 Skills)</h2>
        <div class="row">
          <button onclick="loadCity('mind')">Mind</button>
          <button onclick="loadCity('heart')">Heart</button>
          <button onclick="loadCity('body')">Body</button>
        </div>
        <div id="skills"></div>
        <h3>Available Operations</h3>
        <div class="input-group">
          <input type="number" id="skill-id" placeholder="Skill ID (1-64)" min="1" max="64" value="1">
          <input type="number" id="alignment" placeholder="Alignment (0-1)" min="0" max="1" step="0.1" value="0.9">
          <button onclick="applySkill()">Apply Skill</button>
          <button onclick="composeSkills()">Compose Team (k=3)</button>
        </div>
        <div id="city-result"></div>
      </div>
    </section>

    <!-- TaskFit & Builder -->
    <section id="taskfit" class="section">
      <div class="card">
        <h2>TaskFit & Builder System</h2>
        
        <h3>Builder Jobs</h3>
        <div class="row">
          <button onclick="createJob('module')">+ Module Job</button>
          <button onclick="createJob('city')">+ City Job</button>
          <button onclick="createJob('skill')">+ Skill Job</button>
        </div>
        
        <h3>Job Delegation</h3>
        <div class="input-group">
          <input type="text" id="agent-url" placeholder="Agent URL">
          <button onclick="delegateJob()">Delegate Job</button>
        </div>
        
        <h3>Module Integration</h3>
        <div class="input-group">
          <input type="text" id="module-name" placeholder="Module Name">
          <button onclick="integrateModule()">Integrate Module</button>
        </div>
        
        <div id="builder-status"></div>
      </div>
    </section>

    <!-- Sparkle System -->
    <section id="sparkle" class="section">
      <div class="card">
        <h2>Sparkle Recipe System</h2>
        <p style="margin-bottom: 20px; opacity: 0.8;">Activate gates to complete recipes and earn rewards.</p>
        
        <h3>Active Gates</h3>
        <div class="gate-grid" id="gate-grid">
          <!-- Gates will be populated by JavaScript -->
        </div>
        
        <div class="row">
          <button onclick="checkSparkle()">Check Elements</button>
          <button onclick="clearGates()">Clear Gates</button>
        </div>
        
        <div id="sparkle-result"></div>
      </div>
    </section>

    <!-- LLM Interface -->
    <section id="llm" class="section">
      <div class="card">
        <h2>LLM Interface — Chat with Cynthia</h2>
        
        <div class="input-group">
          <select id="model-select">
            <option value="tinyllama">TinyLlama (Mind)</option>
            <option value="mistral">Mistral (Heart)</option>
            <option value="phi">Phi (Body)</option>
          </select>
          <button onclick="checkHealth()">Check Ollama</button>
        </div>
        
        <div class="chat" id="chat"></div>
        
        <div class="input-group">
          <textarea id="chat-input" placeholder="Ask Cynthia something..." rows="3"></textarea>
          <button onclick="sendChat()">Send</button>
        </div>
        
        <div id="llm-status"></div>
      </div>
    </section>

    <!-- Footer -->
    <div class="footer">
      <p>Cynthia Phase 0.5 — Mind • Heart • Body Integration System</p>
    </div>
  </div>

  <script src="app.js"></script>
</body>
</html>
EOF

# ---------------- frontend/app.js ----------------
cat > frontend/app.js <<'EOF'
// Configuration
const API = () => `http://localhost:${window.location.port || 8787}`;
let ws = null;
let activeGates = new Set([16, 48, 24]);
let currentCore = null;

// Utility functions
const $ = id => document.getElementById(id);
const log = (...args) => console.log('[Cynthia]', ...args);

// WebSocket connection
function connectWS() {
  const wsUrl = `ws://localhost:${window.location.port || 8787}`;
  ws = new WebSocket(wsUrl);
  
  ws.onopen = () => {
    $('status').textContent = 'WebSocket Connected';
    $('status').className = 'status connected';
    log('WebSocket connected');
  };
  
  ws.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      log('WebSocket message:', data.type, data);
      handleWSMessage(data);
    } catch (e) {
      log('WebSocket parse error:', e);
    }
  };
  
  ws.onclose = () => {
    $('status').textContent = 'WebSocket Disconnected';
    $('status').className = 'status disconnected';
    log('WebSocket disconnected');
    setTimeout(connectWS, 3000);
  };
  
  ws.onerror = (error) => {
    log('WebSocket error:', error);
  };
}

function handleWSMessage(data) {
  switch(data.type) {
    case 'health':
      updateHealthStatus(data.data);
      break;
    case 'collapse':
      displayCollapseResult(data.data);
      break;
    case 'chat':
      addChatMessage('assistant', data.data.reply);
      break;
    case 'apply':
    case 'compose':
      displayCityResult(data.data);
      break;
  }
}

// Navigation
function showSection(sectionId) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav button').forEach(b => b.classList.remove('active'));
  $(sectionId).classList.add('active');
  $(`nav-${sectionId}`).classList.add('active');
  
  if (sectionId === 'sparkle') initGateGrid();
}

// Collapse System
async function runCollapse() {
  try {
    const res = await fetch(API() + '/collapse', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    });
    const data = await res.json();
    currentCore = data.core;
    displayCollapseResult(data);
  } catch (e) {
    log('Collapse error:', e);
    $('core-display').innerHTML = `<p style="color: #ff6b9d;">Error: ${e.message}</p>`;
  }
}

function displayCollapseResult(data) {
  const { core, projections, mode } = data;
  const html = `
    <h3>Core Values</h3>
    <div class="grid">
      <div class="skill-card">
        <strong>Mind:</strong> ${core.mind.toFixed(3)}<br>
        <div style="background: rgba(255,107,157,0.3); height: 8px; border-radius: 4px; margin-top: 5px;">
          <div style="background: #ff6b9d; height: 8px; border-radius: 4px; width: ${((core.mind + 1) / 2 * 100)}%;"></div>
        </div>
      </div>
      <div class="skill-card">
        <strong>Heart:</strong> ${core.heart.toFixed(3)}<br>
        <div style="background: rgba(255,215,61,0.3); height: 8px; border-radius: 4px; margin-top: 5px;">
          <div style="background: #ffd93d; height: 8px; border-radius: 4px; width: ${((core.heart + 1) / 2 * 100)}%;"></div>
        </div>
      </div>
      <div class="skill-card">
        <strong>Body:</strong> ${core.body.toFixed(3)}<br>
        <div style="background: rgba(36,214,169,0.3); height: 8px; border-radius: 4px; margin-top: 5px;">
          <div style="background: #24d6a9; height: 8px; border-radius: 4px; width: ${((core.body + 1) / 2 * 100)}%;"></div>
        </div>
      </div>
    </div>
    
    <h3>Nine Projections</h3>
    <div class="grid">
      ${Object.entries(projections).map(([key, value]) => `
        <div class="skill-card" style="background: rgba(255,255,255,0.05);">
          <strong>${key}:</strong> ${value.toFixed(3)}
        </div>
      `).join('')}
    </div>
    
    <h3>Current Mode</h3>
    <div class="skill-card" style="background: rgba(36,214,169,0.1);">
      <strong>Dominant:</strong> ${mode.dominant}<br>
      <strong>Tone:</strong> ${mode.tone}<br>
      <strong>Focus:</strong> ${mode.focus}
    </div>
  `;
  $('core-display').innerHTML = html;
}

function clearCollapse() {
  $('core-display').innerHTML = '';
  currentCore = null;
}

// Cities Engine
async function loadCity(node) {
  try {
    const core = currentCore || { mind: 0, heart: 0, body: 0 };
    const res = await fetch(API() + `/cities/${node}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(core)
    });
    const data = await res.json();
    displayCitySkills(data.skills || []);
  } catch (e) {
    log('City load error:', e);
    $('skills').innerHTML = `<p style="color: #ff6b9d;">Error loading ${node} city: ${e.message}</p>`;
  }
}

function displayCitySkills(skills) {
  const html = skills.slice(0, 12).map(s => `
    <div class="skill-card">
      <strong>${s.name}</strong> (Lv.${s.level})<br>
      XP: ${s.xp} | Active: ${s.active ? 'Yes' : 'No'}<br>
      <small>C:${s.stats.C} O:${s.stats.O} P:${s.stats.P}<br>
      N:${s.stats.N} H:${s.stats.F} F:${s.stats.F} E:${s.stats.E}</small>
    </div>
  `).join('');
  $('skills').innerHTML = html;
}

async function applySkill() {
  const skillId = parseInt($('skill-id').value);
  const alignment = parseFloat($('alignment').value);
  
  try {
    const res = await fetch(API() + '/cities/apply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        node: 'Mind', // Default to Mind for demo
        skillId, 
        alignment,
        taskVec: { C: 1, O: 1, P: 1 }
      })
    });
    const data = await res.json();
    displayCityResult(data);
  } catch (e) {
    log('Apply skill error:', e);
  }
}

async function composeSkills() {
  const core = currentCore || { mind: 0.5, heart: 0.5, body: 0.5 };
  
  try {
    const res = await fetch(API() + '/cities/compose', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        node: 'Mind',
        k: 3,
        core,
        alignment: parseFloat($('alignment').value),
        taskVec: { C: 1, O: 1, P: 1 }
      })
    });
    const data = await res.json();
    displayCityResult(data);
  } catch (e) {
    log('Compose skills error:', e);
  }
}

function displayCityResult(data) {
  const html = `
    <div class="skill-card" style="background: ${data.ok ? 'rgba(36,214,169,0.1)' : 'rgba(255,107,157,0.1)'};">
      <strong>Result:</strong> ${data.ok ? (data.win ? 'Success' : 'Partial') : 'Failed'}<br>
      ${data.ok ? `
        <strong>Score:</strong> ${data.score}<br>
        <strong>Task Fit:</strong> ${data.taskFit}%<br>
        ${data.level ? `<strong>Level:</strong> ${data.level}` : ''}
      ` : `<strong>Reason:</strong> ${data.reason}`}
    </div>
  `;
  $('city-result').innerHTML = html;
}

// TaskFit & Builder
async function createJob(kind) {
  try {
    const res = await fetch(API() + '/builder/jobs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        kind, 
        detail: `${kind.charAt(0).toUpperCase() + kind.slice(1)} enhancement requested`,
        dependencies: []
      })
    });
    const data = await res.json();
    updateBuilderStatus(`Job created: ${data.job.name}`);
  } catch (e) {
    log('Create job error:', e);
  }
}

async function delegateJob() {
  const agentUrl = $('agent-url').value.trim();
  if (!agentUrl) {
    updateBuilderStatus('Please enter agent URL');
    return;
  }
  
  try {
    // For demo, we'll use a mock job ID
    const res = await fetch(API() + '/builder/delegate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        jobId: Date.now(), 
        agentUrl 
      })
    });
    const data = await res.json();
    updateBuilderStatus(data.ok ? 'Job delegated successfully' : `Delegation failed: ${data.error}`);
  } catch (e) {
    log('Delegate job error:', e);
    updateBuilderStatus(`Delegation error: ${e.message}`);
  }
}

async function integrateModule() {
  const moduleName = $('module-name').value.trim();
  if (!moduleName) {
    updateBuilderStatus('Please enter module name');
    return;
  }
  
  try {
    const res = await fetch(API() + '/builder/integrate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        moduleName,
        code: `export default function ${moduleName}() { return { ok: true, message: 'Module ${moduleName} loaded' }; }`
      })
    });
    const data = await res.json();
    updateBuilderStatus(data.ok ? `Module ${moduleName} integrated` : 'Integration failed');
  } catch (e) {
    log('Integrate module error:', e);
  }
}

function updateBuilderStatus(message) {
  $('builder-status').innerHTML = `<p style="color: #24d6a9;">${message}</p>`;
  setTimeout(() => $('builder-status').innerHTML = '', 3000);
}

// Sparkle System
function initGateGrid() {
  const grid = $('gate-grid');
  grid.innerHTML = '';
  
  for (let i = 1; i <= 64; i++) {
    const gate = document.createElement('div');
    gate.className = `gate ${activeGates.has(i) ? 'active' : ''}`;
    gate.textContent = i;
    gate.onclick = () => toggleGate(i);
    grid.appendChild(gate);
  }
}

function toggleGate(gateId) {
  if (activeGates.has(gateId)) {
    activeGates.delete(gateId);
  } else {
    activeGates.add(gateId);
  }
  initGateGrid();
}

function clearGates() {
  activeGates.clear();
  initGateGrid();
}

async function checkSparkle() {
  try {
    const res = await fetch(API() + '/sparkle/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        activeGates: [...activeGates],
        projection: currentCore ? currentCore : {}
      })
    });
    const data = await res.json();
    displaySparkleResult(data);
  } catch (e) {
    log('Sparkle check error:', e);
  }
}

function displaySparkleResult(data) {
  let html = '';
  if (data.element) {
    html = `
      <div class="skill-card" style="background: rgba(255,215,61,0.2); border-color: #ffd93d;">
        <strong>🌟 Element Completed: ${data.label}</strong><br>
        <strong>Reward:</strong> ${data.reward.xp} XP, ${data.reward.shards} Shards<br>
        <small>Active gates: ${[...activeGates].join(', ')}</small>
      </div>
    `;
  } else {
    html = `
      <div class="skill-card" style="background: rgba(255,255,255,0.05);">
        <strong>No elements completed</strong><br>
        <small>Try different gate combinations. Active: ${[...activeGates].join(', ')}</small>
      </div>
    `;
  }
  $('sparkle-result').innerHTML = html;
}

// LLM Interface
async function sendChat() {
  const input = $('chat-input').value.trim();
  if (!input) return;
  
  const model = $('model-select').value;
  addChatMessage('user', input);
  $('chat-input').value = '';
  
  try {
    const res = await fetch(API() + '/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        prompt: input,
        model,
        parser: null // Will use fake parser seed
      })
    });
    const data = await res.json();
    addChatMessage('assistant', data.reply);
  } catch (e) {
    log('Chat error:', e);
    addChatMessage('assistant', `Error: ${e.message}`);
  }
}

function addChatMessage(role, content) {
  const chat = $('chat');
  const msg = document.createElement('div');
  msg.className = `msg ${role}`;
  msg.innerHTML = `<strong>${role === 'user' ? 'You' : 'Cynthia'}:</strong> ${content}`;
  chat.appendChild(msg);
  chat.scrollTop = chat.scrollHeight;
}

async function checkHealth() {
  try {
    const res = await fetch(API() + '/health');
    const data = await res.json();
    updateHealthStatus(data);
  } catch (e) {
    log('Health check error:', e);
  }
}

function updateHealthStatus(data) {
  const status = data.ollama ? '🟢 Ollama Ready' : '🔴 Ollama Offline (set OLLAMA_URL)';
  $('llm-status').innerHTML = `<p>${status}</p>`;
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && e.ctrlKey) {
    if ($('chat-input') === document.activeElement) {
      sendChat();
    }
  }
});

// Initialize
window.addEventListener('load', () => {
  log('Cynthia Phase 0.5 initialized');
  connectWS();
  initGateGrid();
  checkHealth();
});
EOF

echo "✅ Cynthia Phase 0.5 bootstrap complete!"
echo ""
echo "Next steps:"
echo "1. Run: npm install && npm start"
echo "2. Open frontend/index.html in your browser"
echo "3. Optional: export OLLAMA_URL=http://localhost:11434 for LLM features"