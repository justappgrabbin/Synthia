import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { collapseCore, projectNine, modeFrom, buildPrompt } from "./services/collapse";
import { fakeParserSeed } from "./services/parser";
import { callOllama } from "./services/ollama";
import { listAvailable, applySkill, composeSkills, projectAvailability } from "./services/cities";
import { checkElementComplete, updateRecipes } from "./services/sparkle";
import { builderNeed, generateJobSpec, delegateJob, integrateModule } from "./services/builder";
import { coachStub } from "./services/coach";
import { gameganMock } from "./services/gamegan";
import { insertJobSchema, insertTaskSchema, insertRecipeSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // WebSocket server on separate path to avoid conflicts with Vite HMR
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // WebSocket connection handling
  wss.on('connection', (ws: WebSocket) => {
    console.log('WebSocket client connected');
    
    // Send initial data
    const sendUpdate = async (type: string, data: any) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type, data }));
      }
    };
    
    // Send system status
    storage.getSystemStatus().then(status => {
      sendUpdate('system_status', status);
    });
    
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
    
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
  });
  
  // Broadcast function for real-time updates
  const broadcast = (type: string, data: any) => {
    wss.clients.forEach((client: WebSocket) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({ type, data }));
      }
    });
  };

  // Health check
  app.get('/api/health', async (req, res) => {
    const status = await storage.getSystemStatus();
    res.json(status);
  });

  // Collapse system endpoints
  app.post('/api/collapse/analyze', async (req, res) => {
    try {
      const parser = req.body.parser || fakeParserSeed();
      const core = collapseCore(parser);
      const coreValues = await storage.createCoreValues(core);
      const projectionsData = projectNine(core, 0.9);
      projectionsData.coreValuesId = coreValues.id;
      const projections = await storage.createNineProjections(projectionsData);
      const mode = modeFrom(core);
      
      const result = { core: coreValues, projections, mode, parser };
      broadcast('collapse_update', result);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to analyze collapse system' });
    }
  });

  app.get('/api/collapse/current', async (req, res) => {
    try {
      const core = await storage.getCoreValues();
      if (!core) {
        return res.json({ core: null, projections: null, mode: null });
      }
      
      const projections = await storage.getNineProjections(core.id);
      const mode = modeFrom(core);
      res.json({ core, projections, mode });
    } catch (error) {
      res.status(500).json({ error: 'Failed to get current collapse data' });
    }
  });

  // Cities engine endpoints
  app.get('/api/cities/skills', async (req, res) => {
    try {
      const { node } = req.query;
      const skills = await storage.getSkills(node as string);
      res.json(skills);
    } catch (error) {
      res.status(500).json({ error: 'Failed to get skills' });
    }
  });

  app.post('/api/cities/available', async (req, res) => {
    try {
      const { core } = req.body;
      const coreData = core || { mind: 0, heart: 0, body: 0 };
      const list = await listAvailable(coreData);
      const availability = projectAvailability(coreData);
      res.json({ list, availability });
    } catch (error) {
      res.status(500).json({ error: 'Failed to get available skills' });
    }
  });

  app.post('/api/cities/apply', async (req, res) => {
    try {
      const { node, skillId, taskVec, alignment } = req.body;
      const result = await applySkill({
        node: node || 'Mind',
        skillId: skillId || 1,
        taskVec: taskVec || {},
        alignment: typeof alignment === 'number' ? alignment : 1.0
      });
      
      broadcast('skill_applied', { node, skillId, result });
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to apply skill' });
    }
  });

  app.post('/api/cities/compose', async (req, res) => {
    try {
      const { node, k, taskVec, alignment, core } = req.body;
      const result = await composeSkills({
        node: node || 'Mind',
        k: k || 3,
        taskVec: taskVec || {},
        alignment: typeof alignment === 'number' ? alignment : 1.0,
        core: core || { mind: 0, heart: 0, body: 0 }
      });
      
      broadcast('skills_composed', { node, k, result });
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to compose skills' });
    }
  });

  // Tasks endpoints
  app.get('/api/tasks', async (req, res) => {
    try {
      const tasks = await storage.getTasks();
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ error: 'Failed to get tasks' });
    }
  });

  app.post('/api/tasks', async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(taskData);
      broadcast('task_created', task);
      res.json(task);
    } catch (error) {
      res.status(400).json({ error: 'Invalid task data' });
    }
  });

  // Jobs endpoints
  app.get('/api/jobs', async (req, res) => {
    try {
      const jobs = await storage.getJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ error: 'Failed to get jobs' });
    }
  });

  app.post('/api/jobs', async (req, res) => {
    try {
      const { kind, detail, dependencies } = req.body;
      const job = await generateJobSpec(
        kind || 'module',
        detail || 'unspecified',
        dependencies || []
      );
      broadcast('job_created', job);
      res.json({ ok: true, job });
    } catch (error) {
      res.status(500).json({ error: 'Failed to create job' });
    }
  });

  app.post('/api/jobs/delegate', async (req, res) => {
    try {
      const { jobId, agentUrl } = req.body;
      const result = await delegateJob(jobId, agentUrl);
      broadcast('job_delegated', { jobId, agentUrl, result });
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to delegate job' });
    }
  });

  // Modules endpoints
  app.get('/api/modules', async (req, res) => {
    try {
      const modules = await storage.getModules();
      res.json(modules);
    } catch (error) {
      res.status(500).json({ error: 'Failed to get modules' });
    }
  });

  app.post('/api/modules', async (req, res) => {
    try {
      const { moduleName, code } = req.body;
      if (!moduleName) {
        return res.status(400).json({ error: 'Missing moduleName' });
      }
      const result = await integrateModule(moduleName, code || '');
      broadcast('module_integrated', { moduleName, result });
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to integrate module' });
    }
  });

  // Sparkle system endpoints
  app.post('/api/sparkle/check', async (req, res) => {
    try {
      const { activeGates, projection } = req.body;
      const result = await checkElementComplete(activeGates || [], projection || {});
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to check sparkle elements' });
    }
  });

  app.get('/api/sparkle/recipes', async (req, res) => {
    try {
      const recipes = await storage.getRecipes();
      res.json(recipes);
    } catch (error) {
      res.status(500).json({ error: 'Failed to get recipes' });
    }
  });

  app.post('/api/sparkle/recipes', async (req, res) => {
    try {
      const { recipes } = req.body;
      const result = await updateRecipes(recipes || []);
      broadcast('recipes_updated', result);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update recipes' });
    }
  });

  // Coach endpoints
  app.post('/api/coach/stub', async (req, res) => {
    try {
      const { input, parser } = req.body;
      const parserData = parser || fakeParserSeed();
      const core = collapseCore(parserData);
      const mode = modeFrom(core);
      const result = coachStub(input || 'Hello', mode);
      
      await storage.createEvent({
        kind: 'coach',
        data: { input, result }
      });
      
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to get coach response' });
    }
  });

  // GameGAN endpoints
  app.post('/api/gamegan/mock', async (req, res) => {
    try {
      const { spec } = req.body;
      const result = await gameganMock(spec || {});
      
      await storage.createEvent({
        kind: 'game',
        data: { spec, result }
      });
      
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to generate game' });
    }
  });

  // LLM Chat endpoints
  app.post('/api/chat', async (req, res) => {
    try {
      const { prompt, parser, model } = req.body;
      const parserData = parser || fakeParserSeed();
      const core = collapseCore(parserData);
      const projections = projectNine(core, 0.9);
      const mode = modeFrom(core);
      
      const modelMap = {
        Mind: 'tinyllama',
        Heart: 'mistral',
        Body: 'phi'
      };
      
      const selectedModel = model || modelMap[mode.dominant as keyof typeof modelMap] || 'tinyllama';
      const chatPrompt = buildPrompt(prompt || 'Hello', mode);
      
      const ollama = await callOllama({
        url: process.env.OLLAMA_URL || '',
        model: selectedModel,
        prompt: chatPrompt,
        options: { temperature: 0.6, top_p: 0.9, repeat_penalty: 1.08 }
      });
      
      if (!ollama.ok) {
        await builderNeed('module', 'Ollama not reachable — set OLLAMA_URL or config. Using fallback.');
      }
      
      const reply = ollama.text || `(${mode.tone}/${mode.focus}) Thanks for sharing. Try one small aligned step today.`;
      
      const result = { reply, core, projections, mode, parser: parserData };
      broadcast('chat_response', result);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to process chat' });
    }
  });

  // Events endpoints
  app.get('/api/events', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 200;
      const events = await storage.getEvents(limit);
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: 'Failed to get events' });
    }
  });

  return httpServer;
}
