import { builderNeed } from "./builder";

export interface GameSpec {
  title?: string;
  color?: string;
  speed?: number;
  message?: string;
}

export async function gameganMock(spec: GameSpec): Promise<{ ok: boolean; urlHint: string }> {
  const title = spec.title || 'Untitled Game';
  const color = spec.color || '#24d6a9';
  const speed = Number(spec.speed || 3);
  const message = spec.message || 'Play the game!';
  const fileName = `${title.replace(/[^\w]+/g, '_')}_${Date.now()}.html`;
  
  // In a real implementation, this would generate and save the HTML file
  // For now, we'll just log the intent
  await builderNeed('game', `Generated mock game: ${fileName}`);
  
  return { 
    ok: true, 
    urlHint: `/game/${fileName}` 
  };
}
