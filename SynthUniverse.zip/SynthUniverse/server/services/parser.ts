import type { ParserData } from "./collapse";

export function fakeParserSeed(): ParserData {
  const rnd = (n: number) => Math.max(0, Math.min(1, (Math.sin(Date.now() / 10000 + n) * 0.5 + 0.5)));
  const pickGates = () => {
    const out = new Set<number>();
    while (out.size < 3) {
      out.add(1 + Math.floor(Math.random() * 64));
    }
    return [...out];
  };
  
  return {
    aspects: {
      "Sun conjunct Mercury": { weight: rnd(1) },
      "Mars sextile Saturn": { weight: rnd(2) }
    },
    gates: { 
      sunGate: 16, 
      active: pickGates() 
    },
    skills: { 
      Mind: 3, 
      Heart: 2, 
      Body: 2 
    }
  };
}
