import type { Recipe, SparkleElementCheck } from "@shared/schema";
import { storage } from "../storage";

export async function checkElementComplete(activeGates: number[] = [], projection: Record<string, number> = {}): Promise<SparkleElementCheck> {
  const recipes = await storage.getRecipes();
  const set = new Set(activeGates);
  
  for (const recipe of recipes) {
    const gates = Array.isArray(recipe.gates) ? recipe.gates : [];
    if (gates.every(g => set.has(g))) {
      const reward = typeof recipe.reward === 'object' && recipe.reward !== null 
        ? recipe.reward as { xp: number; shards: number }
        : { xp: 10, shards: 1 };
      
      return {
        element: recipe.recipeId,
        label: recipe.label,
        reward
      };
    }
  }
  
  return { element: null };
}

export async function updateRecipes(newRecipes: Array<{ recipeId: string; label: string; gates: number[]; reward: { xp: number; shards: number } }>): Promise<{ ok: boolean; count: number }> {
  const recipes = await storage.updateRecipes(newRecipes);
  return { ok: true, count: recipes.length };
}
