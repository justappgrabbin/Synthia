export function coachStub(input: string, mode: { tone: string; focus: string } = { tone: 'empathetic', focus: 'connection' }): { response: string; tone: string } {
  const prompts = [
    `I hear you: "${input}". What's one small step you can take today to feel more aligned?`,
    `Thanks for sharing: "${input}". Can you name one thought that feels heavy? Let's examine it together.`,
    `Understood: "${input}". Try this micro-step: write one gratitude and one boundary you can keep today.`
  ];
  
  const response = prompts[Math.floor(Math.random() * prompts.length)];
  return { response, tone: mode.tone };
}
