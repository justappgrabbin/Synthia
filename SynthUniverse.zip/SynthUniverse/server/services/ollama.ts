export interface OllamaOptions {
  temperature?: number;
  num_predict?: number;
  top_p?: number;
  repeat_penalty?: number;
}

export interface OllamaRequest {
  url: string;
  model: string;
  prompt: string;
  options?: OllamaOptions;
}

export interface OllamaResponse {
  ok: boolean;
  text: string;
}

export async function callOllama({ url, model, prompt, options }: OllamaRequest): Promise<OllamaResponse> {
  const endpoint = (process.env.OLLAMA_URL || url || '').trim();
  
  if (!endpoint) {
    return { 
      ok: false, 
      text: "(LLM offline — set OLLAMA_URL). Fallback: core-only reply." 
    };
  }

  try {
    const response = await fetch(`${endpoint.replace(/\/$/, '')}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        model, 
        prompt, 
        options: options || { temperature: 0.6, top_p: 0.9 },
        stream: false
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const data = await response.json();
    return { 
      ok: true, 
      text: data.response || '' 
    };
  } catch (error) {
    return { 
      ok: false, 
      text: `(LLM error: ${error instanceof Error ? error.message : 'Unknown error'}). Fallback reply.` 
    };
  }
}
