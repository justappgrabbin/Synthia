import type { CoreValues, NineProjections } from "@shared/schema";

export function clamp(x: number, lo: number = -1, hi: number = 1): number {
  return Math.max(lo, Math.min(hi, x));
}

export interface ParserData {
  aspects?: {
    [key: string]: { weight: number };
  };
  gates?: {
    sunGate?: number;
    active?: number[];
  };
  skills?: {
    Mind?: number;
    Heart?: number;
    Body?: number;
  };
}

export function collapseCore(parser: ParserData): { mind: number; heart: number; body: number } {
  // Lightweight, deterministic-ish core from parser hints
  const a = Number(parser?.aspects?.["Sun conjunct Mercury"]?.weight ?? 0);
  const b = Number(parser?.aspects?.["Mars sextile Saturn"]?.weight ?? 0);
  const sun = Number(parser?.gates?.sunGate ?? 16);
  
  let mind = clamp((a * 0.7 + b * 0.2) * 2 - 1);
  let heart = clamp((a * 0.2 + b * 0.5) * 2 - 1);
  let body = clamp((a * 0.1 + b * 0.3) * 2 - 1);
  
  const mod = sun % 3;
  if (mod === 0) mind = clamp(mind + 0.06);
  if (mod === 1) heart = clamp(heart + 0.06);
  if (mod === 2) body = clamp(body + 0.06);
  
  return { mind, heart, body };
}

export function projectNine(core: { mind: number; heart: number; body: number }, f: number = 0.9): NineProjections {
  const { mind, heart, body } = core;
  const bleed = (a: number, b: number) => clamp(a * f + b * (1 - f));
  
  return {
    id: '', // Will be set by storage
    coreValuesId: '',
    mindPersonal: bleed(mind, body),
    mindInterpersonal: bleed(mind, heart),
    mindTranspersonal: bleed(mind, (heart + body) / 2),
    heartPersonal: bleed(heart, body),
    heartInterpersonal: bleed(heart, mind),
    heartTranspersonal: bleed(heart, (mind + body) / 2),
    bodyPersonal: bleed(body, mind),
    bodyInterpersonal: bleed(body, heart),
    bodyTranspersonal: bleed(body, (mind + heart) / 2)
  };
}

export function modeFrom(core: { mind: number; heart: number; body: number }): { tone: string; focus: string; dominant: string } {
  const ranked = [
    ['mind', core.mind],
    ['heart', core.heart],
    ['body', core.body]
  ].sort((a, b) => (b[1] as number) - (a[1] as number));
  
  const dom = ranked[0][0];
  
  if (dom === 'heart') return { tone: 'empathetic', focus: 'connection', dominant: 'Heart' };
  if (dom === 'mind') return { tone: 'analytical', focus: 'problem-solving', dominant: 'Mind' };
  return { tone: 'practical', focus: 'execution', dominant: 'Body' };
}

export function buildPrompt(input: string, mode: { tone: string; focus: string }): string {
  return `You are Cynthia. Tone: ${mode.tone}. Focus: ${mode.focus}.
Reply briefly, helpfully.

User: ${input}
Cynthia:`;
}
