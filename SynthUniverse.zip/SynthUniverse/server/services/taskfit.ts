import type { TaskFitResult } from "@shared/schema";

export interface Sprite {
  id: string;
  gate: number;
  ring: string;
  level: number;
  copnhfe: Record<string, number>;
  positioning?: string;
  modality?: string;
}

export interface TaskSpec {
  title: string;
  required_axes?: Array<{ axis: string[]; weight: number }>;
  ring_bias?: string[];
  gate_affinity?: number[];
  sun_gate_boost?: boolean;
  min_sprites?: number;
  max_sprites?: number;
  min_team_level?: number;
  difficulty?: number;
}

export function scoreTask(task: TaskSpec, sprites: Sprite[], sunGate: number = 16): TaskFitResult {
  // Lightweight "fit" score 0..100 based on COPNHFE coverage & ring bias
  const axes = (task.required_axes || []).map(x => ({
    axis: x.axis || [],
    weight: Number(x.weight || 0)
  }));
  
  const sum = (o: Record<string, number>) => Object.values(o).reduce((m, x) => m + Number(x || 0), 0);
  
  let team: Record<string, number> = { C: 0, O: 0, P: 0, N: 0, H: 0, F: 0, E: 0 };
  
  for (const s of sprites) {
    for (const k of Object.keys(team)) {
      team[k] += Number(s.copnhfe?.[k] || 0);
    }
  }
  
  const axisScore = axes.reduce((m, a) => {
    const axisSum = a.axis.reduce((acc, k) => acc + (team[k] || 0), 0);
    const avgScore = axisSum / (sprites.length * 100 * a.axis.length || 1);
    return m + a.weight * avgScore;
  }, 0);
  
  const ringBonus = sprites.some(s => task.ring_bias?.includes(s.ring)) ? 0.1 : 0;
  const gateBonus = sprites.some(s => task.gate_affinity?.includes(s.gate)) ? 0.08 : 0;
  const sunBonus = (task.sun_gate_boost && sprites.some(s => s.gate === sunGate)) ? 0.05 : 0;
  
  const raw = Math.max(0, Math.min(1, axisScore + ringBonus + gateBonus + sunBonus));
  const fit = Math.round(raw * 100);
  const tier = fit > 85 ? 'S' : fit > 70 ? 'A' : fit > 55 ? 'B' : fit > 40 ? 'C' : 'D';
  
  return { fit, tier };
}
