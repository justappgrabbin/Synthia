import type { Job, InsertJob } from "@shared/schema";
import { storage } from "../storage";

export async function builderNeed(kind: string, detail: string): Promise<void> {
  await storage.createEvent({
    kind: 'builder_need',
    data: { kind, detail, timestamp: Date.now() }
  });
}

export async function generateJobSpec(kind: string, detail: string, dependencies: string[] = []): Promise<Job> {
  const templates: Record<string, Partial<InsertJob>> = {
    module: { type: 'module', priority: 1, requires: ['code', 'tests'] },
    city: { type: 'city', priority: 2, requires: ['agents', 'skills', 'config'] },
    skill: { type: 'skill', priority: 1.5, requires: ['logic', 'training'] }
  };
  
  const template = templates[kind] || templates.module;
  const jobData: InsertJob = {
    name: detail,
    type: template.type || 'module',
    priority: template.priority || 1,
    requires: template.requires || [],
    dependencies,
    status: 'pending'
  };
  
  const job = await storage.createJob(jobData);
  return job;
}

export async function delegateJob(jobId: string, agentUrl: string): Promise<{ ok: boolean; error?: string; result?: any }> {
  const job = await storage.getJobById(jobId);
  if (!job || !agentUrl) {
    return { ok: false, error: 'Invalid job or agent URL' };
  }
  
  try {
    const response = await fetch(agentUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(job)
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    
    const result = await response.json();
    
    await builderNeed('delegation', `Job ${job.name} -> ${agentUrl}: ${JSON.stringify(result)}`);
    await storage.updateJob(jobId, { status: 'delegated' });
    
    return { ok: true, result };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    await builderNeed('error', `Delegation failed for ${job.name}: ${errorMessage}`);
    return { ok: false, error: errorMessage };
  }
}

export async function integrateModule(moduleName: string, code: string): Promise<{ ok: boolean; module: string }> {
  await storage.createModule({
    name: moduleName,
    code: code || 'export default () => ({ ok: true });',
    active: true
  });
  
  await builderNeed('module', `Integrated ${moduleName}`);
  return { ok: true, module: moduleName };
}
