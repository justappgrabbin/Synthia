import type { Skill } from "@shared/schema";
import { storage } from "../storage";

export function projectAvailability(core: { mind: number; heart: number; body: number }): { Mind: number; Heart: number; Body: number } {
  const clip = (v: number) => Math.max(0, Math.min(1, (v + 1) / 2));
  return {
    Mind: clip(core.mind || 0),
    Heart: clip(core.heart || 0),
    Body: clip(core.body || 0)
  };
}

export async function listAvailable(core: { mind: number; heart: number; body: number }) {
  const avail = projectAvailability(core);
  const nodes = ['Mind', 'Heart', 'Body'] as const;
  const result: Record<string, Array<Skill & { availability: number }>> = {};
  
  for (const node of nodes) {
    const mult = avail[node] || 0;
    const skills = await storage.getAvailableSkills(node, 10);
    
    result[node] = skills.map(s => ({
      ...s,
      availability: Math.round(mult * (50 + s.level * 10))
    })).sort((a, b) => b.availability - a.availability);
  }
  
  return result;
}

export interface SkillApplicationResult {
  ok: boolean;
  reason?: string;
  win?: boolean;
  score?: number;
  level?: number;
  active?: boolean;
  taskFit?: number;
}

export async function applySkill({
  node,
  skillId,
  taskVec = {},
  alignment = 1.0
}: {
  node: string;
  skillId: number;
  taskVec?: Record<string, number>;
  alignment?: number;
}): Promise<SkillApplicationResult> {
  const normalizedNode = node.charAt(0).toUpperCase() + node.slice(1).toLowerCase();
  const skills = await storage.getSkills(normalizedNode);
  const skill = skills.find(s => s.skillId === skillId);
  
  if (!skill || !skill.active) {
    return { ok: false, reason: 'inactive or missing' };
  }
  
  // Simple task fit calculation
  const taskFit = Math.random() * 50 + 30; // 30-80% range
  const score = (taskFit / 100) * alignment;
  const win = score >= 0.42;
  
  // Update skill
  const xpGain = win ? 10 : 2;
  const newXp = skill.xp + xpGain;
  let newLevel = skill.level;
  let finalXp = newXp;
  
  const xpRequired = 50 + skill.level * 25;
  if (newXp >= xpRequired) {
    newLevel++;
    finalXp = 0;
  }
  
  let newActive = skill.active;
  if (!win && alignment < 0.4) {
    newActive = Math.random() > 0.5;
  }
  
  await storage.updateSkill(skill.id, {
    xp: finalXp,
    level: newLevel,
    active: newActive
  });
  
  // Log event
  await storage.createEvent({
    kind: 'apply',
    data: { node: normalizedNode, skillId, win, score, level: newLevel, active: newActive }
  });
  
  return {
    ok: true,
    win,
    score: Number(score.toFixed(3)),
    level: newLevel,
    active: newActive,
    taskFit: Math.round(taskFit)
  };
}

export interface SkillCompositionResult {
  ok: boolean;
  reason?: string;
  win?: boolean;
  score?: number;
  skills?: Array<{ id: string; level: number; active: boolean }>;
  taskFit?: number;
}

export async function composeSkills({
  node,
  k,
  taskVec = {},
  alignment = 1.0,
  core
}: {
  node: string;
  k: number;
  taskVec?: Record<string, number>;
  alignment?: number;
  core: { mind: number; heart: number; body: number };
}): Promise<SkillCompositionResult> {
  const normalizedNode = node.charAt(0).toUpperCase() + node.slice(1).toLowerCase();
  const avail = projectAvailability(core)[normalizedNode as keyof typeof core] || 0;
  
  const skills = await storage.getAvailableSkills(normalizedNode, k * 2);
  const selectedSkills = skills
    .map(s => ({
      ...s,
      availability: Math.round(avail * (50 + s.level * 10))
    }))
    .sort((a, b) => b.availability - a.availability)
    .slice(0, k);
  
  if (selectedSkills.length < k) {
    return { ok: false, reason: `Not enough active skills for k=${k}` };
  }
  
  // Task fit calculation for composition
  const taskFit = Math.random() * 40 + 40; // 40-80% range for composition
  const score = (taskFit / 100) * alignment;
  const win = score >= 0.42;
  
  // Update all selected skills
  for (const skill of selectedSkills) {
    const xpGain = win ? 10 : 2;
    const newXp = skill.xp + xpGain;
    let newLevel = skill.level;
    let finalXp = newXp;
    
    const xpRequired = 50 + skill.level * 25;
    if (newXp >= xpRequired) {
      newLevel++;
      finalXp = 0;
    }
    
    let newActive = skill.active;
    if (!win && alignment < 0.4) {
      newActive = Math.random() > 0.5;
    }
    
    await storage.updateSkill(skill.id, {
      xp: finalXp,
      level: newLevel,
      active: newActive
    });
  }
  
  // Log event
  await storage.createEvent({
    kind: 'compose',
    data: { node: normalizedNode, k, win, score, taskFit: Math.round(taskFit) }
  });
  
  return {
    ok: true,
    win,
    score: Number(score.toFixed(3)),
    skills: selectedSkills.map(s => ({ id: s.id, level: s.level, active: s.active })),
    taskFit: Math.round(taskFit)
  };
}
