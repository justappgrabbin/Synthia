import { 
  type CoreValues, type InsertCoreValues,
  type NineProjections, type InsertNineProjections,
  type Skill, type InsertSkill,
  type Task, type InsertTask,
  type Job, type InsertJob,
  type Recipe, type InsertRecipe,
  type Module, type InsertModule,
  type Event, type InsertEvent,
  type SystemStatus,
  type CollapseSystem,
  type TaskFitResult,
  type SparkleElementCheck,
  type ChatMessage
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Core system
  getCoreValues(): Promise<CoreValues | undefined>;
  createCoreValues(values: InsertCoreValues): Promise<CoreValues>;
  getNineProjections(coreValuesId: string): Promise<NineProjections | undefined>;
  createNineProjections(projections: InsertNineProjections): Promise<NineProjections>;
  
  // Skills
  getSkills(node?: string): Promise<Skill[]>;
  getSkillById(id: string): Promise<Skill | undefined>;
  createSkill(skill: InsertSkill): Promise<Skill>;
  updateSkill(id: string, updates: Partial<Skill>): Promise<Skill>;
  getAvailableSkills(node: string, limit?: number): Promise<Skill[]>;
  
  // Tasks
  getTasks(): Promise<Task[]>;
  getTaskById(id: string): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, updates: Partial<Task>): Promise<Task>;
  deleteTask(id: string): Promise<boolean>;
  
  // Jobs
  getJobs(): Promise<Job[]>;
  getJobById(id: string): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: string, updates: Partial<Job>): Promise<Job>;
  deleteJob(id: string): Promise<boolean>;
  
  // Recipes
  getRecipes(): Promise<Recipe[]>;
  getRecipeById(id: string): Promise<Recipe | undefined>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
  updateRecipes(recipes: InsertRecipe[]): Promise<Recipe[]>;
  
  // Modules
  getModules(): Promise<Module[]>;
  getModuleByName(name: string): Promise<Module | undefined>;
  createModule(module: InsertModule): Promise<Module>;
  updateModule(id: string, updates: Partial<Module>): Promise<Module>;
  
  // Events
  getEvents(limit?: number): Promise<Event[]>;
  createEvent(event: InsertEvent): Promise<Event>;
  
  // System status
  getSystemStatus(): Promise<SystemStatus>;
}

export class MemStorage implements IStorage {
  private coreValues: Map<string, CoreValues> = new Map();
  private nineProjections: Map<string, NineProjections> = new Map();
  private skills: Map<string, Skill> = new Map();
  private tasks: Map<string, Task> = new Map();
  private jobs: Map<string, Job> = new Map();
  private recipes: Map<string, Recipe> = new Map();
  private modules: Map<string, Module> = new Map();
  private events: Map<string, Event> = new Map();
  private startTime: Date = new Date();

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Seed initial recipes
    const defaultRecipes: InsertRecipe[] = [
      {
        recipeId: "TrineSpark",
        label: "Trine Spark",
        gates: [16, 62, 48],
        reward: { xp: 12, shards: 1 }
      },
      {
        recipeId: "MindBloom",
        label: "Mind Bloom",
        gates: [24, 4, 61],
        reward: { xp: 10, shards: 1 }
      }
    ];

    defaultRecipes.forEach(recipe => {
      const id = randomUUID();
      this.recipes.set(id, { ...recipe, id });
    });

    // Seed skills for each node (Mind, Heart, Body) - 64 each
    const nodes = ['Mind', 'Heart', 'Body'];
    nodes.forEach(node => {
      for (let i = 1; i <= 64; i++) {
        const skill: Skill = {
          id: randomUUID(),
          skillId: i,
          name: `${node}-Skill-${i}`,
          node,
          level: 1,
          xp: Math.floor(Math.random() * 50),
          active: Math.random() > 0.3, // 70% chance of being active
          stats: {
            C: 30 + ((i * 7) % 70),
            O: 30 + ((i * 11) % 70),
            P: 30 + ((i * 13) % 70),
            N: 30 + ((i * 17) % 70),
            H: 30 + ((i * 19) % 70),
            F: 30 + ((i * 23) % 70),
            E: 30 + ((i * 29) % 70)
          }
        };
        this.skills.set(skill.id, skill);
      }
    });
  }

  async getCoreValues(): Promise<CoreValues | undefined> {
    return Array.from(this.coreValues.values())[0];
  }

  async createCoreValues(values: InsertCoreValues): Promise<CoreValues> {
    const id = randomUUID();
    const coreValues: CoreValues = { 
      ...values, 
      id, 
      timestamp: new Date() 
    };
    this.coreValues.set(id, coreValues);
    return coreValues;
  }

  async getNineProjections(coreValuesId: string): Promise<NineProjections | undefined> {
    return Array.from(this.nineProjections.values()).find(p => p.coreValuesId === coreValuesId);
  }

  async createNineProjections(projections: InsertNineProjections): Promise<NineProjections> {
    const id = randomUUID();
    const projection: NineProjections = { ...projections, id };
    this.nineProjections.set(id, projection);
    return projection;
  }

  async getSkills(node?: string): Promise<Skill[]> {
    const skills = Array.from(this.skills.values());
    return node ? skills.filter(s => s.node === node) : skills;
  }

  async getSkillById(id: string): Promise<Skill | undefined> {
    return this.skills.get(id);
  }

  async createSkill(skill: InsertSkill): Promise<Skill> {
    const id = randomUUID();
    const newSkill: Skill = { ...skill, id };
    this.skills.set(id, newSkill);
    return newSkill;
  }

  async updateSkill(id: string, updates: Partial<Skill>): Promise<Skill> {
    const skill = this.skills.get(id);
    if (!skill) throw new Error('Skill not found');
    const updated = { ...skill, ...updates };
    this.skills.set(id, updated);
    return updated;
  }

  async getAvailableSkills(node: string, limit: number = 10): Promise<Skill[]> {
    const skills = Array.from(this.skills.values())
      .filter(s => s.node === node && s.active)
      .sort((a, b) => (50 + b.level * 10) - (50 + a.level * 10))
      .slice(0, limit);
    return skills;
  }

  async getTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getTaskById(id: string): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async createTask(task: InsertTask): Promise<Task> {
    const id = randomUUID();
    const newTask: Task = { 
      ...task, 
      id, 
      createdAt: new Date() 
    };
    this.tasks.set(id, newTask);
    return newTask;
  }

  async updateTask(id: string, updates: Partial<Task>): Promise<Task> {
    const task = this.tasks.get(id);
    if (!task) throw new Error('Task not found');
    const updated = { ...task, ...updates };
    this.tasks.set(id, updated);
    return updated;
  }

  async deleteTask(id: string): Promise<boolean> {
    return this.tasks.delete(id);
  }

  async getJobs(): Promise<Job[]> {
    return Array.from(this.jobs.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getJobById(id: string): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async createJob(job: InsertJob): Promise<Job> {
    const id = randomUUID();
    const newJob: Job = { 
      ...job, 
      id, 
      createdAt: new Date() 
    };
    this.jobs.set(id, newJob);
    return newJob;
  }

  async updateJob(id: string, updates: Partial<Job>): Promise<Job> {
    const job = this.jobs.get(id);
    if (!job) throw new Error('Job not found');
    const updated = { ...job, ...updates };
    this.jobs.set(id, updated);
    return updated;
  }

  async deleteJob(id: string): Promise<boolean> {
    return this.jobs.delete(id);
  }

  async getRecipes(): Promise<Recipe[]> {
    return Array.from(this.recipes.values());
  }

  async getRecipeById(id: string): Promise<Recipe | undefined> {
    return this.recipes.get(id);
  }

  async createRecipe(recipe: InsertRecipe): Promise<Recipe> {
    const id = randomUUID();
    const newRecipe: Recipe = { ...recipe, id };
    this.recipes.set(id, newRecipe);
    return newRecipe;
  }

  async updateRecipes(recipes: InsertRecipe[]): Promise<Recipe[]> {
    this.recipes.clear();
    return Promise.all(recipes.map(recipe => this.createRecipe(recipe)));
  }

  async getModules(): Promise<Module[]> {
    return Array.from(this.modules.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getModuleByName(name: string): Promise<Module | undefined> {
    return Array.from(this.modules.values()).find(m => m.name === name);
  }

  async createModule(module: InsertModule): Promise<Module> {
    const id = randomUUID();
    const newModule: Module = { 
      ...module, 
      id, 
      createdAt: new Date() 
    };
    this.modules.set(id, newModule);
    return newModule;
  }

  async updateModule(id: string, updates: Partial<Module>): Promise<Module> {
    const module = this.modules.get(id);
    if (!module) throw new Error('Module not found');
    const updated = { ...module, ...updates };
    this.modules.set(id, updated);
    return updated;
  }

  async getEvents(limit: number = 200): Promise<Event[]> {
    return Array.from(this.events.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const id = randomUUID();
    const newEvent: Event = { 
      ...event, 
      id, 
      timestamp: new Date() 
    };
    this.events.set(id, newEvent);
    return newEvent;
  }

  async getSystemStatus(): Promise<SystemStatus> {
    const now = new Date();
    const uptimeMs = now.getTime() - this.startTime.getTime();
    const hours = Math.floor(uptimeMs / (1000 * 60 * 60));
    const minutes = Math.floor((uptimeMs % (1000 * 60 * 60)) / (1000 * 60));
    
    return {
      websocketConnected: true,
      ollamaReady: !!(process.env.OLLAMA_URL),
      activeModules: Array.from(this.modules.values()).filter(m => m.active).length,
      totalSkills: Array.from(this.skills.values()).filter(s => s.active).length,
      pendingJobs: Array.from(this.jobs.values()).filter(j => j.status === 'pending').length,
      uptime: `${hours}h ${minutes}m`
    };
  }
}

export const storage = new MemStorage();
