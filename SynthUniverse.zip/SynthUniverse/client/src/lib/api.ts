import { apiRequest } from "./queryClient";

export const api = {
  // Collapse system
  analyzeCollapse: (parser?: any) => 
    apiRequest('POST', '/api/collapse/analyze', { parser }),
  
  getCurrentCollapse: () => 
    apiRequest('GET', '/api/collapse/current'),

  // Cities engine
  getSkills: (node?: string) => 
    apiRequest('GET', `/api/cities/skills${node ? `?node=${node}` : ''}`),
  
  getAvailableSkills: (core: any) => 
    apiRequest('POST', '/api/cities/available', { core }),
  
  applySkill: (data: { node: string; skillId: number; taskVec?: any; alignment?: number }) => 
    apiRequest('POST', '/api/cities/apply', data),
  
  composeSkills: (data: { node: string; k: number; taskVec?: any; alignment?: number; core: any }) => 
    apiRequest('POST', '/api/cities/compose', data),

  // Tasks
  getTasks: () => 
    apiRequest('GET', '/api/tasks'),
  
  createTask: (task: any) => 
    apiRequest('POST', '/api/tasks', task),

  // Jobs
  getJobs: () => 
    apiRequest('GET', '/api/jobs'),
  
  createJob: (data: { kind: string; detail: string; dependencies?: string[] }) => 
    apiRequest('POST', '/api/jobs', data),
  
  delegateJob: (data: { jobId: string; agentUrl: string }) => 
    apiRequest('POST', '/api/jobs/delegate', data),

  // Modules
  getModules: () => 
    apiRequest('GET', '/api/modules'),
  
  integrateModule: (data: { moduleName: string; code?: string }) => 
    apiRequest('POST', '/api/modules', data),

  // Sparkle system
  checkSparkleElements: (data: { activeGates: number[]; projection?: any }) => 
    apiRequest('POST', '/api/sparkle/check', data),
  
  getRecipes: () => 
    apiRequest('GET', '/api/sparkle/recipes'),
  
  updateRecipes: (recipes: any[]) => 
    apiRequest('POST', '/api/sparkle/recipes', { recipes }),

  // Chat
  sendChat: (data: { prompt: string; parser?: any; model?: string }) => 
    apiRequest('POST', '/api/chat', data),

  // Coach
  getCoachResponse: (data: { input: string; parser?: any }) => 
    apiRequest('POST', '/api/coach/stub', data),

  // GameGAN
  generateGame: (spec: any) => 
    apiRequest('POST', '/api/gamegan/mock', { spec }),

  // Events
  getEvents: (limit?: number) => 
    apiRequest('GET', `/api/events${limit ? `?limit=${limit}` : ''}`),

  // System
  getHealth: () => 
    apiRequest('GET', '/api/health'),
};
