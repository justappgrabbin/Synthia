import { useState } from "react";
import CollapseSystemPanel from "@/components/collapse-system-panel";
import MainDashboard from "@/components/main-dashboard";
import StatusFooter from "@/components/status-footer";
import WebSocketStatus from "@/components/ui/websocket-status";
import { Brain, Settings, Home, Zap, Star, Building, MessageSquare, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  SidebarInset
} from "@/components/ui/sidebar";

export default function Dashboard() {
  return (
    <SidebarProvider>
      <div className="min-h-screen bg-gray-50 font-roboto flex">
        {/* Side Tray Navigation */}
        <Sidebar>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>SYNTHAI Navigation</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton>
                      <Home className="h-4 w-4" />
                      <span>Dashboard</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton>
                      <Brain className="h-4 w-4" />
                      <span>Collapse System</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton>
                      <Building className="h-4 w-4" />
                      <span>Cities Engine</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton>
                      <Zap className="h-4 w-4" />
                      <span>TaskFit Builder</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton asChild>
                      <a href="/cynthia" className="flex items-center gap-2">
                        <MessageSquare className="h-4 w-4" />
                        <span>Cynthia DIY</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton>
                      <Star className="h-4 w-4" />
                      <span>Sparkle System</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton>
                      <MessageSquare className="h-4 w-4" />
                      <span>LLM Interface</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton>
                      <Activity className="h-4 w-4" />
                      <span>System Status</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        {/* Main Content Area */}
        <SidebarInset>
          {/* Header */}
          <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
            <div className="flex justify-between items-center h-16 px-4">
              {/* Logo and Title with Sidebar Toggle */}
              <div className="flex items-center space-x-4">
                <SidebarTrigger />
                <div className="gradient-mind-heart-body p-2 rounded-lg">
                  <Brain className="text-white text-xl" data-testid="logo-brain" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900" data-testid="app-title">SYNTHAI</h1>
                  <p className="text-xs text-gray-500" data-testid="app-subtitle">You-N-I-Verse Control Center</p>
                </div>
              </div>

              {/* Connection Status */}
              <div className="flex items-center space-x-4">
                <WebSocketStatus />
                <Button variant="ghost" size="sm" data-testid="button-settings">
                  <Settings className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </header>

          {/* Main Dashboard Content */}
          <div className="flex-1 p-4">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <div className="lg:col-span-4">
                <CollapseSystemPanel />
              </div>
              <div className="lg:col-span-8">
                <MainDashboard />
              </div>
            </div>

            {/* Bottom Half - Status Footer */}
            <StatusFooter />
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
