export default function CynthiaPage() {
  return (
    <div className="min-h-screen bg-[#0b0b12] text-white">
      <iframe 
        src="/cynthia.html" 
        className="w-full h-screen border-0"
        title="Cynthia DIY Interface"
      />
    </div>
  );
}