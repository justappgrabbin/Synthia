import { useState, useEffect } from "react";
import { useWebSocket } from "@/hooks/use-websocket";
import { Bot } from "lucide-react";

export default function WebSocketStatus() {
  const { isConnected, lastMessage } = useWebSocket();
  const [ollamaReady, setOllamaReady] = useState(false);

  useEffect(() => {
    if (lastMessage?.type === 'system_status') {
      setOllamaReady(lastMessage.data?.ollamaReady || false);
    }
  }, [lastMessage]);

  return (
    <>
      <div className={`flex items-center space-x-2 px-3 py-1 rounded-full ${
        isConnected ? 'bg-green-50' : 'bg-red-50'
      }`} data-testid="websocket-status">
        <div className={`w-2 h-2 rounded-full ${
          isConnected ? 'bg-green-500 animate-pulse' : 'bg-red-500'
        }`} />
        <span className={`text-sm font-medium ${
          isConnected ? 'text-green-700' : 'text-red-700'
        }`}>
          {isConnected ? 'WebSocket Connected' : 'WebSocket Disconnected'}
        </span>
      </div>
      
      <div className={`flex items-center space-x-2 px-3 py-1 rounded-full ${
        ollamaReady ? 'bg-blue-50' : 'bg-gray-50'
      }`} data-testid="ollama-status">
        <Bot className={`text-sm ${ollamaReady ? 'text-blue-600' : 'text-gray-400'}`} />
        <span className={`text-sm font-medium ${
          ollamaReady ? 'text-blue-700' : 'text-gray-500'
        }`}>
          {ollamaReady ? 'Ollama Ready' : 'Ollama Offline'}
        </span>
      </div>
    </>
  );
}
