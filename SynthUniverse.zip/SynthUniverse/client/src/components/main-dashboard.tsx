import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Building2, Clipboard, Sparkles, Bot } from "lucide-react";
import CitiesEngineTab from "./cities-engine-tab";
import TaskfitBuilderTab from "./taskfit-builder-tab";
import SparkleSystemTab from "./sparkle-system-tab";
import LLMInterfaceTab from "./llm-interface-tab";

export default function MainDashboard() {
  return (
    <Card className="overflow-hidden" data-testid="main-dashboard">
      <Tabs defaultValue="cities" className="w-full">
        <div className="border-b border-gray-200">
          <TabsList className="flex w-full justify-start bg-transparent p-0 h-auto" data-testid="main-tabs">
            <TabsTrigger 
              value="cities" 
              className="flex items-center space-x-2 py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none bg-transparent"
              data-testid="tab-cities"
            >
              <Building2 className="h-4 w-4" />
              <span>Cities Engine</span>
            </TabsTrigger>
            <TabsTrigger 
              value="tasks" 
              className="flex items-center space-x-2 py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none bg-transparent"
              data-testid="tab-tasks"
            >
              <Clipboard className="h-4 w-4" />
              <span>TaskFit & Builder</span>
            </TabsTrigger>
            <TabsTrigger 
              value="sparkle" 
              className="flex items-center space-x-2 py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none bg-transparent"
              data-testid="tab-sparkle"
            >
              <Sparkles className="h-4 w-4" />
              <span>Sparkle System</span>
            </TabsTrigger>
            <TabsTrigger 
              value="llm" 
              className="flex items-center space-x-2 py-4 px-6 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary rounded-none bg-transparent"
              data-testid="tab-llm"
            >
              <Bot className="h-4 w-4" />
              <span>LLM Interface</span>
            </TabsTrigger>
          </TabsList>
        </div>

        <CardContent className="p-6">
          <TabsContent value="cities" className="mt-0">
            <CitiesEngineTab />
          </TabsContent>
          
          <TabsContent value="tasks" className="mt-0">
            <TaskfitBuilderTab />
          </TabsContent>
          
          <TabsContent value="sparkle" className="mt-0">
            <SparkleSystemTab />
          </TabsContent>
          
          <TabsContent value="llm" className="mt-0">
            <LLMInterfaceTab />
          </TabsContent>
        </CardContent>
      </Tabs>
    </Card>
  );
}
