import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Brain, Heart, Activity, Play, Users, ChevronDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/use-websocket";
import { useEffect } from "react";

export default function CitiesEngineTab() {
  const [selectedNode, setSelectedNode] = useState<'Mind' | 'Heart' | 'Body'>('Mind');
  const [skillId, setSkillId] = useState<string>('1');
  const [alignment, setAlignment] = useState<string>('0.9');
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { lastMessage } = useWebSocket();

  // Get current collapse data for core values
  const { data: collapseData } = useQuery({
    queryKey: ['/api/collapse/current'],
    queryFn: () => api.getCurrentCollapse().then(res => res.json()),
  });

  // Get available skills based on core
  const { data: availableSkills, isLoading: skillsLoading } = useQuery({
    queryKey: ['/api/cities/available', collapseData?.core],
    queryFn: () => api.getAvailableSkills(collapseData?.core || { mind: 0, heart: 0, body: 0 }).then(res => res.json()),
    enabled: !!collapseData?.core,
  });

  // Apply skill mutation
  const applySkillMutation = useMutation({
    mutationFn: (data: { node: string; skillId: number; alignment: number }) => 
      api.applySkill(data).then(res => res.json()),
    onSuccess: (result) => {
      if (result.ok) {
        toast({
          title: result.win ? "Success!" : "Partial Success",
          description: `Skill applied with ${(result.score * 100).toFixed(1)}% score. Level: ${result.level}`,
          variant: result.win ? "default" : "destructive",
        });
        queryClient.invalidateQueries({ queryKey: ['/api/cities/available'] });
      } else {
        toast({
          title: "Error",
          description: result.reason || "Failed to apply skill",
          variant: "destructive",
        });
      }
    },
  });

  // Compose skills mutation
  const composeSkillsMutation = useMutation({
    mutationFn: (data: { node: string; k: number; core: any }) => 
      api.composeSkills(data).then(res => res.json()),
    onSuccess: (result) => {
      if (result.ok) {
        toast({
          title: result.win ? "Team Success!" : "Team Partial Success",
          description: `Team composed with ${(result.score * 100).toFixed(1)}% score`,
          variant: result.win ? "default" : "destructive",
        });
        queryClient.invalidateQueries({ queryKey: ['/api/cities/available'] });
      } else {
        toast({
          title: "Error",
          description: result.reason || "Failed to compose team",
          variant: "destructive",
        });
      }
    },
  });

  // Listen for WebSocket updates
  useEffect(() => {
    if (lastMessage?.type === 'skill_applied' || lastMessage?.type === 'skills_composed') {
      queryClient.invalidateQueries({ queryKey: ['/api/cities/available'] });
    }
  }, [lastMessage, queryClient]);

  const handleApplySkill = () => {
    const skillIdNum = parseInt(skillId);
    const alignmentNum = parseFloat(alignment);
    
    if (isNaN(skillIdNum) || skillIdNum < 1 || skillIdNum > 64) {
      toast({
        title: "Invalid Skill ID",
        description: "Skill ID must be between 1 and 64",
        variant: "destructive",
      });
      return;
    }

    if (isNaN(alignmentNum) || alignmentNum < 0 || alignmentNum > 1) {
      toast({
        title: "Invalid Alignment",
        description: "Alignment must be between 0 and 1",
        variant: "destructive",
      });
      return;
    }

    applySkillMutation.mutate({
      node: selectedNode,
      skillId: skillIdNum,
      alignment: alignmentNum,
    });
  };

  const handleComposeTeam = () => {
    if (!collapseData?.core) {
      toast({
        title: "No Core Data",
        description: "Please generate collapse analysis first",
        variant: "destructive",
      });
      return;
    }

    composeSkillsMutation.mutate({
      node: selectedNode,
      k: 3,
      core: collapseData.core,
    });
  };

  const getNodeIcon = (node: string) => {
    switch (node) {
      case 'Mind': return <Brain className="h-4 w-4" />;
      case 'Heart': return <Heart className="h-4 w-4" />;
      case 'Body': return <Activity className="h-4 w-4" />;
      default: return <Brain className="h-4 w-4" />;
    }
  };

  const getNodeColor = (node: string) => {
    switch (node) {
      case 'Mind': return 'mind';
      case 'Heart': return 'heart';
      case 'Body': return 'body';
      default: return 'mind';
    }
  };

  const currentSkills = availableSkills?.list?.[selectedNode] || [];

  return (
    <div className="space-y-6" data-testid="cities-engine-tab">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900" data-testid="cities-title">
          Cities Engine (3×64 Skills)
        </h3>
        <div className="flex space-x-2">
          {(['Mind', 'Heart', 'Body'] as const).map((node) => (
            <Button
              key={node}
              variant={selectedNode === node ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedNode(node)}
              className={`${selectedNode === node ? `bg-${getNodeColor(node)} text-white` : `text-${getNodeColor(node)}`}`}
              data-testid={`filter-${node.toLowerCase()}`}
            >
              {getNodeIcon(node)}
              <span className="ml-1">{node}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Skills Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="font-medium text-gray-900" data-testid={`skills-${selectedNode.toLowerCase()}`}>
            {selectedNode} Skills
          </h4>
          <Button
            onClick={handleComposeTeam}
            disabled={composeSkillsMutation.isPending || !collapseData?.core}
            className={`bg-${getNodeColor(selectedNode)} text-white`}
            data-testid="button-compose-team"
          >
            <Users className="h-4 w-4 mr-2" />
            {composeSkillsMutation.isPending ? 'Composing...' : 'Compose Team'}
          </Button>
        </div>

        {skillsLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2 mb-3"></div>
                  <div className="h-2 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="grid grid-cols-7 gap-1">
                    {Array.from({ length: 7 }).map((_, j) => (
                      <div key={j} className="h-6 bg-gray-200 rounded"></div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {currentSkills.slice(0, 6).map((skill: any, index: number) => (
              <Card 
                key={skill.id} 
                className={`bg-${getNodeColor(selectedNode)}/5 border-${getNodeColor(selectedNode)}/20 hover:shadow-sm transition-shadow`}
                data-testid={`skill-card-${index}`}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-sm text-gray-900" data-testid={`skill-name-${index}`}>
                      {skill.name}
                    </h4>
                    <Badge 
                      className={`bg-${getNodeColor(selectedNode)}/20 text-${getNodeColor(selectedNode)}`}
                      data-testid={`skill-level-${index}`}
                    >
                      Lv.{skill.level}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-600">XP Progress</span>
                      <span data-testid={`skill-xp-${index}`}>
                        {skill.xp}/{50 + skill.level * 25}
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1">
                      <div 
                        className={`bg-${getNodeColor(selectedNode)} h-1 rounded-full`}
                        style={{ width: `${(skill.xp / (50 + skill.level * 25)) * 100}%` }}
                        data-testid={`skill-progress-${index}`}
                      />
                    </div>
                    
                    <div className="grid grid-cols-7 gap-1 text-xs">
                      {['C', 'O', 'P', 'N', 'H', 'F', 'E'].map((stat, statIndex) => (
                        <div key={stat} className="text-center" data-testid={`skill-stat-${index}-${stat}`}>
                          <div className="font-mono text-gray-600">
                            {skill.stats?.[stat] || 0}
                          </div>
                          <div className="text-gray-400">{stat}</div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-600">Availability</span>
                      <span className={`text-${getNodeColor(selectedNode)} font-medium`} data-testid={`skill-availability-${index}`}>
                        {skill.availability || 0}%
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {!skillsLoading && currentSkills.length > 6 && (
          <div className="text-center">
            <Button variant="ghost" className="text-primary" data-testid="button-load-more">
              <ChevronDown className="h-4 w-4 mr-2" />
              Load More Skills ({currentSkills.length - 6} remaining)
            </Button>
          </div>
        )}
      </div>

      {/* Apply Skill Section */}
      <Card>
        <CardContent className="p-4">
          <h4 className="font-medium text-gray-900 mb-4" data-testid="apply-skill-title">Apply Skill</h4>
          <div className="flex flex-wrap gap-4 items-end">
            <div className="flex-1 min-w-32">
              <label className="text-sm font-medium text-gray-700 mb-1 block">
                Skill ID (1-64)
              </label>
              <Input
                type="number"
                min="1"
                max="64"
                value={skillId}
                onChange={(e) => setSkillId(e.target.value)}
                placeholder="Skill ID"
                data-testid="input-skill-id"
              />
            </div>
            <div className="flex-1 min-w-32">
              <label className="text-sm font-medium text-gray-700 mb-1 block">
                Alignment (0-1)
              </label>
              <Input
                type="number"
                min="0"
                max="1"
                step="0.1"
                value={alignment}
                onChange={(e) => setAlignment(e.target.value)}
                placeholder="0.9"
                data-testid="input-alignment"
              />
            </div>
            <Button
              onClick={handleApplySkill}
              disabled={applySkillMutation.isPending}
              className={`bg-${getNodeColor(selectedNode)} text-white`}
              data-testid="button-apply-skill"
            >
              <Play className="h-4 w-4 mr-2" />
              {applySkillMutation.isPending ? 'Applying...' : 'Apply'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
