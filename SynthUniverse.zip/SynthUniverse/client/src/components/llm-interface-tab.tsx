import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Bot, Brain, Heart, Activity, Send, RefreshCw, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/use-websocket";
import { useEffect } from "react";

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  model?: string;
  timestamp: Date;
}

export default function LLMInterfaceTab() {
  const [selectedModel, setSelectedModel] = useState<string>('tinyllama');
  const [chatInput, setChatInput] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { lastMessage } = useWebSocket();

  // Get current collapse data for model selection
  const { data: collapseData } = useQuery({
    queryKey: ['/api/collapse/current'],
    queryFn: () => api.getCurrentCollapse().then(res => res.json()),
  });

  // Get system health for Ollama status
  const { data: healthData } = useQuery({
    queryKey: ['/api/health'],
    queryFn: () => api.getHealth().then(res => res.json()),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Send chat message mutation
  const sendMessageMutation = useMutation({
    mutationFn: (data: { prompt: string; model?: string; parser?: any }) => 
      api.sendChat(data).then(res => res.json()),
    onSuccess: (result) => {
      // Add assistant response
      const assistantMessage: ChatMessage = {
        id: Date.now().toString() + '-assistant',
        role: 'assistant',
        content: result.reply,
        model: selectedModel,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMessage]);
      setChatInput('');
      
      toast({
        title: "Response Received",
        description: `Reply from Cynthia (${result.mode?.dominant || 'Unknown'} mode)`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    },
  });

  // Listen for WebSocket updates
  useEffect(() => {
    if (lastMessage?.type === 'chat_response') {
      const assistantMessage: ChatMessage = {
        id: Date.now().toString() + '-ws',
        role: 'assistant',
        content: lastMessage.data.reply,
        model: selectedModel,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMessage]);
    }
  }, [lastMessage, selectedModel]);

  // Auto-select model based on dominant mode
  useEffect(() => {
    if (collapseData?.mode?.dominant) {
      const modelMap: Record<string, string> = {
        'Mind': 'tinyllama',
        'Heart': 'mistral',
        'Body': 'phi'
      };
      const suggestedModel = modelMap[collapseData.mode.dominant];
      if (suggestedModel) {
        setSelectedModel(suggestedModel);
      }
    }
  }, [collapseData?.mode?.dominant]);

  const handleSendMessage = () => {
    if (!chatInput.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a message",
        variant: "destructive",
      });
      return;
    }

    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now().toString() + '-user',
      role: 'user',
      content: chatInput,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);

    // Send to API
    sendMessageMutation.mutate({
      prompt: chatInput,
      model: selectedModel,
      parser: collapseData?.parser,
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getModelIcon = (model: string) => {
    switch (model) {
      case 'tinyllama': return <Brain className="h-4 w-4" />;
      case 'mistral': return <Heart className="h-4 w-4" />;
      case 'phi': return <Activity className="h-4 w-4" />;
      default: return <Bot className="h-4 w-4" />;
    }
  };

  const getModelName = (model: string) => {
    switch (model) {
      case 'tinyllama': return 'TinyLlama (Mind)';
      case 'mistral': return 'Mistral (Heart)';
      case 'phi': return 'Phi (Body)';
      default: return model;
    }
  };

  const getModelColor = (model: string) => {
    switch (model) {
      case 'tinyllama': return 'mind';
      case 'mistral': return 'heart';
      case 'phi': return 'body';
      default: return 'primary';
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6" data-testid="llm-interface-tab">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900" data-testid="llm-title">
          LLM Interface
        </h3>
        <div className="flex items-center space-x-2">
          <Select value={selectedModel} onValueChange={setSelectedModel}>
            <SelectTrigger className="w-48" data-testid="select-model">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="tinyllama">
                <div className="flex items-center space-x-2">
                  <Brain className="h-4 w-4 text-mind" />
                  <span>TinyLlama (Mind)</span>
                </div>
              </SelectItem>
              <SelectItem value="mistral">
                <div className="flex items-center space-x-2">
                  <Heart className="h-4 w-4 text-heart" />
                  <span>Mistral (Heart)</span>
                </div>
              </SelectItem>
              <SelectItem value="phi">
                <div className="flex items-center space-x-2">
                  <Activity className="h-4 w-4 text-body" />
                  <span>Phi (Body)</span>
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/health'] })}
            data-testid="button-refresh-models"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh Models
          </Button>
        </div>
      </div>

      {/* Ollama Status Warning */}
      {healthData && !healthData.ollamaReady && (
        <Card className="bg-yellow-50 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Bot className="h-5 w-5 text-yellow-600" />
              <div>
                <p className="font-medium text-yellow-800">Ollama Not Connected</p>
                <p className="text-sm text-yellow-700">
                  Set the OLLAMA_URL environment variable to enable LLM functionality
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Chat Interface */}
      <Card className="h-96">
        <CardContent className="p-0 h-full flex flex-col">
          <ScrollArea className="flex-1 p-4" data-testid="chat-messages">
            {messages.length === 0 ? (
              <div className="text-center text-gray-500 mt-8">
                <Bot className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p data-testid="no-messages">Start a conversation with Cynthia</p>
                <p className="text-sm text-gray-400 mt-1">
                  Ask about system analysis, skills, or anything else
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    data-testid={`message-${message.role}`}
                  >
                    <div
                      className={`max-w-xs rounded-lg p-3 ${
                        message.role === 'user'
                          ? 'bg-primary text-white'
                          : `bg-${getModelColor(message.model || selectedModel)}/10 border border-${getModelColor(message.model || selectedModel)}/20`
                      }`}
                    >
                      <div className={`text-xs mb-1 ${
                        message.role === 'user' 
                          ? 'text-primary-100' 
                          : `text-${getModelColor(message.model || selectedModel)}`
                      }`}>
                        {message.role === 'user' ? (
                          <div className="flex items-center space-x-1">
                            <User className="h-3 w-3" />
                            <span>You</span>
                          </div>
                        ) : (
                          <div className="flex items-center space-x-1">
                            {getModelIcon(message.model || selectedModel)}
                            <span>Cynthia ({getModelName(message.model || selectedModel)})</span>
                          </div>
                        )}
                        <span className="ml-auto">{formatTime(message.timestamp)}</span>
                      </div>
                      <div className="text-sm" data-testid="message-content">
                        {message.content}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>

          {/* Input Area */}
          <div className="border-t p-4">
            <div className="flex space-x-4">
              <Input
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask Cynthia something..."
                className="flex-1"
                disabled={sendMessageMutation.isPending}
                data-testid="input-chat"
              />
              <Button
                onClick={handleSendMessage}
                disabled={sendMessageMutation.isPending || !chatInput.trim()}
                className="bg-primary text-white hover:bg-primary/90"
                data-testid="button-send-message"
              >
                <Send className="h-4 w-4 mr-2" />
                {sendMessageMutation.isPending ? 'Sending...' : 'Send'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Model Status */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { key: 'tinyllama', name: 'Mind (TinyLlama)', icon: Brain, color: 'mind' },
          { key: 'mistral', name: 'Heart (Mistral)', icon: Heart, color: 'heart' },
          { key: 'phi', name: 'Body (Phi)', icon: Activity, color: 'body' }
        ].map(({ key, name, icon: Icon, color }) => (
          <Card 
            key={key} 
            className={`bg-${color}/10 border-${color}/20`}
            data-testid={`model-status-${key}`}
          >
            <CardContent className="p-4 text-center">
              <Icon className={`text-${color} text-xl mx-auto mb-2 h-8 w-8`} />
              <div className={`font-medium text-${color}`} data-testid={`model-name-${key}`}>
                {name}
              </div>
              <div className="text-xs text-gray-600 mt-1" data-testid={`model-status-text-${key}`}>
                {healthData?.ollamaReady ? 'Ready' : 'Offline'}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Current Mode Display */}
      {collapseData?.mode && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <h5 className="font-medium text-blue-900 mb-2">Current AI Mode</h5>
            <div className="text-sm text-blue-700">
              <div><strong>Dominant:</strong> {collapseData.mode.dominant}</div>
              <div><strong>Tone:</strong> {collapseData.mode.tone}</div>
              <div><strong>Focus:</strong> {collapseData.mode.focus}</div>
              <div className="mt-2 text-xs text-blue-600">
                Recommended model: {getModelName(selectedModel)}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
