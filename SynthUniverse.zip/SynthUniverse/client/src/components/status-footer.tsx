import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Card, CardContent } from "@/components/ui/card";
import { Box, Star, Clipboard, Clock, Activity, Database, Zap } from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";
import { useEffect } from "react";

export default function StatusFooter() {
  const { lastMessage } = useWebSocket();

  // Get system status
  const { data: systemStatus, isLoading } = useQuery({
    queryKey: ['/api/health'],
    queryFn: () => api.getHealth().then(res => res.json()),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Get additional stats
  const { data: modules = [] } = useQuery({
    queryKey: ['/api/modules'],
    queryFn: () => api.getModules().then(res => res.json()),
  });

  const { data: jobs = [] } = useQuery({
    queryKey: ['/api/jobs'],
    queryFn: () => api.getJobs().then(res => res.json()),
  });

  const { data: events = [] } = useQuery({
    queryKey: ['/api/events'],
    queryFn: () => api.getEvents(100).then(res => res.json()),
  });

  // Calculate derived stats
  const activeModules = modules.filter((m: any) => m.active).length;
  const pendingJobs = jobs.filter((j: any) => j.status === 'pending').length;
  const recentEvents = events.length;

  const stats = [
    {
      label: "Active Modules",
      value: isLoading ? "..." : activeModules.toString(),
      icon: Box,
      color: "text-primary",
      testId: "stat-modules"
    },
    {
      label: "Total Skills",
      value: isLoading ? "..." : systemStatus?.totalSkills?.toString() || "192",
      icon: Star,
      color: "text-warning",
      testId: "stat-skills"
    },
    {
      label: "Pending Jobs",
      value: isLoading ? "..." : pendingJobs.toString(),
      icon: Clipboard,
      color: "text-secondary",
      testId: "stat-jobs"
    },
    {
      label: "Uptime",
      value: isLoading ? "..." : systemStatus?.uptime || "0h 0m",
      icon: Clock,
      color: "text-success",
      testId: "stat-uptime"
    },
    {
      label: "WebSocket",
      value: systemStatus?.websocketConnected ? "Connected" : "Disconnected",
      icon: Zap,
      color: systemStatus?.websocketConnected ? "text-green-600" : "text-red-600",
      testId: "stat-websocket"
    },
    {
      label: "Recent Events",
      value: recentEvents.toString(),
      icon: Activity,
      color: "text-blue-600",
      testId: "stat-events"
    }
  ];

  if (isLoading) {
    return (
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4" data-testid="status-footer">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="h-3 bg-gray-200 rounded w-20 mb-2"></div>
                  <div className="h-6 bg-gray-200 rounded w-12"></div>
                </div>
                <div className="w-5 h-5 bg-gray-200 rounded"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="mt-8" data-testid="status-footer">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {stats.map((stat, index) => (
          <Card 
            key={stat.label} 
            className="bg-white shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
            data-testid={stat.testId}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600" data-testid={`${stat.testId}-label`}>
                    {stat.label}
                  </p>
                  <p 
                    className="text-2xl font-bold text-gray-900" 
                    data-testid={`${stat.testId}-value`}
                  >
                    {stat.value}
                  </p>
                </div>
                <stat.icon className={`${stat.color} text-xl h-6 w-6`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* System Health Indicator */}
      <Card className="mt-4 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`w-3 h-3 rounded-full ${
                systemStatus?.websocketConnected && systemStatus?.ollamaReady 
                  ? 'bg-green-500 animate-pulse' 
                  : systemStatus?.websocketConnected
                  ? 'bg-yellow-500'
                  : 'bg-red-500'
              }`} />
              <div>
                <p className="font-medium text-gray-900" data-testid="system-health-title">
                  System Health
                </p>
                <p className="text-sm text-gray-600" data-testid="system-health-status">
                  {systemStatus?.websocketConnected && systemStatus?.ollamaReady 
                    ? 'All systems operational' 
                    : systemStatus?.websocketConnected
                    ? 'WebSocket connected, Ollama offline'
                    : 'System offline'}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-500">Server: localhost:8000</p>
              <p className="text-xs text-gray-400">
                Last updated: {new Date().toLocaleTimeString()}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
