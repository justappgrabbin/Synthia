import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Clock, ExternalLink, Edit, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/use-websocket";
import { useEffect } from "react";

export default function TaskfitBuilderTab() {
  const [newTaskOpen, setNewTaskOpen] = useState(false);
  const [taskTitle, setTaskTitle] = useState("");
  const [taskDescription, setTaskDescription] = useState("");
  const [delegateJobId, setDelegateJobId] = useState("");
  const [agentUrl, setAgentUrl] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { lastMessage } = useWebSocket();

  // Get tasks
  const { data: tasks = [], isLoading: tasksLoading } = useQuery({
    queryKey: ['/api/tasks'],
    queryFn: () => api.getTasks().then(res => res.json()),
  });

  // Get jobs
  const { data: jobs = [], isLoading: jobsLoading } = useQuery({
    queryKey: ['/api/jobs'],
    queryFn: () => api.getJobs().then(res => res.json()),
  });

  // Create task mutation
  const createTaskMutation = useMutation({
    mutationFn: (taskData: any) => api.createTask(taskData).then(res => res.json()),
    onSuccess: () => {
      toast({
        title: "Task Created",
        description: "New task has been created successfully",
      });
      setNewTaskOpen(false);
      setTaskTitle("");
      setTaskDescription("");
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create task",
        variant: "destructive",
      });
    },
  });

  // Create job mutation
  const createJobMutation = useMutation({
    mutationFn: (jobData: { kind: string; detail: string; dependencies?: string[] }) => 
      api.createJob(jobData).then(res => res.json()),
    onSuccess: () => {
      toast({
        title: "Job Created",
        description: "New job has been added to the queue",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/jobs'] });
    },
  });

  // Delegate job mutation
  const delegateJobMutation = useMutation({
    mutationFn: (data: { jobId: string; agentUrl: string }) => 
      api.delegateJob(data).then(res => res.json()),
    onSuccess: (result) => {
      if (result.ok) {
        toast({
          title: "Job Delegated",
          description: "Job has been successfully delegated to the agent",
        });
        queryClient.invalidateQueries({ queryKey: ['/api/jobs'] });
      } else {
        toast({
          title: "Delegation Failed",
          description: result.error || "Failed to delegate job",
          variant: "destructive",
        });
      }
    },
  });

  // Listen for WebSocket updates
  useEffect(() => {
    if (lastMessage?.type === 'task_created') {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
    }
    if (lastMessage?.type === 'job_created' || lastMessage?.type === 'job_delegated') {
      queryClient.invalidateQueries({ queryKey: ['/api/jobs'] });
    }
  }, [lastMessage, queryClient]);

  const handleCreateTask = () => {
    if (!taskTitle.trim()) {
      toast({
        title: "Validation Error",
        description: "Task title is required",
        variant: "destructive",
      });
      return;
    }

    const taskData = {
      title: taskTitle,
      description: taskDescription,
      requiredAxes: [
        { axis: ['C', 'O', 'P'], weight: 0.33 }
      ],
      ringBias: ['Inner'],
      difficulty: 3,
      minSprites: 1,
      maxSprites: 3,
      minTeamLevel: 1,
    };

    createTaskMutation.mutate(taskData);
  };

  const handleCreateJob = (kind: string) => {
    const detail = `${kind.charAt(0).toUpperCase() + kind.slice(1)} enhancement requested`;
    createJobMutation.mutate({ kind, detail });
  };

  const handleDelegateJob = (jobId: string) => {
    if (!agentUrl.trim()) {
      toast({
        title: "Validation Error",
        description: "Agent URL is required",
        variant: "destructive",
      });
      return;
    }

    delegateJobMutation.mutate({ jobId, agentUrl });
  };

  const formatTimeAgo = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor(diffMs / (1000 * 60));
    
    if (diffHours > 0) {
      return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    } else if (diffMinutes > 0) {
      return `${diffMinutes} minute${diffMinutes > 1 ? 's' : ''} ago`;
    } else {
      return 'Just now';
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'S': return 'bg-purple-100 text-purple-800';
      case 'A': return 'bg-green-100 text-green-800';
      case 'B': return 'bg-blue-100 text-blue-800';
      case 'C': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6" data-testid="taskfit-builder-tab">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900" data-testid="taskfit-title">
          TaskFit & Builder System
        </h3>
        <div className="flex space-x-2">
          <Dialog open={newTaskOpen} onOpenChange={setNewTaskOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary text-white hover:bg-primary/90" data-testid="button-new-task">
                <Plus className="h-4 w-4 mr-2" />
                New Task
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Task</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1 block">
                    Task Title
                  </label>
                  <Input
                    value={taskTitle}
                    onChange={(e) => setTaskTitle(e.target.value)}
                    placeholder="Enter task title"
                    data-testid="input-task-title"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1 block">
                    Description
                  </label>
                  <Textarea
                    value={taskDescription}
                    onChange={(e) => setTaskDescription(e.target.value)}
                    placeholder="Enter task description"
                    rows={3}
                    data-testid="textarea-task-description"
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setNewTaskOpen(false)}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleCreateTask}
                    disabled={createTaskMutation.isPending}
                    data-testid="button-create-task"
                  >
                    {createTaskMutation.isPending ? 'Creating...' : 'Create Task'}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          
          <Button 
            variant="outline" 
            onClick={() => handleCreateJob('module')}
            disabled={createJobMutation.isPending}
            data-testid="button-quick-job"
          >
            Quick Job
          </Button>
        </div>
      </div>

      {/* Active Tasks */}
      <div className="space-y-4">
        <h4 className="font-medium text-gray-900" data-testid="active-tasks-title">Active Tasks</h4>
        
        {tasksLoading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2 mb-3"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : tasks.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500" data-testid="no-tasks-message">No active tasks</p>
              <p className="text-sm text-gray-400 mt-1">Create your first task to get started</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {tasks.map((task: any, index: number) => (
              <Card key={task.id} className="bg-gray-50 border-gray-200" data-testid={`task-card-${index}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h5 className="font-medium text-gray-900" data-testid={`task-name-${index}`}>
                        {task.title}
                      </h5>
                      <p className="text-sm text-gray-600" data-testid={`task-description-${index}`}>
                        {task.description || 'No description provided'}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      {task.tier && (
                        <Badge className={getTierColor(task.tier)} data-testid={`task-tier-${index}`}>
                          Tier {task.tier}
                        </Badge>
                      )}
                      {task.fit && (
                        <Badge className="bg-blue-100 text-blue-800" data-testid={`task-fit-${index}`}>
                          {task.fit}% Fit
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm mb-3">
                    <div>
                      <span className="text-gray-500">Difficulty:</span>
                      <span className="ml-2 text-gray-900" data-testid={`task-difficulty-${index}`}>
                        {task.difficulty || 3}/5
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-500">Sprites:</span>
                      <span className="ml-2 text-gray-900" data-testid={`task-sprites-${index}`}>
                        {task.minSprites || 1}-{task.maxSprites || 3}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-gray-500 flex items-center" data-testid={`task-timestamp-${index}`}>
                      <Clock className="h-3 w-3 mr-1" />
                      Created {formatTimeAgo(task.createdAt)}
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm" data-testid={`button-edit-task-${index}`}>
                        <Edit className="h-3 w-3 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Jobs Queue */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="font-medium text-gray-900" data-testid="jobs-queue-title">Builder Jobs Queue</h4>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleCreateJob('module')}
              disabled={createJobMutation.isPending}
              data-testid="button-create-module-job"
            >
              + Module
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleCreateJob('city')}
              disabled={createJobMutation.isPending}
              data-testid="button-create-city-job"
            >
              + City
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleCreateJob('skill')}
              disabled={createJobMutation.isPending}
              data-testid="button-create-skill-job"
            >
              + Skill
            </Button>
          </div>
        </div>
        
        {jobsLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-gray-200 rounded-full"></div>
                      <div>
                        <div className="h-3 bg-gray-200 rounded w-32 mb-1"></div>
                        <div className="h-2 bg-gray-200 rounded w-20"></div>
                      </div>
                    </div>
                    <div className="h-6 bg-gray-200 rounded w-16"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : jobs.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500" data-testid="no-jobs-message">No pending jobs</p>
              <p className="text-sm text-gray-400 mt-1">Create jobs to start building</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {jobs.map((job: any, index: number) => (
              <Card 
                key={job.id} 
                className="hover:shadow-sm transition-shadow"
                data-testid={`job-card-${index}`}
              >
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-2 h-2 rounded-full ${
                        job.status === 'pending' ? 'bg-warning animate-pulse-slow' : 
                        job.status === 'delegated' ? 'bg-blue-500' : 'bg-success'
                      }`} />
                      <div>
                        <div className="font-medium text-sm text-gray-900" data-testid={`job-name-${index}`}>
                          {job.name}
                        </div>
                        <div className="text-xs text-gray-500" data-testid={`job-type-${index}`}>
                          Type: {job.type} • Priority: {job.priority} • Status: {job.status}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {Array.isArray(job.dependencies) && job.dependencies.length > 0 && (
                        <span className="text-xs text-gray-500" data-testid={`job-dependencies-${index}`}>
                          {job.dependencies.length} dependencies
                        </span>
                      )}
                      {job.status === 'pending' && (
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => setDelegateJobId(job.id)}
                              data-testid={`button-delegate-${index}`}
                            >
                              <Send className="h-3 w-3 mr-1" />
                              Delegate
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Delegate Job</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <label className="text-sm font-medium text-gray-700 mb-1 block">
                                  Agent URL
                                </label>
                                <Input
                                  value={agentUrl}
                                  onChange={(e) => setAgentUrl(e.target.value)}
                                  placeholder="https://agent.example.com/api"
                                  data-testid="input-agent-url"
                                />
                              </div>
                              <div className="flex justify-end space-x-2">
                                <Button variant="outline">Cancel</Button>
                                <Button 
                                  onClick={() => handleDelegateJob(delegateJobId)}
                                  disabled={delegateJobMutation.isPending}
                                  data-testid="button-confirm-delegate"
                                >
                                  {delegateJobMutation.isPending ? 'Delegating...' : 'Delegate'}
                                </Button>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
