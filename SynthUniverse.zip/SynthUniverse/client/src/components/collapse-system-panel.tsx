import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Brain, Heart, Activity, RefreshCw } from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";
import { useEffect } from "react";

export default function CollapseSystemPanel() {
  const queryClient = useQueryClient();
  const { lastMessage } = useWebSocket();

  const { data: collapseData, isLoading } = useQuery({
    queryKey: ['/api/collapse/current'],
    queryFn: () => api.getCurrentCollapse().then(res => res.json()),
  });

  const analyzeMutation = useMutation({
    mutationFn: (parser?: any) => api.analyzeCollapse(parser).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/collapse/current'] });
    },
  });

  // Listen for WebSocket updates
  useEffect(() => {
    if (lastMessage?.type === 'collapse_update') {
      queryClient.setQueryData(['/api/collapse/current'], lastMessage.data);
    }
  }, [lastMessage, queryClient]);

  const core = collapseData?.core;
  const projections = collapseData?.projections;
  const mode = collapseData?.mode;

  const getProgressValue = (value: number) => Math.round(((value + 1) / 2) * 100);

  const nineProjectionEntries = projections ? [
    ['Mind-Personal', projections.mindPersonal],
    ['Mind-Inter', projections.mindInterpersonal],
    ['Mind-Trans', projections.mindTranspersonal],
    ['Heart-Personal', projections.heartPersonal],
    ['Heart-Inter', projections.heartInterpersonal],
    ['Heart-Trans', projections.heartTranspersonal],
    ['Body-Personal', projections.bodyPersonal],
    ['Body-Inter', projections.bodyInterpersonal],
    ['Body-Trans', projections.bodyTranspersonal],
  ] : [];

  if (isLoading) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="gradient-mind-heart-body text-white p-4 rounded-t-lg">
            Collapse System
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-5/6"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden" data-testid="collapse-system-panel">
      <div className="gradient-mind-heart-body p-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-white" data-testid="panel-title">Collapse System</h2>
            <p className="text-sm text-white/80" data-testid="panel-subtitle">Mind • Heart • Body Projection</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => analyzeMutation.mutate()}
            disabled={analyzeMutation.isPending}
            className="bg-white/20 border-white/30 text-white hover:bg-white/30"
            data-testid="button-refresh-collapse"
          >
            <RefreshCw className={`h-4 w-4 ${analyzeMutation.isPending ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>
      
      <CardContent className="p-6 space-y-6">
        {/* Core Values */}
        <div className="space-y-4">
          <h3 className="font-medium text-gray-900" data-testid="core-values-title">Core Values</h3>
          
          {core && (
            <>
              {/* Mind */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-mind flex items-center">
                    <Brain className="h-4 w-4 mr-1" />
                    Mind
                  </span>
                  <span className="text-sm font-mono" data-testid="text-mind-value">
                    {core.mind.toFixed(2)}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-mind h-2 rounded-full transition-all duration-500" 
                    style={{ width: `${getProgressValue(core.mind)}%` }}
                    data-testid="progress-mind"
                  />
                </div>
              </div>

              {/* Heart */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-heart flex items-center">
                    <Heart className="h-4 w-4 mr-1" />
                    Heart
                  </span>
                  <span className="text-sm font-mono" data-testid="text-heart-value">
                    {core.heart.toFixed(2)}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-heart h-2 rounded-full transition-all duration-500" 
                    style={{ width: `${getProgressValue(core.heart)}%` }}
                    data-testid="progress-heart"
                  />
                </div>
              </div>

              {/* Body */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-body flex items-center">
                    <Activity className="h-4 w-4 mr-1" />
                    Body
                  </span>
                  <span className="text-sm font-mono" data-testid="text-body-value">
                    {core.body.toFixed(2)}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-body h-2 rounded-full transition-all duration-500" 
                    style={{ width: `${getProgressValue(core.body)}%` }}
                    data-testid="progress-body"
                  />
                </div>
              </div>
            </>
          )}
        </div>

        {/* Nine Projections Grid */}
        {projections && (
          <div className="space-y-4">
            <h3 className="font-medium text-gray-900" data-testid="nine-projections-title">Nine Projections</h3>
            <div className="grid grid-cols-3 gap-3">
              {nineProjectionEntries.map(([name, value], index) => (
                <div 
                  key={name} 
                  className="bg-gray-50 rounded-lg p-3 text-center"
                  data-testid={`projection-${index}`}
                >
                  <div className="text-xs font-medium text-gray-600 mb-1" data-testid={`projection-name-${index}`}>
                    {name}
                  </div>
                  <div className="text-sm font-mono font-medium text-gray-900" data-testid={`projection-value-${index}`}>
                    {typeof value === 'number' ? value.toFixed(2) : '0.00'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Current Mode */}
        {mode && (
          <div className="bg-mind/10 border border-mind/20 rounded-lg p-4" data-testid="current-mode">
            <div className="flex items-center space-x-2 mb-2">
              <Brain className="text-mind" />
              <span className="font-medium text-mind" data-testid="mode-title">Dominant Mode</span>
            </div>
            <div className="text-sm text-gray-700">
              <div data-testid="mode-tone">
                <strong>Tone:</strong> {mode.tone}
              </div>
              <div data-testid="mode-focus">
                <strong>Focus:</strong> {mode.focus}
              </div>
            </div>
          </div>
        )}

        {!core && !isLoading && (
          <div className="text-center py-8">
            <p className="text-gray-500 mb-4" data-testid="no-data-message">No collapse data available</p>
            <Button 
              onClick={() => analyzeMutation.mutate()}
              disabled={analyzeMutation.isPending}
              data-testid="button-generate-initial"
            >
              {analyzeMutation.isPending ? 'Generating...' : 'Generate Initial Analysis'}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
