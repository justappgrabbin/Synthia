import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, Star, Gift, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/use-websocket";
import { useEffect } from "react";

export default function SparkleSystemTab() {
  const [activeGates, setActiveGates] = useState<number[]>([16, 48, 4]);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { lastMessage } = useWebSocket();

  // Get recipes
  const { data: recipes = [], isLoading: recipesLoading } = useQuery({
    queryKey: ['/api/sparkle/recipes'],
    queryFn: () => api.getRecipes().then(res => res.json()),
  });

  // Check sparkle elements
  const { data: elementCheck, isLoading: checkLoading } = useQuery({
    queryKey: ['/api/sparkle/check', activeGates],
    queryFn: () => api.checkSparkleElements({ activeGates }).then(res => res.json()),
    enabled: activeGates.length > 0,
  });

  // Complete recipe mutation
  const completeRecipeMutation = useMutation({
    mutationFn: (recipeId: string) => {
      // In a real implementation, this would mark the recipe as completed
      return Promise.resolve({ ok: true, recipeId });
    },
    onSuccess: (result) => {
      toast({
        title: "Recipe Completed!",
        description: `Successfully completed recipe: ${result.recipeId}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/sparkle/check'] });
    },
  });

  // Listen for WebSocket updates
  useEffect(() => {
    if (lastMessage?.type === 'recipes_updated') {
      queryClient.invalidateQueries({ queryKey: ['/api/sparkle/recipes'] });
    }
  }, [lastMessage, queryClient]);

  // Generate all possible gates (1-64)
  const allGates = Array.from({ length: 64 }, (_, i) => i + 1);
  
  // Mock gate names for display
  const getGateName = (gate: number) => {
    const names = [
      'Skill', 'Detail', 'Order', 'Formulas', 'Fixed', 'Conflict', 'Army', 'Contribution',
      'Focus', 'Behavior', 'Ideas', 'Caution', 'Attainment', 'Power', 'Love', 'Enthusiasm',
      'Following', 'Correction', 'Approach', 'Now', 'Awakening', 'Grace', 'Splitting',
      'Return', 'Innocence', 'Taming', 'Nourishment', 'Preponderance', 'Abysmal', 'Clinging',
      'Influence', 'Duration', 'Retreat', 'Power', 'Progress', 'Darkening', 'Family',
      'Opposition', 'Obstruction', 'Deliverance', 'Decrease', 'Increase', 'Breakthrough',
      'Coming', 'Gathering', 'Pushing', 'Exhaustion', 'Well', 'Revolution', 'Cauldron',
      'Arousing', 'Keeping', 'Development', 'Marrying', 'Abundance', 'Wanderer', 'Gentle',
      'Joyous', 'Dispersion', 'Limitation', 'Truth', 'Doubt', 'Thunder', 'Mystery'
    ];
    return names[(gate - 1) % names.length];
  };

  const toggleGate = (gate: number) => {
    setActiveGates(prev => 
      prev.includes(gate) 
        ? prev.filter(g => g !== gate)
        : [...prev, gate]
    );
  };

  const isRecipeReady = (recipe: any) => {
    const recipeGates = Array.isArray(recipe.gates) ? recipe.gates : [];
    return recipeGates.every(gate => activeGates.includes(gate));
  };

  return (
    <div className="space-y-6" data-testid="sparkle-system-tab">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900" data-testid="sparkle-title">
          Sparkle Recipe System
        </h3>
        <Button 
          className="bg-warning text-white hover:bg-warning/90"
          onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/sparkle/check'] })}
          disabled={checkLoading}
          data-testid="button-check-elements"
        >
          <Sparkles className="h-4 w-4 mr-2" />
          {checkLoading ? 'Checking...' : 'Check Elements'}
        </Button>
      </div>

      {/* Element Check Result */}
      {elementCheck?.element && (
        <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-warning/20 rounded-full">
                <Star className="h-6 w-6 text-warning" />
              </div>
              <div>
                <h4 className="font-semibold text-gray-900" data-testid="completed-element-title">
                  Element Completed: {elementCheck.label}
                </h4>
                <p className="text-sm text-gray-600" data-testid="completed-element-reward">
                  Reward: {elementCheck.reward?.xp || 0} XP, {elementCheck.reward?.shards || 0} Shards
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Active Gates Display */}
      <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200">
        <CardContent className="p-6">
          <h4 className="font-medium text-gray-900 mb-4" data-testid="active-gates-title">
            Active Gates ({activeGates.length} selected)
          </h4>
          
          <div className="grid grid-cols-8 gap-3 mb-4">
            {allGates.slice(0, 16).map((gate) => (
              <button
                key={gate}
                onClick={() => toggleGate(gate)}
                className={`p-3 rounded-lg text-center shadow-sm transition-all ${
                  activeGates.includes(gate)
                    ? 'bg-white border-2 border-yellow-300 shadow-md'
                    : 'bg-white border border-gray-200 opacity-60 hover:opacity-80'
                }`}
                data-testid={`gate-${gate}`}
              >
                <div className={`text-lg font-bold ${
                  activeGates.includes(gate) ? 'text-gray-900' : 'text-gray-400'
                }`}>
                  {gate}
                </div>
                <div className={`text-xs ${
                  activeGates.includes(gate) ? 'text-gray-500' : 'text-gray-400'
                }`}>
                  {getGateName(gate)}
                </div>
              </button>
            ))}
          </div>
          
          <div className="text-center">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setActiveGates([])}
              data-testid="button-clear-gates"
            >
              Clear All Gates
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Available Recipes */}
      <div className="space-y-4">
        <h4 className="font-medium text-gray-900" data-testid="recipes-title">Available Recipes</h4>
        
        {recipesLoading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                    </div>
                    <div className="h-6 bg-gray-200 rounded w-16"></div>
                  </div>
                  <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : recipes.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500" data-testid="no-recipes-message">No recipes available</p>
              <p className="text-sm text-gray-400 mt-1">Recipes will appear here when they're loaded</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {recipes.map((recipe: any, index: number) => {
              const isReady = isRecipeReady(recipe);
              const recipeGates = Array.isArray(recipe.gates) ? recipe.gates : [];
              const reward = typeof recipe.reward === 'object' && recipe.reward !== null 
                ? recipe.reward as { xp: number; shards: number }
                : { xp: 10, shards: 1 };
              
              return (
                <Card 
                  key={recipe.id} 
                  className={`hover:shadow-sm transition-shadow ${
                    isReady ? 'ring-2 ring-green-200 bg-green-50/50' : ''
                  }`}
                  data-testid={`recipe-card-${index}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h5 className="font-medium text-gray-900 flex items-center" data-testid={`recipe-name-${index}`}>
                          <Sparkles className="text-warning mr-2 h-4 w-4" />
                          {recipe.label}
                        </h5>
                        <p className="text-sm text-gray-600" data-testid={`recipe-gates-${index}`}>
                          Gates: {recipeGates.join(', ')}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        {isReady ? (
                          <Badge className="bg-green-100 text-green-800" data-testid={`recipe-status-${index}`}>
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Ready!
                          </Badge>
                        ) : (
                          <Badge variant="outline" data-testid={`recipe-status-${index}`}>
                            {recipeGates.filter(gate => activeGates.includes(gate)).length}/{recipeGates.length}
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="text-sm text-gray-500 flex items-center" data-testid={`recipe-rewards-${index}`}>
                        <Gift className="h-4 w-4 mr-1" />
                        Rewards: 
                        <span className="font-medium text-gray-900 ml-1">{reward.xp} XP</span>, 
                        <span className="font-medium text-gray-900 ml-1">{reward.shards} Shards</span>
                      </div>
                      <Button
                        size="sm"
                        disabled={!isReady || completeRecipeMutation.isPending}
                        onClick={() => completeRecipeMutation.mutate(recipe.recipeId)}
                        className={isReady ? "bg-warning text-white hover:bg-warning/90" : ""}
                        data-testid={`button-complete-recipe-${index}`}
                      >
                        {completeRecipeMutation.isPending ? 'Completing...' : 
                         isReady ? 'Complete' : 'Not Ready'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Missing Gates Hint */}
      {recipes.length > 0 && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <h5 className="font-medium text-blue-900 mb-2">Recipe Progress Hints</h5>
            <div className="space-y-2">
              {recipes.map((recipe: any) => {
                const recipeGates = Array.isArray(recipe.gates) ? recipe.gates : [];
                const missingGates = recipeGates.filter(gate => !activeGates.includes(gate));
                
                if (missingGates.length === 0) return null;
                
                return (
                  <div key={recipe.id} className="text-sm text-blue-700">
                    <strong>{recipe.label}:</strong> Need gates {missingGates.join(', ')}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
