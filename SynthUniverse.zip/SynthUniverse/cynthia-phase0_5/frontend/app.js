// Configuration
const API = () => `http://localhost:${window.location.port || 8787}`;
let ws = null;
let activeGates = new Set([16, 48, 24]);
let currentCore = null;

// Utility functions
const $ = id => document.getElementById(id);
const log = (...args) => console.log('[Cynthia]', ...args);

// WebSocket connection
function connectWS() {
  const wsUrl = `ws://localhost:${window.location.port || 8787}`;
  ws = new WebSocket(wsUrl);
  
  ws.onopen = () => {
    $('status').textContent = 'WebSocket Connected';
    $('status').className = 'status connected';
    log('WebSocket connected');
  };
  
  ws.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      log('WebSocket message:', data.type, data);
      handleWSMessage(data);
    } catch (e) {
      log('WebSocket parse error:', e);
    }
  };
  
  ws.onclose = () => {
    $('status').textContent = 'WebSocket Disconnected';
    $('status').className = 'status disconnected';
    log('WebSocket disconnected');
    setTimeout(connectWS, 3000);
  };
  
  ws.onerror = (error) => {
    log('WebSocket error:', error);
  };
}

function handleWSMessage(data) {
  switch(data.type) {
    case 'health':
      updateHealthStatus(data.data);
      break;
    case 'collapse':
      displayCollapseResult(data.data);
      break;
    case 'chat':
      addChatMessage('assistant', data.data.reply);
      break;
    case 'apply':
    case 'compose':
      displayCityResult(data.data);
      break;
  }
}

// Navigation
function showSection(sectionId) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav button').forEach(b => b.classList.remove('active'));
  $(sectionId).classList.add('active');
  $(`nav-${sectionId}`).classList.add('active');
  
  if (sectionId === 'sparkle') initGateGrid();
}

// Collapse System
async function runCollapse() {
  try {
    const res = await fetch(API() + '/collapse', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    });
    const data = await res.json();
    currentCore = data.core;
    displayCollapseResult(data);
  } catch (e) {
    log('Collapse error:', e);
    $('core-display').innerHTML = `<p style="color: #ff6b9d;">Error: ${e.message}</p>`;
  }
}

function displayCollapseResult(data) {
  const { core, projections, mode } = data;
  const html = `
    <h3>Core Values</h3>
    <div class="grid">
      <div class="skill-card">
        <strong>Mind:</strong> ${core.mind.toFixed(3)}<br>
        <div style="background: rgba(255,107,157,0.3); height: 8px; border-radius: 4px; margin-top: 5px;">
          <div style="background: #ff6b9d; height: 8px; border-radius: 4px; width: ${((core.mind + 1) / 2 * 100)}%;"></div>
        </div>
      </div>
      <div class="skill-card">
        <strong>Heart:</strong> ${core.heart.toFixed(3)}<br>
        <div style="background: rgba(255,215,61,0.3); height: 8px; border-radius: 4px; margin-top: 5px;">
          <div style="background: #ffd93d; height: 8px; border-radius: 4px; width: ${((core.heart + 1) / 2 * 100)}%;"></div>
        </div>
      </div>
      <div class="skill-card">
        <strong>Body:</strong> ${core.body.toFixed(3)}<br>
        <div style="background: rgba(36,214,169,0.3); height: 8px; border-radius: 4px; margin-top: 5px;">
          <div style="background: #24d6a9; height: 8px; border-radius: 4px; width: ${((core.body + 1) / 2 * 100)}%;"></div>
        </div>
      </div>
    </div>
    
    <h3>Nine Projections</h3>
    <div class="grid">
      ${Object.entries(projections).map(([key, value]) => `
        <div class="skill-card" style="background: rgba(255,255,255,0.05);">
          <strong>${key}:</strong> ${value.toFixed(3)}
        </div>
      `).join('')}
    </div>
    
    <h3>Current Mode</h3>
    <div class="skill-card" style="background: rgba(36,214,169,0.1);">
      <strong>Dominant:</strong> ${mode.dominant}<br>
      <strong>Tone:</strong> ${mode.tone}<br>
      <strong>Focus:</strong> ${mode.focus}
    </div>
  `;
  $('core-display').innerHTML = html;
}

function clearCollapse() {
  $('core-display').innerHTML = '';
  currentCore = null;
}

// Cities Engine
async function loadCity(node) {
  try {
    const core = currentCore || { mind: 0, heart: 0, body: 0 };
    const res = await fetch(API() + `/cities/${node}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(core)
    });
    const data = await res.json();
    displayCitySkills(data.skills || []);
  } catch (e) {
    log('City load error:', e);
    $('skills').innerHTML = `<p style="color: #ff6b9d;">Error loading ${node} city: ${e.message}</p>`;
  }
}

function displayCitySkills(skills) {
  const html = skills.slice(0, 12).map(s => `
    <div class="skill-card">
      <strong>${s.name}</strong> (Lv.${s.level})<br>
      XP: ${s.xp} | Active: ${s.active ? 'Yes' : 'No'}<br>
      <small>C:${s.stats.C} O:${s.stats.O} P:${s.stats.P}<br>
      N:${s.stats.N} H:${s.stats.F} F:${s.stats.F} E:${s.stats.E}</small>
    </div>
  `).join('');
  $('skills').innerHTML = html;
}

async function applySkill() {
  const skillId = parseInt($('skill-id').value);
  const alignment = parseFloat($('alignment').value);
  
  try {
    const res = await fetch(API() + '/cities/apply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        node: 'Mind', // Default to Mind for demo
        skillId, 
        alignment,
        taskVec: { C: 1, O: 1, P: 1 }
      })
    });
    const data = await res.json();
    displayCityResult(data);
  } catch (e) {
    log('Apply skill error:', e);
  }
}

async function composeSkills() {
  const core = currentCore || { mind: 0.5, heart: 0.5, body: 0.5 };
  
  try {
    const res = await fetch(API() + '/cities/compose', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        node: 'Mind',
        k: 3,
        core,
        alignment: parseFloat($('alignment').value),
        taskVec: { C: 1, O: 1, P: 1 }
      })
    });
    const data = await res.json();
    displayCityResult(data);
  } catch (e) {
    log('Compose skills error:', e);
  }
}

function displayCityResult(data) {
  const html = `
    <div class="skill-card" style="background: ${data.ok ? 'rgba(36,214,169,0.1)' : 'rgba(255,107,157,0.1)'};">
      <strong>Result:</strong> ${data.ok ? (data.win ? 'Success' : 'Partial') : 'Failed'}<br>
      ${data.ok ? `
        <strong>Score:</strong> ${data.score}<br>
        <strong>Task Fit:</strong> ${data.taskFit}%<br>
        ${data.level ? `<strong>Level:</strong> ${data.level}` : ''}
      ` : `<strong>Reason:</strong> ${data.reason}`}
    </div>
  `;
  $('city-result').innerHTML = html;
}

// TaskFit & Builder
async function createJob(kind) {
  try {
    const res = await fetch(API() + '/builder/jobs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        kind, 
        detail: `${kind.charAt(0).toUpperCase() + kind.slice(1)} enhancement requested`,
        dependencies: []
      })
    });
    const data = await res.json();
    updateBuilderStatus(`Job created: ${data.job.name}`);
  } catch (e) {
    log('Create job error:', e);
  }
}

async function delegateJob() {
  const agentUrl = $('agent-url').value.trim();
  if (!agentUrl) {
    updateBuilderStatus('Please enter agent URL');
    return;
  }
  
  try {
    // For demo, we'll use a mock job ID
    const res = await fetch(API() + '/builder/delegate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        jobId: Date.now(), 
        agentUrl 
      })
    });
    const data = await res.json();
    updateBuilderStatus(data.ok ? 'Job delegated successfully' : `Delegation failed: ${data.error}`);
  } catch (e) {
    log('Delegate job error:', e);
    updateBuilderStatus(`Delegation error: ${e.message}`);
  }
}

async function integrateModule() {
  const moduleName = $('module-name').value.trim();
  if (!moduleName) {
    updateBuilderStatus('Please enter module name');
    return;
  }
  
  try {
    const res = await fetch(API() + '/builder/integrate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        moduleName,
        code: `export default function ${moduleName}() { return { ok: true, message: 'Module ${moduleName} loaded' }; }`
      })
    });
    const data = await res.json();
    updateBuilderStatus(data.ok ? `Module ${moduleName} integrated` : 'Integration failed');
  } catch (e) {
    log('Integrate module error:', e);
  }
}

function updateBuilderStatus(message) {
  $('builder-status').innerHTML = `<p style="color: #24d6a9;">${message}</p>`;
  setTimeout(() => $('builder-status').innerHTML = '', 3000);
}

// Sparkle System
function initGateGrid() {
  const grid = $('gate-grid');
  grid.innerHTML = '';
  
  for (let i = 1; i <= 64; i++) {
    const gate = document.createElement('div');
    gate.className = `gate ${activeGates.has(i) ? 'active' : ''}`;
    gate.textContent = i;
    gate.onclick = () => toggleGate(i);
    grid.appendChild(gate);
  }
}

function toggleGate(gateId) {
  if (activeGates.has(gateId)) {
    activeGates.delete(gateId);
  } else {
    activeGates.add(gateId);
  }
  initGateGrid();
}

function clearGates() {
  activeGates.clear();
  initGateGrid();
}

async function checkSparkle() {
  try {
    const res = await fetch(API() + '/sparkle/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        activeGates: [...activeGates],
        projection: currentCore ? currentCore : {}
      })
    });
    const data = await res.json();
    displaySparkleResult(data);
  } catch (e) {
    log('Sparkle check error:', e);
  }
}

function displaySparkleResult(data) {
  let html = '';
  if (data.element) {
    html = `
      <div class="skill-card" style="background: rgba(255,215,61,0.2); border-color: #ffd93d;">
        <strong>🌟 Element Completed: ${data.label}</strong><br>
        <strong>Reward:</strong> ${data.reward.xp} XP, ${data.reward.shards} Shards<br>
        <small>Active gates: ${[...activeGates].join(', ')}</small>
      </div>
    `;
  } else {
    html = `
      <div class="skill-card" style="background: rgba(255,255,255,0.05);">
        <strong>No elements completed</strong><br>
        <small>Try different gate combinations. Active: ${[...activeGates].join(', ')}</small>
      </div>
    `;
  }
  $('sparkle-result').innerHTML = html;
}

// LLM Interface
async function sendChat() {
  const input = $('chat-input').value.trim();
  if (!input) return;
  
  const model = $('model-select').value;
  addChatMessage('user', input);
  $('chat-input').value = '';
  
  try {
    const res = await fetch(API() + '/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        prompt: input,
        model,
        parser: null // Will use fake parser seed
      })
    });
    const data = await res.json();
    addChatMessage('assistant', data.reply);
  } catch (e) {
    log('Chat error:', e);
    addChatMessage('assistant', `Error: ${e.message}`);
  }
}

function addChatMessage(role, content) {
  const chat = $('chat');
  const msg = document.createElement('div');
  msg.className = `msg ${role}`;
  msg.innerHTML = `<strong>${role === 'user' ? 'You' : 'Cynthia'}:</strong> ${content}`;
  chat.appendChild(msg);
  chat.scrollTop = chat.scrollHeight;
}

async function checkHealth() {
  try {
    const res = await fetch(API() + '/health');
    const data = await res.json();
    updateHealthStatus(data);
  } catch (e) {
    log('Health check error:', e);
  }
}

function updateHealthStatus(data) {
  const status = data.ollama ? '🟢 Ollama Ready' : '🔴 Ollama Offline (set OLLAMA_URL)';
  $('llm-status').innerHTML = `<p>${status}</p>`;
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && e.ctrlKey) {
    if ($('chat-input') === document.activeElement) {
      sendChat();
    }
  }
});

// Initialize
window.addEventListener('load', () => {
  log('Cynthia Phase 0.5 initialized');
  connectWS();
  initGateGrid();
  checkHealth();
});
