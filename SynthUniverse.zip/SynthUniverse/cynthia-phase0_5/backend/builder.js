import fs from 'fs';
import path from 'path';

const DATA = path.join(process.cwd(), 'data', 'lab');
const TODO = path.join(DATA, 'todos.jsonl');
const JOBS = path.join(DATA, 'jobs.jsonl');
let todoCache = [], jobCache = [];

function ensure(){ fs.mkdirSync(DATA, { recursive:true }); }
function syncToDisk(){
  if (todoCache.length){ fs.appendFileSync(TODO, todoCache.map(r=>JSON.stringify(r)+'\n').join('')); todoCache=[]; }
  if (jobCache.length){ fs.appendFileSync(JOBS, jobCache.map(r=>JSON.stringify(r)+'\n').join('')); jobCache=[]; }
}
setInterval(syncToDisk, 5*60*1000);
process.on('SIGINT', ()=>{ syncToDisk(); process.exit(); });

export function builderNeed(kind, detail){
  ensure(); const rec = { t: Date.now(), kind, detail }; todoCache.push(rec); return rec;
}
export function generateJobSpec(kind, detail, dependencies=[]){
  ensure();
  const templates = {
    module:{ type:'module', priority:1, requires:['code','tests'] },
    city:{ type:'city', priority:2, requires:['agents','skills','config'] },
    skill:{ type:'skill', priority:1.5, requires:['logic','training'] }
  };
  const spec = { t: Date.now(), name: detail, ...(templates[kind]||templates.module), dependencies };
  jobCache.push(spec); return spec;
}
export function listTodos(limit=200){
  ensure();
  const lines = fs.existsSync(TODO)? fs.readFileSync(TODO,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse):[];
  return [...lines, ...todoCache].slice(-limit);
}
export function listJobs(limit=200){
  ensure();
  const lines = fs.existsSync(JOBS)? fs.readFileSync(JOBS,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse):[];
  return [...lines, ...jobCache].slice(-limit);
}
export async function delegateJob(jobId, agentUrl){
  const job = listJobs().find(j=>j.t===jobId); if(!job || !agentUrl) return { ok:false, error:'Invalid job or agent URL' };
  try{
    const res = await fetch(agentUrl,{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(job) });
    if(!res.ok) throw new Error(`HTTP ${res.status}`);
    const result = await res.json();
    builderNeed('delegation', `Job ${job.name} -> ${agentUrl}: ${JSON.stringify(result)}`);
    return { ok:true, result };
  }catch(e){ builderNeed('error', `Delegation failed for ${job.name}: ${e.message}`); return { ok:false, error:e.message }; }
}
export function integrateModule(moduleName, code){
  const file = path.join(process.cwd(), 'backend', 'modules', `${moduleName}.js`);
  fs.mkdirSync(path.dirname(file), { recursive:true });
  fs.writeFileSync(file, code, 'utf8');
  builderNeed('module', `Integrated ${moduleName}`);
  return { ok:true, module: moduleName };
}
