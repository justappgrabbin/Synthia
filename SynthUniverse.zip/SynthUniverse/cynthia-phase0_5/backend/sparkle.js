import fs from 'fs';
import path from 'path';
const REC = path.join(process.cwd(), 'backend', 'recipes.json');
let recipes = [];
try { recipes = JSON.parse(fs.readFileSync(REC,'utf8')); } catch { recipes = []; }

export function checkElementComplete(activeGates=[], projection={}){
  const set = new Set(activeGates);
  for (const r of recipes){
    if ((r.gates||[]).every(g=>set.has(g))) return { element:r.id, label:r.label, reward:r.reward||{xp:10, shards:1} };
  }
  return { element:null };
}

export function updateRecipes(newRecipes){
  recipes = newRecipes||[];
  fs.writeFileSync(REC, JSON.stringify(recipes,null,2));
  return { ok:true, count: recipes.length };
}
