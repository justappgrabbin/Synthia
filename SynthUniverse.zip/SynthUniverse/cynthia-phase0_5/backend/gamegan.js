import fs from 'fs';
import path from 'path';
import { builderNeed } from './builder.js';

export function gameganMock(spec){
  const title = spec.title || 'Untitled Game';
  const color = spec.color || '#24d6a9';
  const speed = Number(spec.speed || 3);
  const message = spec.message || 'Play the game!';
  const fileName = `${title.replace(/[^\w]+/g,'_')}_${Date.now()}.html`;
  const filePath = path.join(process.cwd(), 'frontend', 'game', fileName);
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
  <style>body{margin:0;background:#0b0b12;color:#e9e9ef;font-family:system-ui}canvas{border:1px solid #24244a;display:block;margin:24px auto}</style>
  </head><body><h1 style="text-align:center">${title}</h1><canvas id="game" width="400" height="400"></canvas><p style="text-align:center">${message}</p>
  <script>
  const c = document.getElementById('game').getContext('2d'); c.fillStyle='${color}'; let x=200,y=200,dx=${speed},dy=${speed};
  function loop(){ c.clearRect(0,0,400,400); c.beginPath(); c.arc(x,y,20,0,Math.PI*2); c.fill();
    x+=dx; y+=dy; if(x<20||x>380) dx=-dx; if(y<20||y>380) dy=-dy; requestAnimationFrame(loop); } loop();
  </script></body></html>`;
  fs.mkdirSync(path.dirname(filePath), { recursive:true });
  fs.writeFileSync(filePath, html);
  builderNeed('game', `Generated mock game: ${fileName}`);
  return { ok:true, urlHint:`/game/${fileName}` };
}
