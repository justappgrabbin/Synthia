import fs from 'fs';
import path from 'path';
import { scoreTask } from '../taskfit.js';

const DB = path.join(process.cwd(), 'data', 'cities.json');
const NODES = ['Mind','Heart','Body'];
let cityCache = null;
let writeQueue = [];

function seedSkills(node){
  return Array.from({length:64},(_,i)=>({
    id:i+1, name:`${node}-Skill-${i+1}`,
    stats:{ C:30+((i*7)%70), O:30+((i*11)%70), P:30+((i*13)%70), N:30+((i*17)%70), H:30+((i*19)%70), F:30+((i*23)%70), E:30+((i*29)%70) },
    level:1, xp:0, active:(i%3)!==0
  }));
}

function load(){
  if (cityCache) return cityCache;
  if (!fs.existsSync(DB)){
    const obj = { Mind:{skills:seedSkills('Mind')}, Heart:{skills:seedSkills('Heart')}, Body:{skills:seedSkills('Body')} };
    fs.mkdirSync(path.dirname(DB), { recursive:true });
    fs.writeFileSync(DB, JSON.stringify(obj,null,2));
    cityCache = obj; return obj;
  }
  cityCache = JSON.parse(fs.readFileSync(DB,'utf8')); return cityCache;
}

function queueSave(st){
  writeQueue.push(st);
  if (writeQueue.length>100){ fs.writeFileSync(DB, JSON.stringify(writeQueue.pop(),null,2)); writeQueue=[]; }
}
setInterval(()=>{ if(writeQueue.length){ fs.writeFileSync(DB, JSON.stringify(writeQueue.pop(),null,2)); writeQueue=[]; }}, 10*60*1000);
process.on('SIGINT', ()=>{ if(writeQueue.length) fs.writeFileSync(DB, JSON.stringify(writeQueue.pop(),null,2)); process.exit(); });

export function getCities(){ return load(); }
export function getNode(node){ node=node[0].toUpperCase()+node.slice(1).toLowerCase(); return load()[node]; }
export function projectAvailability(core){ const clip=v=>Math.max(0,Math.min(1,(v+1)/2)); return { Mind:clip(core.mind||0), Heart:clip(core.heart||0), Body:clip(core.body||0) }; }
export function listAvailable(core){
  const st = load(); const avail = projectAvailability(core); const out={};
  for(const node of NODES){
    const mult = avail[node]||0;
    out[node] = st[node].skills
      .filter(s=>s.active)
      .map(s=>({ ...s, availability: Math.round(mult*(50 + s.level*10)) }))
      .sort((a,b)=>b.availability - a.availability)
      .slice(0,10);
  }
  return out;
}

export function applySkill({ node, skillId, taskVec, alignment=1.0 }){
  node=node[0].toUpperCase()+node.slice(1).toLowerCase();
  const st=load(); const s=(st[node]?.skills||[]).find(x=>x.id===Number(skillId));
  if(!s || !s.active) return { ok:false, reason:'inactive or missing' };
  const task={ title:`Apply ${s.name}`, min_sprites:1, max_sprites:1, min_team_level:s.level, difficulty:3,
    required_axes:Object.keys(taskVec||{}).map(k=>({axis:[k],weight:1/((Object.keys(taskVec||{}).length)||1)})),
    ring_bias:[node], gate_affinity:[s.id], sun_gate_boost:false };
  const sprite={ id:s.id, gate:s.id, ring:node, level:s.level, copnhfe:s.stats, positioning:'Personal', modality:'Generic' };
  const taskFit = scoreTask(task,[sprite],s.id);
  const score = (taskFit.fit/100) * alignment;
  const win = score >= 0.42;
  s.xp += win?10:2;
  if (s.xp >= 50 + s.level*25){ s.level++; s.xp = 0; }
  if (!win && alignment<0.4) s.active = Math.random()>0.5 ? false : s.active;
  queueSave(st);
  return { ok:true, win, score:+score.toFixed(3), level:s.level, active:s.active, taskFit:taskFit.fit };
}

export function composeSkills({ node, k, taskVec, alignment=1.0, core }){
  node=node[0].toUpperCase()+node.slice(1).toLowerCase();
  const st=load(); const avail = projectAvailability(core)[node]||0;
  const skills = st[node].skills.filter(s=>s.active).map(s=>({ ...s, availability: Math.round(avail*(50+s.level*10)) }))
    .sort((a,b)=>b.availability-a.availability).slice(0,k);
  if (skills.length<k) return { ok:false, reason:`Not enough active skills for k=${k}` };

  const task={ title:`Compose ${node} Skills`, min_sprites:k, max_sprites:k, min_team_level:Math.min(...skills.map(s=>s.level)), difficulty:3,
    required_axes:Object.keys(taskVec||{}).map(k=>({axis:[k],weight:1/((Object.keys(taskVec||{}).length)||1)})),
    ring_bias:[node], gate_affinity:skills.map(s=>s.id), sun_gate_boost:false };
  const sprites = skills.map(s=>({ id:s.id, gate:s.id, ring:node, level:s.level, copnhfe:s.stats, positioning:'Personal', modality:'Generic' }));
  const taskFit = scoreTask(task, sprites, skills[0].id);
  const score = (taskFit.fit/100) * alignment;
  const win = score >= 0.42;
  for (const s of skills){ s.xp += win?10:2; if (s.xp>=50+s.level*25){ s.level++; s.xp=0; } if (!win && alignment<0.4) s.active = Math.random()>0.5?false:s.active; }
  queueSave(st);
  return { ok:true, win, score:+score.toFixed(3), skills: skills.map(s=>({id:s.id,level:s.level,active:s.active})), taskFit: taskFit.fit };
}

export function bestSkills({ node, k, taskVec, core }){
  node=node[0].toUpperCase()+node.slice(1).toLowerCase();
  const st=load(); const avail = projectAvailability(core)[node]||0;
  const ranked = st[node].skills.filter(s=>s.active).map(s=>{
    const task={ title:`Evaluate ${s.name}`, min_sprites:1, max_sprites:1, min_team_level:s.level, difficulty:3,
      required_axes:Object.keys(taskVec||{}).map(k=>({axis:[k],weight:1/((Object.keys(taskVec||{}).length)||1)})),
      ring_bias:[node], gate_affinity:[s.id], sun_gate_boost:false };
    const sprite={ id:s.id, gate:s.id, ring:node, level:s.level, copnhfe:s.stats };
    const tf = scoreTask(task,[sprite],s.id);
    return { ...s, availability: Math.round(avail*(50+s.level*10)), taskFit: tf.fit };
  }).sort((a,b)=> (b.taskFit + b.availability*0.2) - (a.taskFit + a.availability*0.2)).slice(0,k);
  return { ok:true, skills: ranked };
}
