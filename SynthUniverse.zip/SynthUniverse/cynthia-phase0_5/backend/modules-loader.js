import fs from 'fs';
import path from 'path';
const MODULES_DIR = path.join(process.cwd(), 'backend', 'modules');
export let loadedModules = {};

export function loadModules(){
  loadedModules = {};
  if(!fs.existsSync(MODULES_DIR)) return [];
  for (const file of fs.readdirSync(MODULES_DIR)){
    if (!file.endsWith('.js')) continue;
    const name = file.replace('.js','');
    try{
      const modPath = path.join(MODULES_DIR, file);
      delete import.meta?.resolve && null; // noop; keep ESM
      loadedModules[name] = (await import(`file://${modPath}`)).default ?? (await import(`file://${modPath}`));
    }catch(e){ console.error('Module load failed', name, e.message); }
  }
  return Object.keys(loadedModules);
}

export function getModule(name){ return loadedModules[name] || null; }
