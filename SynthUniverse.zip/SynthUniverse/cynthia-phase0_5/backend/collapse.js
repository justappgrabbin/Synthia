export function clamp(x, lo=-1, hi=1){ return Math.max(lo, Math.min(hi, x)); }

export function collapseCore(parser) {
  // lightweight, deterministic-ish core from parser hints
  const a = Number(parser?.aspects?.["Sun conjunct Mercury"]?.weight ?? 0);
  const b = Number(parser?.aspects?.["Mars sextile Saturn"]?.weight ?? 0);
  const sun = Number(parser?.gates?.sunGate ?? 16);
  let mind = clamp((a*0.7 + b*0.2) * 2 - 1);
  let heart = clamp((a*0.2 + b*0.5) * 2 - 1);
  let body = clamp((a*0.1 + b*0.3) * 2 - 1);
  const mod = sun % 3;
  if (mod===0) mind = clamp(mind + 0.06);
  if (mod===1) heart = clamp(heart + 0.06);
  if (mod===2) body = clamp(body + 0.06);
  return { mind, heart, body };
}

export function projectNine(core, f=0.9) {
  const {mind,heart,body} = core;
  const bleed = (a,b)=> clamp(a*f + b*(1-f));
  return {
    "Mind-Personal": bleed(mind, body),
    "Mind-Interpersonal": bleed(mind, heart),
    "Mind-Transpersonal": bleed(mind, (heart+body)/2),
    "Heart-Personal": bleed(heart, body),
    "Heart-Interpersonal": bleed(heart, mind),
    "Heart-Transpersonal": bleed(heart, (mind+body)/2),
    "Body-Personal": bleed(body, mind),
    "Body-Interpersonal": bleed(body, heart),
    "Body-Transpersonal": bleed(body, (mind+heart)/2)
  };
}

export function modeFrom(core){
  const ranked = [['mind',core.mind],['heart',core.heart],['body',core.body]].sort((a,b)=>b[1]-a[1]);
  const dom = ranked[0][0];
  if (dom==='heart') return { tone:'empathetic', focus:'connection', dominant:'Heart' };
  if (dom==='mind') return { tone:'analytical', focus:'problem-solving', dominant:'Mind' };
  return { tone:'practical', focus:'execution', dominant:'Body' };
}

export function buildPrompt(input, mode){
  return `You are Cynthia. Tone: ${mode.tone}. Focus: ${mode.focus}.
Reply briefly, helpfully.

User: ${input}
Cynthia:`;
}
