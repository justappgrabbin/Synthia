import http from 'http';
const agent = new http.Agent({ maxSockets: 10 });

export async function callOllama({ url, model, prompt, options }) {
  const endpoint = (process.env.OLLAMA_URL || url || '').trim();
  if (!endpoint) {
    return { ok: false, text: "(LLM offline — set OLLAMA_URL). Fallback: core-only reply." };
  }
  try {
    const res = await fetch(`${endpoint.replace(/\/$/, '')}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, prompt, options: options || { temperature: 0.6, top_p: 0.9 } }),
      agent
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const lines = [];
    for await (const chunk of res.body) lines.push(Buffer.from(chunk).toString('utf8'));
    const last = lines.join('').trim().split('\n').filter(Boolean).pop();
    const obj = JSON.parse(last);
    return { ok: true, text: obj.response || '' };
  } catch (e) {
    return { ok: false, text: `(LLM error: ${e.message}). Fallback reply.` };
  }
}
