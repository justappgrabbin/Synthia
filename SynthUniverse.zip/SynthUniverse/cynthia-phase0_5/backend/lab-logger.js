import fs from 'fs';
import path from 'path';
const LOG = path.join(process.cwd(), 'data', 'events.jsonl');
export function logEvent(event){
  fs.mkdirSync(path.dirname(LOG), { recursive:true });
  fs.appendFileSync(LOG, JSON.stringify({ t:Date.now(), ...event }) + '\n');
}
export function listEvents(limit=200){
  if(!fs.existsSync(LOG)) return [];
  const lines = fs.readFileSync(LOG,'utf8').trim().split('\n').filter(Boolean);
  return lines.slice(-limit).map(l=>{ try{return JSON.parse(l)}catch{return null} }).filter(Boolean);
}
