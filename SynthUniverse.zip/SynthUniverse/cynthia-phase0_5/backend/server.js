import http from 'http';
import fs from 'fs';
import path from 'path';
import { WebSocketServer } from 'ws';
import cfgRaw from './config.json' assert { type:'json' };
import { collapseCore, projectNine, modeFrom, buildPrompt } from './collapse.js';
import { fakeParserSeed } from './parserStub.js';
import { callOllama } from './ollama.js';
import { builderNeed, generateJobSpec, listTodos, listJobs, delegateJob, integrateModule } from './builder.js';
import { loadModules, loadedModules } from './modules-loader.js';
import { getCities, listAvailable, applySkill, composeSkills, bestSkills, projectAvailability } from './cities/engine.js';
import { coachStub } from './coach.js';
import { checkElementComplete, updateRecipes } from './sparkle.js';
import { gameganMock } from './gamegan.js';
import { logEvent, listEvents } from './lab-logger.js';

const cfg = cfgRaw;
const server = http.createServer();
const wss = new WebSocketServer({ server });

function send(res, code, obj){ res.writeHead(code, { 'Content-Type':'application/json', 'Access-Control-Allow-Origin':'*' }); res.end(JSON.stringify(obj)); }
function readBody(req){ return new Promise(r=>{ let b=''; req.on('data',d=>b+=d); req.on('end',()=>{ try{ r(JSON.parse(b||'{}')); }catch{ r({}); } }); }); }
function broadcast(msg){ wss.clients.forEach(ws=>ws.readyState===1 && ws.send(JSON.stringify(msg))); }

wss.on('connection', ws=>{
  ws.send(JSON.stringify({ type:'health', data:{ ok:true, ollama: !!(process.env.OLLAMA_URL || cfg.ollama.url) } }));
  ws.send(JSON.stringify({ type:'todos', data:listTodos() }));
  ws.send(JSON.stringify({ type:'jobs', data:listJobs() }));
  ws.send(JSON.stringify({ type:'modules', data:Object.keys(loadedModules) }));
});

await loadModules();

server.on('request', async (req,res)=>{
  const url = new URL(req.url, 'http://localhost');
  if (req.method==='OPTIONS'){
    res.writeHead(204, {
      'Access-Control-Allow-Origin':'*',
      'Access-Control-Allow-Methods':'GET,POST,OPTIONS',
      'Access-Control-Allow-Headers':'Content-Type'
    }); return res.end();
  }

  // Static serve generated games
  if (req.method==='GET' && url.pathname.startsWith('/game/')){
    const filePath = path.join(process.cwd(), 'frontend', url.pathname);
    if (fs.existsSync(filePath)){ res.writeHead(200, {'Content-Type':'text/html'}); fs.createReadStream(filePath).pipe(res); return; }
    return send(res,404,{error:'Game file not found'});
  }

  // Health
  if (req.method==='GET' && url.pathname==='/health'){ return send(res,200,{ ok:true, ollama: !!(process.env.OLLAMA_URL || cfg.ollama.url) }); }

  // Builder & Modules
  if (req.method==='GET' && url.pathname==='/todos'){ return send(res,200, listTodos()); }
  if (req.method==='GET' && url.pathname==='/builder/jobs'){ return send(res,200, listJobs()); }
  if (req.method==='POST' && url.pathname==='/builder/jobs'){ const body=await readBody(req); const job=generateJobSpec(body.kind||'module', body.detail||'unspecified', body.dependencies||[]); broadcast({type:'jobs',data:listJobs()}); return send(res,200,{ok:true, job}); }
  if (req.method==='POST' && url.pathname==='/builder/delegate'){ const body=await readBody(req); const out=await delegateJob(body.jobId, body.agentUrl); broadcast({type:'todos',data:listTodos()}); return send(res,200,out); }
  if (req.method==='POST' && url.pathname==='/builder/integrate'){
    const body=await readBody(req);
    if(!body.moduleName) return send(res,400,{error:'Missing moduleName'});
    const result = integrateModule(body.moduleName, body.code||'export default () => ({ ok:true });');
    await loadModules(); broadcast({type:'modules',data:Object.keys(loadedModules)});
    return send(res,200,result);
  }
  if (req.method==='GET' && url.pathname==='/modules'){ return send(res,200,Object.keys(loadedModules)); }

  // Sparkle
  if (req.method==='POST' && url.pathname==='/sparkle/check'){ const body=await readBody(req); return send(res,200, checkElementComplete(body.activeGates||[], body.projection||{})); }
  if (req.method==='POST' && url.pathname==='/sparkle/update'){ const body=await readBody(req); const out = updateRecipes(body.recipes||[]); return send(res,200,out); }

  // Cities
  if (req.method==='GET' && url.pathname==='/cities'){ return send(res,200, getCities()); }
  if (req.method==='POST' && url.pathname.startsWith('/cities/')){ const node=url.pathname.split('/').pop(); const body=await readBody(req); const core=(body.mind!==undefined)?body:fakeParserSeed(); const cities=getNode(node); return send(res,200, cities); }
  if (req.method==='POST' && url.pathname==='/cities/available'){ const body=await readBody(req); const core=(body.mind!==undefined)?body:fakeParserSeed(); return send(res,200, listAvailable(core)); }
  if (req.method==='POST' && url.pathname==='/cities/apply'){ const body=await readBody(req); const out=applySkill(body); broadcast({type:'apply',data:out}); return send(res,200,out); }
  if (req.method==='POST' && url.pathname==='/cities/compose'){ const body=await readBody(req); const out=composeSkills(body); broadcast({type:'compose',data:out}); return send(res,200,out); }
  if (req.method==='POST' && url.pathname==='/cities/best'){ const body=await readBody(req); return send(res,200, bestSkills(body)); }

  // Collapse
  if (req.method==='POST' && url.pathname==='/collapse'){ const body=await readBody(req); const parser=(body.parser)?body.parser:fakeParserSeed(); const core = collapseCore(parser); const projections = projectNine(core, body.f||0.9); const mode = modeFrom(core); const result={ core, projections, mode, parser }; broadcast({type:'collapse',data:result}); return send(res,200,result); }

  // LLM Chat
  if (req.method==='POST' && url.pathname==='/chat'){ 
    const body=await readBody(req);
    const parser=(body.parser)?body.parser:fakeParserSeed();
    const core = collapseCore(parser); const projections = projectNine(core, 0.9); const mode = modeFrom(core);
    const modelMap = { Mind:'tinyllama', Heart:'mistral', Body:'phi' };
    const model = body.model || modelMap[mode.dominant] || 'tinyllama';
    const prompt = buildPrompt(body.prompt||'Hello', mode);
    const ollama = await callOllama({ url:(process.env.OLLAMA_URL||cfg.ollama.url), model, prompt, options:cfg.ollama.options });
    if (!ollama.ok) builderNeed('module', 'Ollama not reachable — set OLLAMA_URL or config. Using fallback.');
    const reply = ollama.text || `(${mode.tone}/${mode.focus}) Thanks for sharing. Try one small aligned step today.`;
    const result={ reply, core, projections, mode, parser }; broadcast({type:'chat',data:result});
    return send(res,200,result);
  }

  // Coach
  if (req.method==='POST' && url.pathname==='/coach'){ const body=await readBody(req); const parser=(body.parser)?body.parser:fakeParserSeed(); const core=collapseCore(parser); const mode=modeFrom(core); const result=coachStub(body.input||'Hello', mode); logEvent({kind:'coach',input:body.input,result}); return send(res,200,result); }

  // GameGAN
  if (req.method==='POST' && url.pathname==='/gamegan/mock'){ const body=await readBody(req); const result=gameganMock(body.spec||{}); logEvent({kind:'game',spec:body.spec,result}); return send(res,200,result); }

  // Events
  if (req.method==='GET' && url.pathname==='/events'){ const limit=Number(url.searchParams.get('limit')||200); return send(res,200, listEvents(limit)); }

  // Default
  send(res,404,{error:'Not found'});
});

const PORT = process.env.PORT || cfg.port || 8787;
server.listen(PORT, ()=>console.log(`Cynthia Phase 0.5 running on port ${PORT}`));
