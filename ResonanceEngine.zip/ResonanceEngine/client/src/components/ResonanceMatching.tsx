import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useState } from "react";

export default function ResonanceMatching() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedMatch, setSelectedMatch] = useState<string | null>(null);

  const { data: matches, isLoading } = useQuery({
    queryKey: ["/api/resonance/matches"],
    retry: false,
  });

  const { data: connections } = useQuery({
    queryKey: ["/api/resonance/connections"],
    retry: false,
  });

  const connectMutation = useMutation({
    mutationFn: async (partnerId: string) => {
      await apiRequest("POST", "/api/resonance/connect", {
        partnerId,
        exchangeType: "accountability",
      });
    },
    onSuccess: () => {
      toast({
        title: "Connection Created",
        description: "You've successfully connected with your resonance match!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/resonance/connections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/resonance/matches"] });
      setSelectedMatch(null);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session Expired",
          description: "Please log in again to continue.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 1000);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create connection. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-8">
        <Card className="energy-glow">
          <CardContent className="p-6">
            <div className="animate-pulse">
              <div className="h-8 bg-muted rounded mb-6"></div>
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="p-4 border border-border rounded-xl">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-muted rounded-full"></div>
                        <div>
                          <div className="h-4 bg-muted rounded mb-1"></div>
                          <div className="h-3 bg-muted rounded"></div>
                        </div>
                      </div>
                      <div className="h-6 bg-muted rounded w-20"></div>
                    </div>
                    <div className="h-12 bg-muted rounded"></div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const connectedPartnerIds = new Set((connections as any)?.map?.((c: any) => c.partner.id) || []);
  const availableMatches = (matches as any)?.filter?.((match: any) => !connectedPartnerIds.has(match.user.id)) || [];

  return (
    <div className="space-y-8">
      {/* Top Resonance Matches */}
      <Card className="energy-glow" data-testid="resonance-matches">
        <CardContent className="p-6">
          <h2 className="text-2xl font-semibold mb-6">Your Top Resonance Matches</h2>
          
          {availableMatches.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-muted-foreground mb-4">
                No new matches available at the moment.
              </div>
              <p className="text-sm text-muted-foreground">
                We'll notify you when new resonant members join the network.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {availableMatches.slice(0, 5).map((match: any) => (
                <div 
                  key={match.user.id}
                  className={`p-4 border rounded-xl transition-colors ${
                    selectedMatch === match.user.id 
                      ? 'border-primary bg-primary/5' 
                      : 'border-border hover:bg-secondary'
                  }`}
                  data-testid={`match-card-${match.user.id}`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                        <span className="text-primary-foreground font-medium">
                          {match.user.firstName?.[0] || 'M'}
                        </span>
                      </div>
                      <div>
                        <div className="font-medium" data-testid={`match-name-${match.user.id}`}>
                          {match.user.firstName || 'Member'}
                        </div>
                        <div className={`role-badge ${match.profile.dominantRole.toLowerCase()} text-xs`}>
                          {match.profile.dominantRole}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <div className="text-sm font-medium text-primary" data-testid={`match-compatibility-${match.user.id}`}>
                          {match.compatibility}% match
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Readiness: {match.profile.readiness}%
                        </div>
                      </div>
                      
                      <Button
                        onClick={() => setSelectedMatch(match.user.id)}
                        variant={selectedMatch === match.user.id ? "default" : "outline"}
                        size="sm"
                        data-testid={`button-select-${match.user.id}`}
                      >
                        {selectedMatch === match.user.id ? "Selected" : "Select"}
                      </Button>
                    </div>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-3" data-testid={`match-dream-${match.user.id}`}>
                    "{match.profile.dream}"
                  </p>
                  
                  <div className="grid grid-cols-3 gap-4 text-xs">
                    <div>
                      <span className="text-muted-foreground">Mind:</span>
                      <span className="ml-1 font-medium">{match.profile.mindEnergy}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Body:</span>
                      <span className="ml-1 font-medium">{match.profile.bodyEnergy}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Heart:</span>
                      <span className="ml-1 font-medium">{match.profile.heartEnergy}</span>
                    </div>
                  </div>
                  
                  {selectedMatch === match.user.id && (
                    <div className="mt-4 p-3 bg-secondary rounded-lg">
                      <p className="text-sm mb-3">
                        Ready to start a resonance exchange with this member?
                      </p>
                      <div className="flex space-x-2">
                        <Button
                          onClick={() => connectMutation.mutate(match.user.id)}
                          disabled={connectMutation.isPending}
                          size="sm"
                          className="cosmic-gradient"
                          data-testid={`button-connect-${match.user.id}`}
                        >
                          {connectMutation.isPending ? "Connecting..." : "Connect"}
                        </Button>
                        <Button
                          onClick={() => setSelectedMatch(null)}
                          variant="ghost"
                          size="sm"
                          data-testid={`button-cancel-${match.user.id}`}
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Active Connections */}
      <Card className="energy-glow" data-testid="active-connections">
        <CardContent className="p-6">
          <h2 className="text-2xl font-semibold mb-6">Your Active Connections</h2>
          
          {!(connections as any) || (connections as any)?.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-muted-foreground mb-4">
                No active connections yet.
              </div>
              <p className="text-sm text-muted-foreground">
                Connect with resonant matches above to start exchanging value.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {(connections as any)?.map?.((connection: any) => (
                <div 
                  key={connection.connection.id}
                  className="p-4 border border-border rounded-xl"
                  data-testid={`connection-card-${connection.connection.id}`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center">
                        <span className="text-accent-foreground font-medium text-sm">
                          {connection.partner.firstName?.[0] || 'M'}
                        </span>
                      </div>
                      <div>
                        <div className="font-medium" data-testid={`connection-name-${connection.connection.id}`}>
                          {connection.partner.firstName || 'Member'}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {connection.connection.exchangeType || 'General exchange'}
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-sm font-medium text-primary">
                        {connection.connection.overallCompatibility}% compatible
                      </div>
                      <div className={`text-xs px-2 py-1 rounded-full ${
                        connection.connection.status === 'active' 
                          ? 'bg-chart-5/20 text-chart-5' 
                          : 'bg-muted text-muted-foreground'
                      }`}>
                        {connection.connection.status}
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-2">
                    "{connection.partnerProfile.dream}"
                  </p>
                  
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">
                      Connected {new Date(connection.connection.createdAt).toLocaleDateString()}
                    </span>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" data-testid={`button-message-${connection.connection.id}`}>
                        Message
                      </Button>
                      <Button size="sm" variant="outline" data-testid={`button-schedule-${connection.connection.id}`}>
                        Schedule
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
