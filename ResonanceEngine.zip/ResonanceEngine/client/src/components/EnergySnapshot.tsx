import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";

const ROLES = ["Generator", "Amplifier", "Anchor", "Catalyst", "Harmonizer"] as const;

export default function EnergySnapshot() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/network/stats"],
    retry: false,
  });

  if (isLoading) {
    return (
      <Card className="energy-glow">
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-muted rounded mb-6"></div>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="text-center">
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-8 bg-muted rounded mb-1"></div>
                  <div className="h-3 bg-muted rounded"></div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!stats) return null;

  const harmonyScore = Math.min(100, Math.max(60, (stats as any)?.averageReadiness || 60));

  return (
    <Card className="energy-glow" data-testid="energy-snapshot">
      <CardContent className="p-6">
        <h2 className="text-2xl font-semibold mb-6 flex items-center">
          <svg className="w-6 h-6 mr-3 text-primary" fill="currentColor" viewBox="0 0 20 20">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
          </svg>
          Network Energy Balance
        </h2>
        
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          {ROLES.map((role, index) => {
            const count = (stats as any)?.roleDistribution?.[role] || 0;
            const percentage = (stats as any)?.totalUsers > 0 ? Math.round((count / (stats as any).totalUsers) * 100) : 0;
            
            return (
              <motion.div
                key={role}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
                data-testid={`role-${role.toLowerCase()}`}
              >
                <div className={`role-badge ${role.toLowerCase()} mb-2`}>
                  {role}
                </div>
                <div className="text-2xl font-bold" data-testid={`count-${role.toLowerCase()}`}>
                  {count}
                </div>
                <div className="text-sm text-muted-foreground">
                  {percentage}%
                </div>
              </motion.div>
            );
          })}
        </div>

        <div className="bg-secondary rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Network Harmony</span>
            <span className="text-sm text-muted-foreground" data-testid="harmony-score">
              {harmonyScore}% Balanced
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <motion.div 
              className="cosmic-gradient h-2 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${harmonyScore}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-2" data-testid="harmony-message">
            {harmonyScore >= 80 
              ? "Excellent network balance across all energy types."
              : harmonyScore >= 60 
              ? "Good balance. Consider recruiting more diverse energy types."
              : "Network is growing. More members will improve energy balance."
            }
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
