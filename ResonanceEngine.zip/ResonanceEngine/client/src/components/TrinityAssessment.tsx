import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { UserProfile } from "@shared/schema";

const DEFAULT_SKILLS = [
  "Writing", "Speaking", "Facilitation", "Coaching", "Design", "Music",
  "Organizing", "Mentoring", "Healing", "Technology", "Fundraising"
];

const DEFAULT_TASKS = [
  "Accountability Partner", "Storytelling", "Research", "Networking",
  "Circle Hosting", "Conflict Mediation", "Project Coordination",
  "Resource Gathering", "Teaching", "Content Creation"
];

interface TrinityAssessmentProps {
  existingProfile?: UserProfile;
}

export default function TrinityAssessment({ existingProfile }: TrinityAssessmentProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Form state
  const [dream, setDream] = useState(existingProfile?.dream || "");
  const [currentState, setCurrentState] = useState(existingProfile?.currentState || "");
  const [blockers, setBlockers] = useState(existingProfile?.blockers || "");
  const [values, setValues] = useState(existingProfile?.values || "");

  // Assessment answers (1-10 scale)
  const [clarity, setClarity] = useState([existingProfile?.clarity || 5]);
  const [discipline, setDiscipline] = useState([existingProfile?.discipline || 5]);
  const [compassion, setCompassion] = useState([existingProfile?.compassion || 5]);
  const [adaptability, setAdaptability] = useState([existingProfile?.adaptability || 5]);
  const [vitality, setVitality] = useState([existingProfile?.vitality || 5]);
  const [connection, setConnection] = useState([existingProfile?.connection || 5]);

  // Skills and tasks
  const [skills, setSkills] = useState<string[]>(existingProfile?.skills as string[] || []);
  const [tasks, setTasks] = useState<string[]>(existingProfile?.tasks as string[] || []);

  // Calculate preview values based on Trinity algorithm
  const calculateChart = () => {
    // Each question contributes specific energy points (1-10 scale)
    // Clarity: Strategic thinking and vision (Mind)
    const mindFromClarity = clarity[0] * 10; // 10-100 points
    
    // Discipline: Focus and execution (Mind + Body)
    const mindFromDiscipline = discipline[0] * 5; // 5-50 points
    const bodyFromDiscipline = discipline[0] * 5; // 5-50 points
    
    // Compassion: Empathy and care (Heart)
    const heartFromCompassion = compassion[0] * 10; // 10-100 points
    
    // Adaptability: Flexibility and creativity (Mind + Heart)
    const mindFromAdaptability = adaptability[0] * 5; // 5-50 points
    const heartFromAdaptability = adaptability[0] * 5; // 5-50 points
    
    // Vitality: Physical energy and action (Body)
    const bodyFromVitality = vitality[0] * 10; // 10-100 points
    
    // Connection: Interpersonal skills (Heart + Mind)
    const heartFromConnection = connection[0] * 5; // 5-50 points
    const mindFromConnection = connection[0] * 3; // 3-30 points
    
    const mind = mindFromClarity + mindFromDiscipline + mindFromAdaptability + mindFromConnection;
    const body = bodyFromDiscipline + bodyFromVitality;
    const heart = heartFromCompassion + heartFromAdaptability + heartFromConnection;
    
    return {
      mind: Math.max(0, Math.min(100, Math.round(mind))),
      body: Math.max(0, Math.min(100, Math.round(body))),
      heart: Math.max(0, Math.min(100, Math.round(heart)))
    };
  };

  const calculateRole = (chart: ReturnType<typeof calculateChart>) => {
    const { mind, body, heart } = chart;
    
    // Check for specific role patterns first (more reliable than sorting)
    
    // Catalyst: Balanced high energies (all three high)
    if (mind >= 70 && body >= 70 && heart >= 70) {
      const variance = Math.max(mind, body, heart) - Math.min(mind, body, heart);
      if (variance <= 15) return "Catalyst";
    }
    
    // Harmonizer: Moderate balanced energies
    const variance = Math.max(mind, body, heart) - Math.min(mind, body, heart);
    if (variance <= 20 && Math.max(mind, body, heart) < 70) return "Harmonizer";
    
    // High energy role patterns
    if (Math.max(mind, body, heart) >= 70) {
      // Generator: High Mind + Body combination
      if (mind >= 70 && body >= 70 && mind >= heart && body >= heart) return "Generator";
      
      // Amplifier: High Heart + Mind combination  
      if (heart >= 70 && mind >= 70 && heart >= body && mind >= body) return "Amplifier";
      
      // Anchor: High Body + Heart combination
      if (body >= 70 && heart >= 70 && body >= mind && heart >= mind) return "Anchor";
      
      // Single high energy fallbacks
      if (mind >= body && mind >= heart) return "Generator";
      if (heart >= mind && heart >= body) return "Amplifier";
      if (body >= mind && body >= heart) return "Anchor";
    }
    
    // Default fallback for edge cases
    return "Harmonizer";
  };

  const calculateReadiness = (chart: ReturnType<typeof calculateChart>) => {
    const avg = (chart.mind + chart.body + chart.heart) / 3;
    const balancePenalty = (Math.abs(chart.mind - avg) + Math.abs(chart.body - avg) + Math.abs(chart.heart - avg)) / 3;
    return Math.max(0, Math.min(100, Math.round(avg - balancePenalty)));
  };

  const chart = calculateChart();
  const role = calculateRole(chart);
  const readiness = calculateReadiness(chart);

  const saveProfileMutation = useMutation({
    mutationFn: async () => {
      const profileData = {
        dream,
        currentState,
        blockers,
        values,
        clarity: clarity[0],
        discipline: discipline[0],
        compassion: compassion[0],
        adaptability: adaptability[0],
        vitality: vitality[0],
        connection: connection[0],
        skills: skills.length > 0 ? skills : undefined,
        tasks: tasks.length > 0 ? tasks : undefined,
      };

      await apiRequest("POST", "/api/profile", profileData);
    },
    onSuccess: () => {
      toast({
        title: "Profile Saved",
        description: "Your Trinity Resonance profile has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      queryClient.invalidateQueries({ queryKey: ["/api/network/stats"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session Expired",
          description: "Please log in again to continue.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 1000);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to save profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSkillToggle = (skill: string) => {
    setSkills(prev => 
      prev.includes(skill) 
        ? prev.filter(s => s !== skill)
        : [...prev, skill]
    );
  };

  const handleTaskToggle = (task: string) => {
    setTasks(prev => 
      prev.includes(task) 
        ? prev.filter(t => t !== task)
        : [...prev, task]
    );
  };

  const isFormValid = dream.trim() && currentState.trim() && blockers.trim() && values.trim();

  return (
    <div className="space-y-8">
      {/* Personal Intake */}
      <Card className="energy-glow">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-6">1) Personal Intake</h2>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="dream">Your Dream</Label>
              <Textarea
                id="dream"
                placeholder="What is your biggest dream or vision?"
                value={dream}
                onChange={(e) => setDream(e.target.value)}
                className="mt-2"
                rows={3}
                data-testid="textarea-dream"
              />
            </div>
            
            <div>
              <Label htmlFor="current-state">Current State</Label>
              <Textarea
                id="current-state"
                placeholder="Where are you now in relation to this dream?"
                value={currentState}
                onChange={(e) => setCurrentState(e.target.value)}
                className="mt-2"
                rows={3}
                data-testid="textarea-current-state"
              />
            </div>
            
            <div>
              <Label htmlFor="blockers">Blockers</Label>
              <Textarea
                id="blockers"
                placeholder="What's holding you back?"
                value={blockers}
                onChange={(e) => setBlockers(e.target.value)}
                className="mt-2"
                rows={3}
                data-testid="textarea-blockers"
              />
            </div>
            
            <div>
              <Label htmlFor="values">Core Values</Label>
              <Textarea
                id="values"
                placeholder="What principles guide your life?"
                value={values}
                onChange={(e) => setValues(e.target.value)}
                className="mt-2"
                rows={2}
                data-testid="textarea-values"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Trinity Assessment */}
      <Card className="energy-glow">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-6">2) Trinity Alignment Assessment</h2>
          
          <div className="space-y-6">
            {/* Clarity */}
            <div>
              <div className="flex justify-between items-center mb-3">
                <Label>Clarity</Label>
                <span className="text-sm text-primary font-medium" data-testid="value-clarity">
                  {clarity[0]}
                </span>
              </div>
              <Slider
                value={clarity}
                onValueChange={setClarity}
                min={1}
                max={10}
                step={1}
                className="w-full"
                data-testid="slider-clarity"
              />
              <p className="text-xs text-muted-foreground mt-1">
                How clear are you about your path forward?
              </p>
            </div>
            
            {/* Discipline */}
            <div>
              <div className="flex justify-between items-center mb-3">
                <Label>Discipline</Label>
                <span className="text-sm text-primary font-medium" data-testid="value-discipline">
                  {discipline[0]}
                </span>
              </div>
              <Slider
                value={discipline}
                onValueChange={setDiscipline}
                min={1}
                max={10}
                step={1}
                className="w-full"
                data-testid="slider-discipline"
              />
              <p className="text-xs text-muted-foreground mt-1">
                How consistent are you with daily practices?
              </p>
            </div>
            
            {/* Compassion */}
            <div>
              <div className="flex justify-between items-center mb-3">
                <Label>Compassion</Label>
                <span className="text-sm text-primary font-medium" data-testid="value-compassion">
                  {compassion[0]}
                </span>
              </div>
              <Slider
                value={compassion}
                onValueChange={setCompassion}
                min={1}
                max={10}
                step={1}
                className="w-full"
                data-testid="slider-compassion"
              />
              <p className="text-xs text-muted-foreground mt-1">
                How easily do you connect with others?
              </p>
            </div>
            
            {/* Adaptability */}
            <div>
              <div className="flex justify-between items-center mb-3">
                <Label>Adaptability</Label>
                <span className="text-sm text-primary font-medium" data-testid="value-adaptability">
                  {adaptability[0]}
                </span>
              </div>
              <Slider
                value={adaptability}
                onValueChange={setAdaptability}
                min={1}
                max={10}
                step={1}
                className="w-full"
                data-testid="slider-adaptability"
              />
              <p className="text-xs text-muted-foreground mt-1">
                How well do you adjust to change?
              </p>
            </div>
            
            {/* Vitality */}
            <div>
              <div className="flex justify-between items-center mb-3">
                <Label>Vitality</Label>
                <span className="text-sm text-primary font-medium" data-testid="value-vitality">
                  {vitality[0]}
                </span>
              </div>
              <Slider
                value={vitality}
                onValueChange={setVitality}
                min={1}
                max={10}
                step={1}
                className="w-full"
                data-testid="slider-vitality"
              />
              <p className="text-xs text-muted-foreground mt-1">
                How's your physical energy and health?
              </p>
            </div>
            
            {/* Connection */}
            <div>
              <div className="flex justify-between items-center mb-3">
                <Label>Connection</Label>
                <span className="text-sm text-primary font-medium" data-testid="value-connection">
                  {connection[0]}
                </span>
              </div>
              <Slider
                value={connection}
                onValueChange={setConnection}
                min={1}
                max={10}
                step={1}
                className="w-full"
                data-testid="slider-connection"
              />
              <p className="text-xs text-muted-foreground mt-1">
                How connected do you feel to your purpose?
              </p>
            </div>
          </div>

          {/* Energy Preview */}
          <div className="mt-6 p-4 bg-secondary rounded-xl">
            <h3 className="font-medium mb-3">Your Energy Profile Preview</h3>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-lg font-bold text-chart-4" data-testid="preview-mind">
                  {chart.mind}
                </div>
                <div className="text-xs text-muted-foreground">Mind</div>
              </div>
              <div>
                <div className="text-lg font-bold text-chart-2" data-testid="preview-body">
                  {chart.body}
                </div>
                <div className="text-xs text-muted-foreground">Body</div>
              </div>
              <div>
                <div className="text-lg font-bold text-chart-1" data-testid="preview-heart">
                  {chart.heart}
                </div>
                <div className="text-xs text-muted-foreground">Heart</div>
              </div>
            </div>
            <div className="mt-3 text-center">
              <span className={`role-badge ${role.toLowerCase()}`} data-testid="preview-role">
                {role}
              </span>
              <div className="text-xs text-muted-foreground mt-1">
                Readiness: <span data-testid="preview-readiness">{readiness}%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Skills & Tasks Module */}
      <Card className="energy-glow">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-6">3) Potential Mapping (Skills & Tasks)</h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            {/* Skills */}
            <div>
              <h3 className="font-medium mb-4">Skills You Bring</h3>
              <div className="space-y-2">
                {DEFAULT_SKILLS.map(skill => (
                  <label key={skill} className="flex items-center space-x-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={skills.includes(skill)}
                      onChange={() => handleSkillToggle(skill)}
                      className="rounded border-border text-primary focus:ring-ring"
                      data-testid={`checkbox-skill-${skill.toLowerCase().replace(/\s+/g, '-')}`}
                    />
                    <span className="text-sm">{skill}</span>
                  </label>
                ))}
              </div>
            </div>
            
            {/* Tasks */}
            <div>
              <h3 className="font-medium mb-4">Tasks You'd Enjoy</h3>
              <div className="space-y-2">
                {DEFAULT_TASKS.map(task => (
                  <label key={task} className="flex items-center space-x-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={tasks.includes(task)}
                      onChange={() => handleTaskToggle(task)}
                      className="rounded border-border text-primary focus:ring-ring"
                      data-testid={`checkbox-task-${task.toLowerCase().replace(/\s+/g, '-')}`}
                    />
                    <span className="text-sm">{task}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-secondary rounded-xl">
            <p className="text-sm text-muted-foreground">
              <strong>Weighting:</strong> Energy drives placement (85%). Skills/Tasks only refine matches (15%).
              This ensures authentic resonance over surface-level skill matching.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <Card className="energy-glow">
        <CardContent className="p-6">
          <Button
            onClick={() => saveProfileMutation.mutate()}
            disabled={!isFormValid || saveProfileMutation.isPending}
            className="w-full cosmic-gradient px-8 py-4 text-lg font-medium hover:opacity-90 transition-opacity"
            data-testid="button-save-profile"
          >
            {saveProfileMutation.isPending 
              ? "Saving..." 
              : existingProfile 
              ? "Update Profile & Recalculate Matches"
              : "Save Profile & Join Network"
            }
          </Button>
          <p className="text-xs text-muted-foreground text-center mt-3">
            Energy drives placement. Skills/Tasks only refine matches.<br/>
            (Weights: 85% energy / 10% skills / 5% tasks)
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
