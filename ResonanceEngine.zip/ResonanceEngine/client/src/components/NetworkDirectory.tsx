import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import type { UserProfile } from "@shared/schema";

export default function NetworkDirectory() {
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");

  const { data: profiles, isLoading } = useQuery({
    queryKey: ["/api/network/profiles"],
    retry: false,
  });

  if (isLoading) {
    return (
      <Card className="energy-glow">
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-8 bg-muted rounded mb-6"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="p-4 border border-border rounded-xl">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-muted rounded-full"></div>
                      <div>
                        <div className="h-4 bg-muted rounded mb-1"></div>
                        <div className="h-3 bg-muted rounded"></div>
                      </div>
                    </div>
                    <div className="h-3 bg-muted rounded w-16"></div>
                  </div>
                  <div className="h-12 bg-muted rounded mb-2"></div>
                  <div className="flex items-center justify-between">
                    <div className="h-3 bg-muted rounded w-20"></div>
                    <div className="h-3 bg-muted rounded w-16"></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!profiles) return null;

  const filteredProfiles = (profiles as any)?.filter?.((profile: UserProfile) => {
    const matchesSearch = !searchTerm || 
      profile.dream.toLowerCase().includes(searchTerm.toLowerCase()) ||
      profile.values.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = roleFilter === "all" || profile.dominantRole === roleFilter;
    
    return matchesSearch && matchesRole;
  });

  const getInitials = (dream: string) => {
    const words = dream.split(' ').filter(word => word.length > 0);
    return words.slice(0, 2).map(word => word[0].toUpperCase()).join('');
  };

  const getStatusColor = (readiness: number) => {
    if (readiness >= 80) return "text-chart-5";
    if (readiness >= 60) return "text-chart-4";
    return "text-primary";
  };

  const getStatusText = (readiness: number) => {
    if (readiness >= 80) return "Available";
    if (readiness >= 60) return "Active";
    return "Building";
  };

  return (
    <Card className="energy-glow" data-testid="network-directory">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold mb-4 md:mb-0">Network Directory</h2>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Input
              placeholder="Search dreams, values..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full sm:w-64"
              data-testid="input-search"
            />
            
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="px-3 py-2 rounded-md border border-border bg-background text-foreground"
              data-testid="select-role-filter"
            >
              <option value="all">All Roles</option>
              <option value="Generator">Generator</option>
              <option value="Amplifier">Amplifier</option>
              <option value="Anchor">Anchor</option>
              <option value="Catalyst">Catalyst</option>
              <option value="Harmonizer">Harmonizer</option>
            </select>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProfiles.map((profile: UserProfile) => (
            <div 
              key={profile.id}
              className="p-4 border border-border rounded-xl hover:bg-secondary transition-colors cursor-pointer"
              data-testid={`profile-card-${profile.id}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-primary-foreground font-medium text-sm">
                      {getInitials(profile.dream)}
                    </span>
                  </div>
                  <div>
                    <div className="font-medium" data-testid={`profile-name-${profile.id}`}>
                      Member #{profile.id.slice(-6)}
                    </div>
                    <div className={`role-badge ${profile.dominantRole.toLowerCase()} text-xs`}>
                      {profile.dominantRole}
                    </div>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground" data-testid={`profile-readiness-${profile.id}`}>
                  {profile.readiness}% ready
                </div>
              </div>
              
              <p className="text-sm text-muted-foreground mb-2 line-clamp-2" data-testid={`profile-dream-${profile.id}`}>
                "{profile.dream}"
              </p>
              
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground" data-testid={`profile-placement-${profile.id}`}>
                  {profile.preferredPlacement.split(' ')[0]}
                </span>
                <span className={getStatusColor(profile.readiness)} data-testid={`profile-status-${profile.id}`}>
                  {getStatusText(profile.readiness)}
                </span>
              </div>
              
              {profile.skills && profile.skills.length > 0 && (
                <div className="mt-2 text-xs text-muted-foreground">
                  <span className="font-medium">Skills:</span> {(profile.skills as string[]).slice(0, 3).join(", ")}
                  {(profile.skills as string[]).length > 3 && "..."}
                </div>
              )}
            </div>
          ))}
        </div>

        {filteredProfiles.length === 0 && (
          <div className="text-center py-12">
            <div className="text-muted-foreground mb-4">
              No members found matching your search criteria.
            </div>
            <Button 
              onClick={() => {
                setSearchTerm("");
                setRoleFilter("all");
              }}
              variant="outline"
              data-testid="button-clear-filters"
            >
              Clear Filters
            </Button>
          </div>
        )}

        <div className="mt-6 text-center">
          <div className="text-sm text-muted-foreground mb-4">
            {(profiles as any)?.length || 0} total members in the network
          </div>
          <p className="text-xs text-muted-foreground max-w-2xl mx-auto">
            The Resonance Exchange Network is a quantum-inspired, self-adjusting ecosystem that creates conditions 
            for the right outcomes to emerge from millions of possibilities.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
