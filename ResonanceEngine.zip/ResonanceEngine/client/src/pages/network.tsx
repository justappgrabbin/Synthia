import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import EnergySnapshot from "@/components/EnergySnapshot";
import NetworkDirectory from "@/components/NetworkDirectory";

export default function Network() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You need to be logged in to access the network.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="cosmic-gradient w-16 h-16 rounded-2xl flex items-center justify-center animate-pulse">
          <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
          </svg>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation Header */}
      <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setLocation("/")}
                className="flex items-center space-x-4 hover:opacity-80 transition-opacity"
                data-testid="button-home"
              >
                <div className="cosmic-gradient w-8 h-8 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                  </svg>
                </div>
                <h1 className="text-xl font-semibold">Trinity Resonance</h1>
              </button>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setLocation("/")}
                className="text-muted-foreground hover:text-foreground transition-colors text-sm"
                data-testid="link-dashboard"
              >
                Dashboard
              </button>
              <button
                onClick={() => setLocation("/assessment")}
                className="text-muted-foreground hover:text-foreground transition-colors text-sm"
                data-testid="link-assessment"
              >
                Assessment
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Network Explorer
            </span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-6">
            Discover and connect with resonant members across the Trinity network. 
            Explore energy patterns, find complementary roles, and create meaningful exchanges.
          </p>
        </div>

        {/* Network Energy Balance */}
        <div className="mb-8">
          <EnergySnapshot />
        </div>

        {/* Network Principles */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="energy-glow">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="font-semibold mb-2 text-primary">Resonance {'>'} Resources</h3>
              <p className="text-sm text-muted-foreground">
                Connections based on energetic complementarity, not just skills or availability.
              </p>
            </CardContent>
          </Card>

          <Card className="energy-glow">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center mx-auto mb-4">
                <svg className="w-6 h-6 text-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707" />
                </svg>
              </div>
              <h3 className="font-semibold mb-2 text-accent">Potential {'>'} Performance</h3>
              <p className="text-sm text-muted-foreground">
                We honor what someone could bring forth, not only what they already excel at.
              </p>
            </CardContent>
          </Card>

          <Card className="energy-glow">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-chart-4/20 flex items-center justify-center mx-auto mb-4">
                <svg className="w-6 h-6 text-chart-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
              </div>
              <h3 className="font-semibold mb-2 text-chart-4">Circulation {'>'} Extraction</h3>
              <p className="text-sm text-muted-foreground">
                Value flows in loops where one person's challenge becomes another's gift.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
          <Button 
            onClick={() => setLocation("/")}
            className="cosmic-gradient px-6 py-3 hover:opacity-90 transition-opacity"
            data-testid="button-find-matches"
          >
            Find Your Matches
          </Button>
          <Button 
            onClick={() => setLocation("/assessment")}
            variant="outline"
            className="px-6 py-3 border-border hover:bg-secondary"
            data-testid="button-retake-assessment"
          >
            Retake Assessment
          </Button>
        </div>

        {/* Network Directory */}
        <NetworkDirectory />

        {/* Footer */}
        <div className="text-center mt-12 text-xs text-muted-foreground">
          <p className="mb-2">
            The Resonance Exchange Network is a quantum-inspired, self-adjusting ecosystem.
          </p>
          <p>
            It creates conditions for the right outcomes to emerge from millions of possibilities.
          </p>
        </div>
      </div>
    </div>
  );
}
