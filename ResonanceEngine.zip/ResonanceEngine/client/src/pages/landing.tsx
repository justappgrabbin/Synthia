import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-secondary/20" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="cosmic-gradient w-20 h-20 rounded-2xl mx-auto mb-8 flex items-center justify-center">
              <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
              </svg>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Trinity Resonance
              </span>
              <br />
              <span className="text-2xl md:text-3xl text-muted-foreground">Exchange Network</span>
            </h1>
            
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-8">
              A consciousness-based exchange network where people's dreams, energies, and potential are mapped, 
              so value can circulate in ways that help each member move toward their highest goals.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={() => window.location.href = "/api/login"}
                className="cosmic-gradient px-8 py-3 text-lg font-medium hover:opacity-90 transition-opacity"
                data-testid="button-login"
              >
                Join the Network
              </Button>
              <Button 
                variant="outline" 
                className="px-8 py-3 text-lg border-border hover:bg-secondary"
                onClick={() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' })}
                data-testid="button-learn-more"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works Section */}
      <div id="how-it-works" className="py-24 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">How Trinity Resonance Works</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Connect through energy alignment, not just skills matching
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="energy-glow">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-chart-4/20 flex items-center justify-center mx-auto mb-6">
                  <svg className="w-8 h-8 text-chart-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-4">1. Trinity Assessment</h3>
                <p className="text-muted-foreground">
                  Map your Mind, Body, and Heart energies through our 6-question alignment assessment to discover your unique resonance pattern.
                </p>
              </CardContent>
            </Card>

            <Card className="energy-glow">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-6">
                  <svg className="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-4">2. Smart Matching</h3>
                <p className="text-muted-foreground">
                  Get connected with complementary energy patterns. Our algorithm prioritizes resonance over surface-level compatibility.
                </p>
              </CardContent>
            </Card>

            <Card className="energy-glow">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center mx-auto mb-6">
                  <svg className="w-8 h-8 text-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-4">3. Value Exchange</h3>
                <p className="text-muted-foreground">
                  Engage in meaningful exchanges where everyone gives and receives. Transform challenges into gifts through conscious collaboration.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Key Principles Section */}
      <div className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Core Principles</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4 text-primary">Resonance {'>'} Resources</h3>
              <p className="text-muted-foreground">
                People are matched by energetic complementarity, not just skills or availability.
              </p>
            </div>
            
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4 text-accent">Potential {'>'} Performance</h3>
              <p className="text-muted-foreground">
                We honor what someone could bring forth, not only what they already excel at.
              </p>
            </div>
            
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4 text-chart-4">Circulation {'>'} Extraction</h3>
              <p className="text-muted-foreground">
                Value flows in loops where one person's challenge becomes another's gift.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 bg-card">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Find Your Resonance?
          </h2>
          <p className="text-muted-foreground text-lg mb-8">
            Join a living economic-energetic ecosystem where dreams, energies, and potentials interlock.
          </p>
          <Button 
            onClick={() => window.location.href = "/api/login"}
            size="lg"
            className="cosmic-gradient px-12 py-4 text-lg font-medium hover:opacity-90 transition-opacity"
            data-testid="button-join-network"
          >
            Start Your Trinity Assessment
          </Button>
        </div>
      </div>
    </div>
  );
}
