import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import EnergySnapshot from "@/components/EnergySnapshot";
import TrinityAssessment from "@/components/TrinityAssessment";
import NetworkDirectory from "@/components/NetworkDirectory";
import ResonanceMatching from "@/components/ResonanceMatching";
import type { UserProfile } from "@shared/schema";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("dashboard");

  const { data: profile, isLoading: profileLoading, error: profileError } = useQuery({
    queryKey: ["/api/profile"],
    enabled: isAuthenticated,
    retry: false,
  });

  const { data: exchangeStats } = useQuery({
    queryKey: ["/api/exchange/stats"],
    enabled: isAuthenticated && !!profile,
    retry: false,
  });

  if (profileError && isUnauthorizedError(profileError as Error)) {
    toast({
      title: "Session Expired",
      description: "Please log in again to continue.",
      variant: "destructive",
    });
    setTimeout(() => {
      window.location.href = "/api/login";
    }, 1000);
    return null;
  }

  if (profileLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="cosmic-gradient w-16 h-16 rounded-2xl flex items-center justify-center animate-pulse">
          <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
          </svg>
        </div>
      </div>
    );
  }

  // If no profile exists, redirect to assessment
  if (!profile) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-6">
              Welcome to <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Trinity Resonance</span>
            </h1>
            <p className="text-muted-foreground text-lg mb-8">
              Let's start by mapping your unique energy signature
            </p>
          </div>
          
          <TrinityAssessment />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation Header */}
      <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="cosmic-gradient w-8 h-8 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                </svg>
              </div>
              <h1 className="text-xl font-semibold">Trinity Resonance</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-muted-foreground">
                Welcome, {(user as any)?.firstName || 'Member'}
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => window.location.href = "/api/logout"}
                data-testid="button-logout"
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Banner */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Your Resonance Dashboard
            </span>
          </h1>
          <div className="flex items-center justify-center space-x-4">
            <div className={`role-badge ${(profile as any)?.dominantRole?.toLowerCase()}`}>
              {(profile as any)?.dominantRole}
            </div>
            <div className="text-muted-foreground">
              Readiness: {(profile as any)?.readiness}%
            </div>
            <div className="text-muted-foreground">
              {(profile as any)?.preferredPlacement}
            </div>
          </div>
        </div>

        {/* Network Energy Balance */}
        <EnergySnapshot />

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="dashboard" data-testid="tab-dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="resonance" data-testid="tab-resonance">Resonance</TabsTrigger>
            <TabsTrigger value="network" data-testid="tab-network">Network</TabsTrigger>
            <TabsTrigger value="profile" data-testid="tab-profile">Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="mt-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Personal Stats */}
              <div className="lg:col-span-2">
                <Card className="energy-glow">
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold mb-6">Your Network Impact</h2>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-primary" data-testid="stat-exchanges">
                          {(exchangeStats as any)?.totalExchanges || 0}
                        </div>
                        <div className="text-xs text-muted-foreground">Exchanges</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-accent" data-testid="stat-connections">
                          {(exchangeStats as any)?.totalConnections || 0}
                        </div>
                        <div className="text-xs text-muted-foreground">Connections</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-chart-3" data-testid="stat-hours">
                          {(exchangeStats as any)?.totalHours || 0}
                        </div>
                        <div className="text-xs text-muted-foreground">Hours Given</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-chart-4" data-testid="stat-impact">
                          {(exchangeStats as any)?.averageRating || 0}
                        </div>
                        <div className="text-xs text-muted-foreground">Avg Rating</div>
                      </div>
                    </div>

                    <div className="p-4 bg-secondary rounded-xl">
                      <h3 className="font-medium mb-3">Your Energy Profile</h3>
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <div className="text-lg font-bold text-chart-4" data-testid="energy-mind">
                            {(profile as any)?.mindEnergy}
                          </div>
                          <div className="text-xs text-muted-foreground">Mind</div>
                        </div>
                        <div>
                          <div className="text-lg font-bold text-chart-2" data-testid="energy-body">
                            {(profile as any)?.bodyEnergy}
                          </div>
                          <div className="text-xs text-muted-foreground">Body</div>
                        </div>
                        <div>
                          <div className="text-lg font-bold text-chart-1" data-testid="energy-heart">
                            {(profile as any)?.heartEnergy}
                          </div>
                          <div className="text-xs text-muted-foreground">Heart</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Dream Focus */}
              <div>
                <Card className="energy-glow">
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold mb-4">Your Dream</h2>
                    <p className="text-muted-foreground mb-4" data-testid="text-dream">
                      {(profile as any)?.dream}
                    </p>
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => setActiveTab("profile")}
                      data-testid="button-edit-dream"
                    >
                      Update Dream
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="resonance" className="mt-8">
            <ResonanceMatching />
          </TabsContent>

          <TabsContent value="network" className="mt-8">
            <NetworkDirectory />
          </TabsContent>

          <TabsContent value="profile" className="mt-8">
            <TrinityAssessment existingProfile={profile as UserProfile} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
