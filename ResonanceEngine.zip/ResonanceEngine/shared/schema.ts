import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
  real,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User profiles with Trinity data
export const userProfiles = pgTable("user_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  // Intake data
  dream: text("dream").notNull(),
  currentState: text("current_state").notNull(),
  blockers: text("blockers").notNull(),
  values: text("values").notNull(),
  
  // Assessment answers (1-10 scale)
  clarity: integer("clarity").notNull(),
  discipline: integer("discipline").notNull(),
  compassion: integer("compassion").notNull(),
  adaptability: integer("adaptability").notNull(),
  vitality: integer("vitality").notNull(),
  connection: integer("connection").notNull(),
  
  // Calculated energy chart
  mindEnergy: integer("mind_energy").notNull(),
  bodyEnergy: integer("body_energy").notNull(),
  heartEnergy: integer("heart_energy").notNull(),
  
  // Role and readiness
  dominantRole: varchar("dominant_role").notNull(),
  readiness: integer("readiness").notNull(),
  preferredPlacement: varchar("preferred_placement").notNull(),
  
  // Skills and tasks (JSON arrays)
  skills: jsonb("skills").$type<string[]>(),
  tasks: jsonb("tasks").$type<string[]>(),
  
  // Status
  isActive: boolean("is_active").default(true),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Resonance connections between users
export const resonanceConnections = pgTable("resonance_connections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  partnerId: varchar("partner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  // Compatibility scores
  energyCompatibility: real("energy_compatibility").notNull(),
  skillsCompatibility: real("skills_compatibility"),
  tasksCompatibility: real("tasks_compatibility"),
  overallCompatibility: integer("overall_compatibility").notNull(),
  
  // Exchange details
  exchangeType: varchar("exchange_type"), // "accountability", "mentoring", "collaboration", etc.
  status: varchar("status").notNull().default("suggested"), // "suggested", "active", "completed", "paused"
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Exchange activities and logs
export const exchangeActivities = pgTable("exchange_activities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  connectionId: varchar("connection_id").notNull().references(() => resonanceConnections.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  activityType: varchar("activity_type").notNull(), // "session", "feedback", "milestone"
  description: text("description"),
  duration: integer("duration"), // in minutes
  rating: integer("rating"), // 1-10
  
  createdAt: timestamp("created_at").defaultNow(),
});

// Schemas for validation
export const insertUserProfileSchema = createInsertSchema(userProfiles).pick({
  dream: true,
  currentState: true,
  blockers: true,
  values: true,
  clarity: true,
  discipline: true,
  compassion: true,
  adaptability: true,
  vitality: true,
  connection: true,
  skills: true,
  tasks: true,
});

export const insertResonanceConnectionSchema = createInsertSchema(resonanceConnections).pick({
  partnerId: true,
  exchangeType: true,
});

export const insertExchangeActivitySchema = createInsertSchema(exchangeActivities).pick({
  connectionId: true,
  activityType: true,
  description: true,
  duration: true,
  rating: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;
export type ResonanceConnection = typeof resonanceConnections.$inferSelect;
export type InsertResonanceConnection = z.infer<typeof insertResonanceConnectionSchema>;
export type ExchangeActivity = typeof exchangeActivities.$inferSelect;
export type InsertExchangeActivity = z.infer<typeof insertExchangeActivitySchema>;
