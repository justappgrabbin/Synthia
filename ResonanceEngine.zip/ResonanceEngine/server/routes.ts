import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertUserProfileSchema, insertResonanceConnectionSchema, insertExchangeActivitySchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Profile routes
  app.get('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getUserProfile(userId);
      res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  app.post('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertUserProfileSchema.parse(req.body);
      
      const existingProfile = await storage.getUserProfile(userId);
      let profile;
      
      if (existingProfile) {
        profile = await storage.updateUserProfile(userId, validatedData);
      } else {
        profile = await storage.createUserProfile(userId, validatedData);
      }
      
      res.json(profile);
    } catch (error: any) {
      console.error("Error creating/updating profile:", error);
      if (error.name === 'ZodError') {
        res.status(400).json({ message: "Invalid profile data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to save profile" });
      }
    }
  });

  app.put('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const updates = req.body;
      
      const profile = await storage.updateUserProfile(userId, updates);
      res.json(profile);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Network routes
  app.get('/api/network/profiles', isAuthenticated, async (req: any, res) => {
    try {
      const profiles = await storage.getAllActiveProfiles();
      res.json(profiles);
    } catch (error) {
      console.error("Error fetching network profiles:", error);
      res.status(500).json({ message: "Failed to fetch network profiles" });
    }
  });

  app.get('/api/network/stats', isAuthenticated, async (req: any, res) => {
    try {
      const stats = await storage.getNetworkStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching network stats:", error);
      res.status(500).json({ message: "Failed to fetch network stats" });
    }
  });

  // Resonance matching routes
  app.get('/api/resonance/matches', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 10;
      
      const matches = await storage.calculateResonanceMatches(userId, limit);
      res.json(matches);
    } catch (error) {
      console.error("Error calculating resonance matches:", error);
      res.status(500).json({ message: "Failed to calculate matches" });
    }
  });

  app.post('/api/resonance/connect', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertResonanceConnectionSchema.parse(req.body);
      
      const connection = await storage.createResonanceConnection(userId, validatedData);
      res.json(connection);
    } catch (error: any) {
      console.error("Error creating resonance connection:", error);
      if (error.name === 'ZodError') {
        res.status(400).json({ message: "Invalid connection data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create connection" });
      }
    }
  });

  app.get('/api/resonance/connections', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const connections = await storage.getUserConnections(userId);
      res.json(connections);
    } catch (error) {
      console.error("Error fetching user connections:", error);
      res.status(500).json({ message: "Failed to fetch connections" });
    }
  });

  // Exchange routes
  app.post('/api/exchange/activity', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertExchangeActivitySchema.parse(req.body);
      
      const activity = await storage.addExchangeActivity(userId, validatedData);
      res.json(activity);
    } catch (error: any) {
      console.error("Error adding exchange activity:", error);
      if (error.name === 'ZodError') {
        res.status(400).json({ message: "Invalid activity data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to add activity" });
      }
    }
  });

  app.get('/api/exchange/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserExchangeStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching exchange stats:", error);
      res.status(500).json({ message: "Failed to fetch exchange stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
