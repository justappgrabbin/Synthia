import {
  users,
  userProfiles,
  resonanceConnections,
  exchangeActivities,
  type User,
  type UpsertUser,
  type UserProfile,
  type InsertUserProfile,
  type ResonanceConnection,
  type InsertResonanceConnection,
  type ExchangeActivity,
  type InsertExchangeActivity,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, ne } from "drizzle-orm";

// Trinity Resonance calculation functions
const ROLES = ["Generator", "Amplifier", "Anchor", "Catalyst", "Harmonizer"] as const;
type Role = typeof ROLES[number];

const PLACEMENTS = [
  "Core Receiver (Dream Focus)",
  "Distributor (Daily Support Exchange)",
  "Peer Mirror (Mutual Reflection)",
  "Guide (Lived Experience Mentor)",
  "Circle (Group Resonance)",
] as const;
type Placement = typeof PLACEMENTS[number];

const clamp = (n: number, min = 0, max = 100) => Math.max(min, Math.min(max, Math.round(n)));

function chartFromAnswers(answers: {
  clarity: number;
  discipline: number;
  compassion: number;
  adaptability: number;
  vitality: number;
  connection: number;
}) {
  // Match the corrected frontend Trinity algorithm
  // Clarity: Strategic thinking and vision (Mind)
  const mindFromClarity = answers.clarity * 10; // 10-100 points
  
  // Discipline: Focus and execution (Mind + Body)
  const mindFromDiscipline = answers.discipline * 5; // 5-50 points
  const bodyFromDiscipline = answers.discipline * 5; // 5-50 points
  
  // Compassion: Empathy and care (Heart)
  const heartFromCompassion = answers.compassion * 10; // 10-100 points
  
  // Adaptability: Flexibility and creativity (Mind + Heart)
  const mindFromAdaptability = answers.adaptability * 5; // 5-50 points
  const heartFromAdaptability = answers.adaptability * 5; // 5-50 points
  
  // Vitality: Physical energy and action (Body)
  const bodyFromVitality = answers.vitality * 10; // 10-100 points
  
  // Connection: Interpersonal skills (Heart + Mind)
  const heartFromConnection = answers.connection * 5; // 5-50 points
  const mindFromConnection = answers.connection * 3; // 3-30 points
  
  const mind = mindFromClarity + mindFromDiscipline + mindFromAdaptability + mindFromConnection;
  const body = bodyFromDiscipline + bodyFromVitality;
  const heart = heartFromCompassion + heartFromAdaptability + heartFromConnection;
  
  return {
    mind: clamp(mind),
    body: clamp(body),
    heart: clamp(heart)
  };
}

function roleFromChart(chart: { mind: number; body: number; heart: number }): Role {
  const { mind, body, heart } = chart;
  
  // Check for specific role patterns first (more reliable than sorting)
  
  // Catalyst: Balanced high energies (all three high)
  if (mind >= 70 && body >= 70 && heart >= 70) {
    const variance = Math.max(mind, body, heart) - Math.min(mind, body, heart);
    if (variance <= 15) return "Catalyst";
  }
  
  // Harmonizer: Moderate balanced energies
  const variance = Math.max(mind, body, heart) - Math.min(mind, body, heart);
  if (variance <= 20 && Math.max(mind, body, heart) < 70) return "Harmonizer";
  
  // High energy role patterns
  if (Math.max(mind, body, heart) >= 70) {
    // Generator: High Mind + Body combination
    if (mind >= 70 && body >= 70 && mind >= heart && body >= heart) return "Generator";
    
    // Amplifier: High Heart + Mind combination  
    if (heart >= 70 && mind >= 70 && heart >= body && mind >= body) return "Amplifier";
    
    // Anchor: High Body + Heart combination
    if (body >= 70 && heart >= 70 && body >= mind && heart >= mind) return "Anchor";
    
    // Single high energy fallbacks
    if (mind >= body && mind >= heart) return "Generator";
    if (heart >= mind && heart >= body) return "Amplifier";
    if (body >= mind && body >= heart) return "Anchor";
  }
  
  // Default fallback for edge cases
  return "Harmonizer";
}

function readinessIndex(chart: { mind: number; body: number; heart: number }): number {
  const avg = (chart.mind + chart.body + chart.heart) / 3;
  const balancePenalty = (Math.abs(chart.mind - avg) + Math.abs(chart.body - avg) + Math.abs(chart.heart - avg)) / 3;
  return clamp(avg - balancePenalty);
}

function placementSuggestion(profile: UserProfile): Placement {
  if (profile.readiness >= 75) return "Core Receiver (Dream Focus)";
  if (profile.dominantRole === "Amplifier") return "Distributor (Daily Support Exchange)";
  if (profile.dominantRole === "Anchor") return "Circle (Group Resonance)";
  if (profile.dominantRole === "Catalyst") return "Peer Mirror (Mutual Reflection)";
  return "Guide (Lived Experience Mentor)";
}

// Compatibility calculations
const COMPLEMENTS: Record<Role, Role[]> = {
  Generator: ["Amplifier", "Harmonizer"],
  Amplifier: ["Generator", "Anchor"],
  Anchor: ["Catalyst", "Amplifier"],
  Catalyst: ["Anchor", "Harmonizer"],
  Harmonizer: ["Generator", "Catalyst"]
};

function cosine(a: { mind: number; body: number; heart: number }, b: { mind: number; body: number; heart: number }) {
  const v1 = [a.mind, a.body, a.heart];
  const v2 = [b.mind, b.body, b.heart];
  const dot = v1.reduce((s, x, i) => s + x * v2[i], 0);
  const m1 = Math.sqrt(v1.reduce((s, x) => s + x * x, 0));
  const m2 = Math.sqrt(v2.reduce((s, x) => s + x * x, 0));
  return dot / (m1 * m2);
}

function compatibilityEnergy(a: UserProfile, b: UserProfile) {
  const base = cosine(
    { mind: a.mindEnergy, body: a.bodyEnergy, heart: a.heartEnergy },
    { mind: b.mindEnergy, body: b.bodyEnergy, heart: b.heartEnergy }
  );
  const bonus = COMPLEMENTS[a.dominantRole as Role]?.includes(b.dominantRole as Role) ? 0.08 : 0;
  return (base + 1) / 2 + bonus;
}

function jaccard(a: string[] = [], b: string[] = []) {
  if (!a.length && !b.length) return 0;
  const A = new Set(a);
  const B = new Set(b);
  const inter = Array.from(A).filter(x => B.has(x)).length;
  const uni = new Set([...a, ...b]).size;
  return inter / uni;
}

function overallCompatibility(a: UserProfile, b: UserProfile, weights = { energy: 0.85, skills: 0.1, tasks: 0.05 }) {
  const e = compatibilityEnergy(a, b);
  const s = jaccard(a.skills || [], b.skills || []);
  const t = jaccard(a.tasks || [], b.tasks || []);
  const score = weights.energy * e + weights.skills * s + weights.tasks * t;
  return clamp(score * 100);
}

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Profile operations
  createUserProfile(userId: string, profileData: InsertUserProfile): Promise<UserProfile>;
  getUserProfile(userId: string): Promise<UserProfile | undefined>;
  updateUserProfile(userId: string, profileData: Partial<InsertUserProfile>): Promise<UserProfile>;
  
  // Network operations
  getAllActiveProfiles(): Promise<UserProfile[]>;
  getNetworkStats(): Promise<{
    totalUsers: number;
    roleDistribution: Record<Role, number>;
    averageReadiness: number;
  }>;
  
  // Resonance operations
  calculateResonanceMatches(userId: string, limit?: number): Promise<{
    profile: UserProfile;
    user: User;
    compatibility: number;
  }[]>;
  createResonanceConnection(userId: string, connectionData: InsertResonanceConnection): Promise<ResonanceConnection>;
  getUserConnections(userId: string): Promise<{
    connection: ResonanceConnection;
    partner: User;
    partnerProfile: UserProfile;
  }[]>;
  
  // Exchange operations
  addExchangeActivity(userId: string, activityData: InsertExchangeActivity): Promise<ExchangeActivity>;
  getUserExchangeStats(userId: string): Promise<{
    totalExchanges: number;
    totalConnections: number;
    totalHours: number;
    averageRating: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Profile operations
  async createUserProfile(userId: string, profileData: InsertUserProfile): Promise<UserProfile> {
    // Calculate energy chart and role
    const chart = chartFromAnswers(profileData);
    const dominantRole = roleFromChart(chart);
    const readiness = readinessIndex(chart);
    
    const enrichedData = {
      ...profileData,
      userId,
      mindEnergy: chart.mind,
      bodyEnergy: chart.body,
      heartEnergy: chart.heart,
      dominantRole,
      readiness,
      preferredPlacement: "" // Will be set after insert
    };

    const [profile] = await db
      .insert(userProfiles)
      .values(enrichedData)
      .returning();

    // Update with calculated placement
    const placement = placementSuggestion(profile);
    const [updatedProfile] = await db
      .update(userProfiles)
      .set({ preferredPlacement: placement })
      .where(eq(userProfiles.id, profile.id))
      .returning();

    return updatedProfile;
  }

  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    const [profile] = await db
      .select()
      .from(userProfiles)
      .where(and(eq(userProfiles.userId, userId), eq(userProfiles.isActive, true)));
    return profile;
  }

  async updateUserProfile(userId: string, profileData: Partial<InsertUserProfile>): Promise<UserProfile> {
    // Recalculate if assessment data changed
    let updateData: any = { ...profileData, updatedAt: new Date() };
    
    if (profileData.clarity !== undefined || profileData.discipline !== undefined ||
        profileData.compassion !== undefined || profileData.adaptability !== undefined ||
        profileData.vitality !== undefined || profileData.connection !== undefined) {
      
      const currentProfile = await this.getUserProfile(userId);
      if (currentProfile) {
        const newAnswers = {
          clarity: profileData.clarity ?? currentProfile.clarity,
          discipline: profileData.discipline ?? currentProfile.discipline,
          compassion: profileData.compassion ?? currentProfile.compassion,
          adaptability: profileData.adaptability ?? currentProfile.adaptability,
          vitality: profileData.vitality ?? currentProfile.vitality,
          connection: profileData.connection ?? currentProfile.connection,
        };
        
        const chart = chartFromAnswers(newAnswers);
        const dominantRole = roleFromChart(chart);
        const readiness = readinessIndex(chart);
        
        updateData = {
          ...updateData,
          mindEnergy: chart.mind,
          bodyEnergy: chart.body,
          heartEnergy: chart.heart,
          dominantRole,
          readiness,
        };
      }
    }

    const [profile] = await db
      .update(userProfiles)
      .set(updateData)
      .where(eq(userProfiles.userId, userId))
      .returning();

    // Update placement if role/readiness changed
    if (updateData.dominantRole || updateData.readiness) {
      const placement = placementSuggestion(profile);
      const [updatedProfile] = await db
        .update(userProfiles)
        .set({ preferredPlacement: placement })
        .where(eq(userProfiles.id, profile.id))
        .returning();
      return updatedProfile;
    }

    return profile;
  }

  // Network operations
  async getAllActiveProfiles(): Promise<UserProfile[]> {
    return await db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.isActive, true))
      .orderBy(desc(userProfiles.createdAt));
  }

  async getNetworkStats(): Promise<{
    totalUsers: number;
    roleDistribution: Record<Role, number>;
    averageReadiness: number;
  }> {
    const profiles = await this.getAllActiveProfiles();
    
    const roleDistribution = ROLES.reduce((acc, role) => {
      acc[role] = profiles.filter(p => p.dominantRole === role).length;
      return acc;
    }, {} as Record<Role, number>);

    const averageReadiness = profiles.length > 0 
      ? profiles.reduce((sum, p) => sum + p.readiness, 0) / profiles.length
      : 0;

    return {
      totalUsers: profiles.length,
      roleDistribution,
      averageReadiness: Math.round(averageReadiness),
    };
  }

  // Resonance operations
  async calculateResonanceMatches(userId: string, limit = 10): Promise<{
    profile: UserProfile;
    user: User;
    compatibility: number;
  }[]> {
    const userProfile = await this.getUserProfile(userId);
    if (!userProfile) return [];

    const allProfiles = await db
      .select({
        profile: userProfiles,
        user: users,
      })
      .from(userProfiles)
      .innerJoin(users, eq(userProfiles.userId, users.id))
      .where(and(
        eq(userProfiles.isActive, true),
        ne(userProfiles.userId, userId)
      ));

    const matches = allProfiles.map(({ profile, user }) => ({
      profile,
      user,
      compatibility: overallCompatibility(userProfile, profile)
    }))
    .sort((a, b) => b.compatibility - a.compatibility)
    .slice(0, limit);

    return matches;
  }

  async createResonanceConnection(userId: string, connectionData: InsertResonanceConnection): Promise<ResonanceConnection> {
    const userProfile = await this.getUserProfile(userId);
    const partnerProfile = await this.getUserProfile(connectionData.partnerId);
    
    if (!userProfile || !partnerProfile) {
      throw new Error("User profiles not found");
    }

    const energyCompatibility = compatibilityEnergy(userProfile, partnerProfile);
    const skillsCompatibility = jaccard(userProfile.skills || [], partnerProfile.skills || []);
    const tasksCompatibility = jaccard(userProfile.tasks || [], partnerProfile.tasks || []);
    const overallCompatibilityScore = overallCompatibility(userProfile, partnerProfile);

    const [connection] = await db
      .insert(resonanceConnections)
      .values({
        ...connectionData,
        userId,
        energyCompatibility,
        skillsCompatibility,
        tasksCompatibility,
        overallCompatibility: overallCompatibilityScore,
      })
      .returning();

    return connection;
  }

  async getUserConnections(userId: string): Promise<{
    connection: ResonanceConnection;
    partner: User;
    partnerProfile: UserProfile;
  }[]> {
    const connections = await db
      .select({
        connection: resonanceConnections,
        partner: users,
        partnerProfile: userProfiles,
      })
      .from(resonanceConnections)
      .innerJoin(users, eq(resonanceConnections.partnerId, users.id))
      .innerJoin(userProfiles, eq(users.id, userProfiles.userId))
      .where(eq(resonanceConnections.userId, userId))
      .orderBy(desc(resonanceConnections.createdAt));

    return connections;
  }

  // Exchange operations
  async addExchangeActivity(userId: string, activityData: InsertExchangeActivity): Promise<ExchangeActivity> {
    const [activity] = await db
      .insert(exchangeActivities)
      .values({
        ...activityData,
        userId,
      })
      .returning();

    return activity;
  }

  async getUserExchangeStats(userId: string): Promise<{
    totalExchanges: number;
    totalConnections: number;
    totalHours: number;
    averageRating: number;
  }> {
    const connections = await db
      .select()
      .from(resonanceConnections)
      .where(or(
        eq(resonanceConnections.userId, userId),
        eq(resonanceConnections.partnerId, userId)
      ));

    const activities = await db
      .select()
      .from(exchangeActivities)
      .where(eq(exchangeActivities.userId, userId));

    const totalHours = activities
      .filter(a => a.duration)
      .reduce((sum, a) => sum + (a.duration || 0), 0) / 60; // Convert minutes to hours

    const ratingsCount = activities.filter(a => a.rating).length;
    const averageRating = ratingsCount > 0
      ? activities.filter(a => a.rating).reduce((sum, a) => sum + (a.rating || 0), 0) / ratingsCount
      : 0;

    return {
      totalExchanges: activities.length,
      totalConnections: connections.length,
      totalHours: Math.round(totalHours),
      averageRating: Math.round(averageRating * 10) / 10,
    };
  }
}

export const storage = new DatabaseStorage();
