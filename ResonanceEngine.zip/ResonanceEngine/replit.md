# Trinity Resonance Exchange Network

## Overview

Trinity Resonance is a consciousness-based exchange network that maps people's dreams, energies, and potential to facilitate meaningful connections and value circulation. The system operates on the principle of resonance over resources, matching members based on energetic complementarity rather than just skills or availability. It's designed to help each member move toward their highest goals through a marketplace of alignment where dreams and potential are valued alongside traditional skills.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Radix UI primitives with shadcn/ui components for consistent design
- **Styling**: Tailwind CSS with custom theming and CSS variables
- **State Management**: React Query for server state and local React state for UI interactions
- **Routing**: Wouter for lightweight client-side routing
- **Design System**: Custom cosmic gradient theme with dark mode support

### Backend Architecture
- **Runtime**: Node.js with Express server
- **Language**: TypeScript throughout the stack
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Session Management**: Express sessions with PostgreSQL storage via connect-pg-simple
- **Authentication**: Replit OAuth integration with passport.js
- **API Design**: RESTful endpoints with comprehensive error handling and request logging

### Database Design
- **Primary Database**: PostgreSQL with Drizzle schema definitions
- **Key Tables**:
  - Users table for authentication and basic profile data
  - User profiles with Trinity assessment data (Mind/Body/Heart metrics)
  - Resonance connections for member relationships
  - Exchange activities for tracking interactions
  - Sessions table for authentication state
- **Trinity System**: Core algorithm based on six assessment dimensions (clarity, discipline, compassion, adaptability, vitality, connection) that map to Mind/Body/Heart energy centers

### Authentication & Authorization
- **Provider**: Replit OAuth with OpenID Connect
- **Session Storage**: PostgreSQL-backed sessions with configurable TTL
- **Security**: HTTP-only cookies, CSRF protection, and secure session handling
- **User Flow**: Automatic profile creation on first login with redirect to assessment

### Core Features
- **Trinity Assessment**: Six-question evaluation that calculates Mind/Body/Heart energy distribution
- **Role Assignment**: Algorithmic assignment to one of five roles (Generator, Amplifier, Anchor, Catalyst, Harmonizer)
- **Resonance Matching**: Energy-based compatibility scoring with optional skills/tasks weighting
- **Network Balance**: Real-time tracking of role distribution and network harmony
- **Exchange Tracking**: Activity logging for accountability partnerships and support exchanges

### External Dependencies
- **Database**: PostgreSQL (configured for Neon serverless)
- **Authentication**: Replit OAuth service
- **Development**: Vite with HMR and development plugins
- **UI Components**: Extensive Radix UI ecosystem for accessible primitives
- **Utilities**: Date formatting (date-fns), class merging (clsx), and validation (Zod)