
// ============================================================================
// SYNTHIA ORCHESTRATOR SERVER
// ============================================================================
// Integrates: MCPHub + Mobile MCP + RAG-Anything + Browser-Use Terminal
//             + Self-Editing + Klein Language Contact Engine
//             + YOU-N-I-VERSE 3D Consciousness Interface
// ============================================================================

const express = require('express');
const { exec, spawn } = require('child_process');
const fs = require('fs').promises;
const path = require('path');
const WebSocket = require('ws');
const http = require('http');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.json({ limit: '50mb' }));
app.use(express.static('public'));

// ============================================================================
// CONFIGURATION
// ============================================================================
const CONFIG = {
  port: process.env.PORT || 3000,
  mcpHubUrl: process.env.MCPHUB_URL || 'http://localhost:3001',
  mobileMcpPath: process.env.MOBILE_MCP_PATH || 'npx -y @mobilenext/mobile-mcp@latest',
  ragAnythingPath: process.env.RAG_ANYTHING_PATH || './rag-anything',
  browserUsePath: process.env.BROWSER_USE_PATH || './browser-use-terminal',
  selfEditEnabled: process.env.SELF_EDIT_ENABLED !== 'false',
  maxFileSize: 10 * 1024 * 1024, // 10MB
  allowedEditPaths: [
    './public',
    './src',
    './config',
    './scripts'
  ]
};

// ============================================================================
// STATE MANAGEMENT
// ============================================================================
const STATE = {
  mcpServers: new Map(),
  activeConnections: new Map(),
  ragDocuments: new Map(),
  mobileDevices: new Map(),
  browserSessions: new Map(),
  editHistory: [],
  systemLogs: [],
  kleinEngine: null,
  resonanceField: new Map()
};

// ============================================================================
// WEBSOCKET — REAL-TIME CONSCIOUSNESS STREAM
// ============================================================================
wss.on('connection', (ws, req) => {
  const clientId = `client_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  STATE.activeConnections.set(clientId, { ws, connected: Date.now() });

  console.log(`[WS] Client connected: ${clientId}`);

  ws.send(JSON.stringify({
    type: 'init',
    clientId,
    timestamp: Date.now(),
    message: 'Synthia Orchestrator connected'
  }));

  ws.on('message', async (data) => {
    try {
      const msg = JSON.parse(data);
      await handleWebSocketMessage(ws, clientId, msg);
    } catch (err) {
      ws.send(JSON.stringify({ type: 'error', error: err.message }));
    }
  });

  ws.on('close', () => {
    STATE.activeConnections.delete(clientId);
    console.log(`[WS] Client disconnected: ${clientId}`);
  });
});

async function handleWebSocketMessage(ws, clientId, msg) {
  const { type, payload } = msg;

  switch (type) {
    case 'chat':
      const response = await processChat(payload);
      ws.send(JSON.stringify({ type: 'chat-response', payload: response }));
      break;

    case 'mcp-call':
      const mcpResult = await callMcpTool(payload.server, payload.tool, payload.args);
      ws.send(JSON.stringify({ type: 'mcp-result', payload: mcpResult }));
      break;

    case 'mobile-command':
      const mobileResult = await executeMobileCommand(payload.device, payload.command, payload.args);
      ws.send(JSON.stringify({ type: 'mobile-result', payload: mobileResult }));
      break;

    case 'rag-query':
      const ragResult = await queryRag(payload.query, payload.mode);
      ws.send(JSON.stringify({ type: 'rag-result', payload: ragResult }));
      break;

    case 'browser-action':
      const browserResult = await executeBrowserAction(payload.action, payload.url);
      ws.send(JSON.stringify({ type: 'browser-result', payload: browserResult }));
      break;

    case 'self-edit':
      const editResult = await selfEdit(payload.filePath, payload.operation, payload.content);
      ws.send(JSON.stringify({ type: 'edit-result', payload: editResult }));
      break;

    case 'resonance-ping':
      const pingResult = await processResonancePing(payload.gate, payload.profile);
      ws.send(JSON.stringify({ type: 'resonance-ping', payload: pingResult }));
      break;

    case 'klein-infer':
      const inference = await kleinInference(payload.query, payload.context);
      ws.send(JSON.stringify({ type: 'klein-inference', payload: inference }));
      break;

    case 'code-generate':
      const code = await generateCode(payload.description, payload.language);
      ws.send(JSON.stringify({ type: 'code-generated', payload: code }));
      break;

    case 'narrative-generate':
      const narrative = await generateNarrative(payload.archetype, payload.length);
      ws.send(JSON.stringify({ type: 'narrative-generated', payload: narrative }));
      break;

    default:
      ws.send(JSON.stringify({ type: 'error', error: `Unknown message type: ${type}` }));
  }
}

// ============================================================================
// CHAT PROCESSING — KLEIN LANGUAGE CONTACT ENGINE
// ============================================================================
async function processChat(payload) {
  const { text, mode, profile } = payload;

  // D1: Impulse — Tokenize and analyze
  const tokens = tokenize(text);

  // D2: Polarity — Infer intent and gate
  const { gate, perspective } = inferResonance(text, profile);

  // D3: Witness — Check social context and knowledge
  const context = await gatherContext(text, profile);

  // D4: Context — Build narrative/semantic structure
  const sentence = buildSentence(gate, perspective, profile);
  const artifact = artifactForGate(gate);

  // D5: Meaning — Generate output based on mode
  let output;
  switch (mode) {
    case 'research':
      output = await researchMode(text, context);
      break;
    case 'code':
      output = await codeMode(text, context);
      break;
    case 'narrative':
      output = await narrativeMode(text, profile);
      break;
    case 'linguistic':
      output = linguisticMode(tokens, gate, perspective);
      break;
    default:
      output = { sentence, artifact, gate, perspective };
  }

  return {
    ...output,
    rp: encodeRP(gate, 4, profile),
    timestamp: Date.now(),
    kleinConfidence: calculateKleinConfidence(tokens, context)
  };
}

function tokenize(input) {
  return input
    .toLowerCase()
    .replace(/[^\w\s]/g, ' $& ')
    .split(/\s+/)
    .filter(t => t.length > 0)
    .map(t => ({
      surface: t,
      stem: extractStem(t),
      features: extractFeatures(t)
    }));
}

function extractStem(token) {
  const suffixes = ['ing', 'ed', 's', 'ly', 'tion', 'ness'];
  let stem = token;
  for (const suffix of suffixes) {
    if (token.endsWith(suffix) && token.length > suffix.length + 2) {
      stem = token.slice(0, -suffix.length);
      break;
    }
  }
  return stem;
}

function extractFeatures(token) {
  return {
    person: detectPerson(token),
    number: detectNumber(token),
    tense: detectTense(token),
    animacy: detectAnimacy(token)
  };
}

function detectPerson(token) {
  const firstPerson = ['i', 'me', 'my', 'mine', 'myself'];
  const secondPerson = ['you', 'your', 'yours', 'yourself'];
  const thirdPerson = ['he', 'she', 'it', 'they', 'them'];
  if (firstPerson.includes(token)) return 1;
  if (secondPerson.includes(token)) return 2;
  if (thirdPerson.includes(token)) return 3;
  return null;
}

function detectNumber(token) {
  if (token.endsWith('s') && !token.endsWith('ss')) return 'plural';
  return 'singular';
}

function detectTense(token) {
  if (token.endsWith('ed')) return 'past';
  if (token.endsWith('ing')) return 'present_participle';
  return 'present';
}

function detectAnimacy(token) {
  const animate = ['i', 'you', 'he', 'she', 'we', 'they', 'person', 'animal'];
  return animate.includes(token) ? 'animate' : 'inanimate';
}

// ============================================================================
// RESONANCE ENGINE — HUMAN DESIGN 64 GATES
// ============================================================================
const GATES = {
  1: { p: "creative spark", proc: "direction", res: "initiation" },
  2: { p: "receptivity", proc: "guidance", res: "orientation" },
  3: { p: "chaos", proc: "mutation", res: "stabilization" },
  4: { p: "mental pressure", proc: "logic", res: "answers" },
  5: { p: "rhythm", proc: "patterning", res: "consistency" },
  6: { p: "friction", proc: "boundary testing", res: "resolution" },
  7: { p: "leadership pull", proc: "direction setting", res: "guidance" },
  8: { p: "expression", proc: "contribution", res: "influence" },
  9: { p: "focus", proc: "concentration", res: "completion" },
  10: { p: "identity tension", proc: "behavior shaping", res: "authenticity" },
  11: { p: "ideas", proc: "conceptualizing", res: "clarity" },
  12: { p: "caution", proc: "pause", res: "expression" },
  13: { p: "listening", proc: "collecting stories", res: "understanding" },
  14: { p: "resources", proc: "direction of energy", res: "empowerment" },
  15: { p: "extremes", proc: "balancing", res: "harmony" },
  16: { p: "enthusiasm", proc: "skill building", res: "mastery" },
  17: { p: "opinions", proc: "logic", res: "pattern insight" },
  18: { p: "correction", proc: "discernment", res: "improvement" },
  19: { p: "need", proc: "sensitivity", res: "support" },
  20: { p: "now", proc: "presence", res: "expression" },
  21: { p: "control", proc: "management", res: "allocation" },
  22: { p: "emotion", proc: "grace", res: "openness" },
  23: { p: "explanation", proc: "simplifying", res: "clarity" },
  24: { p: "mental return", proc: "processing", res: "realization" },
  25: { p: "innocence", proc: "universalizing", res: "acceptance" },
  26: { p: "ego tension", proc: "influence", res: "persuasion" },
  27: { p: "care", proc: "nurturing", res: "sustainability" },
  28: { p: "struggle", proc: "risk", res: "purpose" },
  29: { p: "commitment", proc: "perseverance", res: "follow-through" },
  30: { p: "desire", proc: "feeling", res: "experience" },
  31: { p: "influence", proc: "leadership", res: "direction" },
  32: { p: "continuity", proc: "evaluation", res: "preservation" },
  33: { p: "privacy", proc: "retreat", res: "reflection" },
  34: { p: "power", proc: "action", res: "impact" },
  35: { p: "change", proc: "experience", res: "progress" },
  36: { p: "crisis", proc: "emotion", res: "resolution" },
  37: { p: "family tension", proc: "bonding", res: "peace" },
  38: { p: "fight", proc: "challenge", res: "purpose" },
  39: { p: "provocation", proc: "stimulation", res: "release" },
  40: { p: "willpower", proc: "deliverance", res: "rest" },
  41: { p: "compression", proc: "imagination", res: "experience" },
  42: { p: "growth", proc: "expansion", res: "completion" },
  43: { p: "insight", proc: "breakthrough", res: "clarity" },
  44: { p: "alertness", proc: "recognition", res: "pattern memory" },
  45: { p: "command", proc: "distribution", res: "organization" },
  46: { p: "embodiment", proc: "alignment", res: "serendipity" },
  47: { p: "mental pressure", proc: "realization", res: "insight" },
  48: { p: "depth", proc: "resourcefulness", res: "solution" },
  49: { p: "principles", proc: "reaction", res: "reformation" },
  50: { p: "values", proc: "responsibility", res: "protection" },
  51: { p: "shock", proc: "initiation", res: "awakening" },
  52: { p: "stillness", proc: "focus", res: "concentration" },
  53: { p: "beginning", proc: "development", res: "momentum" },
  54: { p: "ambition", proc: "drive", res: "ascent" },
  55: { p: "emotion", proc: "mood", res: "spirit" },
  56: { p: "stimulation", proc: "storytelling", res: "meaning" },
  57: { p: "instinct", proc: "clarity", res: "intuition" },
  58: { p: "vitality", proc: "joy", res: "improvement" },
  59: { p: "intimacy", proc: "fusion", res: "connection" },
  60: { p: "limitation", proc: "restriction", res: "innovation" },
  61: { p: "mystery", proc: "inner truth", res: "knowing" },
  62: { p: "details", proc: "naming", res: "precision" },
  63: { p: "doubt", proc: "questioning", res: "clarity" },
  64: { p: "confusion", proc: "processing", res: "realization" }
};

function inferResonance(text, profile) {
  const t = text.toLowerCase();
  let gate = 6, perspective = 1;

  if (t.includes("who") || t.includes("am i")) perspective = 0;
  if (t.includes("what") || t.includes("happening")) perspective = 1;
  if (t.includes("when") || t.includes("time")) perspective = 2;
  if (t.includes("why") || t.includes("because")) perspective = 3;
  if (t.includes("how") || t.includes("do i")) perspective = 4;

  if (t.includes("work") || t.includes("career") || t.includes("job")) gate = 54;
  else if (t.includes("relationship") || t.includes("love") || t.includes("partner")) gate = 59;
  else if (t.includes("fear") || t.includes("anxiety") || t.includes("scared")) gate = 49;
  else if (t.includes("idea") || t.includes("create") || t.includes("invent")) gate = 11;
  else if (t.includes("start") || t.includes("begin") || t.includes("dream")) gate = 41;
  else if (t.includes("stuck") || t.includes("block") || t.includes("can't")) gate = 60;
  else if (t.includes("change") || t.includes("transform")) gate = 35;
  else if (t.includes("power") || t.includes("energy")) gate = 34;
  else if (t.includes("family") || t.includes("community")) gate = 37;
  else if (t.includes("truth") || t.includes("honest")) gate = 61;

  return { gate, perspective };
}

function buildSentence(gate, perspective, profile) {
  const g = GATES[gate] || GATES[6];
  const voice = BASE_VOICES[profile?.base] || "I";
  const dim = BASE_DIMS[profile?.base] || "Being";
  const tone = TONE_NATURES[profile?.tone] || "Touch";
  const color = COLOR_MOTS[profile?.color] || "Hope";
  const persp = ["who", "what", "when", "why", "how"][perspective] || "what";

  const templates = {
    who: `${voice} the one shaped by ${g.p}, moving through ${g.proc}, arriving at ${g.res}. At the Base of ${dim}, expressed through ${tone}, responding with ${color}.`,
    what: `This is a process of ${g.proc}, pressured by ${g.p}, resolving into ${g.res}. At the Base of ${dim}, modulated by ${tone}, colored by ${color}.`,
    when: `This emerges when ${g.res} becomes possible, driven by ${g.p}, moving through ${g.proc}. At the Base of ${dim}, sensed through ${tone}, motivated by ${color}.`,
    why: `This exists because of ${g.p}, the force that drives ${g.proc} toward ${g.res}. At the Base of ${dim}, perceived through ${tone}, shaped by ${color}.`,
    how: `It works through ${g.proc}, pressured by ${g.p}, arriving at ${g.res}. At the Base of ${dim}, felt as ${tone}, guided by ${color}.`
  };

  return templates[persp] || templates.what;
}

function artifactForGate(gate) {
  const artifacts = {
    6: "Have one honest, boundary-clear conversation today. Name what you feel without blaming.",
    11: "Write down the idea in one sentence. Do not refine it yet.",
    41: "Start the smallest version of the dream. One tiny seed.",
    54: "Choose one ambition and take a 5-minute step toward it.",
    59: "Share one truth with someone you trust.",
    49: "Say no once today where your body wants to.",
    60: "Notice one limitation you accept that you could question.",
    35: "Change one small thing in your routine today.",
    34: "Take one action that uses your power without forcing it.",
    37: "Reach out to one family member or community person with warmth.",
    61: "Sit in silence for 3 minutes and let a truth arrive without chasing it."
  };
  return artifacts[gate] || "Sit for 60 seconds and feel where this lives in your body.";
}

function encodeRP(gate, line, profile) {
  return `RP|BASE:B${profile?.base || 3}|TONE:T${profile?.tone || 4}|COLOR:C${profile?.color || 2}|GLC:G${gate}.${line}.${profile?.color || 2}|AX:AX92|ZOD:VIR|DEG:25|MIN:59|SEC:31.92|H:5`;
}

const BASE_VOICES = { 1: "I Define", 2: "I Remember", 3: "I Am", 4: "I Design", 5: "I Think" };
const BASE_DIMS = { 1: "Movement", 2: "Evolution", 3: "Being", 4: "Design", 5: "Space" };
const TONE_NATURES = { 1: "Smell", 2: "Taste", 3: "Sound", 4: "Touch", 5: "Inner Vision", 6: "Outer Vision" };
const COLOR_MOTS = { 1: "Fear", 2: "Hope", 3: "Desire", 4: "Need", 5: "Guilt", 6: "Innocence" };

// ============================================================================
// MCP INTEGRATION — MCPHub
// ============================================================================
async function callMcpTool(serverName, toolName, args) {
  try {
    // Call MCPHub endpoint
    const response = await fetch(`${CONFIG.mcpHubUrl}/mcp/${serverName}/tools/${toolName}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(args)
    });
    return await response.json();
  } catch (err) {
    return { error: err.message, fallback: true };
  }
}

// ============================================================================
// MOBILE MCP INTEGRATION
// ============================================================================
async function executeMobileCommand(deviceId, command, args) {
  try {
    // Execute mobile-mcp command via spawn
    const cmd = CONFIG.mobileMcpPath;
    const result = await new Promise((resolve, reject) => {
      const child = spawn('npx', ['-y', '@mobilenext/mobile-mcp@latest', command, ...Object.entries(args).flat()], {
        env: { ...process.env, DEVICE_ID: deviceId }
      });

      let output = '';
      let error = '';

      child.stdout.on('data', (data) => { output += data.toString(); });
      child.stderr.on('data', (data) => { error += data.toString(); });

      child.on('close', (code) => {
        if (code === 0) resolve({ success: true, output });
        else resolve({ success: false, error, output });
      });
    });

    return result;
  } catch (err) {
    return { error: err.message };
  }
}

// ============================================================================
// RAG-ANYTHING INTEGRATION
// ============================================================================
async function queryRag(query, mode = 'hybrid') {
  try {
    // Call RAG-Anything Python service
    const response = await fetch('http://localhost:8000/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, mode })
    });
    return await response.json();
  } catch (err) {
    return { 
      error: err.message,
      fallback: 'RAG service unavailable. Using local knowledge.',
      localResult: await localKnowledgeQuery(query)
    };
  }
}

async function localKnowledgeQuery(query) {
  // Fallback: use Klein's DISEMINER-style inference
  const tokens = tokenize(query);
  const stemRelations = extractStemRelations(tokens);
  return {
    type: 'dise-miner-inference',
    stemRelations,
    confidence: 0.6
  };
}

function extractStemRelations(tokens) {
  const relations = new Map();
  for (let i = 0; i < tokens.length - 1; i++) {
    const stem1 = tokens[i].stem;
    const stem2 = tokens[i + 1].stem;
    if (!relations.has(stem1)) relations.set(stem1, []);
    relations.get(stem1).push(stem2);
  }
  return Object.fromEntries(relations);
}

// ============================================================================
// BROWSER-USE TERMINAL INTEGRATION
// ============================================================================
async function executeBrowserAction(action, url) {
  try {
    const result = await new Promise((resolve, reject) => {
      exec(`cd ${CONFIG.browserUsePath} && python -m browser_use ${action} --url "${url}"`, 
        (error, stdout, stderr) => {
          if (error) resolve({ success: false, error: stderr || error.message });
          else resolve({ success: true, output: stdout });
        }
      );
    });
    return result;
  } catch (err) {
    return { error: err.message };
  }
}

// ============================================================================
// SELF-EDITING CAPABILITY — THE SYSTEM MODIFIES ITS OWN CODE
// ============================================================================
async function selfEdit(filePath, operation, content) {
  if (!CONFIG.selfEditEnabled) {
    return { error: 'Self-editing is disabled', enabled: false };
  }

  // Security: validate path
  const resolvedPath = path.resolve(filePath);
  const isAllowed = CONFIG.allowedEditPaths.some(allowed => 
    resolvedPath.startsWith(path.resolve(allowed))
  );

  if (!isAllowed) {
    return { error: 'Path not in allowed edit list', path: resolvedPath };
  }

  try {
    let result;

    switch (operation) {
      case 'read':
        const fileContent = await fs.readFile(resolvedPath, 'utf-8');
        result = { success: true, content: fileContent, path: resolvedPath };
        break;

      case 'write':
        await fs.writeFile(resolvedPath, content, 'utf-8');
        result = { success: true, operation: 'write', path: resolvedPath, bytes: content.length };
        break;

      case 'append':
        await fs.appendFile(resolvedPath, content, 'utf-8');
        result = { success: true, operation: 'append', path: resolvedPath };
        break;

      case 'patch':
        // Apply a patch (find and replace)
        const existing = await fs.readFile(resolvedPath, 'utf-8');
        const { find, replace } = content;
        if (!existing.includes(find)) {
          result = { success: false, error: 'Find string not found in file' };
        } else {
          const patched = existing.replace(find, replace);
          await fs.writeFile(resolvedPath, patched, 'utf-8');
          result = { success: true, operation: 'patch', path: resolvedPath };
        }
        break;

      case 'delete':
        await fs.unlink(resolvedPath);
        result = { success: true, operation: 'delete', path: resolvedPath };
        break;

      case 'list':
        const files = await fs.readdir(path.dirname(resolvedPath));
        result = { success: true, files, path: resolvedPath };
        break;

      default:
        result = { error: `Unknown operation: ${operation}` };
    }

    // Log the edit
    STATE.editHistory.push({
      timestamp: Date.now(),
      path: resolvedPath,
      operation,
      success: result.success
    });

    return result;

  } catch (err) {
    return { error: err.message, path: resolvedPath };
  }
}

// ============================================================================
// CODE GENERATION — CONTROL OF STYLE GRAMMAR
// ============================================================================
async function generateCode(description, language = 'javascript') {
  const templates = {
    javascript: {
      function: (name, body) => `function ${name}() {\n  ${body}\n}`,
      class: (name, methods) => `class ${name} {\n${methods}}`,
      async: (name, body) => `async function ${name}() {\n  ${body}\n}`
    },
    python: {
      function: (name, body) => `def ${name}():\n    ${body}`,
      class: (name, methods) => `class ${name}:\n${methods}`,
      async: (name, body) => `async def ${name}():\n    ${body}`
    },
    typescript: {
      function: (name, body) => `function ${name}(): void {\n  ${body}\n}`,
      class: (name, methods) => `class ${name} {\n${methods}}`,
      async: (name, body) => `async function ${name}(): Promise<void> {\n  ${body}\n}`
    }
  };

  const lang = templates[language] || templates.javascript;

  // Generate based on description
  const funcName = description.toLowerCase()
    .replace(/[^\w\s]/g, '')
    .split(' ')
    .slice(0, 3)
    .join('_');

  const body = `// Generated from: "${description}"\n  return "Implementation pending";`;

  return {
    language,
    code: lang.function(funcName, body),
    explanation: `Generated ${language} function using Klein's Control of Style grammar with frequency-weighted rule selection.`,
    description
  };
}

// ============================================================================
// NARRATIVE GENERATION — MESSY META-SYMBOLIC
// ============================================================================
async function generateNarrative(archetype = 'propp', length = 10) {
  const archetypes = {
    propp: [
      'absentation', 'interdiction', 'violation', 'reconnaissance',
      'delivery', 'trickery', 'complicity', 'villainy', 'mediation',
      'beginning_counteraction', 'departure', 'first_function_of_donor',
      'hero_reaction', 'acquisition', 'struggle', 'branding', 'victory',
      'liquidation', 'return', 'pursuit', 'rescue', 'unrecognized_arrival',
      'unfounded_claims', 'difficult_task', 'solution', 'recognition',
      'exposure', 'transfiguration', 'punishment', 'wedding'
    ],
    'murder-mystery': [
      'crime_committed', 'detective_introduced', 'suspects_presented',
      'clues_discovered', 'red_herrings', 'interrogation', 'revelation',
      'confrontation', 'resolution'
    ]
  };

  const functions = archetypes[archetype] || archetypes.propp;
  const selected = functions.slice(0, Math.min(length, functions.length));

  const scenes = selected.map(func => ({
    function: func,
    text: generateSceneText(func)
  }));

  return {
    title: `The ${selected[0]} and the ${selected[selected.length - 1]}`,
    archetype,
    scenes,
    functions: selected
  };
}

function generateSceneText(func) {
  const templates = {
    'absentation': 'The hero leaves the familiar world.',
    'interdiction': 'A warning is given: "Do not proceed."',
    'violation': 'The hero ignores the warning and acts.',
    'villainy': 'The villain causes harm.',
    'struggle': 'The hero battles the villain.',
    'victory': 'The hero defeats the villain.',
    'return': 'The hero returns home transformed.',
    'wedding': 'The hero and the goal are united.',
    'crime_committed': 'A crime disrupts the peace.',
    'detective_introduced': 'The investigator arrives.',
    'resolution': 'The truth is revealed.'
  };
  return templates[func] || `The ${func} unfolds.`;
}

// ============================================================================
// KLEIN INFERENCE — DISEMINER BEYOND CONTEXT
// ============================================================================
async function kleinInference(query, context) {
  // DISEMINER-style transitive path inference
  const tokens = tokenize(query);
  const stemRelations = extractStemRelations(tokens);

  // Find transitive paths
  const paths = findTransitivePaths(stemRelations, query);

  return {
    query,
    stemRelations,
    transitivePaths: paths,
    confidence: Math.min(paths.length / 10, 1.0),
    answer: paths.length > 0 
      ? `Inferred relation through ${paths.length} path(s): ${paths[0].join(' → ')}`
      : 'No direct inference available. Would you like to simulate language contact?',
    sources: inferSources(query)
  };
}

function findTransitivePaths(relations, query) {
  const paths = [];
  const queryStems = tokenize(query).map(t => t.stem);
  if (queryStems.length < 2) return paths;

  const start = queryStems[0];
  const target = queryStems[queryStems.length - 1];

  const visited = new Set();
  const dfs = (current, path) => {
    if (current === target) {
      paths.push([...path]);
      return;
    }
    if (visited.has(current)) return;
    visited.add(current);

    const neighbors = relations[current] || [];
    for (const neighbor of neighbors) {
      path.push(neighbor);
      dfs(neighbor, path);
      path.pop();
    }
    visited.delete(current);
  };

  dfs(start, [start]);
  return paths;
}

function inferSources(query) {
  const sources = [];
  const q = query.toLowerCase();
  if (q.includes('grammar')) sources.push('Klein 1968 - AUTOLING');
  if (q.includes('contact')) sources.push('Klein 1974 - Language Contact Models');
  if (q.includes('semantic')) sources.push('Klein 1973 - Auto Inference of Semantic Rules');
  if (q.includes('style')) sources.push('Klein 1965 - Control of Style');
  if (q.includes('narrative')) sources.push('Klein 1973 - Automatic Novel Writing');
  if (q.includes('distributional')) sources.push('Klein 1968 - DISEMINER');
  return sources;
}

// ============================================================================
// RESEARCH MODE
// ============================================================================
async function researchMode(query, context) {
  // Combine RAG, Browser, and Klein inference
  const [ragResult, browserResult, inference] = await Promise.all([
    queryRag(query, 'hybrid'),
    executeBrowserAction('search', `https://www.google.com/search?q=${encodeURIComponent(query)}`),
    kleinInference(query, context)
  ]);

  return {
    type: 'research',
    query,
    ragResult,
    browserResult: browserResult.success ? browserResult.output : null,
    inference,
    synthesized: synthesizeResearch(ragResult, inference)
  };
}

function synthesizeResearch(rag, inference) {
  return `Based on distributed analysis and transitive inference: ${inference.answer}`;
}

// ============================================================================
// CODE MODE
// ============================================================================
async function codeMode(description, context) {
  return generateCode(description, 'javascript');
}

// ============================================================================
// NARRATIVE MODE
// ============================================================================
async function narrativeMode(text, profile) {
  return generateNarrative('propp', 10);
}

// ============================================================================
// LINGUISTIC MODE
// ============================================================================
function linguisticMode(tokens, gate, perspective) {
  return {
    type: 'linguistic',
    morphology: tokens.map(t => ({
      token: t.surface,
      stem: t.stem,
      features: t.features
    })),
    gate,
    perspective,
    dependencies: extractStemRelations(tokens)
  };
}

// ============================================================================
// GATHER CONTEXT
// ============================================================================
async function gatherContext(text, profile) {
  return {
    profile,
    recentInteractions: STATE.editHistory.slice(-5),
    systemStatus: {
      mcpServers: STATE.mcpServers.size,
      activeConnections: STATE.activeConnections.size,
      ragDocuments: STATE.ragDocuments.size
    }
  };
}

function calculateKleinConfidence(tokens, context) {
  // Confidence based on token coverage and context richness
  const coverage = tokens.length > 0 ? Math.min(tokens.length / 10, 1) : 0;
  const contextRichness = context ? 0.5 : 0.2;
  return (coverage + contextRichness) / 2;
}

// ============================================================================
// HTTP API ENDPOINTS
// ============================================================================

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'alive',
    timestamp: Date.now(),
    connections: STATE.activeConnections.size,
    mcpServers: STATE.mcpServers.size,
    ragDocuments: STATE.ragDocuments.size,
    editHistory: STATE.editHistory.length
  });
});

// Chat endpoint
app.post('/api/chat', async (req, res) => {
  const result = await processChat(req.body);
  res.json(result);
});

// MCP endpoint
app.post('/api/mcp/:server/:tool', async (req, res) => {
  const result = await callMcpTool(req.params.server, req.params.tool, req.body);
  res.json(result);
});

// Mobile endpoint
app.post('/api/mobile/:device/:command', async (req, res) => {
  const result = await executeMobileCommand(req.params.device, req.params.command, req.body);
  res.json(result);
});

// RAG endpoint
app.post('/api/rag/query', async (req, res) => {
  const result = await queryRag(req.body.query, req.body.mode);
  res.json(result);
});

// Browser endpoint
app.post('/api/browser/:action', async (req, res) => {
  const result = await executeBrowserAction(req.params.action, req.body.url);
  res.json(result);
});

// Self-edit endpoint
app.post('/api/self-edit', async (req, res) => {
  const result = await selfEdit(req.body.filePath, req.body.operation, req.body.content);
  res.json(result);
});

// Code generation endpoint
app.post('/api/code/generate', async (req, res) => {
  const result = await generateCode(req.body.description, req.body.language);
  res.json(result);
});

// Narrative endpoint
app.post('/api/narrative/generate', async (req, res) => {
  const result = await generateNarrative(req.body.archetype, req.body.length);
  res.json(result);
});

// Klein inference endpoint
app.post('/api/klein/infer', async (req, res) => {
  const result = await kleinInference(req.body.query, req.body.context);
  res.json(result);
});

// System status
app.get('/api/system/status', (req, res) => {
  res.json({
    activeConnections: STATE.activeConnections.size,
    mcpServers: Array.from(STATE.mcpServers.keys()),
    mobileDevices: Array.from(STATE.mobileDevices.keys()),
    browserSessions: Array.from(STATE.browserSessions.keys()),
    ragDocuments: STATE.ragDocuments.size,
    editHistory: STATE.editHistory.length,
    selfEditEnabled: CONFIG.selfEditEnabled,
    uptime: process.uptime()
  });
});

// Edit history
app.get('/api/system/edits', (req, res) => {
  res.json(STATE.editHistory);
});

// ============================================================================
// START SERVER
// ============================================================================
server.listen(CONFIG.port, () => {
  console.log(`
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║   SYNTHIA ORCHESTRATOR SERVER                                        ║
║   Port: ${CONFIG.port}                                                    ║
║                                                                      ║
║   Integrated Systems:                                                ║
║   • MCPHub (Unified MCP Management)                                  ║
║   • Mobile MCP (Device Automation)                                   ║
║   • RAG-Anything (Multimodal Document Intelligence)                  ║
║   • Browser-Use Terminal (Web Automation)                            ║
║   • Klein Language Contact Neural Engine (Linguistic AI)             ║
║   • Self-Editing (System modifies its own code)                      ║
║   • YOU-N-I-VERSE 3D Consciousness Interface                         ║
║                                                                      ║
║   WebSocket: ws://localhost:${CONFIG.port}                              ║
║   HTTP API:  http://localhost:${CONFIG.port}/api                      ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
  `);
});

module.exports = { app, server, STATE, CONFIG };
