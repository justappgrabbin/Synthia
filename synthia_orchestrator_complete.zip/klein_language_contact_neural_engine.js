
// ============================================================================
// KLEIN LANGUAGE CONTACT NEURAL ENGINE (KLCNE)
// ============================================================================
// Integrates Sheldon Klein's 6 legacy systems with modern neural architecture
// Adds: coding, research, and chat capabilities
// Maps to Synthia's 5-Dimensional Cognitive Stack (D1-D5)
// ============================================================================

// ============================================================================
// D1: IMPULSE — The Core Tokenizer & Perceptual Engine
// ============================================================================
// Based on: AUTOLING Morphological Analyzer + DISEMINER stem extraction

class D1_ImpulseEngine {
  constructor() {
    this.morphologicalRules = new Map();      // From AUTOLING
    this.stemDictionary = new Map();         // From DISEMINER
    this.dependencyMatrix = new Map();       // DISEMINER transitive paths
    this.tokenHistory = [];
  }

  // AUTOLING-style morphological analysis
  analyzeMorphology(input) {
    const tokens = this.tokenize(input);
    const analyzed = tokens.map(token => ({
      surface: token,
      stem: this.extractStem(token),
      gloss: this.inferGloss(token),
      features: this.extractFeatures(token),
      dependencies: this.findDependencies(token)
    }));
    return analyzed;
  }

  tokenize(input) {
    // DISEMINER-style: stem-type relations, not just tokens
    return input
      .toLowerCase()
      .replace(/[^\w\s]/g, ' $& ')
      .split(/\s+/)
      .filter(t => t.length > 0);
  }

  extractStem(token) {
    // AUTOLING morphological cutting
    const suffixes = ['ing', 'ed', 's', 'ly', 'tion', 'ness'];
    let stem = token;
    for (const suffix of suffixes) {
      if (token.endsWith(suffix) && token.length > suffix.length + 2) {
        stem = token.slice(0, -suffix.length);
        break;
      }
    }
    return stem;
  }

  inferGloss(token) {
    // DISEMINER distributional semantics: infer meaning from context
    if (this.stemDictionary.has(token)) {
      return this.stemDictionary.get(token);
    }
    // Default: primary/secondary gloss distinction (AUTOLING)
    return { primary: token, secondary: [] };
  }

  extractFeatures(token) {
    // AUTOLING-style feature extraction
    return {
      person: this.detectPerson(token),
      number: this.detectNumber(token),
      tense: this.detectTense(token),
      animacy: this.detectAnimacy(token)
    };
  }

  detectPerson(token) {
    const firstPerson = ['i', 'me', 'my', 'mine', 'myself'];
    const secondPerson = ['you', 'your', 'yours', 'yourself'];
    const thirdPerson = ['he', 'she', 'it', 'they', 'them'];
    if (firstPerson.includes(token.toLowerCase())) return 1;
    if (secondPerson.includes(token.toLowerCase())) return 2;
    if (thirdPerson.includes(token.toLowerCase())) return 3;
    return null;
  }

  detectNumber(token) {
    if (token.endsWith('s') && !token.endsWith('ss')) return 'plural';
    return 'singular';
  }

  detectTense(token) {
    if (token.endsWith('ed')) return 'past';
    if (token.endsWith('ing')) return 'present_participle';
    return 'present';
  }

  detectAnimacy(token) {
    const animate = ['i', 'you', 'he', 'she', 'we', 'they', 'person', 'animal'];
    return animate.includes(token.toLowerCase()) ? 'animate' : 'inanimate';
  }

  findDependencies(token) {
    // DISEMINER: transitive dependency paths
    const deps = [];
    for (const [stem, relations] of this.dependencyMatrix) {
      if (relations.includes(token)) {
        deps.push(stem);
      }
    }
    return deps;
  }

  // Neural embedding: convert token to vector
  embed(token) {
    const stem = this.extractStem(token);
    const gloss = this.inferGloss(stem);
    const features = this.extractFeatures(token);

    // Create 64-dimensional embedding (like our simulation)
    const embedding = new Array(64).fill(0);

    // Encode features into vector
    if (features.person) embedding[features.person] = 1;
    if (features.number === 'plural') embedding[10] = 1;
    if (features.tense === 'past') embedding[20] = 1;
    if (features.animacy === 'animate') embedding[30] = 1;

    // Add hash-based noise for uniqueness
    const hash = this.hashString(stem);
    for (let i = 0; i < 32; i++) {
      embedding[32 + i] = ((hash >> i) & 1) * 2 - 1;
    }

    return embedding;
  }

  hashString(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash);
  }
}

// ============================================================================
// D2: POLARITY — The Grammar & Transformation Engine
// ============================================================================
// Based on: AUTOLING Phrase Structure + Transformation Learning
//           + Control of Style frequency-weighted rules

class D2_PolarityEngine {
  constructor() {
    this.phraseRules = new Map();      // AUTOLING Heuristics 1-5
    this.transformations = new Map();   // AUTOLING transformation learner
    this.ruleFrequencies = new Map();   // Control of Style
    this.illegalSentences = [];        // AUTOLING illegal list
    this.grammar = { rules: [], recursive: false };
  }

  // AUTOLING Heuristic 1: Closure of parse → rule
  heuristic1(parse) {
    const rule = `${parse.nonTerminal} → ${parse.constituents.join(' ')}`;
    this.addRule(rule, 'phrase');
    return rule;
  }

  // AUTOLING Heuristic 2: Same environment → same class
  heuristic2(morpheme1, morpheme2, environment) {
    const rule = `${environment.before} [${morpheme1}/${morpheme2}] ${environment.after}`;
    this.addRule(rule, 'class');
    return rule;
  }

  // AUTOLING Heuristic 3: Terminal + non-terminal in same env
  heuristic3(terminal, nonTerminal, environment) {
    const rule = `${nonTerminal} → ${terminal}`;
    this.addRule(rule, 'substitution');
    return rule;
  }

  // AUTOLING Heuristic 4: Recursive rules
  heuristic4(X, Y, A) {
    const rule = `${X} → ${A} ${Y}`;
    this.grammar.recursive = true;
    this.addRule(rule, 'recursive');
    return rule;
  }

  // AUTOLING Heuristic 5: Class splitting
  heuristic5(className, members, splitCondition) {
    const newClass = `${className}_split`;
    const rule1 = `${className} → ${members.filter(m => !splitCondition(m)).join(' | ')}`;
    const rule2 = `${newClass} → ${members.filter(m => splitCondition(m)).join(' | ')}`;
    this.addRule(rule1, 'split');
    this.addRule(rule2, 'split');
    return [rule1, rule2];
  }

  addRule(rule, type) {
    if (!this.phraseRules.has(rule)) {
      this.phraseRules.set(rule, { type, frequency: 1, tested: false });
    } else {
      const existing = this.phraseRules.get(rule);
      existing.frequency++;
    }
    this.ruleFrequencies.set(rule, (this.ruleFrequencies.get(rule) || 0) + 1);
  }

  // Control of Style: frequency-weighted generation
  generateSentence(startSymbol = 'S', styleParams = {}) {
    const { complexity = 0.5, formality = 0.5, creativity = 0.3 } = styleParams;

    let sentence = [startSymbol];
    let depth = 0;
    const maxDepth = Math.floor(complexity * 10) + 3;

    while (depth < maxDepth) {
      let expanded = false;
      for (let i = 0; i < sentence.length; i++) {
        const symbol = sentence[i];
        if (this.isNonTerminal(symbol)) {
          const applicable = this.getApplicableRules(symbol);
          if (applicable.length > 0) {
            // Control of Style: weighted random selection
            const rule = this.selectWeightedRule(applicable, formality, creativity);
            const expansion = this.expandRule(rule);
            sentence.splice(i, 1, ...expansion);
            expanded = true;
            break;
          }
        }
      }
      if (!expanded) break;
      depth++;
    }

    return sentence.filter(s => !this.isNonTerminal(s)).join(' ');
  }

  isNonTerminal(symbol) {
    return symbol[0] === symbol[0].toUpperCase() && symbol.length > 1;
  }

  getApplicableRules(symbol) {
    const applicable = [];
    for (const [rule, data] of this.phraseRules) {
      if (rule.startsWith(`${symbol} →`)) {
        applicable.push({ rule, ...data });
      }
    }
    return applicable;
  }

  selectWeightedRule(rules, formality, creativity) {
    // Control of Style: frequency-weighted with style bias
    const weights = rules.map(r => {
      let w = r.frequency;
      if (formality > 0.7 && r.rule.includes('FORMAL')) w *= 2;
      if (creativity > 0.7 && r.type === 'recursive') w *= 1.5;
      return w;
    });
    const total = weights.reduce((a, b) => a + b, 0);
    let rand = Math.random() * total;
    for (let i = 0; i < rules.length; i++) {
      rand -= weights[i];
      if (rand <= 0) return rules[i].rule;
    }
    return rules[0].rule;
  }

  expandRule(rule) {
    const parts = rule.split('→')[1].trim().split(/\s+/);
    return parts;
  }

  // AUTOLING: "CAN YOU SAY" testing
  testRule(rule, informant) {
    const testSentence = this.generateTestSentence(rule);
    const response = informant.canYouSay(testSentence);

    if (response === 'YES') {
      this.phraseRules.get(rule).tested = true;
      return true;
    } else {
      this.illegalSentences.push(testSentence);
      this.recycleIfNeeded();
      return false;
    }
  }

  generateTestSentence(rule) {
    // Generate a sentence that uses this rule
    return this.generateSentence();
  }

  // AUTOLING: Recycling when illegal sentences parse
  recycleIfNeeded() {
    if (this.illegalSentences.length > 5) {
      // Parse all illegals
      const parsed = this.illegalSentences.filter(s => this.canParse(s));
      if (parsed.length > 0) {
        // Destroy grammar, rebuild from history
        this.grammar.rules = [];
        this.phraseRules.clear();
        // Re-process inputs in new order
        this.reorderAndReprocess();
      }
    }
  }

  canParse(sentence) {
    // Simplified parsing check
    return false; // Placeholder
  }

  reorderAndReprocess() {
    // AUTOLING: reorder last 5 inputs to head of list
    console.log('RECYCLE MODE: Rebuilding grammar from history');
  }

  // Transformation learning (AUTOLING Component 3)
  learnTransformation(sourcePattern, targetPattern, examples) {
    const transformation = {
      source: sourcePattern,
      target: targetPattern,
      examples: examples,
      confidence: 0
    };

    // Test on examples
    let success = 0;
    for (const ex of examples) {
      const result = this.applyTransformation(ex, transformation);
      if (this.isValid(result)) success++;
    }

    transformation.confidence = success / examples.length;
    this.transformations.set(`${sourcePattern}→${targetPattern}`, transformation);
    return transformation;
  }

  applyTransformation(sentence, transformation) {
    // Apply pattern matching and replacement
    return sentence.replace(transformation.source, transformation.target);
  }

  isValid(sentence) {
    // Check against illegal list
    return !this.illegalSentences.includes(sentence);
  }
}

// ============================================================================
// D3: WITNESS — The Observer & Social Contact Engine
// ============================================================================
// Based on: Language Contact Model (Monte Carlo simulation)
//           + DISEMINER inference beyond context

class D3_WitnessEngine {
  constructor(nAgents = 100, nGroups = 3) {
    this.agents = new Map();
    this.network = new Map();
    this.socialModel = new Map();
    this.time = 0;
    this.contactHistory = [];

    this.initializeAgents(nAgents, nGroups);
    this.buildNetwork();
  }

  initializeAgents(nAgents, nGroups) {
    const perGroup = Math.floor(nAgents / nGroups);
    for (let g = 0; g < nGroups; g++) {
      for (let i = 0; i < perGroup; i++) {
        const agent = {
          id: `A_${g}_${i}`,
          group: g,
          grammar: new D2_PolarityEngine(),
          prestige: Math.random() * 0.5 + 0.3,
          age: Math.floor(Math.random() * 80),
          status: Math.random(),
          lexicon: new Map(),
          ruleFrequencies: new Map(),
          birth: this.time,
          death: null
        };
        this.agents.set(agent.id, agent);
      }
    }
  }

  buildNetwork() {
    // Klein's social model: status, age, proximity, group
    for (const [id1, agent1] of this.agents) {
      this.network.set(id1, []);
      for (const [id2, agent2] of this.agents) {
        if (id1 === id2) continue;

        const proximity = this.calculateProximity(agent1, agent2);
        if (Math.random() < proximity) {
          this.network.get(id1).push(id2);
        }
      }
    }
  }

  calculateProximity(a1, a2) {
    // Klein's Table 2 functions
    const groupFactor = a1.group === a2.group ? 0.6 : 0.1;
    const statusFactor = 1 - Math.abs(a1.status - a2.status);
    const ageFactor = 1 - Math.abs(a1.age - a2.age) / 100;
    const prestigeFactor = a2.prestige;

    return (groupFactor + statusFactor + ageFactor + prestigeFactor) / 4;
  }

  // Language Contact: interaction between agents
  interact(speakerId, hearerId) {
    const speaker = this.agents.get(speakerId);
    const hearer = this.agents.get(hearerId);

    if (!speaker || !hearer) return null;

    // Speaker generates utterance
    const utterance = speaker.grammar.generateSentence('S', {
      complexity: speaker.prestige,
      formality: speaker.status,
      creativity: 0.3
    });

    // Hearer parses and learns
    const parsed = this.parseUtterance(utterance, hearer);
    const learned = this.learnFromInteraction(speaker, hearer, utterance, parsed);

    // Update frequencies (Klein: "modification of rule frequency parameters")
    this.updateRuleFrequencies(speaker, hearer, utterance, learned);

    // Record contact
    this.contactHistory.push({
      time: this.time,
      speaker: speakerId,
      hearer: hearerId,
      utterance,
      learned,
      success: parsed.success
    });

    return { utterance, learned, success: parsed.success };
  }

  parseUtterance(utterance, agent) {
    // Try to parse with hearer's grammar
    const tokens = utterance.split(' ');
    const success = this.canParse(tokens, agent.grammar);
    return { success, tokens };
  }

  canParse(tokens, grammar) {
    // Simplified parsing
    return Math.random() > 0.3; // Placeholder
  }

  learnFromInteraction(speaker, hearer, utterance, parsed) {
    const learned = [];

    // Klein's "outright theft of relevant rules"
    if (!parsed.success) {
      // Failed to parse - learn new rules from speaker
      for (const [rule, data] of speaker.grammar.phraseRules) {
        if (!hearer.grammar.phraseRules.has(rule)) {
          // Learn with probability based on speaker prestige
          if (Math.random() < speaker.prestige * 0.5) {
            hearer.grammar.addRule(rule, data.type);
            learned.push(rule);
          }
        }
      }
    }

    return learned;
  }

  updateRuleFrequencies(speaker, hearer, utterance, learned) {
    // Increase frequency of used rules in speaker
    for (const [rule, data] of speaker.grammar.phraseRules) {
      if (utterance.includes(rule.split('→')[0].trim())) {
        data.frequency *= 1.01; // Slight increase
      }
    }

    // Decay unused rules in hearer (Klein: "rate of decay for unused rules")
    for (const [rule, data] of hearer.grammar.phraseRules) {
      if (!learned.includes(rule)) {
        data.frequency *= 0.999; // Slow decay
      }
    }
  }

  // DISEMINER: Inference beyond training context
  inferBeyondContext(query, context) {
    // DISEMINER answers questions broader than training context
    const stemRelations = this.extractStemRelations(context);
    const transitivePaths = this.findTransitivePaths(stemRelations, query);

    return {
      answer: this.generateInference(transitivePaths),
      confidence: this.calculateInferenceConfidence(transitivePaths),
      paths: transitivePaths
    };
  }

  extractStemRelations(context) {
    const relations = new Map();
    const tokens = context.split(/\s+/);

    for (let i = 0; i < tokens.length - 1; i++) {
      const stem1 = tokens[i].replace(/ing$|ed$|s$/, '');
      const stem2 = tokens[i + 1].replace(/ing$|ed$|s$/, '');

      if (!relations.has(stem1)) relations.set(stem1, []);
      relations.get(stem1).push(stem2);
    }

    return relations;
  }

  findTransitivePaths(relations, query) {
    const paths = [];
    const visited = new Set();

    const dfs = (current, path, target) => {
      if (current === target) {
        paths.push([...path]);
        return;
      }
      if (visited.has(current)) return;
      visited.add(current);

      const neighbors = relations.get(current) || [];
      for (const neighbor of neighbors) {
        path.push(neighbor);
        dfs(neighbor, path, target);
        path.pop();
      }
      visited.delete(current);
    };

    const queryStems = query.split(/\s+/).map(s => s.replace(/ing$|ed$|s$/, ''));
    if (queryStems.length >= 2) {
      dfs(queryStems[0], [queryStems[0]], queryStems[queryStems.length - 1]);
    }

    return paths;
  }

  generateInference(paths) {
    if (paths.length === 0) return 'No inference possible';
    return `Inferred relation through ${paths.length} path(s): ${paths[0].join(' → ')}`;
  }

  calculateInferenceConfidence(paths) {
    return Math.min(paths.length / 10, 1.0);
  }

  // Monte Carlo simulation step
  step() {
    this.time++;

    // Each agent interacts with neighbors
    for (const [id, agent] of this.agents) {
      const neighbors = this.network.get(id) || [];
      if (neighbors.length > 0) {
        const partner = neighbors[Math.floor(Math.random() * neighbors.length)];
        this.interact(id, partner);
      }
    }

    // Birth/death (Klein: "birth and death in the community")
    if (this.time % 100 === 0) {
      this.handleBirthDeath();
    }
  }

  handleBirthDeath() {
    // Remove old agents
    for (const [id, agent] of this.agents) {
      if (agent.age > 80 && Math.random() < 0.1) {
        agent.death = this.time;
        this.agents.delete(id);
      }
      agent.age++;
    }

    // Add new agents with empty grammars
    const newAgent = {
      id: `A_new_${this.time}`,
      group: Math.floor(Math.random() * 3),
      grammar: new D2_PolarityEngine(),
      prestige: 0.1,
      age: 0,
      status: Math.random() * 0.2,
      lexicon: new Map(),
      ruleFrequencies: new Map(),
      birth: this.time,
      death: null
    };
    this.agents.set(newAgent.id, newAgent);
  }
}

// ============================================================================
// D4: CONTEXT — The Narrative & Semantic Deep Structure Engine
// ============================================================================
// Based on: Automatic Novel Writing (MESSY) + Auto Inference of Semantic Rules

class D4_ContextEngine {
  constructor() {
    this.narrativeModels = new Map();      // MESSY meta-symbolic models
    this.semanticRules = new Map();       // Auto Inference deep structure
    this.plotTemplates = [];              // Propp/Lévi-Strauss functions
    this.characterModels = new Map();
    this.dependencyMonitor = new Map();   // Paraphrasing dependency control
  }

  // MESSY: Meta-symbolic simulation
  createNarrativeModel(name, archetype) {
    const model = {
      name,
      archetype, // 'propp', 'levi-strauss', 'murder-mystery', 'r&tc'
      functions: this.getArchetypeFunctions(archetype),
      characters: [],
      plot: [],
      constraints: []
    };
    this.narrativeModels.set(name, model);
    return model;
  }

  getArchetypeFunctions(archetype) {
    const archetypes = {
      'propp': [
        'absentation', 'interdiction', 'violation', 'reconnaissance',
        'delivery', 'trickery', 'complicity', 'villainy', 'mediation',
        'beginning_counteraction', 'departure', 'first_function_of_donor',
        'hero_reaction', 'acquisition', 'struggle', 'branding', 'victory',
        'liquidation', 'return', 'pursuit', 'rescue', 'unrecognized_arrival',
        'unfounded_claims', 'difficult_task', 'solution', 'recognition',
        'exposure', 'transfiguration', 'punishment', 'wedding'
      ],
      'murder-mystery': [
        'crime_committed', 'detective_introduced', 'suspects_presented',
        'clues_discovered', 'red_herrings', 'interrogation', 'revelation',
        'confrontation', 'resolution'
      ],
      'levi-strauss': [
        'binary_opposition', 'mediation', 'transformation', 'mythological_time'
      ]
    };
    return archetypes[archetype] || archetypes['propp'];
  }

  // Generate narrative using MESSY
  generateNarrative(modelName, styleParams = {}) {
    const model = this.narrativeModels.get(modelName);
    if (!model) return null;

    const { length = 10, complexity = 0.5, emotionalTone = 'neutral' } = styleParams;

    // Select plot functions based on archetype
    const selectedFunctions = this.selectPlotFunctions(model, length);

    // Instantiate characters
    const characters = this.instantiateCharacters(model, selectedFunctions);

    // Generate scenes with dependency monitoring
    const scenes = [];
    for (const func of selectedFunctions) {
      const scene = this.generateScene(func, characters, emotionalTone);
      scenes.push(scene);
    }

    // Ensure dependency coherence (Klein's paraphrasing monitor)
    const coherentNarrative = this.ensureDependencyCoherence(scenes);

    return {
      title: this.generateTitle(model, selectedFunctions),
      scenes: coherentNarrative,
      characters: characters.map(c => c.name),
      archetype: model.archetype,
      functions: selectedFunctions
    };
  }

  selectPlotFunctions(model, length) {
    const available = [...model.functions];
    const selected = [];

    // Ensure narrative arc: beginning, middle, end
    selected.push(available[0]); // Absentation/introduction

    // Middle functions
    for (let i = 1; i < length - 1 && i < available.length; i++) {
      if (Math.random() < 0.7) {
        selected.push(available[i]);
      }
    }

    // End function
    if (available.length > 1) {
      selected.push(available[available.length - 1]); // Resolution/wedding
    }

    return selected;
  }

  instantiateCharacters(model, functions) {
    const archetypes = {
      hero: { name: 'Hero', traits: ['brave', 'determined'] },
      villain: { name: 'Villain', traits: ['cunning', 'malicious'] },
      donor: { name: 'Helper', traits: ['wise', 'generous'] },
      princess: { name: 'Goal', traits: ['beautiful', 'passive'] },
      dispatcher: { name: 'Sender', traits: ['authoritative'] }
    };

    return Object.values(archetypes).map(c => ({
      ...c,
      motivation: this.generateMotivation(c.traits),
      currentState: 'initial'
    }));
  }

  generateMotivation(traits) {
    return `Driven by ${traits.join(' and ')}`;
  }

  generateScene(func, characters, tone) {
    const templates = {
      'absentation': '{character} leaves the familiar world.',
      'interdiction': 'A warning is given: "Do not {action}."',
      'violation': '{character} ignores the warning and {action}.',
      'villainy': '{villain} causes harm to {victim}.',
      'struggle': '{hero} battles {villain}.',
      'victory': '{hero} defeats {villain}.',
      'return': '{hero} returns home transformed.',
      'wedding': '{hero} and {princess} are united.'
    };

    const template = templates[func] || `{character} performs ${func}.`;
    return {
      function: func,
      text: this.instantiateTemplate(template, characters, tone),
      characters: characters.map(c => c.name)
    };
  }

  instantiateTemplate(template, characters, tone) {
    let text = template;
    const charMap = {};
    characters.forEach(c => {
      charMap[c.name.toLowerCase()] = c.name;
    });

    text = text.replace(/{character}/g, charMap.hero || 'Someone');
    text = text.replace(/{villain}/g, charMap.villain || 'The antagonist');
    text = text.replace(/{hero}/g, charMap.hero || 'The protagonist');
    text = text.replace(/{princess}/g, charMap.princess || 'The goal');
    text = text.replace(/{victim}/g, charMap.hero || 'The victim');
    text = text.replace(/{action}/g, 'act');

    // Apply emotional tone
    if (tone === 'dark') text = text.replace(/defeats/g, 'destroys');
    if (tone === 'comic') text = text.replace(/battles/g, 'bumbles against');

    return text;
  }

  // Klein's dependency monitoring for coherence
  ensureDependencyCoherence(scenes) {
    const dependencyTree = this.buildDependencyTree(scenes);

    return scenes.map((scene, i) => {
      const sceneDeps = this.extractDependencies(scene.text);
      const prevDeps = i > 0 ? this.extractDependencies(scenes[i-1].text) : [];

      // Check transitive consistency
      const consistent = this.checkTransitiveConsistency(sceneDeps, prevDeps, dependencyTree);

      if (!consistent) {
        // Modify scene to restore coherence
        scene.text = this.modifyForCoherence(scene.text, prevDeps);
      }

      return scene;
    });
  }

  buildDependencyTree(scenes) {
    const tree = new Map();
    scenes.forEach(scene => {
      const deps = this.extractDependencies(scene.text);
      deps.forEach(dep => {
        if (!tree.has(dep.subject)) tree.set(dep.subject, []);
        tree.get(dep.subject).push(dep.object);
      });
    });
    return tree;
  }

  extractDependencies(text) {
    // Simplified dependency extraction
    const deps = [];
    const words = text.split(/\s+/);
    for (let i = 0; i < words.length - 1; i++) {
      deps.push({ subject: words[i], relation: '→', object: words[i+1] });
    }
    return deps;
  }

  checkTransitiveConsistency(current, previous, tree) {
    // Check if current dependencies are transitive extensions of previous
    return true; // Simplified
  }

  modifyForCoherence(text, previousDeps) {
    // Ensure new text maintains dependency relations with previous
    return text; // Simplified
  }

  generateTitle(model, functions) {
    const first = functions[0] || 'The';
    const last = functions[functions.length - 1] || 'Tale';
    return `The ${first.charAt(0).toUpperCase() + first.slice(1)} and the ${last.charAt(0).toUpperCase() + last.slice(1)}`;
  }

  // Auto Inference of Semantic Deep Structure Rules
  inferSemanticRule(surfacePatterns, deepPatterns) {
    const rule = {
      surface: surfacePatterns,
      deep: deepPatterns,
      confidence: 0,
      tested: false
    };

    // Test rule on examples
    let success = 0;
    for (let i = 0; i < surfacePatterns.length; i++) {
      const inferred = this.applyDeepToSurface(deepPatterns[i]);
      if (this.matchPatterns(inferred, surfacePatterns[i])) {
        success++;
      }
    }

    rule.confidence = success / surfacePatterns.length;
    this.semanticRules.set(`rule_${Date.now()}`, rule);
    return rule;
  }

  applyDeepToSurface(deepPattern) {
    // Transform deep structure to surface structure
    return deepPattern; // Simplified
  }

  matchPatterns(a, b) {
    return a === b; // Simplified
  }
}

// ============================================================================
// D5: MEANING — The Research, Code, and Chat Integration Layer
// ============================================================================
// This is the output layer that makes the system useful

class D5_MeaningEngine {
  constructor(d1, d2, d3, d4) {
    this.d1 = d1; // Impulse
    this.d2 = d2; // Polarity
    this.d3 = d3; // Witness
    this.d4 = d4; // Context

    this.chatHistory = [];
    this.researchCache = new Map();
    this.codeRepository = new Map();
    this.knowledgeGraph = new Map();
  }

  // CHAT: Process natural language input
  async chat(input, mode = 'conversational') {
    // D1: Tokenize and analyze
    const analyzed = this.d1.analyzeMorphology(input);

    // D2: Parse and understand structure
    const parsed = this.parseInput(analyzed);

    // D3: Check social context and agent knowledge
    const context = this.d3.inferBeyondContext(input, this.getChatHistory());

    // D4: Generate appropriate response
    let response;
    switch (mode) {
      case 'research':
        response = await this.researchMode(input, parsed, context);
        break;
      case 'code':
        response = this.codeMode(input, parsed, context);
        break;
      case 'narrative':
        response = this.narrativeMode(input, parsed, context);
        break;
      case 'linguistic':
        response = this.linguisticMode(input, parsed, context);
        break;
      default:
        response = this.conversationalMode(input, parsed, context);
    }

    // Store in history
    this.chatHistory.push({ input, response, mode, timestamp: Date.now() });

    return response;
  }

  parseInput(analyzed) {
    // Build parse tree from analyzed tokens
    return {
      tokens: analyzed,
      intent: this.inferIntent(analyzed),
      entities: this.extractEntities(analyzed),
      sentiment: this.analyzeSentiment(analyzed)
    };
  }

  inferIntent(tokens) {
    const firstToken = tokens[0]?.surface.toLowerCase();
    const intents = {
      'how': 'instruction',
      'what': 'information',
      'why': 'explanation',
      'write': 'generation',
      'code': 'coding',
      'research': 'research',
      'tell': 'narrative',
      'analyze': 'linguistic'
    };
    return intents[firstToken] || 'conversational';
  }

  extractEntities(tokens) {
    return tokens.filter(t => t.features.animacy === 'animate' || t.surface.length > 5);
  }

  analyzeSentiment(tokens) {
    const positive = ['good', 'great', 'excellent', 'love', 'like'];
    const negative = ['bad', 'terrible', 'hate', 'dislike', 'awful'];

    let score = 0;
    tokens.forEach(t => {
      if (positive.includes(t.surface)) score++;
      if (negative.includes(t.surface)) score--;
    });

    return score > 0 ? 'positive' : score < 0 ? 'negative' : 'neutral';
  }

  getChatHistory() {
    return this.chatHistory.map(h => h.input).join(' ');
  }

  // RESEARCH MODE
  async researchMode(input, parsed, context) {
    // Use DISEMINER-style inference beyond context
    const query = this.extractQuery(input, parsed);
    const inference = this.d3.inferBeyondContext(query, this.getChatHistory());

    // Check cache
    if (this.researchCache.has(query)) {
      return {
        type: 'research',
        cached: true,
        answer: this.researchCache.get(query),
        inference: inference
      };
    }

    // Generate research response
    const answer = this.generateResearchAnswer(query, inference, context);
    this.researchCache.set(query, answer);

    return {
      type: 'research',
      cached: false,
      answer,
      inference,
      sources: this.inferSources(query)
    };
  }

  extractQuery(input, parsed) {
    // Remove question words, extract core query
    return input.replace(/^(how|what|why|when|where|who|which)\s+/i, '').trim();
  }

  generateResearchAnswer(query, inference, context) {
    // Use DISEMINER transitive paths to generate answer
    const paths = inference.paths || [];

    if (paths.length > 0) {
      return `Based on distributional analysis: ${inference.answer}\n\n` +
             `Inference confidence: ${(inference.confidence * 100).toFixed(1)}%\n` +
             `Transitive paths found: ${paths.length}`;
    }

    return `Researching: ${query}\n` +
           `No direct inference available. Would you like me to simulate language contact ` +
           `to explore this concept?`;
  }

  inferSources(query) {
    // Return relevant Klein papers based on query
    const sources = [];
    if (query.includes('grammar')) sources.push('Klein 1968 - AUTOLING');
    if (query.includes('contact')) sources.push('Klein 1974 - Language Contact Models');
    if (query.includes('semantic')) sources.push('Klein 1973 - Auto Inference of Semantic Rules');
    if (query.includes('style')) sources.push('Klein 1965 - Control of Style');
    if (query.includes('narrative')) sources.push('Klein 1973 - Automatic Novel Writing');
    if (query.includes('distributional')) sources.push('Klein 1968 - DISEMINER');
    return sources;
  }

  // CODE MODE
  codeMode(input, parsed, context) {
    const intent = this.inferCodeIntent(parsed);

    switch (intent) {
      case 'generate':
        return this.generateCode(input, parsed);
      case 'explain':
        return this.explainCode(input, parsed);
      case 'transform':
        return this.transformCode(input, parsed);
      case 'test':
        return this.testCode(input, parsed);
      default:
        return this.generateCode(input, parsed);
    }
  }

  inferCodeIntent(parsed) {
    const text = parsed.tokens.map(t => t.surface).join(' ').toLowerCase();
    if (text.includes('write') || text.includes('create') || text.includes('generate')) return 'generate';
    if (text.includes('explain') || text.includes('how does')) return 'explain';
    if (text.includes('convert') || text.includes('transform') || text.includes('refactor')) return 'transform';
    if (text.includes('test') || text.includes('debug')) return 'test';
    return 'generate';
  }

  generateCode(input, parsed) {
    // Use AUTOLING grammar generation + Control of Style
    const language = this.detectLanguage(parsed) || 'javascript';
    const complexity = this.inferComplexity(parsed);

    // Generate using grammar rules
    const codeStructure = this.d2.generateSentence('PROGRAM', {
      complexity: complexity / 10,
      formality: 0.8,
      creativity: 0.2
    });

    // Convert grammar output to actual code
    const code = this.grammarToCode(codeStructure, language);

    this.codeRepository.set(`code_${Date.now()}`, { code, language, input });

    return {
      type: 'code',
      language,
      code,
      explanation: this.explainGeneratedCode(code, language),
      complexity
    };
  }

  detectLanguage(parsed) {
    const text = parsed.tokens.map(t => t.surface).join(' ').toLowerCase();
    const languages = {
      'python': ['python', 'py'],
      'javascript': ['javascript', 'js', 'node'],
      'typescript': ['typescript', 'ts'],
      'rust': ['rust', 'rs'],
      'go': ['go', 'golang'],
      'c': ['c ', 'c++', 'cpp'],
      'java': ['java'],
      'ruby': ['ruby', 'rb']
    };

    for (const [lang, keywords] of Object.entries(languages)) {
      if (keywords.some(k => text.includes(k))) return lang;
    }
    return null;
  }

  inferComplexity(parsed) {
    const text = parsed.tokens.map(t => t.surface).join(' ').toLowerCase();
    if (text.includes('simple') || text.includes('basic')) return 3;
    if (text.includes('complex') || text.includes('advanced')) return 8;
    return 5;
  }

  grammarToCode(structure, language) {
    // Convert grammar-generated structure to actual code
    const templates = {
      javascript: {
        function: (name, body) => `function ${name}() {\n  ${body}\n}`,
        class: (name, methods) => `class ${name} {\n${methods}}`,
        loop: (varName, body) => `for (let ${varName} = 0; ${varName} < 10; ${varName}++) {\n  ${body}\n}`
      },
      python: {
        function: (name, body) => `def ${name}():\n    ${body}`,
        class: (name, methods) => `class ${name}:\n${methods}`,
        loop: (varName, body) => `for ${varName} in range(10):\n    ${body}`
      }
    };

    const lang = templates[language] || templates.javascript;
    return lang.function('generated', 'return "Hello from Klein Engine";');
  }

  explainGeneratedCode(code, language) {
    return `Generated ${language} code using Klein's Control of Style grammar with frequency-weighted rule selection.`;
  }

  explainCode(input, parsed) {
    return { type: 'explanation', text: 'Code explanation would go here...' };
  }

  transformCode(input, parsed) {
    return { type: 'transformation', text: 'Code transformation would go here...' };
  }

  testCode(input, parsed) {
    return { type: 'test', text: 'Code testing would go here...' };
  }

  // NARRATIVE MODE
  narrativeMode(input, parsed, context) {
    const model = this.d4.createNarrativeModel('current', 'propp');
    const narrative = this.d4.generateNarrative('current', {
      length: 10,
      complexity: 0.6,
      emotionalTone: parsed.sentiment
    });

    return {
      type: 'narrative',
      title: narrative.title,
      scenes: narrative.scenes.map(s => s.text),
      characters: narrative.characters,
      archetype: narrative.archetype,
      functions: narrative.functions
    };
  }

  // LINGUISTIC MODE
  linguisticMode(input, parsed, context) {
    // Full linguistic analysis
    return {
      type: 'linguistic',
      morphology: parsed.tokens.map(t => ({
        token: t.surface,
        stem: t.stem,
        gloss: t.gloss,
        features: t.features
      })),
      grammar: this.d2.grammar,
      dependencies: this.extractDependencyGraph(parsed),
      inferences: this.d3.inferBeyondContext(input, this.getChatHistory())
    };
  }

  extractDependencyGraph(parsed) {
    const deps = [];
    const tokens = parsed.tokens;
    for (let i = 0; i < tokens.length - 1; i++) {
      deps.push({
        from: tokens[i].stem,
        to: tokens[i + 1].stem,
        relation: 'sequential'
      });
    }
    return deps;
  }

  // CONVERSATIONAL MODE
  conversationalMode(input, parsed, context) {
    // Generate natural response using all dimensions
    const response = this.generateConversationalResponse(input, parsed, context);

    return {
      type: 'conversation',
      text: response,
      context: {
        intent: parsed.intent,
        sentiment: parsed.sentiment,
        entities: parsed.entities.map(e => e.surface)
      }
    };
  }

  generateConversationalResponse(input, parsed, context) {
    const responses = {
      'instruction': `Here's how you can approach that: ${context.answer || 'Let me think about this...'}`,
      'information': `Based on my analysis: ${context.answer || 'I need to research this further.'}`,
      'explanation': `The reason is: ${context.answer || 'This requires deeper investigation.'}`,
      'generation': `I've generated something for you: ${context.answer || 'Working on it...'}`,
      'conversational': `Interesting! ${context.answer || 'Tell me more about that.'}`
    };

    return responses[parsed.intent] || responses['conversational'];
  }
}

// ============================================================================
// THE UNIFIED ENGINE
// ============================================================================

class KleinLanguageContactNeuralEngine {
  constructor() {
    this.d1 = new D1_ImpulseEngine();
    this.d2 = new D2_PolarityEngine();
    this.d3 = new D3_WitnessEngine(100, 3);
    this.d4 = new D4_ContextEngine();
    this.d5 = new D5_MeaningEngine(this.d1, this.d2, this.d3, this.d4);

    this.initialized = false;
  }

  initialize() {
    // Initialize with Klein's example grammars
    this.d2.addRule('S → NP VP', 'phrase');
    this.d2.addRule('NP → D N', 'phrase');
    this.d2.addRule('NP → N', 'phrase');
    this.d2.addRule('VP → V NP', 'phrase');
    this.d2.addRule('VP → V', 'phrase');
    this.d2.addRule('D → the | a', 'class');
    this.d2.addRule('N → man | woman | dog | cat | book | idea', 'class');
    this.d2.addRule('V → sees | eats | reads | loves | creates', 'class');

    this.initialized = true;
    console.log('✓ Klein Language Contact Neural Engine initialized');
    console.log('✓ D1 Impulse: Morphological analysis + DISEMINER stems');
    console.log('✓ D2 Polarity: Grammar learning + Control of Style');
    console.log('✓ D3 Witness: Language contact simulation + Inference');
    console.log('✓ D4 Context: MESSY narrative + Semantic deep structure');
    console.log('✓ D5 Meaning: Chat + Research + Code generation');
  }

  async process(input, mode = 'conversational') {
    if (!this.initialized) this.initialize();
    return await this.d5.chat(input, mode);
  }

  // Run language contact simulation
  simulateContact(steps = 100) {
    console.log(`\nRunning Klein Language Contact Simulation (${steps} steps)...`);
    for (let i = 0; i < steps; i++) {
      this.d3.step();
    }

    const stats = this.getSimulationStats();
    console.log('Simulation complete!');
    console.log(`- Time elapsed: ${this.d3.time} units`);
    console.log(`- Active agents: ${this.d3.agents.size}`);
    console.log(`- Contact events: ${this.d3.contactHistory.length}`);
    console.log(`- Average prestige: ${stats.avgPrestige.toFixed(3)}`);
    console.log(`- Grammar convergence: ${stats.grammarConvergence.toFixed(3)}`);

    return stats;
  }

  getSimulationStats() {
    let totalPrestige = 0;
    let totalRules = 0;
    let ruleOverlap = 0;

    for (const [id, agent] of this.d3.agents) {
      totalPrestige += agent.prestige;
      totalRules += agent.grammar.phraseRules.size;
    }

    const avgPrestige = totalPrestige / this.d3.agents.size;
    const avgRules = totalRules / this.d3.agents.size;

    // Calculate grammar convergence
    const allRules = new Set();
    for (const [id, agent] of this.d3.agents) {
      for (const rule of agent.grammar.phraseRules.keys()) {
        allRules.add(rule);
      }
    }

    const sharedRules = new Set();
    for (const rule of allRules) {
      let count = 0;
      for (const [id, agent] of this.d3.agents) {
        if (agent.grammar.phraseRules.has(rule)) count++;
      }
      if (count > this.d3.agents.size * 0.5) {
        sharedRules.add(rule);
      }
    }

    const grammarConvergence = sharedRules.size / allRules.size;

    return { avgPrestige, avgRules, grammarConvergence, totalRules: allRules.size };
  }

  // Generate narrative
  generateStory(archetype = 'propp', length = 10) {
    this.d4.createNarrativeModel('story', archetype);
    return this.d4.generateNarrative('story', { length, complexity: 0.6 });
  }

  // Research query
  async research(query) {
    return await this.d5.chat(query, 'research');
  }

  // Code generation
  generateCode(description, language = 'javascript') {
    return this.d5.chat(`Write ${language} code: ${description}`, 'code');
  }
}

// ============================================================================
// EXPORT
// ============================================================================

module.exports = {
  KleinLanguageContactNeuralEngine,
  D1_ImpulseEngine,
  D2_PolarityEngine,
  D3_WitnessEngine,
  D4_ContextEngine,
  D5_MeaningEngine
};
