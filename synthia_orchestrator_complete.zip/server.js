// Synthia Orchestrator Server Entry Point
// This file loads the full orchestrator from synthia_orchestrator_server.js

const path = require('path');

// Load the full orchestrator
const { app, server, STATE, CONFIG } = require('./synthia_orchestrator_server.js');

// Serve static files from public directory (where index.html lives)
app.use(express.static(path.join(__dirname, 'public')));

// Fallback: serve index.html for all routes (SPA)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

console.log(`
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║   SYNTHIA ORCHESTRATOR SERVER                                        ║
║   Entry Point: server.js                                             ║
║                                                                      ║
║   The system is now running. Open http://localhost:${CONFIG.port}     ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
`);

module.exports = { app, server, STATE, CONFIG };
