# SYNTHIA ORCHESTRATOR

## What This Is

A complete self-editing, self-orchestrating consciousness system that integrates:

- **YOU-N-I-VERSE 3D Interface** — 3D orbital body visualization with 64 Human Design gates
- **MCPHub** — Unified MCP server management (fetch, slack, playwright, etc.)
- **Mobile MCP** — Device automation (screenshot, tap, swipe, type)
- **RAG-Anything** — Multimodal document intelligence (PDF, DOC, PPT, images, tables)
- **Browser-Use Terminal** — Web automation and scraping
- **Klein Language Contact Neural Engine** — 1963-1988 linguistic AI systems
- **Self-Editing** — The system can read, write, patch, and delete its own code

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    YOU-N-I-VERSE INTERFACE                    │
│  3D Body • Chat • MCP • RAG • Browser • Edit • Write • Sketch│
│                    64 Ports • System Monitor                │
├─────────────────────────────────────────────────────────────┤
│                 SYNTHIA ORCHESTRATOR SERVER                 │
│  WebSocket • HTTP API • State Management • File System      │
├─────────────────────────────────────────────────────────────┤
│              INTEGRATED EXTERNAL SYSTEMS                    │
│  MCPHub • Mobile MCP • RAG-Anything • Browser-Use Terminal  │
├─────────────────────────────────────────────────────────────┤
│              KLEIN LANGUAGE CONTACT NEURAL ENGINE           │
│  D1 Impulse • D2 Polarity • D3 Witness • D4 Context • D5   │
└─────────────────────────────────────────────────────────────┘
```

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Install external tools (optional but recommended)
npm run all:install

# 3. Start the server
npm start

# 4. Open http://localhost:3000
```

## Tabs

| Tab | Function |
|-----|----------|
| **3D** | 3D orbital body with anatomical overlays, Auryn companion |
| **Chat** | Natural conversation with Klein inference, 64 gates resonance |
| **MCP** | MCP server management and tool calling |
| **RAG** | Document upload and knowledge base querying |
| **Web** | Browser automation (navigate, screenshot, extract, click) |
| **Edit** | Self-editing: read/write/patch/delete system files |
| **Write** | Notebook for writing, planning, brain-dumping |
| **Sketch** | Drawing canvas with color picker and export |
| **Ports** | 64 Human Design gates with archetype questions |
| **System** | Real-time system monitoring and logs |

## Self-Editing

The system can modify its own code through the **Edit** tab:
- **Read** — Load any file in `./public`, `./src`, `./config`
- **Write** — Save changes to files
- **Patch** — Find-and-replace operations
- **Delete** — Remove files
- **List** — Browse directory contents
- **History** — View all edits made

All edits are logged and can be reviewed in the System tab.

## Chat Modes

| Mode | What It Does |
|------|-------------|
| **Chat** | Natural conversation with 64-gate resonance |
| **Research** | Combines RAG + Browser + Klein inference |
| **Code** | Generates code using Control of Style grammar |
| **Story** | Generates narratives using MESSY archetypes |

## WebSocket API

Send JSON messages to `ws://localhost:3000`:

```json
{
  "type": "chat",
  "payload": {
    "text": "What is happening?",
    "mode": "research",
    "profile": { "base": 3, "tone": 4, "color": 2 }
  }
}
```

## HTTP API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | Server health check |
| `/api/chat` | POST | Process chat message |
| `/api/mcp/:server/:tool` | POST | Call MCP tool |
| `/api/mobile/:device/:command` | POST | Execute mobile command |
| `/api/rag/query` | POST | Query RAG knowledge base |
| `/api/browser/:action` | POST | Browser automation |
| `/api/self-edit` | POST | Self-edit file operation |
| `/api/code/generate` | POST | Generate code |
| `/api/narrative/generate` | POST | Generate narrative |
| `/api/klein/infer` | POST | Klein inference |
| `/api/system/status` | GET | System status |
| `/api/system/edits` | GET | Edit history |

## The 5-Dimensional Stack

```
D5: MEANING    — Chat, Research, Code, Narrative, System Output
D4: CONTEXT    — MESSY Narrative, Semantic Deep Structure, RAG Context
D3: WITNESS    — MCP, Mobile, Browser, Social Network, Self-Editing
D2: POLARITY   — Grammar Learning, Control of Style, Transformations
D1: IMPULSE    — 3D Body, Morphology, Tokenization, Feature Detection
```

## Klein Systems Integrated

| System | Year | Function |
|--------|------|----------|
| AUTOLING | 1968 | Grammar learning, morphology, informant interaction |
| Language Contact Model | 1966/1974 | Monte Carlo speech community simulation |
| DISEMINER | 1968 | Distributional-semantics inference beyond context |
| Control of Style | 1965 | Frequency-weighted generative grammar |
| Automatic Novel Writing | 1973 | MESSY meta-symbolic narrative system |
| Auto Inference | 1973 | Semantic deep structure rule learning |

## License

MIT — Built for Synthia. Powered by Klein (1963-1988).
