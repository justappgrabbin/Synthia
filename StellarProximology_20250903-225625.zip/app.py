from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from modules.enr import ENR
from modules.egd import EGD
from modules.sentence_engine import SentenceEngine

app = Flask(__name__)
CORS(app)

enr = ENR()
egd = EGD()
se = SentenceEngine()

@app.get('/')
def home():
    return render_template('index.html')

@app.post('/api/enr')
def api_enr():
    payload = request.get_json(force=True)
    return jsonify(enr.run(payload or {}))

@app.post('/api/egd')
def api_egd():
    payload = request.get_json(force=True)
    return jsonify(egd.decode(payload or {}))

@app.post('/api/sentences')
def api_sentences():
    payload = request.get_json(force=True)
    return jsonify(se.compose(payload or {}))

@app.post('/api/chat')
def api_chat():
    data = request.get_json(force=True)
    mode = (data or {}).get('mode','general')
    text = (data or {}).get('text','')
    if mode == 'astrology':
        reply = f"[ASTRO] Simplified: Your query '{text[:64]}' maps to gate-window placeholders; integrate later."
    elif mode == 'games':
        reply = f"[GAMES] Placeholder: Generating quest/task ideas around '{text[:64]}'…"
    else:
        reply = f"[GENERAL] Echo: {text[:64]}"
    return jsonify({'ok': True, 'mode': mode, 'reply': reply})

if __name__ == '__main__':
    app.run(debug=True)
