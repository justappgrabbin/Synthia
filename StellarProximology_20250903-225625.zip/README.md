# Stellar Proximology — Lab Stack (Flask)

A lightweight Flask stack for the Stellar Proximology Lab with endpoints for:
- **ENR** (Electromagnetic Node Recalibrator)
- **EGD** (Energetic Gene Decoder)
- **Sentence Engine** (Resonance Sentence generator, stub)
- **/api/chat** (mode router: 'astrology', 'games' stubs)

Designed for **Termux** and **Replit**. Zero heavy dependencies.

## Quick Start
```bash
pip install -r requirements.txt
python app.py
# open http://127.0.0.1:5000
```

## Files
- `app.py` — Flask app & API routes
- `modules/enr.py` — ENR logic (diag + protocol)
- `modules/egd.py` — Codon ↔ Gate mapping + modulation stub
- `modules/sentence_engine.py` — Resonance Sentence combiner
- `modules/codon_table.json` — **placeholder** structure (fill with your 64-map table later)
- `templates/index.html` — tiny UI to hit endpoints
- `static/js/main.js` — fetch helpers
- `lab_prompts/*.md` — System prompts for your MTG/ENR/EGD modules

## Notes
- The provided `codon_table.json` is a stub schema to drop your full mapping into.
- Endpoints return JSON; expand freely.
