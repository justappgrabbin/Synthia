# ENR — Electromagnetic Node Recalibrator (lightweight)
from dataclasses import dataclass

@dataclass
class ENRConfig:
    phase_thresh: float = 0.8
    drop_thresh: float = 0.7
    incoh_thresh: float = 0.6

class ENR:
    def __init__(self, cfg: ENRConfig|None=None):
        self.cfg = cfg or ENRConfig()

    def run(self, data: dict) -> dict:
        # Pull inputs with defaults
        mind  = float(data.get('mind_freq', 8.0))
        body  = float(data.get('body_freq', 8.0))
        heart = float(data.get('heart_freq',8.0))
        gate  = str(data.get('planetary_gate',"15.4.3.2.1"))
        bio   = data.get('biometrics',{})

        # Analyze simple diffs
        diffs = {
            'mind_body': abs(mind-body),
            'mind_heart': abs(mind-heart),
            'body_heart': abs(body-heart)
        }
        max_pair = max(diffs, key=diffs.get)
        severity = round(max(diffs.values()), 3)

        # Classify distortion type
        if severity > self.cfg.phase_thresh:
            dtype = 'phase_lag'
        elif severity > self.cfg.drop_thresh:
            dtype = 'frequency_drop'
        elif severity > self.cfg.incoh_thresh:
            dtype = 'incoherence'
        else:
            dtype = 'nominal'

        protocol = self._protocol(dtype, gate, bio)
        return {
            'ok': True,
            'planetary_gate': gate,
            'freqs': {'mind':mind,'body':body,'heart':heart},
            'diffs': diffs,
            'dominant_pair': max_pair,
            'severity': severity,
            'distortion': dtype,
            'protocol': protocol
        }

    def _protocol(self, dtype: str, gate: str, bio: dict) -> dict:
        base = {
            'phase_lag':   ['Box breath 4-4-4-4 x 3', 'Left–right sway 60s', 'Hum @ ~128Hz 90s'],
            'frequency_drop':['3 min coherent inhale:exhale 5:5', 'Sit upright 2cm lift', 'Light stretch: neck/shoulders'],
            'incoherence': ['Single-point focus on breath 120s', 'Eyes-closed EMF scan 60s', 'Hand over chest 60s'],
            'nominal':     ['Maintain posture', 'Soft breath', '10s gratitude pulse']
        }[dtype]
        return {'gate': gate, 'steps': base, 'bio_hint': bio}
