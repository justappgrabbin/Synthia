# Sentence Engine (stub): combine Mind/Body/Heart gate+line into a resonance phrase
class SentenceEngine:
    def compose(self, data: dict) -> dict:
        mind  = data.get('mind',  {'gate':64,'line':3})
        body  = data.get('body',  {'gate':9, 'line':1})
        heart = data.get('heart', {'gate':15,'line':4})

        s = (f"Mind {mind['gate']}.{mind['line']} stabilizes perception; "
             f"Body {body['gate']}.{body['line']} focuses the channel; "
             f"Heart {heart['gate']}.{heart['line']} widens coherence.")

        return {'ok': True, 'sentence': s, 'parts': {'mind':mind,'body':body,'heart':heart}}
