# EGD — Energetic Gene Decoder (skeleton)
import json, os

class EGD:
    def __init__(self):
        here = os.path.dirname(__file__)
        with open(os.path.join(here, 'codon_table.json'), 'r', encoding='utf-8') as f:
            self.table = json.load(f)

    def decode(self, data: dict) -> dict:
        codon = (data or {}).get('codon', 'AUG').upper()
        gate  = (data or {}).get('gate', 41)
        line  = (data or {}).get('line', 1)
        transit = (data or {}).get('transit', {})

        codon_info = self.table.get(codon, {})
        aa = codon_info.get('amino_acid','?')
        chem = codon_info.get('chemical','?')
        element = codon_info.get('element','?')

        # Very light modulation heuristic
        activated = False
        if str(transit.get('gate')) == str(gate) and str(transit.get('line')) == str(line):
            activated = True

        note = f"Codon {codon} → Gate {gate}.{line} :: {aa} [{chem}] :: Element {element}"
        if activated:
            note += " — transit resonance detected: upregulate"
        else:
            note += " — no direct resonance"

        return {
            'ok': True,
            'codon': codon,
            'gate': gate,
            'line': line,
            'amino_acid': aa,
            'chemical': chem,
            'element': element,
            'activated': activated,
            'note': note
        }
