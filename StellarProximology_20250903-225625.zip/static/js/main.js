async function sendChat(){
  const mode = document.getElementById('mode').value;
  const text = document.getElementById('chatText').value;
  const r = await fetch('/api/chat', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({mode, text})});
  const j = await r.json();
  document.getElementById('chatOut').textContent = JSON.stringify(j, null, 2);
}

async function demoENR(){
  const payload = {
    mind_freq: 8.2, body_freq: 7.6, heart_freq: 8.9,
    planetary_gate: "15.4.3.2.1",
    biometrics: { HRV: 72, EEG: 12.1, posture: "slouch", EMF: 0.5 }
  };
  const r = await fetch('/api/enr', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
  const j = await r.json();
  document.getElementById('enrOut').textContent = JSON.stringify(j, null, 2);
}

async function demoEGD(){
  const payload = { codon: "AUG", gate: 41, line: 2, transit: { planet: "Jupiter", gate: 41, line: 2 } };
  const r = await fetch('/api/egd', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
  const j = await r.json();
  document.getElementById('egdOut').textContent = JSON.stringify(j, null, 2);
}

async function demoSentence(){
  const payload = { mind:{gate:64,line:3}, body:{gate:9,line:1}, heart:{gate:15,line:4} };
  const r = await fetch('/api/sentences', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
  const j = await r.json();
  document.getElementById('sentOut').textContent = JSON.stringify(j, null, 2);
}
