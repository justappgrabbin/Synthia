# Resonance Codon Layer (Starter)

Minimal lookup + encode/decode for Gate.Line.Tone.Color.Base signatures.
Extend this CSV with your full mapping. Use `codon.py` to encode/decode and query rows.