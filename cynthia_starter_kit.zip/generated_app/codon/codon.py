import csv
from pathlib import Path
from typing import Dict, Any

DATA = Path("generated_app/codon/resonance_codon.csv")

def load_codon_table():
    with DATA.open() as f:
        r = csv.DictReader(f)
        return list(r)

def encode_signature(gate:int, line:int, tone:int, color:int, base:int) -> str:
    return f"G{gate}-{line}-{tone}-{color}-{base}"

def decode_signature(code:str) -> Dict[str, Any]:
    _, rest = code.split("G",1)
    gate, line, tone, color, base = rest.split("-")
    return {
        "gate": int(gate),
        "line": int(line),
        "tone": int(tone),
        "color": int(color),
        "base": int(base),
    }

if __name__ == "__main__":
    table = load_codon_table()
    print("Loaded codon rows:", len(table))
    ex = encode_signature(10,3,4,2,1)
    print("Example encode:", ex, "→", decode_signature(ex))