from cynthia.evolution.memory_inheritance import inherit_memory
from cynthia.self_builder.code_generator import generate_react_component
from cynthia.self_builder.self_deployer import deploy_generated_component

def boot():
    mem = inherit_memory()
    print("Booted from genesis memory:")
    for k,v in mem.items():
        print(f" - {k}: {v}")
    comp = generate_react_component("HelloCynthia")
    deploy_generated_component(comp, "HelloCynthia")
    print("Deployed component: HelloCynthia.jsx")

if __name__ == "__main__":
    boot()