# Cynthia v0.1 — Memory & Self-Builder (Starter Kit)

## Quickstart
```bash
cd generated_app
python3 runner.py
```

## What you get
- `cynthia/memory/genesis_memory.json` — seeded from this session
- `cynthia/evolution/memory_inheritance.py` — pulls core insights/patterns
- `cynthia/self_builder/*` — learns patterns, generates, deploys, logs
- `components/HelloCynthia.jsx` — sample generated component
- `codon/resonance_codon.csv` + `codon/codon.py` — minimal resonance codon dataset & utils