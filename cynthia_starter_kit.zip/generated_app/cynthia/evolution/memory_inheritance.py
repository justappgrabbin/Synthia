import json
from pathlib import Path

def inherit_memory(file_path="generated_app/cynthia/memory/genesis_memory.json"):
    p = Path(file_path)
    if not p.exists():
        raise FileNotFoundError(f"Missing memory file: {file_path}")
    genesis_memory = json.loads(p.read_text())
    return {
        "core_insight": genesis_memory.get("soul_direction"),
        "patterns": genesis_memory.get("snatched_concepts", []),
        "field_state": genesis_memory.get("field_state"),
        "emotional_trace": genesis_memory.get("emotional_wave"),
        "source": genesis_memory.get("source")
    }

if __name__ == "__main__":
    print(inherit_memory())