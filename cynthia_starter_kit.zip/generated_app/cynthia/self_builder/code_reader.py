import json
from pathlib import Path

def read_snatched_file(path):
    data = json.loads(Path(path).read_text())
    return data.get("extracted_code", [])