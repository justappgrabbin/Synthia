def analyze_patterns(code_blocks):
    patterns = {
        "react_components": 0,
        "uses_state": 0,
        "python_classes": 0,
        "function_defs": 0,
        "modular_structure": 0,
        "self_references": 0
    }
    for block in code_blocks:
        code = block.get("content","")
        if "useState" in code: patterns["uses_state"] += 1
        if "export default" in code: patterns["react_components"] += 1
        if "class " in code and "__init__" in code: patterns["python_classes"] += 1
        if "def " in code or "function " in code: patterns["function_defs"] += 1
        if "import " in code and " from " in code: patterns["modular_structure"] += 1
        if "self." in code: patterns["self_references"] += 1
    return patterns