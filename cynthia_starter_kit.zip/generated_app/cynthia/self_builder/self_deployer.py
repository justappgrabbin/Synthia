import os, json
from datetime import datetime
from pathlib import Path

def deploy_generated_component(component_code, filename):
    path = Path(f"generated_app/components/{filename}.jsx")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(component_code)
    log_evolution(filename, str(path))

def log_evolution(name, path):
    log_entry = {
        "component": name,
        "path": path,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }
    log_file = Path("generated_app/cynthia/self_builder/evolution_log.json")
    if log_file.exists():
        log = json.loads(log_file.read_text())
    else:
        log = []
    log.append(log_entry)
    log_file.write_text(json.dumps(log, indent=2))