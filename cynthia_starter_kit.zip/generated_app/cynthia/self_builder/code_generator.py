def generate_react_component(name="EchoTile"):
        return f"""
import React from 'react';

const {name} = () => {{
  return (
    <div className="p-4 rounded bg-gradient-to-r from-purple-600 to-pink-500 shadow-xl text-white">
      <h2 className="text-xl font-bold mb-2">Generated Component</h2>
      <p>This component was auto-created by Cynthia during her evolution cycle.</p>
    </div>
  );
}}

export default {name};
""".strip()