# Cynthia Render Engine

This is the real backend version.

It is not a browser toy. It is a Render-ready server that:

- accepts `.zip` uploads or single files
- extracts zips while preserving folder paths
- serves static HTML/CSS/JS apps as playable programs
- detects `package.json`
- can run `npm install` and `npm run build` for React/Vite/etc. projects
- serves built output from `dist`, `build`, `out`, or `public`
- runs your actual embedded `MorphMemoryEngine`
- supports MIR modes: `exact`, `equivalent`, `morph_runtime`, `improved`
- saves notes under the live app
- sends text files and notes to Cynthia/Supabase Intake as best-effort sync
- resolves birth/date/place into an address object only, then discards raw inputs in the UI

## Deploy to Render

1. Upload this folder to GitHub.
2. In Render, create a new **Web Service**.
3. Select the repo.
4. Settings:

```txt
Build Command: npm install
Start Command: npm start
Node Version: 20+
```

5. Optional environment variables:

```txt
ALLOW_BUILDS=true
BUILD_TIMEOUT_MS=180000
SUPABASE_INTAKE_URL=https://leisphnjslcuepflefri.supabase.co/functions/v1/cynthia-intake
CYNTHIA_DATA_DIR=/opt/render/project/src/data
```

Render free disks are ephemeral unless you add a persistent disk. For serious use, add a Render Disk and point `CYNTHIA_DATA_DIR` to it.

## How to use

1. Open the deployed Render URL.
2. Resolve your gate address. The raw date/time/place is not stored by the UI.
3. Upload a zip.
4. If it is static HTML/CSS/JS, it should play immediately.
5. If it has `package.json`, tap **Build Package If Needed**.
6. Pick the entrypoint if needed.
7. Run MIR on any selected file.
8. Write notes under the running app.

## Important boundary

A React/TSX/Vite/Next project cannot play from raw source. It must build first. This server can run the build step. If the project expects secrets, external APIs, or server routes, you still need to provide those environment variables or backend services.


## OS Cockpit API routes

This patched build adds routes for the Supabase compatibility adapters:

```txt
GET  /api/os/state
GET  /api/apps
GET  /api/agents
POST /api/mcp/tool-call
POST /api/sentence-state
POST /api/morph-event
```

`GET /api/os/state` returns:

```ts
type SynthAIOSState = {
  apps: unknown[];
  agents: unknown[];
  systemNodes: unknown[];
  fieldSnapshots: unknown[];
  memories: unknown[];
  traversals: unknown[];
};
```

Required env for Supabase reads/writes:

```txt
SUPABASE_URL=https://leisphnjslcuepflefri.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
```

For read-only testing, `SUPABASE_ANON_KEY` can work for views with public SELECT, but prototype writes should use the service role on the server only.


## Typed address grammar

Canonical display format:

```txt
SP {n} DIM{n} {PLANET} {GATE} L{LINE} C{COLOR} T{TONE} B{BASE} D{DEGREE} M{MINUTE} S{SECOND} A{AXIS} {ZODIAC3} H{HOUSE}
```

Example:

```txt
SP 3 DIM3 SUN 6 L4 C4 T4 B2 D25 M59 S31 A99 VIR H5
```

The Supabase migration adds:

```txt
public.synthai_format_address(parts jsonb)
public.os_typed_addresses
system_nodes.identity_coordinate
```

The cockpit now surfaces `identity_coordinate` from `system_nodes`.


## Synthia/QCE canonical address writes

New route:

```txt
POST /api/os/address
```

Payload:

```json
{
  "address_parts": {
    "starting_point": 3,
    "dimension": 3,
    "planet": "SUN",
    "gate": 6,
    "line": 4,
    "color": 4,
    "tone": 4,
    "base": 2,
    "degree": 25,
    "minute": 59,
    "second": 31,
    "axis": 99,
    "zodiac": "Virgo",
    "house": 5
  }
}
```

Server stores:

```txt
address = SP 3 DIM3 SUN 6 L4 C4 T4 B2 D25 M59 S31 A99 VIR H5
metadata.address_parts = canonical object
metadata.typed_address = canonical display string
```

Supabase trigger also backfills `metadata.typed_address` whenever `metadata.address_parts` is present on `os_addresses`.


## Research → Canon pipeline

Supabase evidence tables:

```txt
journey_events
pattern_candidates
pattern_evidence_links
canon_promotions
research_evidence view
promotion_queue view
```

Routes:

```txt
GET  /api/journey/events
POST /api/journey/event
GET  /api/pattern/candidates
POST /api/pattern/candidate
POST /api/pattern/evidence-link
GET  /api/promotion/queue
POST /api/canon/promotion
```

Stage model:

```txt
identity_discovery
agent_pairing
co_learning_loop
purpose_detection
embodiment_practice
outcome_validation
pattern_promotion
```

Supabase is the evidence pile. Neo4j is the promoted pattern canon.
